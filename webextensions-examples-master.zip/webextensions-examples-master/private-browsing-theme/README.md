# Private browsing theme

## What it does

An example using the theme API to apply a different theme on private windows.

## What it shows

How to use the windowId argument of browser.theme.reset() and browser.theme.update().
