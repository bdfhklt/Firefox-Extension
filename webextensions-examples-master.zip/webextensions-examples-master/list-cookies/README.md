# list-cookies

## What it does

This extensions list the cookies in the active tab.

# What it shows

Demonstration of the getAll() function in the cookie API
