# Window manipulator

## What it does

This extension includes a browser action with a popup specified as "window.html".

The popup lets the user perform various simple operations using the windows API.

# What it shows

Demonstration of various windows API functions.
