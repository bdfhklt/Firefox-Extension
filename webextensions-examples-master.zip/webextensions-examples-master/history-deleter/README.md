# History deleter

## What it does

This extension includes a page action with a popup specified as "history.html". The page action will not appear on about:... pages.

The popup shows a list of 5 history entries for the current domain. It provides a clear button to delete all entries for that domain.

## What it shows

How to use the history API.
