# Forget it!

This add-on adds a button to the browser's toolbar. When the user clicks the button, the add-on clears some browsing data using the browsingData API. The details of what exactly it clears are determined by the add-on's settings, which can be accessed and modified in its options page.

The example shows how to use the browsingData API, and how to use the options page to handle settings.
