# Themes: Animated

## What it does

Employs two PNG images to create a mirror effect with the theme images.

## What it shows

How to use "additional_backgrounds": in conjunction with "additional_backgrounds_alignment": to place multiple images within the browser header.
