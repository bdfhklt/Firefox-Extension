'use strict';
var h, aa = function(a) {
        var b = 0;
        return function() {
            return b < a.length ? {
                done: !1,
                value: a[b++]
            } : {
                done: !0
            }
        }
    },
    ba = function(a) {
        var b = "undefined" != typeof Symbol && Symbol.iterator && a[Symbol.iterator];
        return b ? b.call(a) : {
            next: aa(a)
        }
    },
    ca = function(a) {
        for (var b, c = []; !(b = a.next()).done;) c.push(b.value);
        return c
    },
    da = "function" == typeof Object.create ? Object.create : function(a) {
        var b = function() {};
        b.prototype = a;
        return new b
    },
    ea;
if ("function" == typeof Object.setPrototypeOf) ea = Object.setPrototypeOf;
else {
    var fa;
    a: {
        var ha = {
                ck: !0
            },
            ia = {};
        try {
            ia.__proto__ = ha;
            fa = ia.ck;
            break a
        } catch (a) {}
        fa = !1
    }
    ea = fa ? function(a, b) {
        a.__proto__ = b;
        if (a.__proto__ !== b) throw new TypeError(a + " is not extensible");
        return a
    } : null
}
var ja = ea,
    ka = function(a, b) {
        a.prototype = da(b.prototype);
        a.prototype.constructor = a;
        if (ja) ja(a, b);
        else
            for (var c in b)
                if ("prototype" != c)
                    if (Object.defineProperties) {
                        var d = Object.getOwnPropertyDescriptor(b, c);
                        d && Object.defineProperty(a, c, d)
                    } else a[c] = b[c];
        a.D = b.prototype
    },
    la = function(a, b, c) {
        a instanceof String && (a = String(a));
        for (var d = a.length, e = 0; e < d; e++) {
            var f = a[e];
            if (b.call(c, f, e, a)) return {
                Li: e,
                Dj: f
            }
        }
        return {
            Li: -1,
            Dj: void 0
        }
    },
    ma = "function" == typeof Object.defineProperties ? Object.defineProperty : function(a,
        b, c) {
        a != Array.prototype && a != Object.prototype && (a[b] = c.value)
    },
    na = "undefined" != typeof window && window === this ? this : "undefined" != typeof global && null != global ? global : this,
    oa = function(a, b) {
        if (b) {
            var c = na;
            a = a.split(".");
            for (var d = 0; d < a.length - 1; d++) {
                var e = a[d];
                e in c || (c[e] = {});
                c = c[e]
            }
            a = a[a.length - 1];
            d = c[a];
            b = b(d);
            b != d && null != b && ma(c, a, {
                configurable: !0,
                writable: !0,
                value: b
            })
        }
    };
oa("Array.prototype.findIndex", function(a) {
    return a ? a : function(b, c) {
        return la(this, b, c).Li
    }
});
var pa = function(a, b, c) {
    if (null == a) throw new TypeError("The 'this' value for String.prototype." + c + " must not be null or undefined");
    if (b instanceof RegExp) throw new TypeError("First argument to String.prototype." + c + " must not be a regular expression");
    return a + ""
};
oa("String.prototype.endsWith", function(a) {
    return a ? a : function(b, c) {
        var d = pa(this, b, "endsWith");
        b += "";
        void 0 === c && (c = d.length);
        c = Math.max(0, Math.min(c | 0, d.length));
        for (var e = b.length; 0 < e && 0 < c;)
            if (d[--c] != b[--e]) return !1;
        return 0 >= e
    }
});
oa("Array.prototype.find", function(a) {
    return a ? a : function(b, c) {
        return la(this, b, c).Dj
    }
});
oa("String.prototype.startsWith", function(a) {
    return a ? a : function(b, c) {
        var d = pa(this, b, "startsWith");
        b += "";
        var e = d.length,
            f = b.length;
        c = Math.max(0, Math.min(c | 0, d.length));
        for (var g = 0; g < f && c < e;)
            if (d[c++] != b[g++]) return !1;
        return g >= f
    }
});
oa("String.prototype.repeat", function(a) {
    return a ? a : function(b) {
        var c = pa(this, null, "repeat");
        if (0 > b || 1342177279 < b) throw new RangeError("Invalid count value");
        b |= 0;
        for (var d = ""; b;)
            if (b & 1 && (d += c), b >>>= 1) c += c;
        return d
    }
});
var qa = function() {
        qa = function() {};
        na.Symbol || (na.Symbol = ra)
    },
    sa = function(a, b) {
        this.a = a;
        ma(this, "description", {
            configurable: !0,
            writable: !0,
            value: b
        })
    };
sa.prototype.toString = function() {
    return this.a
};
var ra = function() {
        function a(c) {
            if (this instanceof a) throw new TypeError("Symbol is not a constructor");
            return new sa("jscomp_symbol_" + (c || "") + "_" + b++, c)
        }
        var b = 0;
        return a
    }(),
    ua = function() {
        qa();
        var a = na.Symbol.iterator;
        a || (a = na.Symbol.iterator = na.Symbol("Symbol.iterator"));
        "function" != typeof Array.prototype[a] && ma(Array.prototype, a, {
            configurable: !0,
            writable: !0,
            value: function() {
                return ta(aa(this))
            }
        });
        ua = function() {}
    },
    ta = function(a) {
        ua();
        a = {
            next: a
        };
        a[na.Symbol.iterator] = function() {
            return this
        };
        return a
    },
    va = function(a, b) {
        ua();
        a instanceof String && (a += "");
        var c = 0,
            d = {
                next: function() {
                    if (c < a.length) {
                        var e = c++;
                        return {
                            value: b(e, a[e]),
                            done: !1
                        }
                    }
                    d.next = function() {
                        return {
                            done: !0,
                            value: void 0
                        }
                    };
                    return d.next()
                }
            };
        d[Symbol.iterator] = function() {
            return d
        };
        return d
    };
oa("Array.prototype.keys", function(a) {
    return a ? a : function() {
        return va(this, function(b) {
            return b
        })
    }
});
oa("Array.prototype.values", function(a) {
    return a ? a : function() {
        return va(this, function(b, c) {
            return c
        })
    }
});
oa("Array.from", function(a) {
    return a ? a : function(b, c, d) {
        c = null != c ? c : function(k) {
            return k
        };
        var e = [],
            f = "undefined" != typeof Symbol && Symbol.iterator && b[Symbol.iterator];
        if ("function" == typeof f) {
            b = f.call(b);
            for (var g = 0; !(f = b.next()).done;) e.push(c.call(d, f.value, g++))
        } else
            for (f = b.length, g = 0; g < f; g++) e.push(c.call(d, b[g], g));
        return e
    }
});
oa("Object.is", function(a) {
    return a ? a : function(b, c) {
        return b === c ? 0 !== b || 1 / b === 1 / c : b !== b && c !== c
    }
});
oa("Array.prototype.includes", function(a) {
    return a ? a : function(b, c) {
        var d = this;
        d instanceof String && (d = String(d));
        var e = d.length;
        c = c || 0;
        for (0 > c && (c = Math.max(c + e, 0)); c < e; c++) {
            var f = d[c];
            if (f === b || Object.is(f, b)) return !0
        }
        return !1
    }
});
oa("String.prototype.includes", function(a) {
    return a ? a : function(b, c) {
        return -1 !== pa(this, b, "includes").indexOf(b, c || 0)
    }
});
var wa = function(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b)
};
oa("WeakMap", function(a) {
    function b() {}

    function c(l) {
        var m = typeof l;
        return "object" === m && null !== l || "function" === m
    }

    function d(l) {
        if (!wa(l, f)) {
            var m = new b;
            ma(l, f, {
                value: m
            })
        }
    }

    function e(l) {
        var m = Object[l];
        m && (Object[l] = function(q) {
            if (q instanceof b) return q;
            d(q);
            return m(q)
        })
    }
    if (function() {
            if (!a || !Object.seal) return !1;
            try {
                var l = Object.seal({}),
                    m = Object.seal({}),
                    q = new a([
                        [l, 2],
                        [m, 3]
                    ]);
                if (2 != q.get(l) || 3 != q.get(m)) return !1;
                q.delete(l);
                q.set(m, 4);
                return !q.has(l) && 4 == q.get(m)
            } catch (r) {
                return !1
            }
        }()) return a;
    var f = "$jscomp_hidden_" + Math.random();
    e("freeze");
    e("preventExtensions");
    e("seal");
    var g = 0,
        k = function(l) {
            this.qa = (g += Math.random() + 1).toString();
            if (l) {
                l = ba(l);
                for (var m; !(m = l.next()).done;) m = m.value, this.set(m[0], m[1])
            }
        };
    k.prototype.set = function(l, m) {
        if (!c(l)) throw Error("Invalid WeakMap key");
        d(l);
        if (!wa(l, f)) throw Error("WeakMap key fail: " + l);
        l[f][this.qa] = m;
        return this
    };
    k.prototype.get = function(l) {
        return c(l) && wa(l, f) ? l[f][this.qa] : void 0
    };
    k.prototype.has = function(l) {
        return c(l) && wa(l, f) && wa(l[f],
            this.qa)
    };
    k.prototype.delete = function(l) {
        return c(l) && wa(l, f) && wa(l[f], this.qa) ? delete l[f][this.qa] : !1
    };
    return k
});
oa("Object.values", function(a) {
    return a ? a : function(b) {
        var c = [],
            d;
        for (d in b) wa(b, d) && c.push(b[d]);
        return c
    }
});
oa("Map", function(a) {
    if (function() {
            if (!a || "function" != typeof a || !a.prototype.entries || "function" != typeof Object.seal) return !1;
            try {
                var k = Object.seal({
                        x: 4
                    }),
                    l = new a(ba([
                        [k, "s"]
                    ]));
                if ("s" != l.get(k) || 1 != l.size || l.get({
                        x: 4
                    }) || l.set({
                        x: 4
                    }, "t") != l || 2 != l.size) return !1;
                var m = l.entries(),
                    q = m.next();
                if (q.done || q.value[0] != k || "s" != q.value[1]) return !1;
                q = m.next();
                return q.done || 4 != q.value[0].x || "t" != q.value[1] || !m.next().done ? !1 : !0
            } catch (r) {
                return !1
            }
        }()) return a;
    ua();
    var b = new WeakMap,
        c = function(k) {
            this.b = {};
            this.a =
                f();
            this.size = 0;
            if (k) {
                k = ba(k);
                for (var l; !(l = k.next()).done;) l = l.value, this.set(l[0], l[1])
            }
        };
    c.prototype.set = function(k, l) {
        k = 0 === k ? 0 : k;
        var m = d(this, k);
        m.list || (m.list = this.b[m.id] = []);
        m.rb ? m.rb.value = l : (m.rb = {
            next: this.a,
            Lc: this.a.Lc,
            head: this.a,
            key: k,
            value: l
        }, m.list.push(m.rb), this.a.Lc.next = m.rb, this.a.Lc = m.rb, this.size++);
        return this
    };
    c.prototype.delete = function(k) {
        k = d(this, k);
        return k.rb && k.list ? (k.list.splice(k.index, 1), k.list.length || delete this.b[k.id], k.rb.Lc.next = k.rb.next, k.rb.next.Lc = k.rb.Lc,
            k.rb.head = null, this.size--, !0) : !1
    };
    c.prototype.clear = function() {
        this.b = {};
        this.a = this.a.Lc = f();
        this.size = 0
    };
    c.prototype.has = function(k) {
        return !!d(this, k).rb
    };
    c.prototype.get = function(k) {
        return (k = d(this, k).rb) && k.value
    };
    c.prototype.entries = function() {
        return e(this, function(k) {
            return [k.key, k.value]
        })
    };
    c.prototype.keys = function() {
        return e(this, function(k) {
            return k.key
        })
    };
    c.prototype.values = function() {
        return e(this, function(k) {
            return k.value
        })
    };
    c.prototype.forEach = function(k, l) {
        for (var m = this.entries(),
                q; !(q = m.next()).done;) q = q.value, k.call(l, q[1], q[0], this)
    };
    c.prototype[Symbol.iterator] = c.prototype.entries;
    var d = function(k, l) {
            var m = l && typeof l;
            "object" == m || "function" == m ? b.has(l) ? m = b.get(l) : (m = "" + ++g, b.set(l, m)) : m = "p_" + l;
            var q = k.b[m];
            if (q && wa(k.b, m))
                for (k = 0; k < q.length; k++) {
                    var r = q[k];
                    if (l !== l && r.key !== r.key || l === r.key) return {
                        id: m,
                        list: q,
                        index: k,
                        rb: r
                    }
                }
            return {
                id: m,
                list: q,
                index: -1,
                rb: void 0
            }
        },
        e = function(k, l) {
            var m = k.a;
            return ta(function() {
                if (m) {
                    for (; m.head != k.a;) m = m.Lc;
                    for (; m.next != m.head;) return m =
                        m.next, {
                            done: !1,
                            value: l(m)
                        };
                    m = null
                }
                return {
                    done: !0,
                    value: void 0
                }
            })
        },
        f = function() {
            var k = {};
            return k.Lc = k.next = k.head = k
        },
        g = 0;
    return c
});
var xa = xa || {},
    n = this || self,
    ya = function(a, b) {
        a = a.split(".");
        var c = n;
        a[0] in c || "undefined" == typeof c.execScript || c.execScript("var " + a[0]);
        for (var d; a.length && (d = a.shift());) a.length || void 0 === b ? c[d] && c[d] !== Object.prototype[d] ? c = c[d] : c = c[d] = {} : c[d] = b
    },
    Ba = function(a) {
        if (a && a != n) return za(a.document);
        null === Aa && (Aa = za(n.document));
        return Aa
    },
    Ca = /^[\w+/_-]+[=]{0,2}$/,
    Aa = null,
    za = function(a) {
        return (a = a.querySelector && a.querySelector("script[nonce]")) && (a = a.nonce || a.getAttribute("nonce")) && Ca.test(a) ? a :
            ""
    },
    Da = function(a, b) {
        a = a.split(".");
        b = b || n;
        for (var c = 0; c < a.length; c++)
            if (b = b[a[c]], null == b) return null;
        return b
    },
    Ea = function() {},
    Fa = function(a) {
        a.Zg = void 0;
        a.M = function() {
            return a.Zg ? a.Zg : a.Zg = new a
        }
    },
    Ga = function(a) {
        var b = typeof a;
        if ("object" == b)
            if (a) {
                if (a instanceof Array) return "array";
                if (a instanceof Object) return b;
                var c = Object.prototype.toString.call(a);
                if ("[object Window]" == c) return "object";
                if ("[object Array]" == c || "number" == typeof a.length && "undefined" != typeof a.splice && "undefined" != typeof a.propertyIsEnumerable &&
                    !a.propertyIsEnumerable("splice")) return "array";
                if ("[object Function]" == c || "undefined" != typeof a.call && "undefined" != typeof a.propertyIsEnumerable && !a.propertyIsEnumerable("call")) return "function"
            } else return "null";
        else if ("function" == b && "undefined" == typeof a.call) return "object";
        return b
    },
    Ia = function(a) {
        return "array" == Ga(a)
    },
    Ja = function(a) {
        var b = Ga(a);
        return "array" == b || "object" == b && "number" == typeof a.length
    },
    Ka = function(a) {
        return "function" == Ga(a)
    },
    La = function(a) {
        var b = typeof a;
        return "object" == b && null !=
            a || "function" == b
    },
    Pa = function(a) {
        return a[Na] || (a[Na] = ++Oa)
    },
    Na = "closure_uid_" + (1E9 * Math.random() >>> 0),
    Oa = 0,
    Qa = function(a, b, c) {
        return a.call.apply(a.bind, arguments)
    },
    Ra = function(a, b, c) {
        if (!a) throw Error();
        if (2 < arguments.length) {
            var d = Array.prototype.slice.call(arguments, 2);
            return function() {
                var e = Array.prototype.slice.call(arguments);
                Array.prototype.unshift.apply(e, d);
                return a.apply(b, e)
            }
        }
        return function() {
            return a.apply(b, arguments)
        }
    },
    p = function(a, b, c) {
        Function.prototype.bind && -1 != Function.prototype.bind.toString().indexOf("native code") ?
            p = Qa : p = Ra;
        return p.apply(null, arguments)
    },
    Sa = function(a, b) {
        var c = Array.prototype.slice.call(arguments, 1);
        return function() {
            var d = c.slice();
            d.push.apply(d, arguments);
            return a.apply(this, d)
        }
    },
    Ta = Date.now || function() {
        return +new Date
    },
    t = function(a, b) {
        function c() {}
        c.prototype = b.prototype;
        a.D = b.prototype;
        a.prototype = new c;
        a.prototype.constructor = a
    };
var Ua = function(a) {
    if (Error.captureStackTrace) Error.captureStackTrace(this, Ua);
    else {
        var b = Error().stack;
        b && (this.stack = b)
    }
    a && (this.message = String(a))
};
t(Ua, Error);
Ua.prototype.name = "CustomError";
var Va;
var Wa = function(a, b) {
    a = a.split("%s");
    for (var c = "", d = a.length - 1, e = 0; e < d; e++) c += a[e] + (e < b.length ? b[e] : "%s");
    Ua.call(this, c + a[d])
};
t(Wa, Ua);
Wa.prototype.name = "AssertionError";
var Xa = function(a, b, c, d) {
        var e = "Assertion failed";
        if (c) {
            e += ": " + c;
            var f = d
        } else a && (e += ": " + a, f = b);
        throw new Wa("" + e, f || []);
    },
    v = function(a, b, c) {
        a || Xa("", null, b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    Ya = function(a, b) {
        throw new Wa("Failure" + (a ? ": " + a : ""), Array.prototype.slice.call(arguments, 1));
    },
    Za = function(a, b, c) {
        "number" !== typeof a && Xa("Expected number but got %s: %s.", [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    $a = function(a, b, c) {
        "string" !== typeof a && Xa("Expected string but got %s: %s.",
            [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    ab = function(a, b, c) {
        Ka(a) || Xa("Expected function but got %s: %s.", [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    bb = function(a, b, c) {
        La(a) || Xa("Expected object but got %s: %s.", [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    cb = function(a, b, c) {
        Ia(a) || Xa("Expected array but got %s: %s.", [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    db = function(a, b, c) {
        "boolean" !== typeof a && Xa("Expected boolean but got %s: %s.",
            [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    eb = function(a, b, c) {
        La(a) && 1 == a.nodeType || Xa("Expected Element but got %s: %s.", [Ga(a), a], b, Array.prototype.slice.call(arguments, 2));
        return a
    },
    gb = function(a, b, c, d) {
        a instanceof b || Xa("Expected instanceof %s but got %s.", [fb(b), fb(a)], c, Array.prototype.slice.call(arguments, 3));
        return a
    },
    fb = function(a) {
        return a instanceof Function ? a.displayName || a.name || "unknown type name" : a instanceof Object ? a.constructor.displayName || a.constructor.name ||
            Object.prototype.toString.call(a) : null === a ? "null" : typeof a
    };
var hb = function(a) {
        return a[a.length - 1]
    },
    ib = Array.prototype.indexOf ? function(a, b) {
        v(null != a.length);
        return Array.prototype.indexOf.call(a, b, void 0)
    } : function(a, b) {
        if ("string" === typeof a) return "string" !== typeof b || 1 != b.length ? -1 : a.indexOf(b, 0);
        for (var c = 0; c < a.length; c++)
            if (c in a && a[c] === b) return c;
        return -1
    },
    w = Array.prototype.forEach ? function(a, b, c) {
        v(null != a.length);
        Array.prototype.forEach.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, e = "string" === typeof a ? a.split("") : a, f = 0; f < d; f++) f in e && b.call(c,
            e[f], f, a)
    },
    jb = Array.prototype.filter ? function(a, b) {
        v(null != a.length);
        return Array.prototype.filter.call(a, b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = [], e = 0, f = "string" === typeof a ? a.split("") : a, g = 0; g < c; g++)
            if (g in f) {
                var k = f[g];
                b.call(void 0, k, g, a) && (d[e++] = k)
            } return d
    },
    kb = Array.prototype.map ? function(a, b, c) {
        v(null != a.length);
        return Array.prototype.map.call(a, b, c)
    } : function(a, b, c) {
        for (var d = a.length, e = Array(d), f = "string" === typeof a ? a.split("") : a, g = 0; g < d; g++) g in f && (e[g] = b.call(c, f[g], g, a));
        return e
    },
    lb = Array.prototype.reduce ? function(a, b, c) {
        v(null != a.length);
        return Array.prototype.reduce.call(a, b, c)
    } : function(a, b, c) {
        var d = c;
        w(a, function(e, f) {
            d = b.call(void 0, d, e, f, a)
        });
        return d
    },
    mb = Array.prototype.some ? function(a, b) {
        v(null != a.length);
        return Array.prototype.some.call(a, b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
            if (e in d && b.call(void 0, d[e], e, a)) return !0;
        return !1
    },
    nb = Array.prototype.every ? function(a, b) {
        v(null != a.length);
        return Array.prototype.every.call(a,
            b, void 0)
    } : function(a, b) {
        for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
            if (e in d && !b.call(void 0, d[e], e, a)) return !1;
        return !0
    },
    ob = function(a, b) {
        var c = 0;
        w(a, function(d, e, f) {
            b.call(void 0, d, e, f) && ++c
        }, void 0);
        return c
    },
    pb = function(a, b) {
        a: {
            for (var c = a.length, d = "string" === typeof a ? a.split("") : a, e = 0; e < c; e++)
                if (e in d && b.call(void 0, d[e], e, a)) {
                    b = e;
                    break a
                } b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    },
    qb = function(a, b) {
        a: {
            for (var c = "string" === typeof a ? a.split("") : a, d = a.length -
                    1; 0 <= d; d--)
                if (d in c && b.call(void 0, c[d], d, a)) {
                    b = d;
                    break a
                } b = -1
        }
        return 0 > b ? null : "string" === typeof a ? a.charAt(b) : a[b]
    },
    rb = function(a, b) {
        return 0 <= ib(a, b)
    },
    sb = function(a, b) {
        rb(a, b) || a.push(b)
    },
    ub = function(a, b) {
        b = ib(a, b);
        var c;
        (c = 0 <= b) && tb(a, b);
        return c
    },
    tb = function(a, b) {
        v(null != a.length);
        Array.prototype.splice.call(a, b, 1)
    },
    vb = function(a) {
        return Array.prototype.concat.apply([], arguments)
    },
    wb = function(a) {
        return Array.prototype.concat.apply([], arguments)
    },
    xb = function(a) {
        var b = a.length;
        if (0 < b) {
            for (var c =
                    Array(b), d = 0; d < b; d++) c[d] = a[d];
            return c
        }
        return []
    },
    yb = function(a, b) {
        for (var c = 1; c < arguments.length; c++) {
            var d = arguments[c];
            if (Ja(d)) {
                var e = a.length || 0,
                    f = d.length || 0;
                a.length = e + f;
                for (var g = 0; g < f; g++) a[e + g] = d[g]
            } else a.push(d)
        }
    },
    Ab = function(a, b, c, d) {
        v(null != a.length);
        Array.prototype.splice.apply(a, zb(arguments, 1))
    },
    zb = function(a, b, c) {
        v(null != a.length);
        return 2 >= arguments.length ? Array.prototype.slice.call(a, b) : Array.prototype.slice.call(a, b, c)
    },
    Bb = function(a, b) {
        return vb.apply([], kb(a, b, void 0))
    };
var Eb = function(a) {
        var b = Cb(a);
        b && (!a || !(a instanceof b.Location) && a instanceof b.Element) && Ya("Argument is not a Location (or a non-Element mock); got: %s", Db(a))
    },
    Fb = function(a, b) {
        var c = Cb(a);
        c && "undefined" != typeof c[b] && (a && (a instanceof c[b] || !(a instanceof c.Location || a instanceof c.Element)) || Ya("Argument is not a %s (or a non-Element, non-Location mock); got: %s", b, Db(a)))
    },
    Db = function(a) {
        if (La(a)) try {
            return a.constructor.displayName || a.constructor.name || Object.prototype.toString.call(a)
        } catch (b) {
            return "<object could not be stringified>"
        } else return void 0 ===
            a ? "undefined" : null === a ? "null" : typeof a
    },
    Cb = function(a) {
        try {
            var b = a && a.ownerDocument,
                c = b && (b.defaultView || b.parentWindow);
            c = c || n;
            if (c.Element && c.Location) return c
        } catch (d) {}
        return null
    };
var Gb = function() {
        return null
    },
    Hb = function(a) {
        var b = b || 0;
        return function() {
            return a.apply(this, Array.prototype.slice.call(arguments, 0, b))
        }
    },
    Ib = function(a) {
        var b = !1,
            c;
        return function() {
            b || (c = a(), b = !0);
            return c
        }
    };
var Jb = function(a, b, c) {
        for (var d in a) b.call(c, a[d], d, a)
    },
    Mb = function(a, b) {
        for (var c in a)
            if (b.call(void 0, a[c], c, a)) return !0;
        return !1
    },
    Nb = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = a[d];
        return b
    },
    Ob = function(a) {
        var b = [],
            c = 0,
            d;
        for (d in a) b[c++] = d;
        return b
    },
    Pb = function(a, b) {
        return null !== a && b in a
    },
    Qb = function(a, b) {
        for (var c in a)
            if (a[c] == b) return !0;
        return !1
    },
    Sb = function() {
        var a = Rb,
            b;
        for (b in a) return !1;
        return !0
    },
    Tb = function(a, b, c) {
        if (null !== a && b in a) throw Error('The object already contains the key "' +
            b + '"');
        a[b] = c
    },
    Ub = function(a) {
        var b = {},
            c;
        for (c in a) b[c] = a[c];
        return b
    },
    Vb = "constructor hasOwnProperty isPrototypeOf propertyIsEnumerable toLocaleString toString valueOf".split(" "),
    Wb = function(a, b) {
        for (var c, d, e = 1; e < arguments.length; e++) {
            d = arguments[e];
            for (c in d) a[c] = d[c];
            for (var f = 0; f < Vb.length; f++) c = Vb[f], Object.prototype.hasOwnProperty.call(d, c) && (a[c] = d[c])
        }
    },
    Xb = function(a) {
        var b = arguments.length;
        if (1 == b && Ia(arguments[0])) return Xb.apply(null, arguments[0]);
        if (b % 2) throw Error("Uneven number of arguments");
        for (var c = {}, d = 0; d < b; d += 2) c[arguments[d]] = arguments[d + 1];
        return c
    },
    Yb = function(a) {
        var b = arguments.length;
        if (1 == b && Ia(arguments[0])) return Yb.apply(null, arguments[0]);
        for (var c = {}, d = 0; d < b; d++) c[arguments[d]] = !0;
        return c
    };
var Zb = {
    area: !0,
    base: !0,
    br: !0,
    col: !0,
    command: !0,
    embed: !0,
    hr: !0,
    img: !0,
    input: !0,
    keygen: !0,
    link: !0,
    meta: !0,
    param: !0,
    source: !0,
    track: !0,
    wbr: !0
};
var bc = function(a, b) {
    this.a = a === $b && b || "";
    this.b = ac
};
bc.prototype.xc = !0;
bc.prototype.ub = function() {
    return this.a
};
bc.prototype.toString = function() {
    return "Const{" + this.a + "}"
};
var cc = function(a) {
        if (a instanceof bc && a.constructor === bc && a.b === ac) return a.a;
        Ya("expected object of type Const, got '" + a + "'");
        return "type_error:Const"
    },
    dc = function(a) {
        return new bc($b, a)
    },
    ac = {},
    $b = {},
    ec = dc("");
var fc = /[A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]/,
    gc = /^[^A-Za-z\u00c0-\u00d6\u00d8-\u00f6\u00f8-\u02b8\u0300-\u0590\u0900-\u1fff\u200e\u2c00-\ud801\ud804-\ud839\ud83c-\udbff\uf900-\ufb1c\ufe00-\ufe6f\ufefd-\uffff]*[\u0591-\u06ef\u06fa-\u08ff\u200f\ud802-\ud803\ud83a-\ud83b\ufb1d-\ufdff\ufe70-\ufefc]/,
    hc = /^http:\/\/.*/,
    ic = /^(ar|ckb|dv|he|iw|fa|nqo|ps|sd|ug|ur|yi|.*[-_](Adlm|Arab|Hebr|Nkoo|Rohg|Thaa))(?!.*[-_](Latn|Cyrl)($|-|_))($|-|_)/i,
    jc = function(a) {
        return ic.test(a)
    },
    kc = /\s+/,
    lc = /[\d\u06f0-\u06f9]/,
    mc = function(a) {
        var b = 0,
            c = 0,
            d = !1;
        a = a.split(kc);
        for (var e = 0; e < a.length; e++) {
            var f = a[e];
            gc.test(f) ? (b++, c++) : hc.test(f) ? d = !0 : fc.test(f) ? c++ : lc.test(f) && (d = !0)
        }
        return -1 == (0 == c ? d ? 1 : 0 : .4 < b / c ? -1 : 1)
    };
var pc = function(a, b) {
    this.a = a === nc && b || "";
    this.b = oc
};
h = pc.prototype;
h.xc = !0;
h.ub = function() {
    return this.a.toString()
};
h.Xg = !0;
h.Vc = function() {
    return 1
};
h.toString = function() {
    return "TrustedResourceUrl{" + this.a + "}"
};
var rc = function(a) {
        return qc(a).toString()
    },
    qc = function(a) {
        if (a instanceof pc && a.constructor === pc && a.b === oc) return a.a;
        Ya("expected object of type TrustedResourceUrl, got '" + a + "' of type " + Ga(a));
        return "type_error:TrustedResourceUrl"
    },
    sc = /^([^?#]*)(\?[^#]*)?(#[\s\S]*)?/,
    oc = {},
    tc = function(a) {
        return new pc(nc, a)
    },
    uc = function(a, b, c) {
        if (null == c) return b;
        if ("string" === typeof c) return c ? a + encodeURIComponent(c) : "";
        for (var d in c) {
            var e = c[d];
            e = Ia(e) ? e : [e];
            for (var f = 0; f < e.length; f++) {
                var g = e[f];
                null != g && (b ||
                    (b = a), b += (b.length > a.length ? "&" : "") + encodeURIComponent(d) + "=" + encodeURIComponent(String(g)))
            }
        }
        return b
    },
    nc = {};
var vc = function(a, b) {
        return 0 == a.lastIndexOf(b, 0)
    },
    wc = function(a, b) {
        var c = a.length - b.length;
        return 0 <= c && a.indexOf(b, c) == c
    },
    xc = function(a) {
        return /^[\s\xa0]*$/.test(a)
    },
    yc = String.prototype.trim ? function(a) {
        return a.trim()
    } : function(a) {
        return /^[\s\xa0]*([\s\S]*?)[\s\xa0]*$/.exec(a)[1]
    },
    zc = function(a, b) {
        a = String(a).toLowerCase();
        b = String(b).toLowerCase();
        return a < b ? -1 : a == b ? 0 : 1
    },
    Ac = function(a) {
        return a.replace(/(\r\n|\r|\n)/g, "<br>")
    },
    Ic = function(a, b) {
        if (b) a = a.replace(Bc, "&amp;").replace(Cc, "&lt;").replace(Dc,
            "&gt;").replace(Ec, "&quot;").replace(Fc, "&#39;").replace(Gc, "&#0;");
        else {
            if (!Hc.test(a)) return a; - 1 != a.indexOf("&") && (a = a.replace(Bc, "&amp;")); - 1 != a.indexOf("<") && (a = a.replace(Cc, "&lt;")); - 1 != a.indexOf(">") && (a = a.replace(Dc, "&gt;")); - 1 != a.indexOf('"') && (a = a.replace(Ec, "&quot;")); - 1 != a.indexOf("'") && (a = a.replace(Fc, "&#39;")); - 1 != a.indexOf("\x00") && (a = a.replace(Gc, "&#0;"))
        }
        return a
    },
    Bc = /&/g,
    Cc = /</g,
    Dc = />/g,
    Ec = /"/g,
    Fc = /'/g,
    Gc = /\x00/g,
    Hc = /[\x00&<>"']/,
    Jc = function(a, b) {
        return -1 != a.indexOf(b)
    },
    Lc = function(a,
        b) {
        var c = 0;
        a = yc(String(a)).split(".");
        b = yc(String(b)).split(".");
        for (var d = Math.max(a.length, b.length), e = 0; 0 == c && e < d; e++) {
            var f = a[e] || "",
                g = b[e] || "";
            do {
                f = /(\d*)(\D*)(.*)/.exec(f) || ["", "", "", ""];
                g = /(\d*)(\D*)(.*)/.exec(g) || ["", "", "", ""];
                if (0 == f[0].length && 0 == g[0].length) break;
                c = Kc(0 == f[1].length ? 0 : parseInt(f[1], 10), 0 == g[1].length ? 0 : parseInt(g[1], 10)) || Kc(0 == f[2].length, 0 == g[2].length) || Kc(f[2], g[2]);
                f = f[3];
                g = g[3]
            } while (0 == c)
        }
        return c
    },
    Kc = function(a, b) {
        return a < b ? -1 : a > b ? 1 : 0
    };
var Oc = function(a, b) {
    this.a = a === Mc && b || "";
    this.b = Nc
};
h = Oc.prototype;
h.xc = !0;
h.ub = function() {
    return this.a.toString()
};
h.Xg = !0;
h.Vc = function() {
    return 1
};
h.toString = function() {
    return "SafeUrl{" + this.a + "}"
};
var Pc = function(a) {
        if (a instanceof Oc && a.constructor === Oc && a.b === Nc) return a.a;
        Ya("expected object of type SafeUrl, got '" + a + "' of type " + Ga(a));
        return "type_error:SafeUrl"
    },
    Qc = /^(?:audio\/(?:3gpp2|3gpp|aac|L16|midi|mp3|mp4|mpeg|oga|ogg|opus|x-m4a|x-wav|wav|webm)|image\/(?:bmp|gif|jpeg|jpg|png|tiff|webp|x-icon)|text\/csv|video\/(?:mpeg|mp4|ogg|webm|quicktime))(?:;\w+=(?:\w+|"[\w;=]+"))*$/i,
    Rc = /^data:([^,]*);base64,[a-z0-9+\/]+=*$/i,
    Sc = /^(?:(?:https?|mailto|ftp):|[^:/?#]*(?:[/?#]|$))/i,
    Tc = function(a) {
        if (a instanceof Oc) return a;
        a = "object" == typeof a && a.xc ? a.ub() : String(a);
        Sc.test(a) || (a = "about:invalid#zClosurez");
        return new Oc(Mc, a)
    },
    Uc = function(a, b) {
        if (a instanceof Oc) return a;
        a = "object" == typeof a && a.xc ? a.ub() : String(a);
        if (b && /^data:/i.test(a)) {
            b = a.replace(/(%0A|%0D)/g, "");
            var c = b.match(Rc);
            c = c && Qc.test(c[1]);
            b = new Oc(Mc, c ? b : "about:invalid#zClosurez");
            if (b.ub() == a) return b
        }
        v(Sc.test(a), "%s does not match the safe URL pattern", a) || (a = "about:invalid#zClosurez");
        return new Oc(Mc, a)
    },
    Nc = {},
    Mc = {};
var Wc = function() {
    this.a = "";
    this.b = Vc
};
Wc.prototype.xc = !0;
var Vc = {};
Wc.prototype.ub = function() {
    return this.a
};
Wc.prototype.toString = function() {
    return "SafeStyle{" + this.a + "}"
};
var Xc = function(a) {
        if (a instanceof Wc && a.constructor === Wc && a.b === Vc) return a.a;
        Ya("expected object of type SafeStyle, got '" + a + "' of type " + Ga(a));
        return "type_error:SafeStyle"
    },
    Yc = function(a) {
        var b = new Wc;
        b.a = a;
        return b
    },
    Zc = Yc(""),
    ad = function(a) {
        var b = "",
            c;
        for (c in a) {
            if (!/^[-_a-zA-Z0-9]+$/.test(c)) throw Error("Name allows only [-_a-zA-Z0-9], got: " + c);
            var d = a[c];
            null != d && (d = Ia(d) ? kb(d, $c).join(" ") : $c(d), b += c + ":" + d + ";")
        }
        return b ? Yc(b) : Zc
    },
    $c = function(a) {
        if (a instanceof Oc) return 'url("' + Pc(a).replace(/</g,
            "%3c").replace(/[\\"]/g, "\\$&") + '")';
        a = a instanceof bc ? cc(a) : bd(String(a));
        if (/[{;}]/.test(a)) throw new Wa("Value does not allow [{;}], got: %s.", [a]);
        return a
    },
    bd = function(a) {
        var b = a.replace(cd, "$1").replace(cd, "$1").replace(dd, "url");
        if (ed.test(b)) {
            if (fd.test(a)) return Ya("String value disallows comments, got: " + a), "zClosurez";
            for (var c = b = !0, d = 0; d < a.length; d++) {
                var e = a.charAt(d);
                "'" == e && c ? b = !b : '"' == e && b && (c = !c)
            }
            if (!b || !c) return Ya("String value requires balanced quotes, got: " + a), "zClosurez";
            if (!gd(a)) return Ya("String value requires balanced square brackets and one identifier per pair of brackets, got: " +
                a), "zClosurez"
        } else return Ya("String value allows only [-,.\"'%_!# a-zA-Z0-9\\[\\]] and simple functions, got: " + a), "zClosurez";
        return hd(a)
    },
    gd = function(a) {
        for (var b = !0, c = /^[-_a-zA-Z0-9]$/, d = 0; d < a.length; d++) {
            var e = a.charAt(d);
            if ("]" == e) {
                if (b) return !1;
                b = !0
            } else if ("[" == e) {
                if (!b) return !1;
                b = !1
            } else if (!b && !c.test(e)) return !1
        }
        return b
    },
    ed = /^[-,."'%_!# a-zA-Z0-9\[\]]+$/,
    dd = /\b(url\([ \t\n]*)('[ -&(-\[\]-~]*'|"[ !#-\[\]-~]*"|[!#-&*-\[\]-~]*)([ \t\n]*\))/g,
    cd = /\b(calc|cubic-bezier|fit-content|hsl|hsla|matrix|minmax|repeat|rgb|rgba|(rotate|scale|translate)(X|Y|Z|3d)?)\([-+*/0-9a-z.%\[\], ]+\)/g,
    fd = /\/\*/,
    hd = function(a) {
        return a.replace(dd, function(b, c, d, e) {
            var f = "";
            d = d.replace(/^(['"])(.*)\1$/, function(g, k, l) {
                f = k;
                return l
            });
            b = Tc(d).ub();
            return c + f + b + f + e
        })
    };
var jd = function() {
    this.a = "";
    this.b = id
};
jd.prototype.xc = !0;
var id = {},
    ld = function(a, b) {
        if (Jc(a, "<")) throw Error("Selector does not allow '<', got: " + a);
        var c = a.replace(/('|")((?!\1)[^\r\n\f\\]|\\[\s\S])*\1/g, "");
        if (!/^[-_a-zA-Z0-9#.:* ,>+~[\]()=^$|]+$/.test(c)) throw Error("Selector allows only [-_a-zA-Z0-9#.:* ,>+~[\\]()=^$|] and strings, got: " + a);
        a: {
            for (var d = {
                    "(": ")",
                    "[": "]"
                }, e = [], f = 0; f < c.length; f++) {
                var g = c[f];
                if (d[g]) e.push(d[g]);
                else if (Qb(d, g) && e.pop() != g) {
                    c = !1;
                    break a
                }
            }
            c = 0 == e.length
        }
        if (!c) throw Error("() and [] in selector must be balanced, got: " + a);
        b instanceof Wc || (b = ad(b));
        a = a + "{" + Xc(b).replace(/</g, "\\3C ") + "}";
        return kd(a)
    },
    nd = function(a) {
        var b = "",
            c = function(d) {
                Ia(d) ? w(d, c) : b += md(d)
            };
        w(arguments, c);
        return kd(b)
    };
jd.prototype.ub = function() {
    return this.a
};
jd.prototype.toString = function() {
    return "SafeStyleSheet{" + this.a + "}"
};
var md = function(a) {
        if (a instanceof jd && a.constructor === jd && a.b === id) return a.a;
        Ya("expected object of type SafeStyleSheet, got '" + a + "' of type " + Ga(a));
        return "type_error:SafeStyleSheet"
    },
    kd = function(a) {
        var b = new jd;
        b.a = a;
        return b
    },
    od = kd("");
var pd;
a: {
    var qd = n.navigator;
    if (qd) {
        var rd = qd.userAgent;
        if (rd) {
            pd = rd;
            break a
        }
    }
    pd = ""
}
var x = function(a) {
        return Jc(pd, a)
    },
    sd = function(a) {
        for (var b = /(\w[\w ]+)\/([^\s]+)\s*(?:\((.*?)\))?/g, c = [], d; d = b.exec(a);) c.push([d[1], d[2], d[3] || void 0]);
        return c
    };
var td = function() {
        return x("Trident") || x("MSIE")
    },
    ud = function() {
        return x("Firefox") || x("FxiOS")
    },
    wd = function() {
        return x("Safari") && !(vd() || x("Coast") || x("Opera") || x("Edge") || x("Edg/") || x("OPR") || ud() || x("Silk") || x("Android"))
    },
    vd = function() {
        return (x("Chrome") || x("CriOS")) && !x("Edge")
    },
    xd = function() {
        function a(e) {
            e = pb(e, d);
            return c[e] || ""
        }
        var b = pd;
        if (!td()) {
            b = sd(b);
            var c = {};
            w(b, function(e) {
                c[e[0]] = e[1]
            });
            var d = Sa(Pb, c);
            x("Opera") ? a(["Version", "Opera"]) : x("Edge") ? a(["Edge"]) : x("Edg/") ? a(["Edg"]) : vd() &&
                a(["Chrome", "CriOS"])
        }
    };
var zd = function() {
    this.a = "";
    this.c = yd;
    this.b = null
};
h = zd.prototype;
h.Xg = !0;
h.Vc = function() {
    return this.b
};
h.xc = !0;
h.ub = function() {
    return this.a.toString()
};
h.toString = function() {
    return "SafeHtml{" + this.a + "}"
};
var Ad = function(a) {
        if (a instanceof zd && a.constructor === zd && a.c === yd) return a.a;
        Ya("expected object of type SafeHtml, got '" + a + "' of type " + Ga(a));
        return "type_error:SafeHtml"
    },
    Cd = function(a) {
        if (a instanceof zd) return a;
        var b = "object" == typeof a,
            c = null;
        b && a.Xg && (c = a.Vc());
        return Bd(Ic(b && a.xc ? a.ub() : String(a)), c)
    },
    Dd = function(a) {
        if (a instanceof zd) return a;
        a = Cd(a);
        return Bd(Ac(Ad(a).toString()), a.Vc())
    },
    Ed = /^[a-zA-Z0-9-]+$/,
    Fd = {
        action: !0,
        cite: !0,
        data: !0,
        formaction: !0,
        href: !0,
        manifest: !0,
        poster: !0,
        src: !0
    },
    Gd = {
        APPLET: !0,
        BASE: !0,
        EMBED: !0,
        IFRAME: !0,
        LINK: !0,
        MATH: !0,
        META: !0,
        OBJECT: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    },
    Id = function(a, b, c) {
        var d = String(a);
        if (!Ed.test(d)) throw Error("Invalid tag name <" + d + ">.");
        if (d.toUpperCase() in Gd) throw Error("Tag name <" + d + "> is not allowed for SafeHtml.");
        return Hd(String(a), b, c)
    },
    Kd = function(a) {
        var b = Cd(Jd),
            c = b.Vc(),
            d = [],
            e = function(f) {
                Ia(f) ? w(f, e) : (f = Cd(f), d.push(Ad(f).toString()), f = f.Vc(), 0 == c ? c = f : 0 != f && c != f && (c = null))
            };
        w(a, e);
        return Bd(d.join(Ad(b).toString()),
            c)
    },
    Ld = function(a) {
        return Kd(Array.prototype.slice.call(arguments))
    },
    yd = {},
    Bd = function(a, b) {
        return Md(a, b)
    },
    Md = function(a, b) {
        var c = new zd;
        c.a = a;
        c.b = b;
        return c
    },
    Hd = function(a, b, c) {
        var d = null,
            e = "";
        if (b)
            for (l in b) {
                if (!Ed.test(l)) throw Error('Invalid attribute name "' + l + '".');
                var f = b[l];
                if (null != f) {
                    var g = a;
                    var k = l;
                    if (f instanceof bc) f = cc(f);
                    else if ("style" == k.toLowerCase()) {
                        if (!La(f)) throw Error('The "style" attribute requires goog.html.SafeStyle or map of style properties, ' + typeof f + " given: " + f);
                        f instanceof Wc || (f = ad(f));
                        f = Xc(f)
                    } else {
                        if (/^on/i.test(k)) throw Error('Attribute "' + k + '" requires goog.string.Const value, "' + f + '" given.');
                        if (k.toLowerCase() in Fd)
                            if (f instanceof pc) f = rc(f);
                            else if (f instanceof Oc) f = Pc(f);
                        else if ("string" === typeof f) f = Tc(f).ub();
                        else throw Error('Attribute "' + k + '" on tag "' + g + '" requires goog.html.SafeUrl, goog.string.Const, or string, value "' + f + '" given.');
                    }
                    f.xc && (f = f.ub());
                    v("string" === typeof f || "number" === typeof f, "String or number value expected, got " + typeof f +
                        " with value: " + f);
                    k = k + '="' + Ic(String(f)) + '"';
                    e += " " + k
                }
            }
        var l = "<" + a + e;
        null == c ? c = [] : Ia(c) || (c = [c]);
        !0 === Zb[a.toLowerCase()] ? (v(!c.length, "Void tag <" + a + "> does not allow content."), l += ">") : (d = Ld(c), l += ">" + Ad(d).toString() + "</" + a + ">", d = d.Vc());
        (a = b && b.dir) && (/^(ltr|rtl|auto)$/i.test(a) ? d = 0 : d = null);
        return Md(l, d)
    };
Md("<!DOCTYPE html>", 0);
var Jd = Md("", 0),
    Nd = Md("<br>", 0);
var Od = function(a, b, c) {
        $a(cc(a), "must provide justification");
        v(!xc(cc(a)), "must provide non-empty justification");
        return Md(b, c || null)
    },
    Pd = function(a) {
        var b = dc("Output of CSS sanitizer");
        $a(cc(b), "must provide justification");
        v(!xc(cc(b)), "must provide non-empty justification");
        return Yc(a)
    };
var Qd = {
        MATH: !0,
        SCRIPT: !0,
        STYLE: !0,
        SVG: !0,
        TEMPLATE: !0
    },
    Rd = Ib(function() {
        if ("undefined" === typeof document) return !1;
        var a = document.createElement("div"),
            b = document.createElement("div");
        b.appendChild(document.createElement("div"));
        a.appendChild(b);
        if (!a.firstChild) return !1;
        b = a.firstChild.firstChild;
        a.innerHTML = Ad(Jd);
        return !b.parentElement
    }),
    Sd = function(a, b) {
        if (Rd())
            for (; a.lastChild;) a.removeChild(a.lastChild);
        a.innerHTML = Ad(b)
    },
    Td = function(a, b) {
        if (Qd[a.tagName.toUpperCase()]) throw Error("goog.dom.safe.setInnerHtml cannot be used to set content of " +
            a.tagName + ".");
        Sd(a, b)
    },
    Ud = function(a, b) {
        Fb(a, "HTMLAnchorElement");
        b = b instanceof Oc ? b : Uc(b);
        a.href = Pc(b)
    },
    Vd = function(a, b) {
        Fb(a, "HTMLIFrameElement");
        a.src = rc(b)
    },
    Wd = function(a, b) {
        Fb(a, "HTMLScriptElement");
        a.src = qc(b);
        (b = Ba()) && a.setAttribute("nonce", b)
    },
    Xd = function(a, b) {
        Eb(a);
        b = b instanceof Oc ? b : Uc(b);
        a.href = Pc(b)
    },
    Yd = function(a, b) {
        Eb(a);
        b = b instanceof Oc ? b : Uc(b);
        a.replace(Pc(b))
    },
    Zd = function(a, b, c) {
        a = a instanceof Oc ? a : Uc(a);
        (b || n).open(Pc(a), c ? cc(c) : "", void 0, void 0)
    };
var $d = function(a) {
        return a.replace(/(\r\n|\r|\n)/g, "\n")
    },
    ae = function(a) {
        return a.replace(/[\t\r\n ]+/g, " ").replace(/^[\t\r\n ]+|[\t\r\n ]+$/g, "")
    },
    be = function(a) {
        return encodeURIComponent(String(a))
    },
    ce = function(a) {
        return decodeURIComponent(a.replace(/\+/g, " "))
    },
    de = function(a) {
        return a = Ic(a, void 0)
    },
    ge = function(a) {
        return Jc(a, "&") ? "document" in n ? ee(a) : fe(a) : a
    },
    ee = function(a) {
        var b = {
            "&amp;": "&",
            "&lt;": "<",
            "&gt;": ">",
            "&quot;": '"'
        };
        var c = n.document.createElement("div");
        return a.replace(he, function(d,
            e) {
            var f = b[d];
            if (f) return f;
            "#" == e.charAt(0) && (e = Number("0" + e.substr(1)), isNaN(e) || (f = String.fromCharCode(e)));
            f || (Td(c, Od(dc("Single HTML entity."), d + " ")), f = c.firstChild.nodeValue.slice(0, -1));
            return b[d] = f
        })
    },
    fe = function(a) {
        return a.replace(/&([^;]+);/g, function(b, c) {
            switch (c) {
                case "amp":
                    return "&";
                case "lt":
                    return "<";
                case "gt":
                    return ">";
                case "quot":
                    return '"';
                default:
                    return "#" != c.charAt(0) || (c = Number("0" + c.substr(1)), isNaN(c)) ? b : String.fromCharCode(c)
            }
        })
    },
    he = /&([^;\s<&]+);?/g,
    ie = function(a) {
        return String(a).replace(/([-()\[\]{}+?*.$\^|,:#<!\\])/g,
            "\\$1").replace(/\x08/g, "\\x08")
    },
    je = String.prototype.repeat ? function(a, b) {
        return a.repeat(b)
    } : function(a, b) {
        return Array(b + 1).join(a)
    },
    ke = function(a) {
        return null == a ? "" : String(a)
    },
    le = function(a) {
        return Array.prototype.join.call(arguments, "")
    },
    me = function(a) {
        var b = Number(a);
        return 0 == b && xc(a) ? NaN : b
    },
    ne = function(a) {
        return String(a).replace(/\-([a-z])/g, function(b, c) {
            return c.toUpperCase()
        })
    },
    oe = function(a) {
        return a.replace(/(^|[\s]+)([a-z])/g, function(b, c, d) {
            return c + d.toUpperCase()
        })
    };
var pe = function() {
        return x("iPhone") && !x("iPod") && !x("iPad")
    },
    qe = function() {
        return pe() || x("iPad") || x("iPod")
    },
    re = function(a) {
        var b = pd,
            c = "";
        x("Windows") ? (c = /Windows (?:NT|Phone) ([0-9.]+)/, c = (b = c.exec(b)) ? b[1] : "0.0") : qe() ? (c = /(?:iPhone|iPod|iPad|CPU)\s+OS\s+(\S+)/, c = (b = c.exec(b)) && b[1].replace(/_/g, ".")) : x("Macintosh") ? (c = /Mac OS X ([0-9_.]+)/, c = (b = c.exec(b)) ? b[1].replace(/_/g, ".") : "10") : Jc(pd.toLowerCase(), "kaios") ? (c = /(?:KaiOS)\/(\S+)/i, c = (b = c.exec(b)) && b[1]) : x("Android") ? (c = /Android\s+([^\);]+)(\)|;)/,
            c = (b = c.exec(b)) && b[1]) : x("CrOS") && (c = /(?:CrOS\s+(?:i686|x86_64)\s+([0-9.]+))/, c = (b = c.exec(b)) && b[1]);
        return 0 <= Lc(c || "", a)
    };
var se = function(a) {
    se[" "](a);
    return a
};
se[" "] = Ea;
var te = function(a, b) {
        try {
            return se(a[b]), !0
        } catch (c) {}
        return !1
    },
    ue = function(a, b, c) {
        return Object.prototype.hasOwnProperty.call(a, b) ? a[b] : a[b] = c(b)
    };
var ve = x("Opera"),
    y = td(),
    we = x("Edge"),
    xe = we || y,
    ye = x("Gecko") && !(Jc(pd.toLowerCase(), "webkit") && !x("Edge")) && !(x("Trident") || x("MSIE")) && !x("Edge"),
    ze = Jc(pd.toLowerCase(), "webkit") && !x("Edge"),
    Ae = ze && x("Mobile"),
    Ce = x("Macintosh"),
    De = x("Windows"),
    Ee = x("Android"),
    Fe = pe(),
    Ge = x("iPad"),
    He = x("iPod"),
    Ie = qe(),
    Je = function() {
        var a = n.document;
        return a ? a.documentMode : void 0
    },
    Ke;
a: {
    var Le = "",
        Me = function() {
            var a = pd;
            if (ye) return /rv:([^\);]+)(\)|;)/.exec(a);
            if (we) return /Edge\/([\d\.]+)/.exec(a);
            if (y) return /\b(?:MSIE|rv)[: ]([^\);]+)(\)|;)/.exec(a);
            if (ze) return /WebKit\/(\S+)/.exec(a);
            if (ve) return /(?:Version)[ \/]?(\S+)/.exec(a)
        }();Me && (Le = Me ? Me[1] : "");
    if (y) {
        var Ne = Je();
        if (null != Ne && Ne > parseFloat(Le)) {
            Ke = String(Ne);
            break a
        }
    }
    Ke = Le
}
var Oe = Ke,
    Pe = {},
    Qe = function(a) {
        return ue(Pe, a, function() {
            return 0 <= Lc(Oe, a)
        })
    },
    Se = function(a) {
        return Number(Re) >= a
    },
    Te;
Te = n.document && y ? Je() : void 0;
var Re = Te;
var Ue = ud(),
    Ve = pe() || x("iPod"),
    We = x("iPad"),
    Xe = x("Android") && !(vd() || ud() || x("Opera") || x("Silk")),
    Ye = vd(),
    Ze = wd() && !qe();
var $e = {},
    af = null,
    bf = function(a, b) {
        v(Ja(a), "encodeByteArray takes an array as a parameter");
        void 0 === b && (b = 0);
        if (!af) {
            af = {};
            for (var c = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789".split(""), d = ["+/=", "+/", "-_=", "-_.", "-_"], e = 0; 5 > e; e++) {
                var f = c.concat(d[e].split(""));
                $e[e] = f;
                for (var g = 0; g < f.length; g++) {
                    var k = f[g],
                        l = af[k];
                    void 0 === l ? af[k] = g : v(l === g)
                }
            }
        }
        b = $e[b];
        c = [];
        for (d = 0; d < a.length; d += 3) {
            l = a[d];
            var m = (e = d + 1 < a.length) ? a[d + 1] : 0;
            k = (f = d + 2 < a.length) ? a[d + 2] : 0;
            g = l >> 2;
            l = (l & 3) << 4 | m >> 4;
            m = (m &
                15) << 2 | k >> 6;
            k &= 63;
            f || (k = 64, e || (m = 64));
            c.push(b[g], b[l], b[m] || "", b[k] || "")
        }
        return c.join("")
    };
var cf = function() {},
    df = "function" == typeof Uint8Array,
    gf = function(a, b, c, d) {
        a.a = null;
        b || (b = []);
        a.w = void 0;
        a.g = -1;
        a.b = b;
        a: {
            var e = a.b.length;b = -1;
            if (e && (b = e - 1, e = a.b[b], !(null === e || "object" != typeof e || Ia(e) || df && e instanceof Uint8Array))) {
                a.h = b - a.g;
                a.c = e;
                break a
            } - 1 < c ? (a.h = Math.max(c, b + 1 - a.g), a.c = null) : a.h = Number.MAX_VALUE
        }
        a.m = {};
        if (d)
            for (c = 0; c < d.length; c++) b = d[c], b < a.h ? (b += a.g, a.b[b] = a.b[b] || ef) : (ff(a), a.c[b] = a.c[b] || ef)
    },
    ef = Object.freeze ? Object.freeze([]) : [],
    ff = function(a) {
        var b = a.h + a.g;
        a.b[b] || (a.c =
            a.b[b] = {})
    },
    hf = function(a, b) {
        if (b < a.h) {
            b += a.g;
            var c = a.b[b];
            return c === ef ? a.b[b] = [] : c
        }
        if (a.c) return c = a.c[b], c === ef ? a.c[b] = [] : c
    },
    jf = function(a, b) {
        a = hf(a, 1);
        return null == a ? b : a
    },
    A = function(a, b, c) {
        gb(a, cf);
        b < a.h ? a.b[b + a.g] = c : (ff(a), a.c[b] = c);
        return a
    },
    kf = function(a, b, c) {
        a.a || (a.a = {});
        if (!a.a[c]) {
            for (var d = hf(a, c), e = [], f = 0; f < d.length; f++) e[f] = new b(d[f]);
            a.a[c] = e
        }
    },
    lf = function(a, b, c) {
        gb(a, cf);
        a.a || (a.a = {});
        var d = c ? c.zb() : c;
        a.a[b] = c;
        return A(a, b, d)
    },
    mf = function(a, b, c) {
        gb(a, cf);
        a.a || (a.a = {});
        c = c || [];
        for (var d = [], e = 0; e < c.length; e++) d[e] = c[e].zb();
        a.a[b] = c;
        return A(a, b, d)
    },
    nf = function(a, b, c) {
        kf(a, c, b);
        var d = a.a[b];
        d || (d = a.a[b] = []);
        c = new c;
        a = hf(a, b);
        d.push(c);
        a.push(c.zb());
        return c
    },
    of = function(a) {
        if (a.a)
            for (var b in a.a) {
                var c = a.a[b];
                if (Ia(c))
                    for (var d = 0; d < c.length; d++) c[d] && c[d].zb();
                else c && c.zb()
            }
    };
cf.prototype.zb = function() {
    of (this);
    return this.b
};
cf.prototype.o = df ? function() {
    var a = Uint8Array.prototype.toJSON;
    Uint8Array.prototype.toJSON = function() {
        return bf(this)
    };
    try {
        return JSON.stringify(this.b && this.zb(), pf)
    } finally {
        Uint8Array.prototype.toJSON = a
    }
} : function() {
    return JSON.stringify(this.b && this.zb(), pf)
};
var pf = function(a, b) {
    return "number" !== typeof b || !isNaN(b) && Infinity !== b && -Infinity !== b ? b : String(b)
};
cf.prototype.toString = function() {
    of (this);
    return this.b.toString()
};
var rf = function(a) {
        return new a.constructor(qf(a.zb()))
    },
    qf = function(a) {
        if (Ia(a)) {
            for (var b = Array(a.length), c = 0; c < a.length; c++) {
                var d = a[c];
                null != d && (b[c] = "object" == typeof d ? qf(v(d)) : d)
            }
            return b
        }
        if (df && a instanceof Uint8Array) return new Uint8Array(a);
        b = {};
        for (c in a) d = a[c], null != d && (b[c] = "object" == typeof d ? qf(v(d)) : d);
        return b
    };
var tf = function(a) {
    gf(this, a, -1, sf)
};
t(tf, cf);
var sf = [2];
var vf = function(a) {
    gf(this, a, -1, uf)
};
t(vf, cf);
var uf = [1, 2, 3, 4];
var wf = function(a) {
    if (!a) return "";
    a = a.split("#")[0].split("?")[0];
    a = a.toLowerCase();
    0 == a.indexOf("//") && (a = window.location.protocol + a);
    /^[\w\-]*:\/\//.test(a) || (a = window.location.href);
    var b = a.substring(a.indexOf("://") + 3),
        c = b.indexOf("/"); - 1 != c && (b = b.substring(0, c));
    a = a.substring(0, a.indexOf("://"));
    if ("http" !== a && "https" !== a && "chrome-extension" !== a && "file" !== a && "android-app" !== a && "chrome-search" !== a && "app" !== a) throw Error("Invalid URI scheme in origin: " + a);
    c = "";
    var d = b.indexOf(":");
    if (-1 != d) {
        var e =
            b.substring(d + 1);
        b = b.substring(0, d);
        if ("http" === a && "80" !== e || "https" === a && "443" !== e) c = ":" + e
    }
    return a + "://" + b + c
};
var xf = {
    ascii_tlds: "aarp abarth abb abbott abbvie abc able abogado abudhabi ac academy accenture accountant accountants aco actor ad adac ads adult ae aeg aero aetna af afamilycompany afl africa ag agakhan agency ai aig aigo airbus airforce airtel akdn al alfaromeo alibaba alipay allfinanz allstate ally alsace alstom am americanexpress americanfamily amex amfam amica amsterdam analytics android anquan anz ao aol apartments app apple aq aquarelle ar arab aramco archi army arpa art arte as asda asia associates at athleta attorney au auction audi audible audio auspost author auto autos avianca aw aws ax axa az azure ba baby baidu banamex bananarepublic band bank bar barcelona barclaycard barclays barefoot bargains baseball basketball bauhaus bayern bb bbc bbt bbva bcg bcn bd be beats beauty beer bentley berlin best bestbuy bet bf bg bh bharti bi bible bid bike bing bingo bio biz bj black blackfriday blockbuster blog bloomberg blue bm bms bmw bn bnl bnpparibas bo boats boehringer bofa bom bond boo book booking bosch bostik boston bot boutique box br bradesco bridgestone broadway broker brother brussels bs bt budapest bugatti build builders business buy buzz bv bw by bz bzh ca cab cafe cal call calvinklein cam camera camp cancerresearch canon capetown capital capitalone car caravan cards care career careers cars cartier casa case caseih cash casino cat catering catholic cba cbn cbre cbs cc cd ceb center ceo cern cf cfa cfd cg ch chanel channel charity chase chat cheap chintai christmas chrome chrysler church ci cipriani circle cisco citadel citi citic city cityeats ck cl claims cleaning click clinic clinique clothing cloud club clubmed cm cn co coach codes coffee college cologne com comcast commbank community company compare computer comsec condos construction consulting contact contractors cooking cookingchannel cool coop corsica country coupon coupons courses cr credit creditcard creditunion cricket crown crs cruise cruises csc cu cuisinella cv cw cx cy cymru cyou cz dabur dad dance data date dating datsun day dclk dds de deal dealer deals degree delivery dell deloitte delta democrat dental dentist desi design dev dhl diamonds diet digital direct directory discount discover dish diy dj dk dm dnp do docs doctor dodge dog doha domains dot download drive dtv dubai duck dunlop duns dupont durban dvag dvr dz earth eat ec eco edeka edu education ee eg email emerck energy engineer engineering enterprises epson equipment er ericsson erni es esq estate esurance et etisalat eu eurovision eus events everbank exchange expert exposed express extraspace fage fail fairwinds faith family fan fans farm farmers fashion fast fedex feedback ferrari ferrero fi fiat fidelity fido film final finance financial fire firestone firmdale fish fishing fit fitness fj fk flickr flights flir florist flowers fly fm fo foo food foodnetwork football ford forex forsale forum foundation fox fr free fresenius frl frogans frontdoor frontier ftr fujitsu fujixerox fun fund furniture futbol fyi ga gal gallery gallo gallup game games gap garden gb gbiz gd gdn ge gea gent genting george gf gg ggee gh gi gift gifts gives giving gl glade glass gle global globo gm gmail gmbh gmo gmx gn godaddy gold goldpoint golf goo goodyear goog google gop got gov gp gq gr grainger graphics gratis green gripe grocery group gs gt gu guardian gucci guge guide guitars guru gw gy hair hamburg hangout haus hbo hdfc hdfcbank health healthcare help helsinki here hermes hgtv hiphop hisamitsu hitachi hiv hk hkt hm hn hockey holdings holiday homedepot homegoods homes homesense honda honeywell horse hospital host hosting hot hoteles hotels hotmail house how hr hsbc ht hu hughes hyatt hyundai ibm icbc ice icu id ie ieee ifm ikano il im imamat imdb immo immobilien in inc industries infiniti info ing ink institute insurance insure int intel international intuit investments io ipiranga iq ir irish is iselect ismaili ist istanbul it itau itv iveco jaguar java jcb jcp je jeep jetzt jewelry jio jll jm jmp jnj jo jobs joburg jot joy jp jpmorgan jprs juegos juniper kaufen kddi ke kerryhotels kerrylogistics kerryproperties kfh kg kh ki kia kim kinder kindle kitchen kiwi km kn koeln komatsu kosher kp kpmg kpn kr krd kred kuokgroup kw ky kyoto kz la lacaixa ladbrokes lamborghini lamer lancaster lancia lancome land landrover lanxess lasalle lat latino latrobe law lawyer lb lc lds lease leclerc lefrak legal lego lexus lgbt li liaison lidl life lifeinsurance lifestyle lighting like lilly limited limo lincoln linde link lipsy live living lixil lk llc loan loans locker locus loft lol london lotte lotto love lpl lplfinancial lr ls lt ltd ltda lu lundbeck lupin luxe luxury lv ly ma macys madrid maif maison makeup man management mango map market marketing markets marriott marshalls maserati mattel mba mc mckinsey md me med media meet melbourne meme memorial men menu merckmsd metlife mg mh miami microsoft mil mini mint mit mitsubishi mk ml mlb mls mm mma mn mo mobi mobile mobily moda moe moi mom monash money monster mopar mormon mortgage moscow moto motorcycles mov movie movistar mp mq mr ms msd mt mtn mtr mu museum mutual mv mw mx my mz na nab nadex nagoya name nationwide natura navy nba nc ne nec net netbank netflix network neustar new newholland news next nextdirect nexus nf nfl ng ngo nhk ni nico nike nikon ninja nissan nissay nl no nokia northwesternmutual norton now nowruz nowtv np nr nra nrw ntt nu nyc nz obi observer off office okinawa olayan olayangroup oldnavy ollo om omega one ong onl online onyourside ooo open oracle orange org organic origins osaka otsuka ott ovh pa page panasonic paris pars partners parts party passagens pay pccw pe pet pf pfizer pg ph pharmacy phd philips phone photo photography photos physio piaget pics pictet pictures pid pin ping pink pioneer pizza pk pl place play playstation plumbing plus pm pn pnc pohl poker politie porn post pr pramerica praxi press prime pro prod productions prof progressive promo properties property protection pru prudential ps pt pub pw pwc py qa qpon quebec quest qvc racing radio raid re read realestate realtor realty recipes red redstone redumbrella rehab reise reisen reit reliance ren rent rentals repair report republican rest restaurant review reviews rexroth rich richardli ricoh rightathome ril rio rip rmit ro rocher rocks rodeo rogers room rs rsvp ru rugby ruhr run rw rwe ryukyu sa saarland safe safety sakura sale salon samsclub samsung sandvik sandvikcoromant sanofi sap sarl sas save saxo sb sbi sbs sc sca scb schaeffler schmidt scholarships school schule schwarz science scjohnson scor scot sd se search seat secure security seek select sener services ses seven sew sex sexy sfr sg sh shangrila sharp shaw shell shia shiksha shoes shop shopping shouji show showtime shriram si silk sina singles site sj sk ski skin sky skype sl sling sm smart smile sn sncf so soccer social softbank software sohu solar solutions song sony soy space sport spot spreadbetting sr srl srt ss st stada staples star starhub statebank statefarm stc stcgroup stockholm storage store stream studio study style su sucks supplies supply support surf surgery suzuki sv swatch swiftcover swiss sx sy sydney symantec systems sz tab taipei talk taobao target tatamotors tatar tattoo tax taxi tc tci td tdk team tech technology tel telefonica temasek tennis teva tf tg th thd theater theatre tiaa tickets tienda tiffany tips tires tirol tj tjmaxx tjx tk tkmaxx tl tm tmall tn to today tokyo tools top toray toshiba total tours town toyota toys tr trade trading training travel travelchannel travelers travelersinsurance trust trv tt tube tui tunes tushu tv tvs tw tz ua ubank ubs uconnect ug uk unicom university uno uol ups us uy uz va vacations vana vanguard vc ve vegas ventures verisign versicherung vet vg vi viajes video vig viking villas vin vip virgin visa vision vistaprint viva vivo vlaanderen vn vodka volkswagen volvo vote voting voto voyage vu vuelos wales walmart walter wang wanggou warman watch watches weather weatherchannel webcam weber website wed wedding weibo weir wf whoswho wien wiki williamhill win windows wine winners wme wolterskluwer woodside work works world wow ws wtc wtf xbox xerox xfinity xihuan xin xn--11b4c3d xn--1ck2e1b xn--1qqw23a xn--2scrj9c xn--30rr7y xn--3bst00m xn--3ds443g xn--3e0b707e xn--3hcrj9c xn--3oq18vl8pn36a xn--3pxu8k xn--42c2d9a xn--45br5cyl xn--45brj9c xn--45q11c xn--4gbrim xn--54b7fta0cc xn--55qw42g xn--55qx5d xn--5su34j936bgsg xn--5tzm5g xn--6frz82g xn--6qq986b3xl xn--80adxhks xn--80ao21a xn--80aqecdr1a xn--80asehdb xn--80aswg xn--8y0a063a xn--90a3ac xn--90ae xn--90ais xn--9dbq2a xn--9et52u xn--9krt00a xn--b4w605ferd xn--bck1b9a5dre4c xn--c1avg xn--c2br7g xn--cck2b3b xn--cg4bki xn--clchc0ea0b2g2a9gcd xn--czr694b xn--czrs0t xn--czru2d xn--d1acj3b xn--d1alf xn--e1a4c xn--eckvdtc9d xn--efvy88h xn--estv75g xn--fct429k xn--fhbei xn--fiq228c5hs xn--fiq64b xn--fiqs8s xn--fiqz9s xn--fjq720a xn--flw351e xn--fpcrj9c3d xn--fzc2c9e2c xn--fzys8d69uvgm xn--g2xx48c xn--gckr3f0f xn--gecrj9c xn--gk3at1e xn--h2breg3eve xn--h2brj9c xn--h2brj9c8c xn--hxt814e xn--i1b6b1a6a2e xn--imr513n xn--io0a7i xn--j1aef xn--j1amh xn--j6w193g xn--jlq61u9w7b xn--jvr189m xn--kcrx77d1x4a xn--kprw13d xn--kpry57d xn--kpu716f xn--kput3i xn--l1acc xn--lgbbat1ad8j xn--mgb9awbf xn--mgba3a3ejt xn--mgba3a4f16a xn--mgba7c0bbn0a xn--mgbaakc7dvf xn--mgbaam7a8h xn--mgbab2bd xn--mgbah1a3hjkrd xn--mgbai9azgqp6j xn--mgbayh7gpa xn--mgbb9fbpob xn--mgbbh1a xn--mgbbh1a71e xn--mgbc0a9azcg xn--mgbca7dzdo xn--mgberp4a5d4ar xn--mgbgu82a xn--mgbi4ecexp xn--mgbpl2fh xn--mgbt3dhd xn--mgbtx2b xn--mgbx4cd0ab xn--mix891f xn--mk1bu44c xn--mxtq1m xn--ngbc5azd xn--ngbe9e0a xn--ngbrx xn--node xn--nqv7f xn--nqv7fs00ema xn--nyqy26a xn--o3cw4h xn--ogbpf8fl xn--otu796d xn--p1acf xn--p1ai xn--pbt977c xn--pgbs0dh xn--pssy2u xn--q9jyb4c xn--qcka1pmc xn--qxam xn--rhqv96g xn--rovu88b xn--rvc1e0am3e xn--s9brj9c xn--ses554g xn--t60b56a xn--tckwe xn--tiq49xqyj xn--unup4y xn--vermgensberater-ctb xn--vermgensberatung-pwb xn--vhquv xn--vuq861b xn--w4r85el8fhu5dnra xn--w4rs40l xn--wgbh1c xn--wgbl6a xn--xhq521b xn--xkc2al3hye2a xn--xkc2dl3a5ee0h xn--y9a3aq xn--yfro4i67o xn--ygbi2ammx xn--zfr164b xxx xyz yachts yahoo yamaxun yandex ye yodobashi yoga yokohama you youtube yt yun za zappos zara zero zip zm zone zuerich zw".split(" "),
    unicode_tlds: "\u0915\u0949\u092e \u30bb\u30fc\u30eb \u4f5b\u5c71 \u0cad\u0cbe\u0cb0\u0ca4 \u6148\u5584 \u96c6\u56e2 \u5728\u7ebf \ud55c\uad6d \u0b2d\u0b3e\u0b30\u0b24 \u5927\u4f17\u6c7d\u8f66 \u70b9\u770b \u0e04\u0e2d\u0e21 \u09ad\u09be\u09f0\u09a4 \u09ad\u09be\u09b0\u09a4 \u516b\u5366 \u0645\u0648\u0642\u0639 \u09ac\u09be\u0982\u09b2\u09be \u516c\u76ca \u516c\u53f8 \u9999\u683c\u91cc\u62c9 \u7f51\u7ad9 \u79fb\u52a8 \u6211\u7231\u4f60 \u043c\u043e\u0441\u043a\u0432\u0430 \u049b\u0430\u0437 \u043a\u0430\u0442\u043e\u043b\u0438\u043a \u043e\u043d\u043b\u0430\u0439\u043d \u0441\u0430\u0439\u0442 \u8054\u901a \u0441\u0440\u0431 \u0431\u0433 \u0431\u0435\u043b \u05e7\u05d5\u05dd \u65f6\u5c1a \u5fae\u535a \u6de1\u9a6c\u9521 \u30d5\u30a1\u30c3\u30b7\u30e7\u30f3 \u043e\u0440\u0433 \u0928\u0947\u091f \u30b9\u30c8\u30a2 \uc0bc\uc131 \u0b9a\u0bbf\u0b99\u0bcd\u0b95\u0baa\u0bcd\u0baa\u0bc2\u0bb0\u0bcd \u5546\u6807 \u5546\u5e97 \u5546\u57ce \u0434\u0435\u0442\u0438 \u043c\u043a\u0434 \u0435\u044e \u30dd\u30a4\u30f3\u30c8 \u65b0\u95fb \u5de5\u884c \u5bb6\u96fb \u0643\u0648\u0645 \u4e2d\u6587\u7f51 \u4e2d\u4fe1 \u4e2d\u56fd \u4e2d\u570b \u5a31\u4e50 \u8c37\u6b4c \u0c2d\u0c3e\u0c30\u0c24\u0c4d \u0dbd\u0d82\u0d9a\u0dcf \u96fb\u8a0a\u76c8\u79d1 \u8d2d\u7269 \u30af\u30e9\u30a6\u30c9 \u0aad\u0abe\u0ab0\u0aa4 \u901a\u8ca9 \u092d\u093e\u0930\u0924\u092e\u094d \u092d\u093e\u0930\u0924 \u092d\u093e\u0930\u094b\u0924 \u7f51\u5e97 \u0938\u0902\u0917\u0920\u0928 \u9910\u5385 \u7f51\u7edc \u043a\u043e\u043c \u0443\u043a\u0440 \u9999\u6e2f \u8bfa\u57fa\u4e9a \u98df\u54c1 \u98de\u5229\u6d66 \u53f0\u6e7e \u53f0\u7063 \u624b\u8868 \u624b\u673a \u043c\u043e\u043d \u0627\u0644\u062c\u0632\u0627\u0626\u0631 \u0639\u0645\u0627\u0646 \u0627\u0631\u0627\u0645\u0643\u0648 \u0627\u06cc\u0631\u0627\u0646 \u0627\u0644\u0639\u0644\u064a\u0627\u0646 \u0627\u062a\u0635\u0627\u0644\u0627\u062a \u0627\u0645\u0627\u0631\u0627\u062a \u0628\u0627\u0632\u0627\u0631 \u0645\u0648\u0631\u064a\u062a\u0627\u0646\u064a\u0627 \u067e\u0627\u06a9\u0633\u062a\u0627\u0646 \u0627\u0644\u0627\u0631\u062f\u0646 \u0645\u0648\u0628\u0627\u064a\u0644\u064a \u0628\u0627\u0631\u062a \u0628\u06be\u0627\u0631\u062a \u0627\u0644\u0645\u063a\u0631\u0628 \u0627\u0628\u0648\u0638\u0628\u064a \u0627\u0644\u0633\u0639\u0648\u062f\u064a\u0629 \u0680\u0627\u0631\u062a \u0643\u0627\u062b\u0648\u0644\u064a\u0643 \u0633\u0648\u062f\u0627\u0646 \u0647\u0645\u0631\u0627\u0647 \u0639\u0631\u0627\u0642 \u0645\u0644\u064a\u0633\u064a\u0627 \u6fb3\u9580 \ub2f7\ucef4 \u653f\u5e9c \u0634\u0628\u0643\u0629 \u0628\u064a\u062a\u0643 \u0639\u0631\u0628 \u10d2\u10d4 \u673a\u6784 \u7ec4\u7ec7\u673a\u6784 \u5065\u5eb7 \u0e44\u0e17\u0e22 \u0633\u0648\u0631\u064a\u0629 \u62db\u8058 \u0440\u0443\u0441 \u0440\u0444 \u73e0\u5b9d \u062a\u0648\u0646\u0633 \u5927\u62ff \u307f\u3093\u306a \u30b0\u30fc\u30b0\u30eb \u03b5\u03bb \u4e16\u754c \u66f8\u7c4d \u0d2d\u0d3e\u0d30\u0d24\u0d02 \u0a2d\u0a3e\u0a30\u0a24 \u7f51\u5740 \ub2f7\ub137 \u30b3\u30e0 \u5929\u4e3b\u6559 \u6e38\u620f verm\u00f6gensberater verm\u00f6gensberatung \u4f01\u4e1a \u4fe1\u606f \u5609\u91cc\u5927\u9152\u5e97 \u5609\u91cc \u0645\u0635\u0631 \u0642\u0637\u0631 \u5e7f\u4e1c \u0b87\u0bb2\u0b99\u0bcd\u0b95\u0bc8 \u0b87\u0ba8\u0bcd\u0ba4\u0bbf\u0baf\u0bbe \u0570\u0561\u0575 \u65b0\u52a0\u5761 \u0641\u0644\u0633\u0637\u064a\u0646 \u653f\u52a1".split(" ")
};
try {
    (new self.OffscreenCanvas(0, 0)).getContext("2d")
} catch (a) {}
var yf = !y || Se(9),
    zf = !ye && !y || y && Se(9) || ye && Qe("1.9.1"),
    Af = y && !Qe("9"),
    Bf = y || ve || ze,
    Cf = y && !Se(9);
var Df = function(a, b) {
    return a + Math.random() * (b - a)
};
var Ef = function(a, b) {
    this.x = void 0 !== a ? a : 0;
    this.a = void 0 !== b ? b : 0
};
Ef.prototype.toString = function() {
    return "(" + this.x + ", " + this.a + ")"
};
var Ff = function(a, b) {
    return new Ef(a.x - b.x, a.a - b.a)
};
Ef.prototype.ceil = function() {
    this.x = Math.ceil(this.x);
    this.a = Math.ceil(this.a);
    return this
};
Ef.prototype.floor = function() {
    this.x = Math.floor(this.x);
    this.a = Math.floor(this.a);
    return this
};
Ef.prototype.round = function() {
    this.x = Math.round(this.x);
    this.a = Math.round(this.a);
    return this
};
var Gf = function(a, b) {
    this.width = a;
    this.height = b
};
h = Gf.prototype;
h.toString = function() {
    return "(" + this.width + " x " + this.height + ")"
};
h.aspectRatio = function() {
    return this.width / this.height
};
h.ceil = function() {
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this
};
h.floor = function() {
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this
};
h.round = function() {
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this
};
var Jf = function(a) {
        return a ? new Hf(If(a)) : Va || (Va = new Hf)
    },
    Kf = function(a) {
        return "string" === typeof a ? document.getElementById(a) : a
    },
    Lf = function(a, b) {
        return (b || document).getElementsByTagName(String(a))
    },
    Nf = function(a, b) {
        var c = b || document;
        return c.querySelectorAll && c.querySelector ? c.querySelectorAll("." + a) : Mf(document, "*", a, b)
    },
    B = function(a, b) {
        var c = b || document,
            d = null;
        c.getElementsByClassName ? d = c.getElementsByClassName(a)[0] : d = Of("*", a, b);
        return d || null
    },
    C = function(a, b) {
        b = B(a, b);
        return v(b, "No element found with className: " +
            a)
    },
    Mf = function(a, b, c, d) {
        a = d || a;
        b = b && "*" != b ? String(b).toUpperCase() : "";
        if (a.querySelectorAll && a.querySelector && (b || c)) return a.querySelectorAll(b + (c ? "." + c : ""));
        if (c && a.getElementsByClassName) {
            a = a.getElementsByClassName(c);
            if (b) {
                d = {};
                for (var e = 0, f = 0, g; g = a[f]; f++) b == g.nodeName && (d[e++] = g);
                d.length = e;
                return d
            }
            return a
        }
        a = a.getElementsByTagName(b || "*");
        if (c) {
            d = {};
            for (f = e = 0; g = a[f]; f++) b = g.className, "function" == typeof b.split && rb(b.split(/\s+/), c) && (d[e++] = g);
            d.length = e;
            return d
        }
        return a
    },
    Of = function(a,
        b, c) {
        var d = document,
            e = c || d,
            f = a && "*" != a ? String(a).toUpperCase() : "";
        return e.querySelectorAll && e.querySelector && (f || b) ? e.querySelector(f + (b ? "." + b : "")) : Mf(d, a, b, c)[0] || null
    },
    Qf = function(a, b) {
        Jb(b, function(c, d) {
            c && "object" == typeof c && c.xc && (c = c.ub());
            "style" == d ? a.style.cssText = c : "class" == d ? a.className = c : "for" == d ? a.htmlFor = c : Pf.hasOwnProperty(d) ? a.setAttribute(Pf[d], c) : vc(d, "aria-") || vc(d, "data-") ? a.setAttribute(d, c) : a[d] = c
        })
    },
    Pf = {
        cellpadding: "cellPadding",
        cellspacing: "cellSpacing",
        colspan: "colSpan",
        frameborder: "frameBorder",
        height: "height",
        maxlength: "maxLength",
        nonce: "nonce",
        role: "role",
        rowspan: "rowSpan",
        type: "type",
        usemap: "useMap",
        valign: "vAlign",
        width: "width"
    },
    Sf = function(a) {
        a = a.document;
        a = Rf(a) ? a.documentElement : a.body;
        return new Gf(a.clientWidth, a.clientHeight)
    },
    Uf = function(a) {
        var b = Tf(a);
        a = a.parentWindow || a.defaultView;
        return y && Qe("10") && a.pageYOffset != b.scrollTop ? new Ef(b.scrollLeft, b.scrollTop) : new Ef(a.pageXOffset || b.scrollLeft, a.pageYOffset || b.scrollTop)
    },
    Tf = function(a) {
        return a.scrollingElement ? a.scrollingElement :
            !ze && Rf(a) ? a.documentElement : a.body || a.documentElement
    },
    Vf = function(a) {
        return a ? a.parentWindow || a.defaultView : window
    },
    D = function(a, b, c) {
        return Wf(document, arguments)
    },
    Wf = function(a, b) {
        var c = String(b[0]),
            d = b[1];
        if (!yf && d && (d.name || d.type)) {
            c = ["<", c];
            d.name && c.push(' name="', de(d.name), '"');
            if (d.type) {
                c.push(' type="', de(d.type), '"');
                var e = {};
                Wb(e, d);
                delete e.type;
                d = e
            }
            c.push(">");
            c = c.join("")
        }
        c = Xf(a, c);
        d && ("string" === typeof d ? c.className = d : Ia(d) ? c.className = d.join(" ") : Qf(c, d));
        2 < b.length && Yf(a, c, b,
            2);
        return c
    },
    Yf = function(a, b, c, d) {
        function e(g) {
            g && b.appendChild("string" === typeof g ? a.createTextNode(g) : g)
        }
        for (; d < c.length; d++) {
            var f = c[d];
            !Ja(f) || La(f) && 0 < f.nodeType ? e(f) : w(Zf(f) ? xb(f) : f, e)
        }
    },
    $f = function(a) {
        return Xf(document, a)
    },
    Xf = function(a, b) {
        b = String(b);
        "application/xhtml+xml" === a.contentType && (b = b.toLowerCase());
        return a.createElement(b)
    },
    ag = function(a) {
        return document.createTextNode(String(a))
    },
    bg = function(a, b) {
        var c = Xf(a, "DIV");
        y ? (Td(c, Ld(Nd, b)), c.removeChild(v(c.firstChild))) : Td(c, b);
        if (1 ==
            c.childNodes.length) c = c.removeChild(v(c.firstChild));
        else {
            for (a = a.createDocumentFragment(); c.firstChild;) a.appendChild(c.firstChild);
            c = a
        }
        return c
    },
    Rf = function(a) {
        return "CSS1Compat" == a.compatMode
    },
    cg = function(a) {
        if (1 != a.nodeType) return !1;
        switch (a.tagName) {
            case "APPLET":
            case "AREA":
            case "BASE":
            case "BR":
            case "COL":
            case "COMMAND":
            case "EMBED":
            case "FRAME":
            case "HR":
            case "IMG":
            case "INPUT":
            case "IFRAME":
            case "ISINDEX":
            case "KEYGEN":
            case "LINK":
            case "NOFRAMES":
            case "NOSCRIPT":
            case "META":
            case "OBJECT":
            case "PARAM":
            case "SCRIPT":
            case "SOURCE":
            case "STYLE":
            case "TRACK":
            case "WBR":
                return !1
        }
        return !0
    },
    dg = function(a, b) {
        v(null != a && null != b, "goog.dom.appendChild expects non-null arguments");
        a.appendChild(b)
    },
    eg = function(a, b) {
        Yf(If(a), a, arguments, 1)
    },
    fg = function(a) {
        for (var b; b = a.firstChild;) a.removeChild(b)
    },
    gg = function(a, b) {
        v(null != a && null != b, "goog.dom.insertSiblingBefore expects non-null arguments");
        b.parentNode && b.parentNode.insertBefore(a, b)
    },
    hg = function(a, b) {
        v(null != a && null != b, "goog.dom.insertSiblingAfter expects non-null arguments");
        b.parentNode && b.parentNode.insertBefore(a, b.nextSibling)
    },
    ig =
    function(a, b, c) {
        v(null != a, "goog.dom.insertChildAt expects a non-null parent");
        a.insertBefore(b, a.childNodes[c] || null)
    },
    jg = function(a) {
        return a && a.parentNode ? a.parentNode.removeChild(a) : null
    },
    kg = function(a) {
        return zf && void 0 != a.children ? a.children : jb(a.childNodes, function(b) {
            return 1 == b.nodeType
        })
    },
    mg = function(a) {
        return void 0 !== a.firstElementChild ? a.firstElementChild : lg(a.firstChild, !0)
    },
    lg = function(a, b) {
        for (; a && 1 != a.nodeType;) a = b ? a.nextSibling : a.previousSibling;
        return a
    },
    ng = function(a) {
        return La(a) &&
            1 == a.nodeType
    },
    og = function(a) {
        var b;
        if (Bf && !(y && Qe("9") && !Qe("10") && n.SVGElement && a instanceof n.SVGElement) && (b = a.parentElement)) return b;
        b = a.parentNode;
        return ng(b) ? b : null
    },
    pg = function(a, b) {
        if (!a || !b) return !1;
        if (a.contains && 1 == b.nodeType) return a == b || a.contains(b);
        if ("undefined" != typeof a.compareDocumentPosition) return a == b || !!(a.compareDocumentPosition(b) & 16);
        for (; b && a != b;) b = b.parentNode;
        return b == a
    },
    sg = function(a, b) {
        if (a == b) return 0;
        if (a.compareDocumentPosition) return a.compareDocumentPosition(b) &
            2 ? 1 : -1;
        if (y && !Se(9)) {
            if (9 == a.nodeType) return -1;
            if (9 == b.nodeType) return 1
        }
        if ("sourceIndex" in a || a.parentNode && "sourceIndex" in a.parentNode) {
            var c = 1 == a.nodeType,
                d = 1 == b.nodeType;
            if (c && d) return a.sourceIndex - b.sourceIndex;
            var e = a.parentNode,
                f = b.parentNode;
            return e == f ? qg(a, b) : !c && pg(e, b) ? -1 * rg(a, b) : !d && pg(f, a) ? rg(b, a) : (c ? a.sourceIndex : e.sourceIndex) - (d ? b.sourceIndex : f.sourceIndex)
        }
        d = If(a);
        c = d.createRange();
        c.selectNode(a);
        c.collapse(!0);
        a = d.createRange();
        a.selectNode(b);
        a.collapse(!0);
        return c.compareBoundaryPoints(n.Range.START_TO_END,
            a)
    },
    rg = function(a, b) {
        var c = a.parentNode;
        if (c == b) return -1;
        for (; b.parentNode != c;) b = b.parentNode;
        return qg(b, a)
    },
    qg = function(a, b) {
        for (; b = b.previousSibling;)
            if (b == a) return -1;
        return 1
    },
    tg = function(a) {
        var b, c = arguments.length;
        if (!c) return null;
        if (1 == c) return arguments[0];
        var d = [],
            e = Infinity;
        for (b = 0; b < c; b++) {
            for (var f = [], g = arguments[b]; g;) f.unshift(g), g = g.parentNode;
            d.push(f);
            e = Math.min(e, f.length)
        }
        f = null;
        for (b = 0; b < e; b++) {
            g = d[0][b];
            for (var k = 1; k < c; k++)
                if (g != d[k][b]) return f;
            f = g
        }
        return f
    },
    If = function(a) {
        v(a,
            "Node cannot be null or undefined.");
        return 9 == a.nodeType ? a : a.ownerDocument || a.document
    },
    ug = function(a) {
        return a.contentDocument || a.contentWindow.document
    },
    E = function(a, b) {
        v(null != a, "goog.dom.setTextContent expects a non-null value for node");
        if ("textContent" in a) a.textContent = b;
        else if (3 == a.nodeType) a.data = String(b);
        else if (a.firstChild && 3 == a.firstChild.nodeType) {
            for (; a.lastChild != a.firstChild;) a.removeChild(v(a.lastChild));
            a.firstChild.data = String(b)
        } else {
            fg(a);
            var c = If(a);
            a.appendChild(c.createTextNode(String(b)))
        }
    },
    vg = {
        SCRIPT: 1,
        STYLE: 1,
        HEAD: 1,
        IFRAME: 1,
        OBJECT: 1
    },
    wg = {
        IMG: " ",
        BR: "\n"
    },
    xg = function(a, b) {
        b ? a.tabIndex = 0 : (a.tabIndex = -1, a.removeAttribute("tabIndex"))
    },
    zg = function(a) {
        return y && !Qe("9") ? (a = a.getAttributeNode("tabindex"), null != a && a.specified) : a.hasAttribute("tabindex")
    },
    Ag = function(a) {
        a = a.tabIndex;
        return "number" === typeof a && 0 <= a && 32768 > a
    },
    Cg = function(a) {
        if (Af && null !== a && "innerText" in a) a = $d(a.innerText);
        else {
            var b = [];
            Bg(a, b, !0);
            a = b.join("")
        }
        a = a.replace(/ \xAD /g, " ").replace(/\xAD/g, "");
        a = a.replace(/\u200B/g,
            "");
        Af || (a = a.replace(/ +/g, " "));
        " " != a && (a = a.replace(/^\s*/, ""));
        return a
    },
    Dg = function(a) {
        var b = [];
        Bg(a, b, !1);
        return b.join("")
    },
    Bg = function(a, b, c) {
        if (!(a.nodeName in vg))
            if (3 == a.nodeType) c ? b.push(String(a.nodeValue).replace(/(\r\n|\r|\n)/g, "")) : b.push(a.nodeValue);
            else if (a.nodeName in wg) b.push(wg[a.nodeName]);
        else
            for (a = a.firstChild; a;) Bg(a, b, c), a = a.nextSibling
    },
    Zf = function(a) {
        if (a && "number" == typeof a.length) {
            if (La(a)) return "function" == typeof a.item || "string" == typeof a.item;
            if (Ka(a)) return "function" ==
                typeof a.item
        }
        return !1
    },
    Fg = function(a) {
        return Eg(a, function(b) {
            return "string" === typeof b.className && rb(b.className.split(/\s+/), "gt-baf-entry-clickable")
        }, void 0)
    },
    Eg = function(a, b, c) {
        for (var d = 0; a && (null == c || d <= c);) {
            v("parentNode" != a.name);
            if (b(a)) return a;
            a = a.parentNode;
            d++
        }
        return null
    },
    Gg = function(a) {
        try {
            var b = a && a.activeElement;
            return b && b.nodeName ? b : null
        } catch (c) {
            return null
        }
    },
    Hf = function(a) {
        this.a = a || n.document || document
    };
Hf.prototype.j = function(a) {
    return "string" === typeof a ? this.a.getElementById(a) : a
};
Hf.prototype.c = Hf.prototype.j;
Hf.prototype.wd = function(a, b) {
    return B(a, b || this.a)
};
Hf.prototype.b = function(a, b, c) {
    return Wf(this.a, arguments)
};
var Hg = function(a, b) {
        return Xf(a.a, b)
    },
    Ig = function(a) {
        a = a.a;
        return a.parentWindow || a.defaultView
    };
h = Hf.prototype;
h.appendChild = dg;
h.ni = eg;
h.vf = fg;
h.ri = jg;
h.oi = kg;
h.ki = mg;
h.mm = ng;
h.contains = pg;
h.wf = E;
h.pi = Cg;
var Jg = function() {
    this.La = this.La;
    this.Fa = this.Fa
};
Jg.prototype.La = !1;
Jg.prototype.isDisposed = function() {
    return this.La
};
Jg.prototype.Ia = function() {
    this.La || (this.La = !0, this.T())
};
var Lg = function(a, b) {
    b = Sa(Kg, b);
    a.La ? b() : (a.Fa || (a.Fa = []), a.Fa.push(b))
};
Jg.prototype.T = function() {
    if (this.Fa)
        for (; this.Fa.length;) this.Fa.shift()()
};
var Kg = function(a) {
    a && "function" == typeof a.Ia && a.Ia()
};
var F = function(a, b) {
    this.type = a;
    this.a = this.target = b;
    this.defaultPrevented = this.c = !1;
    this.dj = !0
};
F.prototype.stopPropagation = function() {
    this.c = !0
};
F.prototype.preventDefault = function() {
    this.defaultPrevented = !0;
    this.dj = !1
};
var Mg = Object.freeze || function(a) {
    return a
};
var Ng = !y || Se(9),
    Og = !y || Se(9),
    Pg = y && !Qe("9"),
    Qg = function() {
        if (!n.addEventListener || !Object.defineProperty) return !1;
        var a = !1,
            b = Object.defineProperty({}, "passive", {
                get: function() {
                    a = !0
                }
            });
        try {
            n.addEventListener("test", Ea, b), n.removeEventListener("test", Ea, b)
        } catch (c) {}
        return a
    }();
var Rg;
Rg = ze ? "webkitTransitionEnd" : ve ? "otransitionend" : "transitionend";
var Sg = {
    Jd: "mousedown",
    Kd: "mouseup",
    me: "mousecancel",
    Rp: "mousemove",
    Tp: "mouseover",
    Sp: "mouseout",
    Pp: "mouseenter",
    Qp: "mouseleave"
};
var Tg = function(a, b) {
    F.call(this, a ? a.type : "");
    this.relatedTarget = this.a = this.target = null;
    this.button = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.key = "";
    this.keyCode = 0;
    this.metaKey = this.shiftKey = this.altKey = this.ctrlKey = !1;
    this.state = null;
    this.g = !1;
    this.pointerId = 0;
    this.pointerType = "";
    this.b = null;
    a && this.init(a, b)
};
t(Tg, F);
var Ug = Mg([1, 4, 2]),
    Vg = Mg({
        2: "touch",
        3: "pen",
        4: "mouse"
    });
Tg.prototype.init = function(a, b) {
    var c = this.type = a.type,
        d = a.changedTouches && a.changedTouches.length ? a.changedTouches[0] : null;
    this.target = a.target || a.srcElement;
    this.a = b;
    (b = a.relatedTarget) ? ye && (te(b, "nodeName") || (b = null)): "mouseover" == c ? b = a.fromElement : "mouseout" == c && (b = a.toElement);
    this.relatedTarget = b;
    d ? (this.clientX = void 0 !== d.clientX ? d.clientX : d.pageX, this.clientY = void 0 !== d.clientY ? d.clientY : d.pageY, this.screenX = d.screenX || 0, this.screenY = d.screenY || 0) : (this.clientX = void 0 !== a.clientX ? a.clientX :
        a.pageX, this.clientY = void 0 !== a.clientY ? a.clientY : a.pageY, this.screenX = a.screenX || 0, this.screenY = a.screenY || 0);
    this.button = a.button;
    this.keyCode = a.keyCode || 0;
    this.key = a.key || "";
    this.ctrlKey = a.ctrlKey;
    this.altKey = a.altKey;
    this.shiftKey = a.shiftKey;
    this.metaKey = a.metaKey;
    this.g = Ce ? a.metaKey : a.ctrlKey;
    this.pointerId = a.pointerId || 0;
    this.pointerType = "string" === typeof a.pointerType ? a.pointerType : Vg[a.pointerType] || "";
    this.state = a.state;
    this.b = a;
    a.defaultPrevented && this.preventDefault()
};
var Wg = function(a) {
    return (Ng ? 0 == a.b.button : "click" == a.type ? !0 : !!(a.b.button & Ug[0])) && !(ze && Ce && a.ctrlKey)
};
Tg.prototype.stopPropagation = function() {
    Tg.D.stopPropagation.call(this);
    this.b.stopPropagation ? this.b.stopPropagation() : this.b.cancelBubble = !0
};
Tg.prototype.preventDefault = function() {
    Tg.D.preventDefault.call(this);
    var a = this.b;
    if (a.preventDefault) a.preventDefault();
    else if (a.returnValue = !1, Pg) try {
        if (a.ctrlKey || 112 <= a.keyCode && 123 >= a.keyCode) a.keyCode = -1
    } catch (b) {}
};
var Xg = "closure_listenable_" + (1E6 * Math.random() | 0),
    Yg = function(a) {
        return !(!a || !a[Xg])
    },
    Zg = 0;
var $g = function(a, b, c, d, e) {
        this.listener = a;
        this.a = null;
        this.src = b;
        this.type = c;
        this.capture = !!d;
        this.Mf = e;
        this.key = ++Zg;
        this.ae = this.df = !1
    },
    ah = function(a) {
        a.ae = !0;
        a.listener = null;
        a.a = null;
        a.src = null;
        a.Mf = null
    };
var bh = function(a) {
    this.src = a;
    this.a = {};
    this.b = 0
};
bh.prototype.add = function(a, b, c, d, e) {
    var f = a.toString();
    a = this.a[f];
    a || (a = this.a[f] = [], this.b++);
    var g = ch(a, b, d, e); - 1 < g ? (b = a[g], c || (b.df = !1)) : (b = new $g(b, this.src, f, !!d, e), b.df = c, a.push(b));
    return b
};
var dh = function(a, b) {
    var c = b.type;
    if (!(c in a.a)) return !1;
    var d = ub(a.a[c], b);
    d && (ah(b), 0 == a.a[c].length && (delete a.a[c], a.b--));
    return d
};
bh.prototype.pf = function(a, b) {
    a = this.a[a.toString()];
    var c = [];
    if (a)
        for (var d = 0; d < a.length; ++d) {
            var e = a[d];
            e.capture == b && c.push(e)
        }
    return c
};
bh.prototype.Ae = function(a, b, c, d) {
    a = this.a[a.toString()];
    var e = -1;
    a && (e = ch(a, b, c, d));
    return -1 < e ? a[e] : null
};
bh.prototype.hasListener = function(a, b) {
    var c = void 0 !== a,
        d = c ? a.toString() : "",
        e = void 0 !== b;
    return Mb(this.a, function(f) {
        for (var g = 0; g < f.length; ++g)
            if (!(c && f[g].type != d || e && f[g].capture != b)) return !0;
        return !1
    })
};
var ch = function(a, b, c, d) {
    for (var e = 0; e < a.length; ++e) {
        var f = a[e];
        if (!f.ae && f.listener == b && f.capture == !!c && f.Mf == d) return e
    }
    return -1
};
var eh = "closure_lm_" + (1E6 * Math.random() | 0),
    fh = {},
    gh = 0,
    G = function(a, b, c, d, e) {
        if (d && d.once) return hh(a, b, c, d, e);
        if (Ia(b)) {
            for (var f = 0; f < b.length; f++) G(a, b[f], c, d, e);
            return null
        }
        c = ih(c);
        return Yg(a) ? a.listen(b, c, La(d) ? !!d.capture : !!d, e) : jh(a, b, c, !1, d, e)
    },
    jh = function(a, b, c, d, e, f) {
        if (!b) throw Error("Invalid event type");
        var g = La(e) ? !!e.capture : !!e,
            k = kh(a);
        k || (a[eh] = k = new bh(a));
        c = k.add(b, c, d, g, f);
        if (c.a) return c;
        d = lh();
        c.a = d;
        d.src = a;
        d.listener = c;
        if (a.addEventListener) Qg || (e = g), void 0 === e && (e = !1), a.addEventListener(b.toString(),
            d, e);
        else if (a.attachEvent) a.attachEvent(mh(b.toString()), d);
        else if (a.addListener && a.removeListener) v("change" === b, "MediaQueryList only has a change event"), a.addListener(d);
        else throw Error("addEventListener and attachEvent are unavailable.");
        gh++;
        return c
    },
    lh = function() {
        var a = nh,
            b = Og ? function(c) {
                return a.call(b.src, b.listener, c)
            } : function(c) {
                c = a.call(b.src, b.listener, c);
                if (!c) return c
            };
        return b
    },
    hh = function(a, b, c, d, e) {
        if (Ia(b)) {
            for (var f = 0; f < b.length; f++) hh(a, b[f], c, d, e);
            return null
        }
        c = ih(c);
        return Yg(a) ?
            a.fh(b, c, La(d) ? !!d.capture : !!d, e) : jh(a, b, c, !0, d, e)
    },
    oh = function(a, b, c, d, e) {
        if (Ia(b))
            for (var f = 0; f < b.length; f++) oh(a, b[f], c, d, e);
        else d = La(d) ? !!d.capture : !!d, c = ih(c), Yg(a) ? a.Ga(b, c, d, e) : a && (a = kh(a)) && (b = a.Ae(b, c, d, e)) && ph(b)
    },
    ph = function(a) {
        if ("number" === typeof a || !a || a.ae) return !1;
        var b = a.src;
        if (Yg(b)) return dh(b.Ub, a);
        var c = a.type,
            d = a.a;
        b.removeEventListener ? b.removeEventListener(c, d, a.capture) : b.detachEvent ? b.detachEvent(mh(c), d) : b.addListener && b.removeListener && b.removeListener(d);
        gh--;
        (c = kh(b)) ?
        (dh(c, a), 0 == c.b && (c.src = null, b[eh] = null)) : ah(a);
        return !0
    },
    qh = function(a, b) {
        if (!a) return 0;
        if (Yg(a)) return a.nh(b);
        a = kh(a);
        if (!a) return 0;
        var c = 0;
        b = b && b.toString();
        for (var d in a.a)
            if (!b || d == b)
                for (var e = a.a[d].concat(), f = 0; f < e.length; ++f) ph(e[f]) && ++c;
        return c
    },
    mh = function(a) {
        return a in fh ? fh[a] : fh[a] = "on" + a
    },
    sh = function(a, b, c, d) {
        var e = !0;
        if (a = kh(a))
            if (b = a.a[b.toString()])
                for (b = b.concat(), a = 0; a < b.length; a++) {
                    var f = b[a];
                    f && f.capture == c && !f.ae && (f = rh(f, d), e = e && !1 !== f)
                }
        return e
    },
    rh = function(a, b) {
        var c =
            a.listener,
            d = a.Mf || a.src;
        a.df && ph(a);
        return c.call(d, b)
    },
    th = function(a, b) {
        v(Yg(a), "Can not use goog.events.dispatchEvent with non-goog.events.Listenable instance.");
        a.dispatchEvent(b)
    },
    nh = function(a, b) {
        if (a.ae) return !0;
        if (!Og) {
            var c = b || Da("window.event");
            b = new Tg(c, this);
            var d = !0;
            if (!(0 > c.keyCode || void 0 != c.returnValue)) {
                a: {
                    var e = !1;
                    if (0 == c.keyCode) try {
                        c.keyCode = -1;
                        break a
                    } catch (g) {
                        e = !0
                    }
                    if (e || void 0 == c.returnValue) c.returnValue = !0
                }
                c = [];
                for (e = b.a; e; e = e.parentNode) c.push(e);a = a.type;
                for (e = c.length -
                    1; !b.c && 0 <= e; e--) {
                    b.a = c[e];
                    var f = sh(c[e], a, !0, b);
                    d = d && f
                }
                for (e = 0; !b.c && e < c.length; e++) b.a = c[e],
                f = sh(c[e], a, !1, b),
                d = d && f
            }
            return d
        }
        return rh(a, new Tg(b, this))
    },
    kh = function(a) {
        a = a[eh];
        return a instanceof bh ? a : null
    },
    uh = "__closure_events_fn_" + (1E9 * Math.random() >>> 0),
    ih = function(a) {
        v(a, "Listener can not be null.");
        if (Ka(a)) return a;
        v(a.handleEvent, "An object listener must have handleEvent method.");
        a[uh] || (a[uh] = function(b) {
            return a.handleEvent(b)
        });
        return a[uh]
    };
var wh = function(a) {
        if (a.altKey && !a.ctrlKey || a.metaKey || 112 <= a.keyCode && 123 >= a.keyCode) return !1;
        if (vh(a.keyCode)) return !0;
        switch (a.keyCode) {
            case 18:
            case 20:
            case 93:
            case 17:
            case 40:
            case 35:
            case 27:
            case 36:
            case 45:
            case 37:
            case 224:
            case 91:
            case 144:
            case 12:
            case 34:
            case 33:
            case 19:
            case 255:
            case 44:
            case 39:
            case 145:
            case 16:
            case 38:
            case 252:
            case 224:
            case 92:
                return !1;
            case 0:
                return !ye;
            default:
                return 166 > a.keyCode || 183 < a.keyCode
        }
    },
    yh = function(a, b, c, d, e, f) {
        if (ze && !Qe("525")) return !0;
        if (Ce && e) return vh(a);
        if (e &&
            !d) return !1;
        if (!ye) {
            "number" === typeof b && (b = xh(b));
            var g = 17 == b || 18 == b || Ce && 91 == b;
            if ((!c || Ce) && g || Ce && 16 == b && (d || f)) return !1
        }
        if ((ze || we) && d && c) switch (a) {
            case 220:
            case 219:
            case 221:
            case 192:
            case 186:
            case 189:
            case 187:
            case 188:
            case 190:
            case 191:
            case 192:
            case 222:
                return !1
        }
        if (y && d && b == a) return !1;
        switch (a) {
            case 13:
                return ye ? f || e ? !1 : !(c && d) : !0;
            case 27:
                return !(ze || we || ye)
        }
        return ye && (d || e || f) ? !1 : vh(a)
    },
    vh = function(a) {
        if (48 <= a && 57 >= a || 96 <= a && 106 >= a || 65 <= a && 90 >= a || (ze || we) && 0 == a) return !0;
        switch (a) {
            case 32:
            case 43:
            case 63:
            case 64:
            case 107:
            case 109:
            case 110:
            case 111:
            case 186:
            case 59:
            case 189:
            case 187:
            case 61:
            case 188:
            case 190:
            case 191:
            case 192:
            case 222:
            case 219:
            case 220:
            case 221:
            case 163:
            case 58:
                return !0;
            case 173:
                return ye;
            default:
                return !1
        }
    },
    xh = function(a) {
        if (ye) a = zh(a);
        else if (Ce && ze) switch (a) {
            case 93:
                a = 91
        }
        return a
    },
    zh = function(a) {
        switch (a) {
            case 61:
                return 187;
            case 59:
                return 186;
            case 173:
                return 189;
            case 224:
                return 91;
            case 0:
                return 224;
            default:
                return a
        }
    };
var Ah = function(a, b) {
        b = xb(b);
        var c = Gg(document);
        if (c) {
            var d = b.indexOf(c);
            c = d + 1 === b.length ? 0 : d + 1;
            d = 0 > d - 1 ? b.length - 1 : d - 1;
            switch (a.keyCode) {
                case 39:
                    b[c].focus();
                    break;
                case 37:
                    b[d].focus()
            }
        }
    },
    Bh = function(a, b) {
        G(a, "click", b, !1);
        G(a, "keypress", function(c) {
            13 === c.keyCode && b(c)
        }, !1)
    };
var Ch = function(a, b, c, d) {
    window.__gaTracker && __gaTracker("send", "event", a, b, c, d)
};
var Kh = function(a) {
        this.b = !1;
        this.a = [];
        this.c = {};
        for (var b = 0; b < H(a, 1); b++) {
            var c = Dh(a, b),
                d = I(c, 0),
                e = "";
            Eh(c, 3) && (e = I(c, 3));
            d in this.c ? d = this.c[d] : (c = new Fh(d, e), this.c[d] = c, this.a.push(c), d = c);
            for (c = 0; c < Dh(a, b).a(); c++) {
                var f = Dh(a, b).b(c);
                e = f;
                e = 0 == H(e, 2) ? -Pa(e) : Gh(e, 2, 0);
                var g = d;
                if (e in g.b) e = g.b[e];
                else {
                    var k = new Hh;
                    g.b[e] = k;
                    g.a.push(k);
                    e = k
                }
                g = I(f, 0);
                k = I(f, 4);
                var l = Eh(f, 3) ? Ih(f, 3) : -1;
                var m = [];
                for (var q = 0; q < H(f, 1); q++) m.push(Gh(f, 1, q));
                f = e;
                g in f.b || (k = new Jh(g, k, l, m), f.b[g] = k, f.a.push(k));
                this.b |=
                    1 < e.a.length
            }
        }
    },
    Lh = function(a) {
        for (var b = 0, c = 0; c < a.a.length; c++) {
            for (var d = a.a[c], e = 0, f = 0; f < d.a.length; f++) e += d.a[f].a.length;
            b += e
        }
        for (d = c = 0; d < a.a.length; d++) {
            e = a.a[d];
            for (var g = f = 0; g < e.a.length; g++) {
                for (var k = e.a[g], l = 0, m = 0; m < k.a.length; m++) l += k.a[m].a ? 1 : 0;
                f += l
            }
            c += f
        }
        return b - c
    },
    Mh = function(a) {
        for (var b = [], c = 0; c < a.a.length; c++)
            for (var d = 0; d < a.a[c].a.length; d++) Array.prototype.push.apply(b, a.a[c].a[d].a);
        return b
    },
    Nh = function(a) {
        for (var b = 0; b < a.a.length; b++)
            for (var c = 0; c < a.a[b].a.length; c++) a.a[b].a[c].a.sort(function(d,
                e) {
                return e.Pb - d.Pb
            })
    },
    Fh = function(a, b) {
        this.g = a;
        this.c = b;
        this.a = [];
        this.b = {}
    };
Fh.prototype.Pb = function() {
    for (var a = 0, b = 0; b < this.a.length; b++) a = Math.max(a, this.a[b].Pb());
    return a
};
var Ph = function(a) {
        for (var b = 0; b < a.a.length; b++)
            if (Oh(a.a[b])) return !0;
        return !1
    },
    Hh = function() {
        this.a = [];
        this.b = {}
    };
Hh.prototype.Pb = function() {
    for (var a = 0, b = 0; b < this.a.length; b++) a = Math.max(a, this.a[b].Pb);
    return a
};
var Oh = function(a) {
        for (var b = 0; b < a.a.length; b++)
            if (a.a[b].a) return !0;
        return !1
    },
    Jh = function(a, b, c, d) {
        this.text = a;
        this.Qe = b;
        this.Pb = c;
        this.cg = d;
        this.a = !1;
        this.b = 0
    };
var J = function() {
    Jg.call(this);
    this.Ub = new bh(this);
    this.ek = this;
    this.mh = null
};
t(J, Jg);
J.prototype[Xg] = !0;
h = J.prototype;
h.Od = function() {
    return this.mh
};
h.Fd = function(a) {
    this.mh = a
};
h.addEventListener = function(a, b, c, d) {
    G(this, a, b, c, d)
};
h.removeEventListener = function(a, b, c, d) {
    oh(this, a, b, c, d)
};
h.dispatchEvent = function(a) {
    Qh(this);
    var b = this.Od();
    if (b) {
        var c = [];
        for (var d = 1; b; b = b.Od()) c.push(b), v(1E3 > ++d, "infinite loop")
    }
    b = this.ek;
    d = a.type || a;
    if ("string" === typeof a) a = new F(a, b);
    else if (a instanceof F) a.target = a.target || b;
    else {
        var e = a;
        a = new F(d, b);
        Wb(a, e)
    }
    e = !0;
    if (c)
        for (var f = c.length - 1; !a.c && 0 <= f; f--) {
            var g = a.a = c[f];
            e = Rh(g, d, !0, a) && e
        }
    a.c || (g = a.a = b, e = Rh(g, d, !0, a) && e, a.c || (e = Rh(g, d, !1, a) && e));
    if (c)
        for (f = 0; !a.c && f < c.length; f++) g = a.a = c[f], e = Rh(g, d, !1, a) && e;
    return e
};
h.T = function() {
    J.D.T.call(this);
    this.nh();
    this.mh = null
};
h.listen = function(a, b, c, d) {
    Qh(this);
    return this.Ub.add(String(a), b, !1, c, d)
};
h.fh = function(a, b, c, d) {
    return this.Ub.add(String(a), b, !0, c, d)
};
h.Ga = function(a, b, c, d) {
    var e = this.Ub;
    a = String(a).toString();
    if (a in e.a) {
        var f = e.a[a];
        b = ch(f, b, c, d); - 1 < b ? (ah(f[b]), tb(f, b), 0 == f.length && (delete e.a[a], e.b--), e = !0) : e = !1
    } else e = !1;
    return e
};
h.nh = function(a) {
    if (this.Ub) {
        var b = this.Ub;
        a = a && a.toString();
        var c = 0,
            d;
        for (d in b.a)
            if (!a || d == a) {
                for (var e = b.a[d], f = 0; f < e.length; f++) ++c, ah(e[f]);
                delete b.a[d];
                b.b--
            } b = c
    } else b = 0;
    return b
};
var Rh = function(a, b, c, d) {
    b = a.Ub.a[String(b)];
    if (!b) return !0;
    b = b.concat();
    for (var e = !0, f = 0; f < b.length; ++f) {
        var g = b[f];
        if (g && !g.ae && g.capture == c) {
            var k = g.listener,
                l = g.Mf || g.src;
            g.df && dh(a.Ub, g);
            e = !1 !== k.call(l, d) && e
        }
    }
    return e && 0 != d.dj
};
J.prototype.pf = function(a, b) {
    return this.Ub.pf(String(a), b)
};
J.prototype.Ae = function(a, b, c, d) {
    return this.Ub.Ae(String(a), b, c, d)
};
J.prototype.hasListener = function(a, b) {
    return this.Ub.hasListener(void 0 !== a ? String(a) : void 0, b)
};
var Qh = function(a) {
    v(a.Ub, "Event target is not initialized. Did you call the superclass (goog.events.EventTarget) constructor?")
};
var Sh = function(a, b) {
    this.c = a;
    this.g = b;
    this.b = 0;
    this.a = null
};
Sh.prototype.get = function() {
    if (0 < this.b) {
        this.b--;
        var a = this.a;
        this.a = a.next;
        a.next = null
    } else a = this.c();
    return a
};
var Th = function(a, b) {
    a.g(b);
    100 > a.b && (a.b++, b.next = a.a, a.a = b)
};
var Uh = function(a) {
        n.setTimeout(function() {
            throw a;
        }, 0)
    },
    Vh, Wh = function() {
        var a = n.MessageChannel;
        "undefined" === typeof a && "undefined" !== typeof window && window.postMessage && window.addEventListener && !x("Presto") && (a = function() {
            var e = $f("IFRAME");
            e.style.display = "none";
            Vd(e, tc(cc(ec)));
            document.documentElement.appendChild(e);
            var f = e.contentWindow;
            e = f.document;
            e.open();
            e.write(Ad(Jd));
            e.close();
            var g = "callImmediate" + Math.random(),
                k = "file:" == f.location.protocol ? "*" : f.location.protocol + "//" + f.location.host;
            e = p(function(l) {
                if (("*" == k || l.origin == k) && l.data == g) this.port1.onmessage()
            }, this);
            f.addEventListener("message", e, !1);
            this.port1 = {};
            this.port2 = {
                postMessage: function() {
                    f.postMessage(g, k)
                }
            }
        });
        if ("undefined" !== typeof a && !td()) {
            var b = new a,
                c = {},
                d = c;
            b.port1.onmessage = function() {
                if (void 0 !== c.next) {
                    c = c.next;
                    var e = c.ai;
                    c.ai = null;
                    e()
                }
            };
            return function(e) {
                d.next = {
                    ai: e
                };
                d = d.next;
                b.port2.postMessage(0)
            }
        }
        return "undefined" !== typeof document && "onreadystatechange" in $f("SCRIPT") ? function(e) {
            var f = $f("SCRIPT");
            f.onreadystatechange =
                function() {
                    f.onreadystatechange = null;
                    f.parentNode.removeChild(f);
                    f = null;
                    e();
                    e = null
                };
            document.documentElement.appendChild(f)
        } : function(e) {
            n.setTimeout(e, 0)
        }
    };
var Xh = function() {
        this.b = this.a = null
    },
    Zh = new Sh(function() {
        return new Yh
    }, function(a) {
        a.reset()
    });
Xh.prototype.add = function(a, b) {
    var c = Zh.get();
    c.set(a, b);
    this.b ? this.b.next = c : (v(!this.a), this.a = c);
    this.b = c
};
var ai = function() {
        var a = $h,
            b = null;
        a.a && (b = a.a, a.a = a.a.next, a.a || (a.b = null), b.next = null);
        return b
    },
    Yh = function() {
        this.next = this.a = this.Dc = null
    };
Yh.prototype.set = function(a, b) {
    this.Dc = a;
    this.a = b;
    this.next = null
};
Yh.prototype.reset = function() {
    this.next = this.a = this.Dc = null
};
var ei = function(a, b) {
        bi || ci();
        di || (bi(), di = !0);
        $h.add(a, b)
    },
    bi, ci = function() {
        if (n.Promise && n.Promise.resolve) {
            var a = n.Promise.resolve(void 0);
            bi = function() {
                a.then(fi)
            }
        } else bi = function() {
            var b = fi;
            !Ka(n.setImmediate) || n.Window && n.Window.prototype && !x("Edge") && n.Window.prototype.setImmediate == n.setImmediate ? (Vh || (Vh = Wh()), Vh(b)) : n.setImmediate(b)
        }
    },
    di = !1,
    $h = new Xh,
    fi = function() {
        for (var a; a = ai();) {
            try {
                a.Dc.call(a.a)
            } catch (b) {
                Uh(b)
            }
            Th(Zh, a)
        }
        di = !1
    };
var gi = function(a) {
    if (!a) return !1;
    try {
        return !!a.$goog_Thenable
    } catch (b) {
        return !1
    }
};
var ji = function(a) {
        this.a = 0;
        this.m = void 0;
        this.g = this.b = this.c = null;
        this.h = this.o = !1;
        if (a != Ea) try {
            var b = this;
            a.call(void 0, function(c) {
                hi(b, 2, c)
            }, function(c) {
                if (!(c instanceof ii)) try {
                    if (c instanceof Error) throw c;
                    throw Error("Promise rejected.");
                } catch (d) {}
                hi(b, 3, c)
            })
        } catch (c) {
            hi(this, 3, c)
        }
    },
    ki = function() {
        this.next = this.context = this.c = this.b = this.a = null;
        this.g = !1
    };
ki.prototype.reset = function() {
    this.context = this.c = this.b = this.a = null;
    this.g = !1
};
var li = new Sh(function() {
        return new ki
    }, function(a) {
        a.reset()
    }),
    mi = function(a, b, c) {
        var d = li.get();
        d.b = a;
        d.c = b;
        d.context = c;
        return d
    },
    oi = function(a, b, c) {
        ni(a, b, c, null) || ei(Sa(b, a))
    },
    pi = function(a) {
        new ji(function(b, c) {
            var d = a.length,
                e = [];
            if (d)
                for (var f = function(m, q) {
                        d--;
                        e[m] = q;
                        0 == d && b(e)
                    }, g = function(m) {
                        c(m)
                    }, k = 0, l; k < a.length; k++) l = a[k], oi(l, Sa(f, k), g);
            else b(e)
        })
    };
ji.prototype.then = function(a, b, c) {
    null != a && ab(a, "opt_onFulfilled should be a function.");
    null != b && ab(b, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?");
    return qi(this, Ka(a) ? a : null, Ka(b) ? b : null, c)
};
ji.prototype.$goog_Thenable = !0;
ji.prototype.cancel = function(a) {
    if (0 == this.a) {
        var b = new ii(a);
        ei(function() {
            ri(this, b)
        }, this)
    }
};
var ri = function(a, b) {
        if (0 == a.a)
            if (a.c) {
                var c = a.c;
                if (c.b) {
                    for (var d = 0, e = null, f = null, g = c.b; g && (g.g || (d++, g.a == a && (e = g), !(e && 1 < d))); g = g.next) e || (f = g);
                    e && (0 == c.a && 1 == d ? ri(c, b) : (f ? (d = f, v(c.b), v(null != d), d.next == c.g && (c.g = d), d.next = d.next.next) : si(c), ti(c, e, 3, b)))
                }
                a.c = null
            } else hi(a, 3, b)
    },
    vi = function(a, b) {
        a.b || 2 != a.a && 3 != a.a || ui(a);
        v(null != b.b);
        a.g ? a.g.next = b : a.b = b;
        a.g = b
    },
    qi = function(a, b, c, d) {
        var e = mi(null, null, null);
        e.a = new ji(function(f, g) {
            e.b = b ? function(k) {
                    try {
                        var l = b.call(d, k);
                        f(l)
                    } catch (m) {
                        g(m)
                    }
                } :
                f;
            e.c = c ? function(k) {
                try {
                    var l = c.call(d, k);
                    void 0 === l && k instanceof ii ? g(k) : f(l)
                } catch (m) {
                    g(m)
                }
            } : g
        });
        e.a.c = a;
        vi(a, e);
        return e.a
    };
ji.prototype.G = function(a) {
    v(1 == this.a);
    this.a = 0;
    hi(this, 2, a)
};
ji.prototype.C = function(a) {
    v(1 == this.a);
    this.a = 0;
    hi(this, 3, a)
};
var hi = function(a, b, c) {
        0 == a.a && (a === c && (b = 3, c = new TypeError("Promise cannot resolve to itself")), a.a = 1, ni(c, a.G, a.C, a) || (a.m = c, a.a = b, a.c = null, ui(a), 3 != b || c instanceof ii || wi(a, c)))
    },
    ni = function(a, b, c, d) {
        if (a instanceof ji) return null != b && ab(b, "opt_onFulfilled should be a function."), null != c && ab(c, "opt_onRejected should be a function. Did you pass opt_context as the second argument instead of the third?"), vi(a, mi(b || Ea, c || null, d)), !0;
        if (gi(a)) return a.then(b, c, d), !0;
        if (La(a)) try {
            var e = a.then;
            if (Ka(e)) return xi(a,
                e, b, c, d), !0
        } catch (f) {
            return c.call(d, f), !0
        }
        return !1
    },
    xi = function(a, b, c, d, e) {
        var f = !1,
            g = function(l) {
                f || (f = !0, c.call(e, l))
            },
            k = function(l) {
                f || (f = !0, d.call(e, l))
            };
        try {
            b.call(a, g, k)
        } catch (l) {
            k(l)
        }
    },
    ui = function(a) {
        a.o || (a.o = !0, ei(a.w, a))
    },
    si = function(a) {
        var b = null;
        a.b && (b = a.b, a.b = b.next, b.next = null);
        a.b || (a.g = null);
        null != b && v(null != b.b);
        return b
    };
ji.prototype.w = function() {
    for (var a; a = si(this);) ti(this, a, this.a, this.m);
    this.o = !1
};
var ti = function(a, b, c, d) {
        if (3 == c && b.c && !b.g)
            for (; a && a.h; a = a.c) a.h = !1;
        if (b.a) b.a.c = null, yi(b, c, d);
        else try {
            b.g ? b.b.call(b.context) : yi(b, c, d)
        } catch (e) {
            zi.call(null, e)
        }
        Th(li, b)
    },
    yi = function(a, b, c) {
        2 == b ? a.b.call(a.context, c) : a.c && a.c.call(a.context, c)
    },
    wi = function(a, b) {
        a.h = !0;
        ei(function() {
            a.h && zi.call(null, b)
        })
    },
    zi = Uh,
    ii = function(a) {
        Ua.call(this, a)
    };
t(ii, Ua);
ii.prototype.name = "cancel";
var Ai = function(a, b) {
    J.call(this);
    this.c = a || 1;
    this.b = b || n;
    this.g = p(this.o, this);
    this.h = Ta()
};
t(Ai, J);
Ai.prototype.enabled = !1;
Ai.prototype.a = null;
var Bi = function(a, b) {
    a.c = b;
    a.a && a.enabled ? (a.stop(), a.start()) : a.a && a.stop()
};
Ai.prototype.o = function() {
    if (this.enabled) {
        var a = Ta() - this.h;
        0 < a && a < .8 * this.c ? this.a = this.b.setTimeout(this.g, this.c - a) : (this.a && (this.b.clearTimeout(this.a), this.a = null), this.dispatchEvent("tick"), this.enabled && (this.stop(), this.start()))
    }
};
Ai.prototype.start = function() {
    this.enabled = !0;
    this.a || (this.a = this.b.setTimeout(this.g, this.c), this.h = Ta())
};
Ai.prototype.stop = function() {
    this.enabled = !1;
    this.a && (this.b.clearTimeout(this.a), this.a = null)
};
Ai.prototype.T = function() {
    Ai.D.T.call(this);
    this.stop();
    delete this.b
};
var Ci = function(a, b, c) {
        if (Ka(a)) c && (a = p(a, c));
        else if (a && "function" == typeof a.handleEvent) a = p(a.handleEvent, a);
        else throw Error("Invalid listener argument");
        return 2147483647 < Number(b) ? -1 : n.setTimeout(a, b || 0)
    },
    Di = function(a) {
        n.clearTimeout(a)
    };
var Ei = function() {
    function a() {
        e[0] = 1732584193;
        e[1] = 4023233417;
        e[2] = 2562383102;
        e[3] = 271733878;
        e[4] = 3285377520;
        q = m = 0
    }

    function b(r) {
        for (var u = g, z = 0; 64 > z; z += 4) u[z / 4] = r[z] << 24 | r[z + 1] << 16 | r[z + 2] << 8 | r[z + 3];
        for (z = 16; 80 > z; z++) r = u[z - 3] ^ u[z - 8] ^ u[z - 14] ^ u[z - 16], u[z] = (r << 1 | r >>> 31) & 4294967295;
        r = e[0];
        var P = e[1],
            L = e[2],
            Ma = e[3],
            Kb = e[4];
        for (z = 0; 80 > z; z++) {
            if (40 > z)
                if (20 > z) {
                    var Ha = Ma ^ P & (L ^ Ma);
                    var Lb = 1518500249
                } else Ha = P ^ L ^ Ma, Lb = 1859775393;
            else 60 > z ? (Ha = P & L | Ma & (P | L), Lb = 2400959708) : (Ha = P ^ L ^ Ma, Lb = 3395469782);
            Ha = ((r << 5 | r >>>
                27) & 4294967295) + Ha + Kb + Lb + u[z] & 4294967295;
            Kb = Ma;
            Ma = L;
            L = (P << 30 | P >>> 2) & 4294967295;
            P = r;
            r = Ha
        }
        e[0] = e[0] + r & 4294967295;
        e[1] = e[1] + P & 4294967295;
        e[2] = e[2] + L & 4294967295;
        e[3] = e[3] + Ma & 4294967295;
        e[4] = e[4] + Kb & 4294967295
    }

    function c(r, u) {
        if ("string" === typeof r) {
            r = unescape(encodeURIComponent(r));
            for (var z = [], P = 0, L = r.length; P < L; ++P) z.push(r.charCodeAt(P));
            r = z
        }
        u || (u = r.length);
        z = 0;
        if (0 == m)
            for (; z + 64 < u;) b(r.slice(z, z + 64)), z += 64, q += 64;
        for (; z < u;)
            if (f[m++] = r[z++], q++, 64 == m)
                for (m = 0, b(f); z + 64 < u;) b(r.slice(z, z + 64)), z += 64, q +=
                    64
    }

    function d() {
        var r = [],
            u = 8 * q;
        56 > m ? c(k, 56 - m) : c(k, 64 - (m - 56));
        for (var z = 63; 56 <= z; z--) f[z] = u & 255, u >>>= 8;
        b(f);
        for (z = u = 0; 5 > z; z++)
            for (var P = 24; 0 <= P; P -= 8) r[u++] = e[z] >> P & 255;
        return r
    }
    for (var e = [], f = [], g = [], k = [128], l = 1; 64 > l; ++l) k[l] = 0;
    var m, q;
    a();
    return {
        reset: a,
        update: c,
        digest: d,
        digestString: function() {
            for (var r = d(), u = "", z = 0; z < r.length; z++) u += "0123456789ABCDEF".charAt(Math.floor(r[z] / 16)) + "0123456789ABCDEF".charAt(r[z] % 16);
            return u
        }
    }
};
var Gi = function(a, b, c) {
        var d = [],
            e = [];
        if (1 == (Ia(c) ? 2 : 1)) return e = [b, a], w(d, function(k) {
            e.push(k)
        }), Fi(e.join(" "));
        var f = [],
            g = [];
        w(c, function(k) {
            g.push(k.key);
            f.push(k.value)
        });
        c = Math.floor((new Date).getTime() / 1E3);
        e = 0 == f.length ? [c, b, a] : [f.join(":"), c, b, a];
        w(d, function(k) {
            e.push(k)
        });
        a = Fi(e.join(" "));
        a = [c, a];
        0 == g.length || a.push(g.join(""));
        return a.join("_")
    },
    Fi = function(a) {
        var b = Ei();
        b.update(a);
        return b.digestString().toLowerCase()
    };
var Hi = function() {
    this.a = document || {
        cookie: ""
    }
};
h = Hi.prototype;
h.isEnabled = function() {
    return navigator.cookieEnabled
};
h.set = function(a, b, c, d, e, f) {
    if ("object" === typeof c) {
        v(null == d);
        v(null == e);
        v(null == f);
        var g = c.g;
        f = c.h;
        e = c.a;
        d = c.b;
        c = c.c
    }
    if (/[;=\s]/.test(a)) throw Error('Invalid cookie name "' + a + '"');
    if (/[;\r\n]/.test(b)) throw Error('Invalid cookie value "' + b + '"');
    void 0 === c && (c = -1);
    e = e ? ";domain=" + e : "";
    d = d ? ";path=" + d : "";
    f = f ? ";secure" : "";
    c = 0 > c ? "" : 0 == c ? ";expires=" + (new Date(1970, 1, 1)).toUTCString() : ";expires=" + (new Date(Ta() + 1E3 * c)).toUTCString();
    this.a.cookie = a + "=" + b + e + d + c + f + (null != g ? ";samesite=" + g : "")
};
h.get = function(a, b) {
    for (var c = a + "=", d = (this.a.cookie || "").split(";"), e = 0, f; e < d.length; e++) {
        f = yc(d[e]);
        if (0 == f.lastIndexOf(c, 0)) return f.substr(c.length);
        if (f == a) return ""
    }
    return b
};
h.Cb = function() {
    return Ii(this).keys
};
h.Wb = function() {
    return Ii(this).values
};
h.Hg = function() {
    return this.a.cookie ? (this.a.cookie || "").split(";").length : 0
};
var Ii = function(a) {
    a = (a.a.cookie || "").split(";");
    for (var b = [], c = [], d, e, f = 0; f < a.length; f++) e = yc(a[f]), d = e.indexOf("="), -1 == d ? (b.push(""), c.push(e)) : (b.push(e.substring(0, d)), c.push(e.substring(d + 1)));
    return {
        keys: b,
        values: c
    }
};
var Ji = function(a) {
    var b = wf(String(n.location.href));
    var c = (b = 0 == b.indexOf("https:") || 0 == b.indexOf("chrome-extension:")) ? n.__SAPISID : n.__APISID;
    if (!c) {
        var d = new Hi;
        (c = d.get(b ? "SAPISID" : "APISID")) || (c = d.get("__Secure-3PAPISID"))
    }
    b = c;
    if (!b) return null;
    c = wf(String(n.location.href));
    c = 0 == c.indexOf("https:") || 0 == c.indexOf("chrome-extension:") ? "SAPISIDHASH" : "APISIDHASH";
    return (d = String(n.location.href)) && b && c ? [c, Gi(wf(d), b, a || null)].join(" ") : null
};
var Ki = function(a, b, c) {
    this.reset(a, b, c, void 0, void 0)
};
Ki.prototype.a = null;
var Li = 0;
Ki.prototype.reset = function(a, b, c, d, e) {
    "number" == typeof e || Li++;
    d || Ta();
    delete this.a
};
var Mi = function(a) {
        this.g = a;
        this.b = this.c = this.a = null
    },
    Ni = function(a, b) {
        this.name = a;
        this.value = b
    };
Ni.prototype.toString = function() {
    return this.name
};
var Oi = new Ni("SEVERE", 1E3),
    Pi = new Ni("WARNING", 900),
    Qi = new Ni("INFO", 800),
    Ri = new Ni("CONFIG", 700),
    Si = new Ni("FINE", 500);
Mi.prototype.getParent = function() {
    return this.a
};
var Ti = function(a) {
    if (a.c) return a.c;
    if (a.a) return Ti(a.a);
    Ya("Root logger has no level set.");
    return null
};
Mi.prototype.log = function(a, b, c) {
    if (a.value >= Ti(this).value)
        for (Ka(b) && (b = b()), a = new Ki(a, String(b), this.g), c && (a.a = c), c = this; c;) c = c.getParent()
};
Mi.prototype.config = function(a, b) {
    this.log(Ri, a, b)
};
var Ui = {},
    Vi = null,
    Wi = function(a) {
        Vi || (Vi = new Mi(""), Ui[""] = Vi, Vi.c = Ri);
        var b;
        if (!(b = Ui[a])) {
            b = new Mi(a);
            var c = a.lastIndexOf("."),
                d = a.substr(c + 1);
            c = Wi(a.substr(0, c));
            c.b || (c.b = {});
            c.b[d] = b;
            b.a = c;
            Ui[a] = b
        }
        return b
    };
var Xi = function(a, b) {
        a && a.log(Oi, b, void 0)
    },
    Yi = function(a, b) {
        a && a.log(Pi, b, void 0)
    },
    Zi = function(a, b) {
        a && a.log(Qi, b, void 0)
    },
    $i = function(a, b) {
        a && a.log(Si, b, void 0)
    };
var aj = function(a) {
    v(0 < a, "Initial value must be greater than zero.");
    v(3E5 >= a, "Max value should be at least as large as initial value.");
    v(!0, "Randomness factor should be between 0 and 1.");
    this.a = this.b = this.c = a
};
aj.prototype.reset = function() {
    this.a = this.b = this.c
};
aj.prototype.Y = function() {
    return this.b
};
var bj = function(a) {
        a = String(a);
        if (/^\s*$/.test(a) ? 0 : /^[\],:{}\s\u2028\u2029]*$/.test(a.replace(/\\["\\\/bfnrtu]/g, "@").replace(/(?:"[^"\\\n\r\u2028\u2029\x00-\x08\x0a-\x1f]*"|true|false|null|-?\d+(?:\.\d*)?(?:[eE][+\-]?\d+)?)[\s\u2028\u2029]*(?=:|,|]|}|$)/g, "]").replace(/(?:^|:|,)(?:[\s\u2028\u2029]*\[)+/g, ""))) try {
            return eval("(" + a + ")")
        } catch (b) {}
        throw Error("Invalid JSON string: " + a);
    },
    ej = function(a) {
        var b = [];
        cj(new dj, a, b);
        return b.join("")
    },
    dj = function() {},
    cj = function(a, b, c) {
        if (null == b) c.push("null");
        else {
            if ("object" == typeof b) {
                if (Ia(b)) {
                    var d = b;
                    b = d.length;
                    c.push("[");
                    for (var e = "", f = 0; f < b; f++) c.push(e), cj(a, d[f], c), e = ",";
                    c.push("]");
                    return
                }
                if (b instanceof String || b instanceof Number || b instanceof Boolean) b = b.valueOf();
                else {
                    c.push("{");
                    e = "";
                    for (d in b) Object.prototype.hasOwnProperty.call(b, d) && (f = b[d], "function" != typeof f && (c.push(e), fj(d, c), c.push(":"), cj(a, f, c), e = ","));
                    c.push("}");
                    return
                }
            }
            switch (typeof b) {
                case "string":
                    fj(b, c);
                    break;
                case "number":
                    c.push(isFinite(b) && !isNaN(b) ? String(b) : "null");
                    break;
                case "boolean":
                    c.push(String(b));
                    break;
                case "function":
                    c.push("null");
                    break;
                default:
                    throw Error("Unknown type: " + typeof b);
            }
        }
    },
    gj = {
        '"': '\\"',
        "\\": "\\\\",
        "/": "\\/",
        "\b": "\\b",
        "\f": "\\f",
        "\n": "\\n",
        "\r": "\\r",
        "\t": "\\t",
        "\x0B": "\\u000b"
    },
    hj = /\uffff/.test("\uffff") ? /[\\"\x00-\x1f\x7f-\uffff]/g : /[\\"\x00-\x1f\x7f-\xff]/g,
    fj = function(a, b) {
        b.push('"', a.replace(hj, function(c) {
            var d = gj[c];
            d || (d = "\\u" + (c.charCodeAt(0) | 65536).toString(16).substr(1), gj[c] = d);
            return d
        }), '"')
    };
var ij = function() {};
ij.prototype.a = null;
var kj = function(a) {
    var b;
    (b = a.a) || (b = {}, jj(a) && (b[0] = !0, b[1] = !0), b = a.a = b);
    return b
};
var lj, mj = function() {};
t(mj, ij);
var nj = function(a) {
        return (a = jj(a)) ? new ActiveXObject(a) : new XMLHttpRequest
    },
    jj = function(a) {
        if (!a.b && "undefined" == typeof XMLHttpRequest && "undefined" != typeof ActiveXObject) {
            for (var b = ["MSXML2.XMLHTTP.6.0", "MSXML2.XMLHTTP.3.0", "MSXML2.XMLHTTP", "Microsoft.XMLHTTP"], c = 0; c < b.length; c++) {
                var d = b[c];
                try {
                    return new ActiveXObject(d), a.b = d
                } catch (e) {}
            }
            throw Error("Could not create ActiveXObject. ActiveX might be disabled, or MSXML might not be installed");
        }
        return a.b
    };
lj = new mj;
var oj = "StopIteration" in n ? n.StopIteration : {
        message: "StopIteration",
        stack: ""
    },
    pj = function() {};
pj.prototype.next = function() {
    throw oj;
};
pj.prototype.mc = function() {
    return this
};
var qj = function(a) {
        if (a instanceof pj) return a;
        if ("function" == typeof a.mc) return a.mc(!1);
        if (Ja(a)) {
            var b = 0,
                c = new pj;
            c.next = function() {
                for (;;) {
                    if (b >= a.length) throw oj;
                    if (b in a) return a[b++];
                    b++
                }
            };
            return c
        }
        throw Error("Not implemented");
    },
    rj = function(a, b, c) {
        if (Ja(a)) try {
            w(a, b, c)
        } catch (d) {
            if (d !== oj) throw d;
        } else {
            a = qj(a);
            try {
                for (;;) b.call(c, a.next(), void 0, a)
            } catch (d) {
                if (d !== oj) throw d;
            }
        }
    },
    sj = function(a, b, c) {
        a = qj(a);
        try {
            for (; b.call(c, a.next(), void 0, a););
        } catch (d) {
            if (d !== oj) throw d;
        }
    };
var tj = function(a, b) {
    this.b = {};
    this.a = [];
    this.g = this.c = 0;
    var c = arguments.length;
    if (1 < c) {
        if (c % 2) throw Error("Uneven number of arguments");
        for (var d = 0; d < c; d += 2) this.set(arguments[d], arguments[d + 1])
    } else if (a)
        if (a instanceof tj)
            for (c = a.Cb(), d = 0; d < c.length; d++) this.set(c[d], a.get(c[d]));
        else
            for (d in a) this.set(d, a[d])
};
tj.prototype.Hg = function() {
    return this.c
};
tj.prototype.Wb = function() {
    uj(this);
    for (var a = [], b = 0; b < this.a.length; b++) a.push(this.b[this.a[b]]);
    return a
};
tj.prototype.Cb = function() {
    uj(this);
    return this.a.concat()
};
var wj = function(a, b) {
    return vj(a.b, b)
};
tj.prototype.Wc = function() {
    this.b = {};
    this.g = this.c = this.a.length = 0
};
var uj = function(a) {
    if (a.c != a.a.length) {
        for (var b = 0, c = 0; b < a.a.length;) {
            var d = a.a[b];
            vj(a.b, d) && (a.a[c++] = d);
            b++
        }
        a.a.length = c
    }
    if (a.c != a.a.length) {
        var e = {};
        for (c = b = 0; b < a.a.length;) d = a.a[b], vj(e, d) || (a.a[c++] = d, e[d] = 1), b++;
        a.a.length = c
    }
};
tj.prototype.get = function(a, b) {
    return vj(this.b, a) ? this.b[a] : b
};
tj.prototype.set = function(a, b) {
    vj(this.b, a) || (this.c++, this.a.push(a), this.g++);
    this.b[a] = b
};
tj.prototype.forEach = function(a, b) {
    for (var c = this.Cb(), d = 0; d < c.length; d++) {
        var e = c[d],
            f = this.get(e);
        a.call(b, f, e, this)
    }
};
tj.prototype.mc = function(a) {
    uj(this);
    var b = 0,
        c = this.g,
        d = this,
        e = new pj;
    e.next = function() {
        if (c != d.g) throw Error("The map has changed since the iterator was created");
        if (b >= d.a.length) throw oj;
        var f = d.a[b++];
        return a ? f : d.b[f]
    };
    return e
};
var vj = function(a, b) {
    return Object.prototype.hasOwnProperty.call(a, b)
};
var xj = function(a) {
        if (a.Wb && "function" == typeof a.Wb) return a.Wb();
        if ("string" === typeof a) return a.split("");
        if (Ja(a)) {
            for (var b = [], c = a.length, d = 0; d < c; d++) b.push(a[d]);
            return b
        }
        return Nb(a)
    },
    yj = function(a, b, c) {
        if (a.forEach && "function" == typeof a.forEach) a.forEach(b, c);
        else if (Ja(a) || "string" === typeof a) w(a, b, c);
        else {
            if (a.Cb && "function" == typeof a.Cb) var d = a.Cb();
            else if (a.Wb && "function" == typeof a.Wb) d = void 0;
            else if (Ja(a) || "string" === typeof a) {
                d = [];
                for (var e = a.length, f = 0; f < e; f++) d.push(f)
            } else d = Ob(a);
            e = xj(a);
            f = e.length;
            for (var g = 0; g < f; g++) b.call(c, e[g], d && d[g], a)
        }
    };
var zj = /^(?:([^:/?#.]+):)?(?:\/\/(?:([^/?#]*)@)?([^/#?]*?)(?::([0-9]+))?(?=[/#?]|$))?([^?#]+)?(?:\?([^#]*))?(?:#([\s\S]*))?$/,
    Aj = function(a, b) {
        if (a) {
            a = a.split("&");
            for (var c = 0; c < a.length; c++) {
                var d = a[c].indexOf("="),
                    e = null;
                if (0 <= d) {
                    var f = a[c].substring(0, d);
                    e = a[c].substring(d + 1)
                } else f = a[c];
                b(f, e ? ce(e) : "")
            }
        }
    },
    Bj = function(a, b) {
        if (!b) return a;
        var c = a.indexOf("#");
        0 > c && (c = a.length);
        var d = a.indexOf("?");
        if (0 > d || d > c) {
            d = c;
            var e = ""
        } else e = a.substring(d + 1, c);
        a = [a.substr(0, d), e, a.substr(c)];
        c = a[1];
        a[1] = b ?
            c ? c + "&" + b : b : c;
        return a[0] + (a[1] ? "?" + a[1] : "") + a[2]
    },
    Cj = function(a, b, c) {
        $a(a);
        if (Ia(b)) {
            cb(b);
            for (var d = 0; d < b.length; d++) Cj(a, String(b[d]), c)
        } else null != b && c.push(a + ("" === b ? "" : "=" + be(b)))
    },
    Dj = function(a, b) {
        v(0 == Math.max(a.length - (b || 0), 0) % 2, "goog.uri.utils: Key/value lists must be even in length.");
        var c = [];
        for (b = b || 0; b < a.length; b += 2) Cj(a[b], a[b + 1], c);
        return c.join("&")
    },
    Ej = function(a) {
        var b = [],
            c;
        for (c in a) Cj(c, a[c], b);
        return b.join("&")
    },
    Fj = function(a, b) {
        var c = 2 == arguments.length ? Dj(arguments[1],
            0) : Dj(arguments, 1);
        return Bj(a, c)
    },
    Gj = function(a, b, c) {
        c = null != c ? "=" + be(c) : "";
        return Bj(a, b + c)
    },
    Hj = function(a, b, c, d) {
        for (var e = c.length; 0 <= (b = a.indexOf(c, b)) && b < d;) {
            var f = a.charCodeAt(b - 1);
            if (38 == f || 63 == f)
                if (f = a.charCodeAt(b + e), !f || 61 == f || 38 == f || 35 == f) return b;
            b += e + 1
        }
        return -1
    },
    Ij = /#|$/,
    Jj = function() {
        var a = n.location.href,
            b = a.search(Ij),
            c = Hj(a, 0, "authuser", b);
        if (0 > c) return null;
        var d = a.indexOf("&", c);
        if (0 > d || d > b) d = b;
        c += 9;
        return ce(a.substr(c, d - c))
    },
    Kj = /[?&]($|#)/,
    Lj = function(a, b) {
        v(0 > a.indexOf("#") &&
            0 > a.indexOf("?"), "goog.uri.utils: Fragment or query identifiers are not supported: [%s]", a);
        wc(a, "/") && (a = a.substr(0, a.length - 1));
        vc(b, "/") && (b = b.substr(1));
        return le(a, "/", b)
    };
var Mj = function(a) {
    J.call(this);
    this.headers = new tj;
    this.fg = a || null;
    this.Ib = !1;
    this.eg = this.Aa = null;
    this.Qi = this.Yd = "";
    this.Bd = 0;
    this.Pe = "";
    this.Ad = this.Yg = this.Pf = this.Cg = !1;
    this.ee = 0;
    this.$f = null;
    this.cj = "";
    this.dg = this.Ue = !1
};
t(Mj, J);
Mj.prototype.F = Wi("goog.net.XhrIo");
var Nj = /^https?$/i,
    Oj = ["POST", "PUT"],
    Pj = [],
    Qj = function(a, b, c, d, e, f, g) {
        var k = new Mj;
        Pj.push(k);
        b && k.listen("complete", b);
        k.fh("ready", k.ik);
        f && (k.ee = Math.max(0, f));
        g && (k.Ue = g);
        k.send(a, c, d, e);
        return k
    };
Mj.prototype.ik = function() {
    this.Ia();
    ub(Pj, this)
};
Mj.prototype.send = function(a, b, c, d) {
    if (this.Aa) throw Error("[goog.net.XhrIo] Object is active with another request=" + this.Yd + "; newUri=" + a);
    b = b ? b.toUpperCase() : "GET";
    this.Yd = a;
    this.Pe = "";
    this.Bd = 0;
    this.Qi = b;
    this.Cg = !1;
    this.Ib = !0;
    this.Aa = this.fg ? nj(this.fg) : nj(lj);
    this.eg = this.fg ? kj(this.fg) : kj(lj);
    this.Aa.onreadystatechange = p(this.Zi, this);
    try {
        $i(this.F, Rj(this, "Opening Xhr")), this.Yg = !0, this.Aa.open(b, String(a), !0), this.Yg = !1
    } catch (f) {
        $i(this.F, Rj(this, "Error opening Xhr: " + f.message));
        this.kf(5,
            f);
        return
    }
    a = c || "";
    var e = new tj(this.headers);
    d && yj(d, function(f, g) {
        e.set(g, f)
    });
    d = pb(e.Cb(), Sj);
    c = n.FormData && a instanceof n.FormData;
    !rb(Oj, b) || d || c || e.set("Content-Type", "application/x-www-form-urlencoded;charset=utf-8");
    e.forEach(function(f, g) {
        this.Aa.setRequestHeader(g, f)
    }, this);
    this.cj && (this.Aa.responseType = this.cj);
    "withCredentials" in this.Aa && this.Aa.withCredentials !== this.Ue && (this.Aa.withCredentials = this.Ue);
    try {
        Tj(this), 0 < this.ee && (this.dg = Vj(this.Aa), $i(this.F, Rj(this, "Will abort after " +
            this.ee + "ms if incomplete, xhr2 " + this.dg)), this.dg ? (this.Aa.timeout = this.ee, this.Aa.ontimeout = p(this.ed, this)) : this.$f = Ci(this.ed, this.ee, this)), $i(this.F, Rj(this, "Sending request")), this.Pf = !0, this.Aa.send(a), this.Pf = !1
    } catch (f) {
        $i(this.F, Rj(this, "Send error: " + f.message)), this.kf(5, f)
    }
};
var Vj = function(a) {
        return y && Qe(9) && "number" === typeof a.timeout && void 0 !== a.ontimeout
    },
    Sj = function(a) {
        return "content-type" == a.toLowerCase()
    };
Mj.prototype.ed = function() {
    "undefined" != typeof xa && this.Aa && (this.Pe = "Timed out after " + this.ee + "ms, aborting", this.Bd = 8, $i(this.F, Rj(this, this.Pe)), this.dispatchEvent("timeout"), this.abort(8))
};
Mj.prototype.kf = function(a, b) {
    this.Ib = !1;
    this.Aa && (this.Ad = !0, this.Aa.abort(), this.Ad = !1);
    this.Pe = b;
    this.Bd = a;
    Wj(this);
    Xj(this)
};
var Wj = function(a) {
    a.Cg || (a.Cg = !0, a.dispatchEvent("complete"), a.dispatchEvent("error"))
};
Mj.prototype.abort = function(a) {
    this.Aa && this.Ib && ($i(this.F, Rj(this, "Aborting")), this.Ib = !1, this.Ad = !0, this.Aa.abort(), this.Ad = !1, this.Bd = a || 7, this.dispatchEvent("complete"), this.dispatchEvent("abort"), Xj(this))
};
Mj.prototype.T = function() {
    this.Aa && (this.Ib && (this.Ib = !1, this.Ad = !0, this.Aa.abort(), this.Ad = !1), Xj(this, !0));
    Mj.D.T.call(this)
};
Mj.prototype.Zi = function() {
    this.isDisposed() || (this.Yg || this.Pf || this.Ad ? Yj(this) : this.Zm())
};
Mj.prototype.Zm = function() {
    Yj(this)
};
var Yj = function(a) {
        if (a.Ib && "undefined" != typeof xa)
            if (a.eg[1] && 4 == Zj(a) && 2 == a.Sc()) $i(a.F, Rj(a, "Local request error detected and ignored"));
            else if (a.Pf && 4 == Zj(a)) Ci(a.Zi, 0, a);
        else if (a.dispatchEvent("readystatechange"), 4 == Zj(a)) {
            $i(a.F, Rj(a, "Request complete"));
            a.Ib = !1;
            try {
                if (ak(a)) a.dispatchEvent("complete"), a.dispatchEvent("success");
                else {
                    a.Bd = 6;
                    try {
                        var b = 2 < Zj(a) ? a.Aa.statusText : ""
                    } catch (c) {
                        $i(a.F, "Can not get status: " + c.message), b = ""
                    }
                    a.Pe = b + " [" + a.Sc() + "]";
                    Wj(a)
                }
            } finally {
                Xj(a)
            }
        }
    },
    Xj = function(a,
        b) {
        if (a.Aa) {
            Tj(a);
            var c = a.Aa,
                d = a.eg[0] ? Ea : null;
            a.Aa = null;
            a.eg = null;
            b || a.dispatchEvent("ready");
            try {
                c.onreadystatechange = d
            } catch (e) {
                Xi(a.F, "Problem encountered resetting onreadystatechange: " + e.message)
            }
        }
    },
    Tj = function(a) {
        a.Aa && a.dg && (a.Aa.ontimeout = null);
        a.$f && (Di(a.$f), a.$f = null)
    };
Mj.prototype.nb = function() {
    return !!this.Aa
};
var ak = function(a) {
        var b = a.Sc();
        a: switch (b) {
            case 200:
            case 201:
            case 202:
            case 204:
            case 206:
            case 304:
            case 1223:
                var c = !0;
                break a;
            default:
                c = !1
        }
        if (!c) {
            if (b = 0 === b) a = String(a.Yd).match(zj)[1] || null, !a && n.self && n.self.location && (a = n.self.location.protocol, a = a.substr(0, a.length - 1)), b = !Nj.test(a ? a.toLowerCase() : "");
            c = b
        }
        return c
    },
    Zj = function(a) {
        return a.Aa ? a.Aa.readyState : 0
    };
Mj.prototype.Sc = function() {
    try {
        return 2 < Zj(this) ? this.Aa.status : -1
    } catch (a) {
        return -1
    }
};
var bk = function(a) {
        try {
            return a.Aa ? a.Aa.responseText : ""
        } catch (b) {
            return $i(a.F, "Can not get responseText: " + b.message), ""
        }
    },
    ck = function(a) {
        if (a.Aa) {
            a: {
                a = a.Aa.responseText;
                if (n.JSON) try {
                    var b = n.JSON.parse(a);
                    v("object" == typeof b);
                    var c = b;
                    break a
                } catch (d) {}
                c = bj(a)
            }
            return c
        }
    };
Mj.prototype.getResponseHeader = function(a) {
    if (this.Aa && 4 == Zj(this)) return a = this.Aa.getResponseHeader(a), null === a ? void 0 : a
};
Mj.prototype.getAllResponseHeaders = function() {
    return this.Aa && 4 == Zj(this) ? this.Aa.getAllResponseHeaders() || "" : ""
};
var Rj = function(a, b) {
    return b + " [" + a.Qi + " " + a.Yd + " " + a.Sc() + "]"
};
var dk = function(a, b, c) {
    Qj(a.url, function(d) {
        d = d.target;
        ak(d) ? b(bk(d)) : c(d.Sc())
    }, a.wn, a.body, a.vn, a.Xn, a.withCredentials)
};
var ek = function(a) {
    gf(this, a, -1, null)
};
t(ek, cf);
var fk = function(a) {
    gf(this, a, -1, null)
};
t(fk, cf);
var hk = function(a) {
    gf(this, a, 30, gk)
};
t(hk, cf);
var gk = [3, 20, 27];
var jk = function(a) {
    gf(this, a, 17, ik)
};
t(jk, cf);
var ik = [3, 5],
    kk = function(a) {
        var b = Ta().toString();
        return A(a, 4, b)
    },
    lk = function(a, b) {
        return mf(a, 3, b)
    },
    mk = function(a, b) {
        return A(a, 14, b)
    };
var ok = function(a) {
    gf(this, a, 6, nk)
};
t(ok, cf);
var nk = [5];
var pk = function(a) {
    gf(this, a, -1, null)
};
t(pk, cf);
var qk = new function() {
    this.a = pk
};
var sk = function(a, b, c, d, e, f, g, k, l, m, q) {
    J.call(this);
    this.ia = a;
    this.N = b || Ea;
    this.h = new jk;
    this.Na = d;
    this.V = q;
    this.a = [];
    this.R = "";
    this.xa = Sa(Df, 0, 1);
    this.G = e || null;
    this.m = c || null;
    this.C = g || !1;
    this.K = l || null;
    this.na = this.X = !1;
    this.W = this.O = -1;
    this.c = null;
    this.F = Wi("playlog.clearcut.ClearcutBase");
    this.Ue = !k;
    this.L = 0;
    this.ra = 1;
    this.Z = f || !1;
    a = new fk;
    a = A(a, 1, 1);
    f || (f = new ek, b = document.documentElement.getAttribute("lang"), f = A(f, 5, b), lf(a, 11, f));
    lf(this.h, 1, a);
    A(this.h, 2, this.ia);
    this.g = new aj(1E4);
    this.b =
        new Ai(this.g.Y());
    Lg(this, this.b);
    G(this.b, "tick", Hb(rk(this, m)), !1, this);
    this.w = new Ai(6E5);
    Lg(this, this.w);
    G(this.w, "tick", Hb(rk(this, m)), !1, this);
    this.C || this.w.start();
    this.Z || (G(Vf(), "beforeunload", this.o, !1, this), G(Vf(), "unload", this.o, !1, this), G(document, "pagehide", this.o, !1, this))
};
t(sk, J);
var rk = function(a, b) {
    return b ? function() {
        b().then(a.flush.bind(a))
    } : a.flush
};
sk.prototype.T = function() {
    this.o();
    sk.D.T.call(this)
};
var tk = function(a) {
    a.G || (a.G = .01 > a.xa() ? "https://www.google.com/log?format=json&hasfast=true" : "https://play.google.com/log?format=json&hasfast=true");
    return a.G
};
sk.prototype.log = function(a) {
    a = rf(a);
    var b = this.ra++;
    A(a, 21, b);
    if (!hf(a, 1)) {
        b = a;
        var c = Ta().toString();
        A(b, 1, c)
    }
    this.c && (b = rf(this.c), lf(a, 16, b));
    for (; 1E3 <= this.a.length;) this.a.shift(), ++this.L;
    this.a.push(a);
    this.dispatchEvent(new uk(a));
    this.C || this.b.enabled || this.b.start()
};
sk.prototype.flush = function(a, b) {
    if (0 == this.a.length) a && a();
    else {
        var c = Ta();
        if (this.W > c && this.O < c) Zi(this.F, "Not flushing because server requested delay."), b && b("throttled");
        else {
            var d = mk(lk(kk(rf(this.h)), this.a), this.L);
            c = {};
            var e = this.N();
            e && (c.Authorization = e);
            var f = tk(this);
            this.m && (c["X-Goog-AuthUser"] = this.m, f = Gj(f, "authuser", this.m));
            this.K && (c["X-Goog-PageId"] = this.K, f = Gj(f, "pageId", this.K));
            if (e && this.R == e) Zi(this.F, "XHR with unauthorized request not retried"), b && b("stale-auth-token");
            else {
                Zi(this.F,
                    "Flushing log to clearcut.");
                this.a = [];
                this.b.enabled && this.b.stop();
                this.L = 0;
                var g = d.o();
                c = {
                    url: f,
                    body: g,
                    Qq: 1,
                    vn: c,
                    wn: "POST",
                    withCredentials: this.Ue,
                    Xn: 0
                };
                f = p(function(k) {
                    this.g.reset();
                    Bi(this.b, this.g.Y());
                    if (k) {
                        try {
                            var l = JSON.parse(k.replace(")]}'\n", ""));
                            var m = new ok(l)
                        } catch (q) {
                            Yi(this.F, "Response parse failed: " + q)
                        }
                        m && (k = jf(m, "-1"), k = Number(k), 0 < k && (this.O = Ta(), this.W = this.O + k), m.c ? (m.a || (m.a = {}), qk.a ? (!m.a[175237375] && m.c[175237375] && (m.a[175237375] = new qk.a(m.c[175237375])), m = m.a[175237375]) :
                            m = m.c[175237375]) : m = void 0, m && (m = jf(m, -1), -1 != m && (this.g = new aj(1 > m ? 1 : m), Bi(this.b, this.g.Y()))))
                    }
                    a && a()
                }, this);
                g = p(function(k) {
                    kf(d, hk, 3);
                    var l = d.a[3];
                    l == ef && (l = d.a[3] = []);
                    var m = this.g;
                    m.a = Math.min(3E5, 2 * m.a);
                    m.b = Math.min(3E5, m.a + Math.round(.2 * (Math.random() - .5) * m.a));
                    Bi(this.b, this.g.Y());
                    401 == k && e && (this.R = e);
                    if (500 <= k && 600 > k || 401 == k || 0 == k) this.a = l.concat(this.a), this.C || this.b.enabled || this.b.start();
                    Yi(this.F, "Flush failed. Status code: " + k);
                    b && b("net-send-failed", k)
                }, this);
                this.V ? this.V.send(c,
                    f, g) : this.Na(c, f, g)
            }
        }
    }
};
sk.prototype.o = function() {
    this.X && vk(this);
    this.na && wk(this);
    this.flush()
};
var vk = function(a) {
        Zi(a.F, "Flushing log using sendBeacon.");
        xk(a, 32, 10, function(b, c) {
            b = Gj(b, "format", "json");
            return Vf().navigator.sendBeacon(b, c.o())
        })
    },
    wk = function(a) {
        Zi(a.F, "Flushing log using Image GET.");
        xk(a, 6, 5, function(b, c) {
            c = c.o();
            for (var d = [], e = 0, f = 0; f < c.length; f++) {
                var g = c.charCodeAt(f);
                255 < g && (d[e++] = g & 255, g >>= 8);
                d[e++] = g
            }
            c = bf(d, 3);
            c = Fj(b, "format", "base64json", "p", c);
            b = new Image;
            Fb(b, "HTMLImageElement");
            c = c instanceof Oc ? c : Uc(c, /^data:image\//i.test(c));
            b.src = Pc(c);
            return !0
        })
    },
    xk = function(a,
        b, c, d) {
        if (0 != a.a.length) {
            var e = tk(a);
            for (var f = e.search(Ij), g = 0, k, l = []; 0 <= (k = Hj(e, g, "format", f));) l.push(e.substring(g, k)), g = Math.min(e.indexOf("&", k) + 1 || f, f);
            l.push(e.substr(g));
            e = l.join("").replace(Kj, "$1");
            e = Fj(e, "auth", a.N(), "authuser", a.m || "0");
            for (f = 0; f < c && a.a.length; ++f) {
                g = a.a.slice(0, b);
                k = lk(kk(rf(a.h)), g);
                if (!d(e, k)) break;
                a.a = a.a.slice(g.length)
            }
        }
    },
    uk = function() {
        this.type = "event-logged"
    };
t(uk, F);
var yk = function(a, b, c, d, e, f, g) {
    sk.call(this, a, Ji, b, dk, c, d, e, void 0, f, g)
};
t(yk, sk);
var zk = function(a, b) {
    this.a = new yk(375, a, void 0, !1, !0);
    Lg(this, this.a);
    this.a.X = !!Vf().navigator.sendBeacon && (Ye || Ue && Qe(45));
    this.a.na = !0;
    b && 0 < b.length && (a = new vf, a = A(a, 3, b || []), b = this.a, a ? (b.c || (b.c = new tf), a = a.o(), A(b.c, 4, a)) : b.c && A(b.c, 4, void 0));
    this.g = 0;
    this.b = new Ai(1E3);
    Lg(this, this.b);
    G(this.b, "tick", this.c, !1, this);
    this.b.start()
};
t(zk, J);
zk.prototype.T = function() {
    this.b.stop();
    oh(this.b, "tick", this.c, !1, this);
    this.c();
    zk.D.T.call(this)
};
zk.prototype.c = function() {
    0 < this.g && this.a.flush(p(this.h, this))
};
zk.prototype.h = function() {
    this.g = 0
};
zk.prototype.log = function(a) {
    this.a.log(a);
    900 <= ++this.g && this.c()
};
var Ak = function(a) {
        return (a = a.exec(pd)) ? a[1] : ""
    },
    Bk = function() {
        if (Ue) return Ak(/Firefox\/([0-9.]+)/);
        if (y || we || ve) return Oe;
        if (Ye) return qe() ? Ak(/CriOS\/([0-9.]+)/) : Ak(/Chrome\/([0-9.]+)/);
        if (Ze && !qe()) return Ak(/Version\/([0-9.]+)/);
        if (Ve || We) {
            var a = /Version\/(\S+).*Mobile\/(\S+)/.exec(pd);
            if (a) return a[1] + "." + a[2]
        } else if (Xe) return (a = Ak(/Android\s+([0-9.]+)/)) ? a : Ak(/Version\/([0-9.]+)/);
        return ""
    }(),
    Ck = function(a) {
        return 0 <= Lc(Bk, a)
    };
var Dk = function() {
    this.a = y ? Ck(9) : Ye && Ck(25) || y && Ck(8) || we || Ue && Ck(19) || ve && Ck(12.1) || Ze && Ck(5.1) || We && Ck(3.2) || Xe && Ck(2.1)
};
Fa(Dk);
var Gk = function(a, b) {
        var c = Ek[b];
        b = Fk[b];
        c = null != c ? xb(c) : [];
        if (a.a && null != b)
            for (a = 0; a < b.length; a++) c.push(b[a]);
        return c
    },
    Ik = function(a) {
        return 0 <= a.indexOf("-i0-") && !Hk(a)
    },
    Hk = function(a) {
        return 0 <= a.indexOf("-i0-handwrit")
    },
    Ek = {
        af: ["latn-002-t-k0-und"],
        am: ["am-t-i0-und", "und-ethi-t-k0-und"],
        ar: ["ar-t-i0-und", "ar-t-k0-und"],
        be: ["be-t-i0-und", "be-t-k0-und"],
        bg: ["bg-t-i0-und", "bg-t-k0-und", "bg-t-k0-qwerty"],
        bn: ["bn-t-i0-und", "bn-t-k0-und", "bn-t-und-latn-k0-und"],
        bs: ["bs-t-k0-und"],
        ca: ["ca-t-k0-und"],
        chr: ["chr-t-k0-und", "chr-t-und-latn-k0-und"],
        cs: ["cs-t-k0-und", "cs-t-k0-qwertz"],
        cy: ["latn-002-t-k0-und"],
        da: ["da-t-k0-und"],
        de: ["de-t-k0-und", "de-ch-t-k0-und", "en-us-t-k0-intl"],
        el: ["el-t-i0-und", "el-t-k0-und"],
        en: ["en-t-k0-und", "en-t-k0-dvorak"],
        es: ["es-t-k0-und", "en-us-t-k0-intl"],
        et: ["et-t-k0-und"],
        eu: ["eu-t-k0-und"],
        fa: ["fa-t-i0-und", "fa-t-k0-und"],
        fi: ["fi-t-k0-und"],
        fr: ["fr-t-k0-und", "en-us-t-k0-intl"],
        ga: ["latn-002-t-k0-und"],
        gl: ["gl-t-k0-und"],
        gu: ["gu-t-i0-und", "gu-t-k0-und", "gu-t-und-latn-k0-qwerty"],
        ha: ["latn-002-t-k0-und"],
        hi: ["hi-t-i0-und", "hi-t-k0-und", "hi-t-k0-qwerty"],
        hr: ["hr-t-k0-und"],
        ht: ["fr-t-k0-und"],
        hu: ["hu-t-k0-101key"],
        hy: ["hy-hyr-t-k0-und", "hy-hyt-t-k0-und"],
        id: ["latn-002-t-k0-und"],
        ig: ["latn-002-t-k0-und"],
        is: ["is-t-k0-und"],
        it: ["it-t-k0-und", "en-us-t-k0-intl"],
        iw: ["he-t-i0-und", "he-t-k0-und"],
        jw: ["latn-002-t-k0-und"],
        ja: ["ja-t-ja-hira-i0-und"],
        ka: ["ka-t-k0-und", "ka-t-k0-legacy"],
        kk: ["kk-t-k0-und"],
        km: ["km-t-k0-und"],
        kn: ["kn-t-i0-und", "kn-t-k0-und", "kn-t-und-latn-k0-und"],
        ko: ["ko-t-k0-und"],
        ku: ["ku-t-k0-und"],
        ky: ["ky-cyrl-t-k0-und"],
        lb: ["fr-t-k0-und", "en-us-t-k0-intl"],
        lo: ["lo-t-k0-und"],
        lt: ["lt-t-k0-und"],
        lv: ["lv-t-k0-und"],
        mg: ["latn-002-t-k0-und"],
        mi: ["mi-t-k0-und"],
        mk: ["mk-t-k0-und"],
        ml: ["ml-t-i0-und", "ml-t-und-latn-k0-und", "ml-t-k0-und"],
        mn: ["mn-cyrl-t-k0-und"],
        mr: ["mr-t-i0-und", "hi-t-k0-qwerty"],
        ms: ["latn-002-t-k0-und"],
        mt: ["mt-t-k0-und"],
        my: ["my-t-k0-und", "my-t-k0-myansan"],
        ne: ["ne-t-i0-und", "ne-t-k0-und", "ne-t-und-latn-k0-und"],
        nl: ["nl-t-k0-und", "en-us-t-k0-intl"],
        no: ["no-t-k0-und"],
        ny: ["latn-002-t-k0-und"],
        pa: ["pa-t-i0-und", "pa-guru-t-und-latn-k0-und", "pa-guru-t-k0-und"],
        pl: ["pl-t-k0-und"],
        ps: ["ps-t-k0-und"],
        pt: ["pt-br-t-k0-und", "pt-pt-t-k0-und", "en-us-t-k0-intl"],
        ro: ["ro-t-k0-und", "ro-t-k0-legacy", "ro-t-k0-extended"],
        ru: ["ru-t-i0-und", "ru-t-k0-und"],
        rw: ["latn-002-t-k0-und"],
        sd: ["sd-t-k0-und"],
        si: ["si-t-i0-und", "si-t-k0-und"],
        sk: ["sk-t-k0-und", "sk-t-k0-qwerty"],
        sl: ["sl-t-k0-und"],
        sn: ["latn-002-t-k0-und"],
        so: ["latn-002-t-k0-und"],
        sq: ["sq-t-k0-und"],
        sr: ["sr-t-i0-und", "sr-cyrl-t-k0-und",
            "sr-latn-t-k0-und"
        ],
        st: ["latn-002-t-k0-und"],
        su: ["latn-002-t-k0-und"],
        sv: ["sv-t-k0-und"],
        sw: ["latn-002-t-k0-und"],
        ta: "ta-t-i0-und ta-t-k0-ta99 ta-t-und-latn-k0-und ta-t-k0-und ta-t-k0-typewriter ta-t-k0-itrans".split(" "),
        te: ["te-t-i0-und", "te-t-k0-und", "te-t-und-latn-k0-und"],
        tg: ["tg-t-k0-und"],
        th: ["th-t-i0-und", "th-t-k0-und", "th-t-k0-pattajoti", "th-t-k0-tis"],
        tk: ["latn-002-t-k0-und"],
        tl: ["latn-002-t-k0-und"],
        tr: ["tr-t-k0-und", "tr-t-k0-legacy"],
        tt: ["tt-t-k0-und"],
        ug: ["ug-t-k0-und"],
        uk: ["uk-t-i0-und",
            "uk-t-k0-101key"
        ],
        ur: ["ur-t-i0-und", "ur-t-k0-und"],
        uz: ["uz-latn-t-k0-und", "uz-cyrl-t-k0-und", "uz-cyrl-t-k0-legacy"],
        vi: ["vi-t-i0-und", "vi-t-k0-legacy", "vi-t-k0-viqr", "vi-t-k0-und", "vi-t-k0-vni"],
        wo: ["latn-002-t-k0-und"],
        xh: ["latn-002-t-k0-und"],
        yi: ["yi-t-k0-und"],
        yo: ["latn-002-t-k0-und"],
        yue: ["yue-hant-t-i0-und", "zh-hant-t-i0-cangjie-1982"],
        zu: ["latn-002-t-k0-und"],
        "zh-CN": "zh-t-i0-pinyin zh-t-i0-wubi-1986 zh-hant-t-i0-und zh-hant-t-i0-cangjie-1982 zh-hant-t-i0-pinyin yue-hant-t-i0-und".split(" "),
        "zh-TW": ["zh-hant-t-i0-und", "zh-hant-t-i0-cangjie-1982", "zh-hant-t-i0-pinyin", "yue-hant-t-i0-und"]
    },
    Fk = {
        af: ["af-t-i0-handwrit"],
        am: ["am-t-i0-handwrit"],
        ar: ["ar-t-i0-handwrit"],
        auto: ["mul-t-i0-handwrit"],
        az: ["az-t-i0-handwrit"],
        be: ["be-t-i0-handwrit"],
        bg: ["bg-t-i0-handwrit"],
        bn: ["bn-t-i0-handwrit"],
        bs: ["bs-t-i0-handwrit"],
        ca: ["ca-t-i0-handwrit"],
        ceb: ["ceb-t-i0-handwrit"],
        co: ["co-t-i0-handwrit"],
        cs: ["cs-t-i0-handwrit"],
        cy: ["cy-t-i0-handwrit"],
        da: ["da-t-i0-handwrit"],
        de: ["de-t-i0-handwrit"],
        el: ["el-t-i0-handwrit"],
        en: ["en-t-i0-handwrit"],
        eo: ["eo-t-i0-handwrit"],
        es: ["es-t-i0-handwrit"],
        et: ["et-t-i0-handwrit"],
        eu: ["eu-t-i0-handwrit"],
        fa: ["fa-t-i0-handwrit"],
        fi: ["fi-t-i0-handwrit"],
        fr: ["fr-t-i0-handwrit"],
        fy: ["fy-t-i0-handwrit"],
        ga: ["ga-t-i0-handwrit"],
        gd: ["gd-t-i0-handwrit"],
        gl: ["gl-t-i0-handwrit"],
        gu: ["gu-t-i0-handwrit"],
        haw: ["haw-t-i0-handwrit"],
        hi: ["hi-t-i0-handwrit"],
        hmn: ["hmn-t-i0-handwrit"],
        hr: ["hr-t-i0-handwrit"],
        ht: ["ht-t-i0-handwrit"],
        hu: ["hu-t-i0-handwrit"],
        hy: ["hy-t-i0-handwrit"],
        id: ["id-t-i0-handwrit"],
        is: ["is-t-i0-handwrit"],
        it: ["it-t-i0-handwrit"],
        iw: ["he-t-i0-handwrit"],
        ja: ["ja-t-i0-handwrit"],
        jv: ["jv-t-i0-handwrit"],
        ka: ["ka-t-i0-handwrit"],
        kk: ["kk-t-i0-handwrit"],
        km: ["km-t-i0-handwrit"],
        kn: ["kn-t-i0-handwrit"],
        ko: ["ko-t-i0-handwrit"],
        ku: ["ku-t-i0-handwrit"],
        ky: ["ky-t-i0-handwrit"],
        la: ["la-t-i0-handwrit"],
        lb: ["lb-t-i0-handwrit"],
        lo: ["lo-t-i0-handwrit"],
        lt: ["lt-t-i0-handwrit"],
        lv: ["lv-t-i0-handwrit"],
        mg: ["mg-t-i0-handwrit"],
        mi: ["mi-t-i0-handwrit"],
        mk: ["mk-t-i0-handwrit"],
        ml: ["ml-t-i0-handwrit"],
        mn: ["mn-t-i0-handwrit"],
        mr: ["mr-t-i0-handwrit"],
        ms: ["ms-t-i0-handwrit"],
        mt: ["mt-t-i0-handwrit"],
        my: ["my-t-i0-handwrit"],
        ne: ["ne-t-i0-handwrit"],
        nl: ["nl-t-i0-handwrit"],
        no: ["no-t-i0-handwrit"],
        ny: ["ny-t-i0-handwrit"],
        pa: ["pa-t-i0-handwrit"],
        pl: ["pl-t-i0-handwrit"],
        pt: ["pt-t-i0-handwrit"],
        ro: ["ro-t-i0-handwrit"],
        ru: ["ru-t-i0-handwrit"],
        si: ["si-t-i0-handwrit"],
        sk: ["sk-t-i0-handwrit"],
        sl: ["sl-t-i0-handwrit"],
        sm: ["sm-t-i0-handwrit"],
        sn: ["sn-t-i0-handwrit"],
        so: ["so-t-i0-handwrit"],
        sq: ["sq-t-i0-handwrit"],
        sr: ["sr-t-i0-handwrit"],
        su: ["su-t-i0-handwrit"],
        sv: ["sv-t-i0-handwrit"],
        sw: ["sw-t-i0-handwrit"],
        ta: ["ta-t-i0-handwrit"],
        te: ["te-t-i0-handwrit"],
        tg: ["tg-t-i0-handwrit"],
        th: ["th-t-i0-handwrit"],
        tl: ["fil-t-i0-handwrit"],
        tr: ["tr-t-i0-handwrit"],
        uk: ["uk-t-i0-handwrit"],
        ur: ["ur-t-i0-handwrit"],
        uz: ["uz-t-i0-handwrit"],
        vi: ["vi-t-i0-handwrit"],
        xh: ["xh-t-i0-handwrit"],
        "zh-CN": ["zh-t-i0-handwrit"],
        zu: ["zu-t-i0-handwrit"]
    };
var Jk = function(a) {
    gf(this, a, -1, null)
};
t(Jk, cf);
Jk.prototype.Nd = function() {
    return hf(this, 1)
};
Jk.prototype.fb = function() {
    return hf(this, 4)
};
var Kk = function(a) {
    gf(this, a, -1, null)
};
t(Kk, cf);
var Mk = function(a) {
    gf(this, a, -1, null)
};
t(Mk, cf);
var Nk = function(a) {
    gf(this, a, -1, null)
};
t(Nk, cf);
var Pk = function(a) {
    gf(this, a, -1, Ok)
};
t(Pk, cf);
var Ok = [1];
var Qk = function(a) {
    gf(this, a, -1, null)
};
t(Qk, cf);
var Rk = function(a) {
    gf(this, a, -1, null)
};
t(Rk, cf);
var Sk = function(a) {
    gf(this, a, -1, null)
};
t(Sk, cf);
var Tk = function(a) {
    gf(this, a, -1, null)
};
t(Tk, cf);
var Uk = function(a) {
    gf(this, a, -1, null)
};
t(Uk, cf);
Uk.prototype.Ua = function() {
    return hf(this, 1)
};
var Vk = function(a) {
    gf(this, a, -1, null)
};
t(Vk, cf);
var Xk = function(a) {
    gf(this, a, -1, Wk)
};
t(Xk, cf);
var Wk = [1, 3, 4];
var Yk = function(a) {
    gf(this, a, -1, null)
};
t(Yk, cf);
var Zk = function() {
    var a = new Yk;
    return A(a, 1, 1)
};
var $k = function(a) {
    gf(this, a, -1, null)
};
t($k, cf);
$k.prototype.Kb = function() {
    return hf(this, 1)
};
var al = function(a) {
    gf(this, a, -1, null)
};
t(al, cf);
var cl = function(a) {
    gf(this, a, -1, bl)
};
t(cl, cf);
var bl = [1];
cl.prototype.fb = function() {
    return hf(this, 5)
};
var dl = function(a) {
    gf(this, a, -1, null)
};
t(dl, cf);
var fl = function(a) {
    gf(this, a, -1, el)
};
t(fl, cf);
var el = [2];
var gl = function(a) {
    gf(this, a, -1, null)
};
t(gl, cf);
var hl = function() {
    var a = new gl;
    return A(a, 1, 3)
};
var il = function(a) {
    gf(this, a, -1, null)
};
t(il, cf);
var jl = function(a) {
    gf(this, a, -1, null)
};
t(jl, cf);
jl.prototype.mf = function() {
    return hf(this, 4)
};
jl.prototype.Hi = function() {
    return null != hf(this, 4)
};
var kl = function(a) {
    gf(this, a, -1, null)
};
t(kl, cf);
var ml = function(a) {
    gf(this, a, -1, ll)
};
t(ml, cf);
var ll = [3, 4];
var ol = function(a) {
    gf(this, a, -1, nl)
};
t(ol, cf);
var nl = [3];
ol.prototype.Be = function() {
    return hf(this, 1)
};
var ql = function(a) {
    gf(this, a, -1, pl)
};
t(ql, cf);
var pl = [2];
var sl = function(a) {
    gf(this, a, -1, rl)
};
t(sl, cf);
var rl = [26, 80];
sl.prototype.Ce = function() {
    return hf(this, 1)
};
sl.prototype.Be = function() {
    return hf(this, 53)
};
var tl = function() {
        this.h = 0;
        this.G = this.o = this.g = this.c = this.w = "";
        this.m = this.b = this.C = 0;
        Dk.M();
        this.a = null
    },
    ul = {
        bh: 27,
        btn: 1,
        clks: 2,
        clkt: 3,
        pb: 4,
        sel: 5,
        selalt: 6,
        tws_confirm: 7,
        tws_lsugg: 8,
        tws_revert: 9,
        tws_spell: 10,
        is: 11
    };
Fa(tl);
var vl = function() {
        var a = DATA.DisplayLanguage,
            b = tl.M();
        b.h = 2;
        b.w = a;
        return b
    },
    wl = function(a, b) {
        "string" === typeof b && (b = ul[b], b = null != b ? b : 0);
        a.C = b
    },
    xl = function(a, b) {
        if ("string" === typeof b) {
            var c = 0;
            0 <= b.indexOf("-k0-") ? c = 2 : Ik(b) ? c = 1 : Hk(b) && (c = 5);
            b = c
        }
        a.b = b
    };
tl.prototype.store = function(a) {
    A(a, 65, this.h);
    A(a, 16, this.c);
    A(a, 14, this.o);
    A(a, 1, this.g);
    A(a, 50, this.w);
    A(a, 52, this.G);
    A(a, 32, this.b)
};
var zl = function(a, b) {
        var c = a[b - 1];
        if (null == c || yl(c)) a = a[a.length - 1], yl(a) && (c = a[b]);
        return c
    },
    yl = function(a) {
        return La(a) && !Ja(a)
    };
var Bl = function(a, b) {
        return a === b ? !0 : nb(a, function(c, d) {
            if (yl(c)) {
                d = bb(c);
                for (var e in d) {
                    c = d[e];
                    var f = zl(b, +e);
                    if (!Al(c, f)) return !1
                }
                return !0
            }
            e = zl(b, d + 1);
            return Al(c, e)
        }) && nb(b, function(c, d) {
            if (yl(c)) {
                c = bb(c);
                for (var e in c)
                    if (null == zl(a, +e)) return !1;
                return !0
            }
            return null == c == (null == zl(a, d + 1))
        })
    },
    Al = function(a, b) {
        return a === b || null == a && null == b || !(!0 !== a && 1 !== a || !0 !== b && 1 !== b) || !(!1 !== a && 0 !== a || !1 !== b && 0 !== b) ? !0 : Ia(a) && Ia(b) ? Bl(cb(a), cb(b)) : !1
    };
var Cl = function() {},
    Dl = function(a, b, c) {
        a = a.Wa = b = b || [];
        if (a.length) {
            var d = a.length - 1;
            b = a[d];
            if (yl(b) && (delete a[d], d < c)) {
                d = 0;
                for (var e in b) {
                    var f = +e;
                    f <= c ? (a[f - 1] = b[e], delete b[e]) : d++
                }
                d && (a[c] = b)
            }
        }
    },
    Eh = function(a, b) {
        return null != a.Wa[b]
    },
    El = function(a, b, c) {
        a = a.Wa[b];
        return null != a ? a : c
    },
    Fl = function(a, b) {
        return !!El(a, b, void 0)
    },
    Ih = function(a, b) {
        return El(a, b, 0)
    },
    I = function(a, b, c) {
        return El(a, b, c || "")
    },
    Gl = function(a, b) {
        a = a.Wa;
        a[b] || (a[b] = []);
        return a[b]
    },
    Gh = function(a, b, c) {
        return Gl(a, b)[c]
    },
    Hl = function(a,
        b, c) {
        return Gl(a, b)[c]
    },
    Il = function(a, b, c) {
        for (var d = [], e = 0; e < H(a, b); e++) d.push(new c(Hl(a, b, e)));
        return d.slice().values()
    },
    H = function(a, b) {
        return a.Wa[b] ? a.Wa[b].length : 0
    };
Cl.prototype.zb = function() {
    return this.Wa
};
var Jl = function(a) {
    var b = a.za();
    a = a.Wa;
    for (var c = {}, d = 0; d < a.length; d++)
        if (void 0 !== a[d] && null !== a[d]) {
            var e = !1,
                f = void 0,
                g = void 0,
                k;
            for (k in b)
                if (g = b[k], f = k, g.H == d) {
                    e = !0;
                    break
                } if (e)
                if (g = v(g), g.sa)
                    if (g.J)
                        for (c[f] = [], e = 0; e < a[d].length; e++) c[f].push(g.sa(a[d][e]));
                    else c[f] = g.sa(a[d]);
            else c[f] = a[d]
        } return c
};
Cl.prototype.toString = function() {
    return JSON.stringify(Jl(this))
};
var Kl = function(a, b) {
    var c = [];
    a = new a(c);
    var d = gb(a, Cl).za(),
        e;
    for (e in b) {
        var f = v(d[e]),
            g = b[e];
        if (f.va)
            if (g instanceof Array) {
                var k = [];
                for (var l = 0; l < g.length; l++) k.push(f.va(g[l]).zb())
            } else k = f.va(g).zb();
        else k = g;
        c[f.H] = k
    }
    return a
};
var Ll = function(a) {
    Dl(this, a, 1)
};
t(Ll, Cl);
var Ml = {
    romanization: {
        H: 0,
        J: !1
    }
};
Ll.prototype.za = function() {
    return Ml
};
var Nl = function(a) {
    Dl(this, a, 3)
};
t(Nl, Cl);
var Ol = {
    source_span_index: {
        H: 0,
        J: !1
    },
    target_span_index: {
        H: 1,
        J: !1
    },
    direction: {
        H: 2,
        J: !1
    }
};
Nl.prototype.za = function() {
    return Ol
};
var Pl = function(a) {
    Dl(this, a, 2)
};
t(Pl, Cl);
var Ql = {
    begin: {
        H: 0,
        J: !1
    },
    end: {
        H: 1,
        J: !1
    }
};
Pl.prototype.za = function() {
    return Ql
};
var Rl = function(a) {
    Dl(this, a, 3)
};
t(Rl, Cl);
var Sl = {
    source_span: {
        H: 0,
        va: function(a) {
            return Kl(Pl, a)
        },
        sa: function(a) {
            return Jl(new Pl(a))
        },
        J: !0
    },
    target_span: {
        H: 1,
        va: function(a) {
            return Kl(Pl, a)
        },
        sa: function(a) {
            return Jl(new Pl(a))
        },
        J: !0
    },
    link: {
        H: 2,
        va: function(a) {
            return Kl(Nl, a)
        },
        sa: function(a) {
            return Jl(new Nl(a))
        },
        J: !0
    }
};
Rl.prototype.za = function() {
    return Sl
};
var Tl = function(a) {
    Dl(this, a, 2)
};
t(Tl, Cl);
var Ul = {
    model_path: {
        H: 0,
        J: !1
    },
    label: {
        H: 1,
        J: !1
    }
};
Tl.prototype.za = function() {
    return Ul
};
var Vl = function(a) {
    Dl(this, a, 2)
};
t(Vl, Cl);
var Wl = {
    checkpoint_md5: {
        H: 0,
        J: !1
    },
    launch_doc: {
        H: 1,
        J: !1
    }
};
Vl.prototype.za = function() {
    return Wl
};
var Xl = function(a) {
    Dl(this, a, 1)
};
t(Xl, Cl);
var Yl = {
    model_tracking: {
        H: 0,
        va: function(a) {
            return Kl(Vl, a)
        },
        sa: function(a) {
            return Jl(new Vl(a))
        },
        J: !1
    }
};
Xl.prototype.za = function() {
    return Yl
};
var Zl = function(a) {
    Dl(this, a, 9)
};
t(Zl, Cl);
var $l = {
    trans: {
        H: 0,
        J: !1
    },
    orig: {
        H: 1,
        J: !1
    },
    translit: {
        H: 2,
        J: !1
    },
    src_translit: {
        H: 3,
        J: !1
    },
    backend: {
        H: 4,
        J: !1
    },
    model: {
        H: 5,
        J: !0
    },
    word_alignment: {
        H: 6,
        va: function(a) {
            return Kl(Rl, a)
        },
        sa: function(a) {
            return Jl(new Rl(a))
        },
        J: !1
    },
    model_specification: {
        H: 7,
        va: function(a) {
            return Kl(Tl, a)
        },
        sa: function(a) {
            return Jl(new Tl(a))
        },
        J: !0
    },
    translation_engine_debug_info: {
        H: 8,
        va: function(a) {
            return Kl(Xl, a)
        },
        sa: function(a) {
            return Jl(new Xl(a))
        },
        J: !0
    }
};
Zl.prototype.za = function() {
    return $l
};
Zl.prototype.Tc = function() {
    return I(this, 0)
};
Zl.prototype.Hi = function() {
    return Eh(this, 4)
};
Zl.prototype.mf = function() {
    return El(this, 4, 0)
};
var am = function(a) {
    Dl(this, a, 4)
};
t(am, Cl);
var bm = {
    gender: {
        H: 0,
        J: !1
    },
    translation: {
        H: 1,
        J: !1
    },
    sentences: {
        H: 2,
        va: function(a) {
            return Kl(Zl, a)
        },
        sa: function(a) {
            return Jl(new Zl(a))
        },
        J: !0
    },
    romanization: {
        H: 3,
        va: function(a) {
            return Kl(Ll, a)
        },
        sa: function(a) {
            return Jl(new Ll(a))
        },
        J: !1
    }
};
h = am.prototype;
h.za = function() {
    return bm
};
h.Rc = function() {
    return El(this, 0, 0)
};
h.tb = function() {
    return I(this, 1)
};
h.jc = function() {
    return H(this, 2)
};
h.cb = function(a) {
    return new Zl(Hl(this, 2, a))
};
var cm = function(a) {
    Dl(this, a, 2)
};
t(cm, Cl);
var dm = {
    gendered_translations: {
        H: 0,
        va: function(a) {
            return Kl(am, a)
        },
        sa: function(a) {
            return Jl(new am(a))
        },
        J: !0
    },
    status: {
        H: 1,
        J: !1
    }
};
cm.prototype.za = function() {
    return dm
};
cm.prototype.Sc = function() {
    return El(this, 1, 0)
};
var K = function() {
    this.b = null;
    this.a = tl.M()
};
t(K, Jg);
Fa(K);
K.prototype.config = function(a, b) {
    this.b = new zk(a, b);
    Lg(this, this.b)
};
var gm = function(a, b, c, d, e) {
        b = em(a, 237, b, void 0, void 0, void 0, e);
        if (null != c) {
            e = new Pk;
            var f = a.a.a;
            null != f && A(e, 1, f || []);
            A(e, 2, fm(c));
            lf(b, 83, e)
        }
        void 0 !== d && 0 != d && A(b, 74, d);
        M(a, b)
    },
    hm = function(a, b, c) {
        M(a, em(a, 190, b, c, !0, 0))
    },
    im = function(a, b, c, d) {
        M(a, em(a, 78, b, c, d, 0))
    },
    jm = function(a, b) {
        var c = N(a, 21),
            d = hl();
        lf(c, 56, d);
        if (null != b) {
            d = new Pk;
            var e = a.a.a;
            null != e && A(d, 1, e || []);
            A(d, 2, fm(b));
            lf(c, 83, d)
        }
        M(a, c)
    },
    km = {},
    lm = (km.st = 231, km.unst = 232, km.sw = 229, km.lnk = 230, km),
    mm = function(a, b, c) {
        var d = N(a, 148),
            e = new Mk;
        b = A(e, 1, b);
        c && A(b, 5, c);
        lf(d, 63, b);
        M(a, d)
    },
    nm = function(a, b) {
        b = N(a, b);
        var c = Zk();
        lf(b, 46, c);
        M(a, b)
    },
    om = function(a, b, c, d, e, f) {
        b = N(a, b ? 84 : 85);
        var g = Zk();
        c = A(g, 2, c);
        d = A(c, 3, d);
        e = A(d, 4, e + 1);
        0 < f.length && A(e, 5, f);
        lf(b, 46, e);
        M(a, b)
    },
    qm = function(a, b, c) {
        M(a, pm(a, 251, b, c))
    },
    sm = function(a, b) {
        M(a, rm(a, 71, b))
    },
    tm = function(a, b) {
        M(a, rm(a, 72, b))
    },
    um = function(a, b) {
        var c = N(a, 244);
        b = A(c, 74, b);
        M(a, b)
    },
    wm = function(a, b) {
        M(a, vm(a, 245, b))
    },
    xm = function(a) {
        M(a, N(a, 223))
    },
    ym = function(a) {
        var b = K.M(),
            c = N(b, 22),
            d = hl();
        a = A(d, 2, a);
        lf(c, 56, a);
        M(b, c)
    };
K.prototype.c = function() {
    M(this, N(this, 145))
};
var zm = function(a, b, c, d, e, f, g, k) {
        b = N(a, b);
        var l = new jl;
        c = A(l, 1, c);
        c = A(c, 4, 1);
        d = A(c, 7, d);
        e = A(d, 5, e);
        f && A(e, 8, f);
        void 0 !== g && A(e, 6, g + 1);
        lf(b, 43, e);
        null != k && (f = new Pk, k = A(f, 2, fm(k)), f = a.a.a, null != f && A(k, 1, f || []), lf(b, 83, k));
        M(a, b)
    },
    Am = function(a) {
        var b = N(a, 1);
        A(b, 53, a.a.C);
        M(a, b);
        wl(a.a, 0)
    },
    Bm = function(a, b, c, d) {
        b = N(a, b);
        var e = new kl;
        c = A(e, 1, c);
        d = A(c, 2, d);
        lf(b, 75, d);
        M(a, b)
    };
K.prototype.g = function() {
    M(this, N(this, 25))
};
var Cm = function(a, b) {
        for (var c = N(a, 339), d = new Pk, e = 0; e < b.length; e++) {
            var f = fm(b[e].Rc());
            gb(d, cf);
            hf(d, 1).push(f)
        }
        b = hf(d, 1);
        a.a.a = b;
        lf(c, 83, d);
        M(a, c)
    },
    N = function(a, b) {
        var c = new sl;
        a.a.store(c);
        A(c, 31, b);
        return c
    },
    em = function(a, b, c, d, e, f, g) {
        var k = new Jk;
        c = A(k, 1, c);
        void 0 !== d && A(c, 4, d);
        void 0 !== e && A(c, 2, e);
        void 0 !== f && 0 != f && A(c, 3, f);
        void 0 !== g && 0 != g && A(c, 5, g);
        a = N(a, b);
        return lf(a, 61, c)
    },
    Dm = function(a, b, c, d) {
        var e = new Qk;
        c = A(e, 1, c + 1);
        d = A(c, 2, d);
        a = N(a, b);
        return lf(a, 60, d)
    },
    Em = function(a, b, c, d, e, f, g, k) {
        for (var l =
                new Xk, m = [], q = 0; q < c.length; q++) {
            var r = c[q];
            var u = new Rk;
            u = A(u, 1, r[0]);
            r = A(u, 2, !!r[1]);
            m.push(r)
        }
        mf(l, 1, m);
        c = new Vk;
        d = A(c, 1, !!d);
        lf(l, 2, d);
        d = [];
        for (c = 0; c < e.length; c++) m = new Uk, m = A(m, 1, e[c]), d.push(m);
        mf(l, 3, d);
        e = [];
        for (d = 0; d < f.length; d++) c = f[d], m = new Sk, m = A(m, 1, !!c[0]), c = A(m, 2, !!c[1]), e.push(c);
        mf(l, 4, e);
        g && (f = new Tk, f = A(f, 1, !0), lf(l, 5, f));
        0 != k && A(l, 6, k);
        a = N(a, b);
        return lf(a, 66, l)
    },
    Fm = function(a, b) {
        a = N(a, b);
        b = new cl;
        b = A(b, 1, []);
        A(b, 4, 1);
        lf(a, 59, b);
        return a
    },
    pm = function(a, b, c, d) {
        var e = new al;
        d = A(e,
            1, d);
        a = N(a, b);
        c = A(a, 74, c);
        return lf(c, 71, d)
    },
    rm = function(a, b, c) {
        var d = new dl;
        c = A(d, 1, c);
        a = N(a, b);
        return lf(a, 44, c)
    },
    vm = function(a, b, c) {
        a = N(a, b);
        b = new cl;
        c = A(b, 5, c);
        lf(a, 59, c);
        return a
    },
    M = function(a, b) {
        if (a.b) {
            var c = new hk;
            b = b.o();
            c = A(c, 8, b);
            a.b.log(c)
        }
    },
    fm = function(a) {
        switch (a) {
            case 2:
                return 1;
            case 1:
                return 2;
            default:
                return 0
        }
    };
var Gm = function() {
    this.g = [];
    this.b = {};
    this.a = {};
    this.h = !1;
    this.oh = 1;
    this.pe = {};
    this.c = null;
    this.o = "";
    G(window, "beforeunload", this.G, !1, this)
};
Fa(Gm);
var Hm = function(a, b, c) {
        if (null == b) return "1";
        switch (Ga(b)) {
            case "string":
                return a = b, 64 < a.length && (null == c || !c) && (a = a.substr(0, 64)), be(a);
            case "number":
                return "" + b;
            case "boolean":
                return b ? "1" : "0";
            case "array":
                var d = [],
                    e;
                for (e in b) d.push(Hm(a, b[e], c));
                return d.join(",");
            case "object":
                d = [];
                for (e in b) d.push(Im(a, e, b[e], c));
                return d.join(",");
            default:
                return ""
        }
    },
    Im = function(a, b, c, d) {
        return [be(b), Hm(a, c, d || "smtalt" == b)].join("=")
    };
Gm.prototype.log = function(a, b) {
    this.g.push([a, b]);
    this.h || (this.h = !0, Ci(this.m, 0, this))
};
var O = function(a, b, c, d, e) {
        b = a.o + "/gen204?" + Im(a, c, d) + "&" + Im(a, "client", b, !0);
        e && (b += Jm(a, e));
        Km(a, b)
    },
    Jm = function(a, b) {
        var c = "";
        void 0 !== b && Jb(b, function(d, e) {
            if (d instanceof Array)
                for (var f = 0; f < d.length; f++) c += "&" + Im(this, e, d[f]);
            else c += "&" + Im(this, e, d)
        }, a);
        return c
    };
Gm.prototype.m = function() {
    for (var a = 0; a < this.g.length; a++) {
        var b = this.g[a];
        Lm(this, b[0], b[1])
    }
    this.g = [];
    this.h = !1
};
var Lm = function(a, b, c) {
        Km(a, a.o + "/gen204?" + (a.c ? ["client=", a.c, "&"].join("") : "") + Im(a, b, c))
    },
    Km = function(a, b) {
        var c = new Image,
            d = a.oh++;
        a.pe[d] = c;
        c.onload = c.onerror = function() {
            delete Gm.M().pe[d]
        };
        c.src = b;
        c = null
    },
    Nm = function(a, b, c, d) {
        var e = null;
        b in a.b && (e = a.b[b]);
        a.b[b] = Mm(e, c, d)
    },
    Om = function(a, b) {
        var c = 0,
            d = null;
        b in a.a && (d = a.a[b], c = d[0], d = d[1]);
        d = Mm(d, 1, "accumulate");
        a.a[b] = [c, d];
        Di(a.a[b][0]);
        c = Ci(p(a.w, a, b), 2E3);
        a.a[b][0] = c
    };
Gm.prototype.w = function(a) {
    Lm(this, a, this.a[a][1]);
    a in this.a && (Di(this.a[a][0]), delete this.a[a])
};
var Pm = function(a, b, c) {
        null == b && (b = 1);
        "accumulate" == c ? (isNaN(a) && (a = parseInt(a, 10)), isNaN(b) && (b = parseInt(b, 10)), a += b) : a = b;
        return a
    },
    Mm = function(a, b, c) {
        if ("object" == Ga(b)) {
            "object" != Ga(a) && (a = {});
            for (var d in b) a[d] = Pm(d in a ? a[d] : null, b[d], c)
        } else a = Pm(a, b, c);
        return a
    },
    Qm = function(a) {
        var b = [],
            c;
        for (c in a.b) b.push(Im(a, c, a.b[c]));
        a.b = {};
        return b.join("&")
    };
Gm.prototype.G = function() {
    this.m();
    for (var a in this.a) 0 != this.a[a] && this.w(a)
};
var Rm = function(a, b) {
    this.b = this.m = this.c = "";
    this.o = null;
    this.h = this.w = "";
    this.g = !1;
    var c;
    a instanceof Rm ? (this.g = void 0 !== b ? b : a.g, Sm(this, a.c), this.m = a.m, this.b = a.b, Tm(this, a.o), Vm(this, a.w), Wm(this, Xm(a.a)), this.h = a.h) : a && (c = String(a).match(zj)) ? (this.g = !!b, Sm(this, c[1] || "", !0), this.m = Ym(c[2] || ""), this.b = Ym(c[3] || "", !0), Tm(this, c[4]), Vm(this, c[5] || "", !0), Wm(this, c[6] || "", !0), this.h = Ym(c[7] || "")) : (this.g = !!b, this.a = new Zm(null, this.g))
};
Rm.prototype.toString = function() {
    var a = [],
        b = this.c;
    b && a.push($m(b, an, !0), ":");
    var c = this.b;
    if (c || "file" == b) a.push("//"), (b = this.m) && a.push($m(b, an, !0), "@"), a.push(be(c).replace(/%25([0-9a-fA-F]{2})/g, "%$1")), c = this.o, null != c && a.push(":", String(c));
    if (c = this.w) this.b && "/" != c.charAt(0) && a.push("/"), a.push($m(c, "/" == c.charAt(0) ? bn : cn, !0));
    (c = this.a.toString()) && a.push("?", c);
    (c = this.h) && a.push("#", $m(c, dn));
    return a.join("")
};
var Sm = function(a, b, c) {
        a.c = c ? Ym(b, !0) : b;
        a.c && (a.c = a.c.replace(/:$/, ""))
    },
    Tm = function(a, b) {
        if (b) {
            b = Number(b);
            if (isNaN(b) || 0 > b) throw Error("Bad port number " + b);
            a.o = b
        } else a.o = null
    },
    Vm = function(a, b, c) {
        a.w = c ? Ym(b, !0) : b
    },
    Wm = function(a, b, c) {
        b instanceof Zm ? (a.a = b, en(a.a, a.g)) : (c || (b = $m(b, fn)), a.a = new Zm(b, a.g))
    },
    hn = function(a, b, c) {
        Ia(c) || (c = [String(c)]);
        gn(a.a, b, c)
    },
    jn = function(a) {
        return a instanceof Rm ? new Rm(a) : new Rm(a, void 0)
    },
    Ym = function(a, b) {
        return a ? b ? decodeURI(a.replace(/%25/g, "%2525")) : decodeURIComponent(a) :
            ""
    },
    $m = function(a, b, c) {
        return "string" === typeof a ? (a = encodeURI(a).replace(b, kn), c && (a = a.replace(/%25([0-9a-fA-F]{2})/g, "%$1")), a) : null
    },
    kn = function(a) {
        a = a.charCodeAt(0);
        return "%" + (a >> 4 & 15).toString(16) + (a & 15).toString(16)
    },
    an = /[#\/\?@]/g,
    cn = /[#\?:]/g,
    bn = /[#\?]/g,
    fn = /[#\?@]/g,
    dn = /#/g,
    Zm = function(a, b) {
        this.b = this.a = null;
        this.c = a || null;
        this.h = !!b
    },
    ln = function(a) {
        a.a || (a.a = new tj, a.b = 0, a.c && Aj(a.c, function(b, c) {
            a.add(ce(b), c)
        }))
    };
Zm.prototype.Hg = function() {
    ln(this);
    return this.b
};
Zm.prototype.add = function(a, b) {
    ln(this);
    this.c = null;
    a = mn(this, a);
    var c = this.a.get(a);
    c || this.a.set(a, c = []);
    c.push(b);
    this.b = Za(this.b) + 1;
    return this
};
var nn = function(a, b) {
        ln(a);
        b = mn(a, b);
        wj(a.a, b) && (a.c = null, a.b = Za(a.b) - a.a.get(b).length, a = a.a, vj(a.b, b) && (delete a.b[b], a.c--, a.g++, a.a.length > 2 * a.c && uj(a)))
    },
    on = function(a, b) {
        ln(a);
        b = mn(a, b);
        return wj(a.a, b)
    };
h = Zm.prototype;
h.forEach = function(a, b) {
    ln(this);
    this.a.forEach(function(c, d) {
        w(c, function(e) {
            a.call(b, e, d, this)
        }, this)
    }, this)
};
h.Cb = function() {
    ln(this);
    for (var a = this.a.Wb(), b = this.a.Cb(), c = [], d = 0; d < b.length; d++)
        for (var e = a[d], f = 0; f < e.length; f++) c.push(b[d]);
    return c
};
h.Wb = function(a) {
    ln(this);
    var b = [];
    if ("string" === typeof a) on(this, a) && (b = vb(b, this.a.get(mn(this, a))));
    else {
        a = this.a.Wb();
        for (var c = 0; c < a.length; c++) b = vb(b, a[c])
    }
    return b
};
h.set = function(a, b) {
    ln(this);
    this.c = null;
    a = mn(this, a);
    on(this, a) && (this.b = Za(this.b) - this.a.get(a).length);
    this.a.set(a, [b]);
    this.b = Za(this.b) + 1;
    return this
};
h.get = function(a, b) {
    if (!a) return b;
    a = this.Wb(a);
    return 0 < a.length ? String(a[0]) : b
};
var gn = function(a, b, c) {
    nn(a, b);
    0 < c.length && (a.c = null, a.a.set(mn(a, b), xb(c)), a.b = Za(a.b) + c.length)
};
Zm.prototype.toString = function() {
    if (this.c) return this.c;
    if (!this.a) return "";
    for (var a = [], b = this.a.Cb(), c = 0; c < b.length; c++) {
        var d = b[c],
            e = be(d);
        d = this.Wb(d);
        for (var f = 0; f < d.length; f++) {
            var g = e;
            "" !== d[f] && (g += "=" + be(d[f]));
            a.push(g)
        }
    }
    return this.c = a.join("&")
};
var Xm = function(a) {
        var b = new Zm;
        b.c = a.c;
        a.a && (b.a = new tj(a.a), b.b = a.b);
        return b
    },
    mn = function(a, b) {
        b = String(b);
        a.h && (b = b.toLowerCase());
        return b
    },
    en = function(a, b) {
        b && !a.h && (ln(a), a.c = null, a.a.forEach(function(c, d) {
            var e = d.toLowerCase();
            d != e && (nn(this, d), gn(this, e, c))
        }, a));
        a.h = b
    };
Zm.prototype.g = function(a) {
    for (var b = 0; b < arguments.length; b++) yj(arguments[b], function(c, d) {
        this.add(d, c)
    }, this)
};
var pn = {
        Xq: !0
    },
    qn = {
        Zq: !0
    },
    rn = {
        Yq: !0
    },
    sn = {
        Wq: !0
    },
    tn = {
        Vq: !0
    },
    un = function() {
        throw Error("Do not instantiate directly");
    };
un.prototype.rd = null;
un.prototype.Sa = function() {
    return this.content
};
un.prototype.toString = function() {
    return this.content
};
var vn = function(a) {
        if (a.qc !== pn) throw Error("Sanitized content was not of kind HTML.");
        return Od(dc("Soy SanitizedContent of kind HTML produces SafeHtml-contract-compliant value."), a.toString(), a.rd)
    },
    wn = function() {
        un.call(this)
    };
t(wn, un);
wn.prototype.qc = pn;
var xn = function() {
    un.call(this)
};
t(xn, un);
xn.prototype.qc = qn;
xn.prototype.rd = 1;
var yn = function() {
    un.call(this)
};
t(yn, un);
yn.prototype.qc = rn;
yn.prototype.rd = 1;
var zn = function() {
    un.call(this)
};
t(zn, un);
zn.prototype.qc = sn;
zn.prototype.rd = 1;
var An = function() {
    un.call(this)
};
t(An, un);
An.prototype.qc = tn;
An.prototype.rd = 1;
var Bn = function(a, b, c) {
    (b = null != a && a.qc === b) && v(a.constructor === c);
    return b
};
var Cn = function(a) {
        if (null != a) switch (a.rd) {
            case 1:
                return 1;
            case -1:
                return -1;
            case 0:
                return 0
        }
        return null
    },
    R = function(a) {
        return Bn(a, pn, wn) ? a : a instanceof zd ? Q(Ad(a).toString(), a.Vc()) : Q(de(String(String(a))), Cn(a))
    },
    Q = function(a) {
        function b(c) {
            this.content = c
        }
        b.prototype = a.prototype;
        return function(c, d) {
            c = new b(String(c));
            void 0 !== d && (c.rd = d);
            return c
        }
    }(wn),
    Dn = function(a, b) {
        return Ka(a) && Ka(b) ? a.qc !== b.qc ? !1 : a.toString() === b.toString() : a instanceof un && b instanceof un ? a.qc != b.qc ? !1 : a.toString() == b.toString() :
            a == b
    },
    En = function(a) {
        return a instanceof un ? !!a.Sa() : !!a
    },
    Fn = function(a) {
        return a.replace(/<\//g, "<\\/").replace(/\]\]>/g, "]]\\>")
    },
    S = function(a) {
        Bn(a, pn, wn) ? (a = a.Sa(), a = String(a).replace(Gn, "").replace(Hn, "&lt;"), a = String(a).replace(In, Jn)) : a = de(String(a));
        return a
    },
    Kn = /['()]/g,
    Ln = function(a) {
        return "%" + a.charCodeAt(0).toString(16)
    },
    Mn = function(a) {
        a = be(String(a));
        Kn.lastIndex = 0;
        return Kn.test(a) ? a.replace(Kn, Ln) : a
    },
    Qn = function(a) {
        Bn(a, qn, xn) || Bn(a, rn, yn) ? a = String(a).replace(Nn, On) : a instanceof Oc ?
            a = String(Pc(a)).replace(Nn, On) : a instanceof pc ? a = String(rc(a)).replace(Nn, On) : (a = String(a), Pn.test(a) ? a = a.replace(Nn, On) : (Ya("Bad value `%s` for |filterNormalizeUri", [a]), a = "about:invalid#zSoyz"));
        return a
    },
    Sn = function(a) {
        Bn(a, tn, An) ? a = Fn(a.Sa()) : null == a ? a = "" : a instanceof Wc ? a = Fn(Xc(a)) : a instanceof jd ? a = Fn(md(a)) : (a = String(a), Rn.test(a) || (Ya("Bad value `%s` for |filterCssValue", [a]), a = "zSoyz"));
        return a
    },
    Tn = function(a, b, c, d) {
        a || (a = c instanceof Function ? c.displayName || c.name || "unknown type name" :
            c instanceof Object ? c.constructor.displayName || c.constructor.name || Object.prototype.toString.call(c) : null === c ? "null" : typeof c, Ya("expected param " + b + " of type " + d + (", but got " + a) + "."));
        return c
    },
    Un = {
        "\x00": "&#0;",
        "\t": "&#9;",
        "\n": "&#10;",
        "\x0B": "&#11;",
        "\f": "&#12;",
        "\r": "&#13;",
        " ": "&#32;",
        '"': "&quot;",
        "&": "&amp;",
        "'": "&#39;",
        "-": "&#45;",
        "/": "&#47;",
        "<": "&lt;",
        "=": "&#61;",
        ">": "&gt;",
        "`": "&#96;",
        "\u0085": "&#133;",
        "\u00a0": "&#160;",
        "\u2028": "&#8232;",
        "\u2029": "&#8233;"
    },
    Jn = function(a) {
        return Un[a]
    },
    Vn = {
        "\x00": "\\x00",
        "\b": "\\x08",
        "\t": "\\t",
        "\n": "\\n",
        "\x0B": "\\x0b",
        "\f": "\\f",
        "\r": "\\r",
        '"': "\\x22",
        $: "\\x24",
        "&": "\\x26",
        "'": "\\x27",
        "(": "\\x28",
        ")": "\\x29",
        "*": "\\x2a",
        "+": "\\x2b",
        ",": "\\x2c",
        "-": "\\x2d",
        ".": "\\x2e",
        "/": "\\/",
        ":": "\\x3a",
        "<": "\\x3c",
        "=": "\\x3d",
        ">": "\\x3e",
        "?": "\\x3f",
        "[": "\\x5b",
        "\\": "\\\\",
        "]": "\\x5d",
        "^": "\\x5e",
        "{": "\\x7b",
        "|": "\\x7c",
        "}": "\\x7d",
        "\u0085": "\\x85",
        "\u2028": "\\u2028",
        "\u2029": "\\u2029"
    },
    Wn = function(a) {
        return Vn[a]
    },
    Xn = {
        "\x00": "%00",
        "\u0001": "%01",
        "\u0002": "%02",
        "\u0003": "%03",
        "\u0004": "%04",
        "\u0005": "%05",
        "\u0006": "%06",
        "\u0007": "%07",
        "\b": "%08",
        "\t": "%09",
        "\n": "%0A",
        "\x0B": "%0B",
        "\f": "%0C",
        "\r": "%0D",
        "\u000e": "%0E",
        "\u000f": "%0F",
        "\u0010": "%10",
        "\u0011": "%11",
        "\u0012": "%12",
        "\u0013": "%13",
        "\u0014": "%14",
        "\u0015": "%15",
        "\u0016": "%16",
        "\u0017": "%17",
        "\u0018": "%18",
        "\u0019": "%19",
        "\u001a": "%1A",
        "\u001b": "%1B",
        "\u001c": "%1C",
        "\u001d": "%1D",
        "\u001e": "%1E",
        "\u001f": "%1F",
        " ": "%20",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "<": "%3C",
        ">": "%3E",
        "\\": "%5C",
        "{": "%7B",
        "}": "%7D",
        "\u007f": "%7F",
        "\u0085": "%C2%85",
        "\u00a0": "%C2%A0",
        "\u2028": "%E2%80%A8",
        "\u2029": "%E2%80%A9",
        "\uff01": "%EF%BC%81",
        "\uff03": "%EF%BC%83",
        "\uff04": "%EF%BC%84",
        "\uff06": "%EF%BC%86",
        "\uff07": "%EF%BC%87",
        "\uff08": "%EF%BC%88",
        "\uff09": "%EF%BC%89",
        "\uff0a": "%EF%BC%8A",
        "\uff0b": "%EF%BC%8B",
        "\uff0c": "%EF%BC%8C",
        "\uff0f": "%EF%BC%8F",
        "\uff1a": "%EF%BC%9A",
        "\uff1b": "%EF%BC%9B",
        "\uff1d": "%EF%BC%9D",
        "\uff1f": "%EF%BC%9F",
        "\uff20": "%EF%BC%A0",
        "\uff3b": "%EF%BC%BB",
        "\uff3d": "%EF%BC%BD"
    },
    On = function(a) {
        return Xn[a]
    },
    In = /[\x00\x22\x27\x3c\x3e]/g,
    Yn = /[\x00\x08-\x0d\x22\x26\x27\/\x3c-\x3e\x5b-\x5d\x7b\x7d\x85\u2028\u2029]/g,
    Nn = /[\x00- \x22\x27-\x29\x3c\x3e\\\x7b\x7d\x7f\x85\xa0\u2028\u2029\uff01\uff03\uff04\uff06-\uff0c\uff0f\uff1a\uff1b\uff1d\uff1f\uff20\uff3b\uff3d]/g,
    Rn = /^(?!-*(?:expression|(?:moz-)?binding))(?:(?:[.#]?-?(?:[_a-z0-9-]+)(?:-[_a-z0-9-]+)*-?|(?:rgb|hsl)a?\([0-9.%,\u0020]+\)|-?(?:[0-9]+(?:\.[0-9]*)?|\.[0-9]+)(?:[a-z]{1,4}|%)?|!important)(?:\s+|$))*$/i,
    Pn = /^(?![^#?]*\/(?:\.|%2E){2}(?:[\/?#]|$))(?:(?:https?|mailto):|[^&:\/?#]*(?:[\/?#]|$))/i,
    Zn = /^(?!on|src|(?:action|archive|background|cite|classid|codebase|content|data|dsync|href|http-equiv|longdesc|style|usemap)\s*$)(?:[a-z0-9_$:-]*)$/i,
    $n = function(a) {
        return String(a).replace(Yn, Wn)
    },
    Gn = /<(?:!|\/?([a-zA-Z][a-zA-Z0-9:\-]*))(?:[^>'"]|"[^"]*"|'[^']*')*>/g,
    Hn = /</g;
var ao = function(a) {
    var b = a.vm,
        c = a.um,
        d = a.Yn,
        e = a.Pn,
        f = a.url;
    return Q('<div id="' + S(a.id) + '" class="cp-promo" style="display:none"><div class="cp-promo-c"><div class="cp-dismiss"></div><a href="' + S(Qn(f)) + '" target="_blank" class="cp-promo-href"><div class="cp-promo-graphic"></div><div class="cp-promo-text-c"><div class="cp-promo-text"><div class="cp-promo-title">' + R(d) + '</div><div class="cp-promo-subtext">' + R(e) + '</div></div></div><div class="cp-promo-bottom"><div class="cp-promo-link"><div class="cp-promo-link-badge"></div><div class="cp-promo-link-arrow"></div><div class="cp-promo-link-text">' +
        R(b) + '</div><div class="cp-promo-link-subtext">' + R(c) + "</div></div></div></a></div></div>")
};
ao.a = "trans.common.templates.communityPromotion";
var bo = function(a) {
    return Q('<div><div class="speech-mic"><div class="gt-speech-l1"></div><div class="gt-speech-l2"></div><div class="gt-speech-l3"></div><div class="gt-speech-l4"></div></div><div class="speech-mic-label">' + R(a.label) + "</div></div>")
};
bo.a = "trans.common.templates.speechInput";
var co = function(a) {
    var b = a.Zf,
        c = a.rm,
        d = a.tm,
        e = a.Ch,
        f = a.Ao;
    return Q('<div class="gt-ex-info">' + (a.Jn ? '<span class="gt-ex-quote">\x3c!--This SVG renders a quotation mark.--\x3e<svg viewBox="0 0 24 24"><path d="M6 17h3l2-4V7H5v6h3zm8 0h3l2-4V7h-6v6h3z"></path><path d="M0 0h24v24H0z" fill="none"></path></svg></span>' : "") + '<div class="gt-ex-top"><div class="gt-ex-text" dir="' + S(a.Mn) + '">' + R(b) + '</div></div><div class="gt-ex-mt" style="display:none"><span class="gt-cd-mt" dir="' + S(e) + '"></span><br><span class="gt-cd-mt-label">' +
        R(f) + '</span><span class="gt-ex-credit"><a class="gt-ex-link" target="_blank" href="' + S(Qn(c)) + '">' + R(d) + "</a></span></div></div>")
};
co.a = "trans.common.templates.exampleSentence";
var eo = function(a) {
    var b = a.Pm;
    a = a.Qm;
    return Q('<div class="st-stp1">' + (b ? "" : '<div class="st-stp1-text"><div>' + R(a) + "</div></div>") + '<div id="st-buttons"></div>' + (b ? '<div class="st-stp1-epu-text">' + R(a) + "</div>" : "") + "</div>")
};
eo.a = "trans.common.templates.submitTranslation";
var fo = function() {
    return Q('<div class="gt-cc-t"><span class="gt-cc-tc"></span><span class="gt-cc-bc"></span></div><div class="gt-cc"><div class="gt-cc-l"><div class="gt-cc-l-i"></div><div class="gt-cc-exp" style="display:none"><div class="cd-exp-ar"></div></div></div><div class="gt-cc-r"><div class="gt-cc-r-i"></div></div></div>')
};
fo.a = "trans.common.templates.cardContainer";
var go = function() {
    return Q('<div class="gt-cd-t"><div class="gt-cd-tl"></div><div class="gt-cd-tr"></div></div><div class="gt-cd-c"></div><div class="cd-expand-button" role="button" tabindex="0"><span class="jfk-button-img"></span><span class="cd-expand-label"></span></div>')
};
go.a = "trans.common.templates.card";
var ho = function() {
    return Q('<span class="gt-ct-text"></span><span class="gt-ct-translit" style="display:none"></span><div class="gt-ct-tts goog-inline-block"></div>')
};
ho.a = "trans.common.templates.lexiconTitle";
var io = function(a) {
    var b = a.yk,
        c = a.Mj,
        d = a.zk,
        e = a.Pk,
        f = a.Sn,
        g = a.Rn,
        k = a.Ch,
        l = a.lk;
    a = '<div class="gt-def-info" lang="' + S(a.Ba) + '">' + (c ? '<span class="gt-def-num">' + R(b) + "</span>" : "") + '<div class="gt-def-row">' + R(d) + '<div class="gt-mt-md" style="display:none"><span class="gt-cd-mt"></span></div></div>' + (e ? '<div class="gt-def-example"><q>' + R(e) + '</q><div class="gt-mt-ex" style="display:none"><q class="gt-cd-mt" dir="' + S(k) + '"></q></div></div>' : "");
    if (0 < g.length) {
        a += '<div class="gt-def-synonym"><span class="gt-def-synonym-title">' +
            R(f) + ': </span><span class="gt-def-synonyms-group"></span><span class="gt-def-synonyms-group"></span>';
        f = g.length;
        for (b = 0; b < f; b++)
            for (d = g[b], e = d.length, k = 0; k < e; k++) {
                var m = d[k];
                var q = c ? "" : k != e - 1 ? ", " : b != f - 1 ? "; " : "";
                a += (l ? c ? '<span class="gt-cd-cl"> ' + R(m) + " </span>" : '<span class="gt-cd-cl">' + R(m) + "</span>" : '<span class="gt-cd-ncl">' + R(m) + "</span>") + q
            }
        a += "</div>"
    }
    return Q(a + "</div>")
};
io.a = "trans.common.templates.definitionRow";
var jo = function(a) {
    var b = a.Dk,
        c = a.Vk,
        d = a.Wk,
        e = a.fn;
    a = a.Hd;
    return Q((a ? "" : '<div class="gt-card-expand-wrapper gt-card-collapsed">') + '<div class="gt-baf-cell gt-baf-pos-head">' + (e ? '<span class="gt-cd-pos">' + R(e) + "</span>" : "") + (b ? '<div class="gt-cd-pos-pop">' + R(c) + '<div class="help-icon-container tlid-frequency-help-icon-container"><div class="help-icon tlid-frequency-help-icon"></div><div class="help-tooltip tlid-frequency-help-tooltip"><p>' + R(d) + "</p></div></div></div>" : "") + "</div>" + (a ? "" : "</div>"))
};
jo.a = "trans.common.templates.partOfSpeechEntryHeading";
var ko = function(a) {
    var b = a.ah,
        c = a.Qe,
        d = a.Un,
        e = a.Hd,
        f = a.Ho;
    a = a.Io;
    return Q((e ? "" : '<div class="gt-card-expand-wrapper gt-card-collapsed">') + '<div class="gt-baf-cell gt-baf-term-text-parent"' + (d ? ' style="direction: ' + S(Sn(d)) + ';"' : "") + '><span class="gt-baf-term-text' + (b ? " gt-baf-word-selected" : "") + '">' + (c ? '<span class="gt-baf-cell gt-baf-previous-word gt-baf-previous-word-mobile">' + R(c) + "</span>" : "") + '<span class="' + S(a) + '">' + R(f) + "</span></span></div>" + (e ? "" : "</div>"))
};
ko.a = "trans.common.templates.termText";
var lo = function(a) {
    var b = a.ef,
        c = a.Ak,
        d = a.cg;
    a = a.Hd;
    c = (a ? "" : '<div class="gt-card-expand-wrapper gt-card-collapsed">') + '<div class="gt-baf-cell gt-baf-translations gt-baf-translations-mobile"' + (c ? ' style="direction: ' + S(Sn(c)) + ';"' : "") + ">";
    for (var e = d.length, f = 0; f < e; f++) {
        var g = d[f];
        c += "<span" + (b ? ' class="' + S(b) + '"' : "") + ">" + R(g) + "</span>" + (f != e - 1 ? ", " : "")
    }
    return Q(c + ("</div>" + (a ? "" : "</div>")))
};
lo.a = "trans.common.templates.translationsCell";
var no = function(a) {
    var b = a.Pb,
        c = a.Hd;
    a = (c ? "" : '<div class="gt-card-expand-wrapper gt-card-collapsed">') + '<div class="gt-baf-cell gt-baf-entry-score" title="' + S(a.zc) + '">';
    for (var d = Math.max(0, Math.ceil(b + 1 - 1)), e = 0; e < d; e++) {
        var f = Q(mo({
            className: "filled"
        }));
        a += f
    }
    if (3 > b)
        for (b = Math.max(0, Math.ceil(4 - (b + 1))), d = 0; d < b; d++) e = Q(mo({
            className: "empty"
        })), a += e;
    return Q(a + ("</div>" + (c ? "" : "</div>")))
};
no.a = "trans.common.templates.backAndForthViewEntryScore";
var mo = function(a) {
    return Q('<div class="' + S(a.className) + ' gt-score-dot"></div>')
};
var oo = null != window.KNOWLEDGE_PANEL,
    po = null != window.MSG_SPEECH_INPUT_TURN_ON,
    qo = null != window.ADD_INFLECTION;
var ro;

function so() {
    var a = DATA.SentenceGenderLanguagePairs,
        b = DATA.SingleWordGenderLanguagePairs;
    ro = {};
    if (a)
        for (var c = 0; c < a.length; c++) {
            var d = a[c];
            ro[d.Target] = {};
            ro[d.Target][d.Source] = !0
        }
    if (b)
        for (c = 0; c < b.length; c++) a = b[c], ro[a.Target] = {}, ro[a.Target][a.Source] = !0
}

function to(a, b) {
    if ("auto" === a) throw Error('detectedSourceLanguage should not be "auto". Did you mean shouldRequestGenderedTranslations()?');
    return !!ro[b] && !!ro[b][a]
};
var uo = function(a, b) {
    try {
        return JSON.parse(a)
    } catch (d) {
        var c = Gm.M();
        b.js = a;
        b.error = d.message;
        c.log("jsonParseErr", b);
        throw d;
    }
};
var vo = function(a) {
        return function() {
            return a
        }
    },
    wo = function(a, b) {
        for (var c = 0; c < b.length - 2; c += 3) {
            var d = b.charAt(c + 2);
            d = "a" <= d ? d.charCodeAt(0) - 87 : Number(d);
            d = "+" == b.charAt(c + 1) ? a >>> d : a << d;
            a = "+" == b.charAt(c) ? a + d & 4294967295 : a ^ d
        }
        return a
    },
    xo = null,
    yo = function(a) {
        if (null !== xo) var b = xo;
        else {
            b = vo(String.fromCharCode(84));
            var c = vo(String.fromCharCode(75));
            b = [b(), b()];
            b[1] = c();
            b = (xo = window[b.join(c())] || "") || ""
        }
        var d = vo(String.fromCharCode(116));
        c = vo(String.fromCharCode(107));
        d = [d(), d()];
        d[1] = c();
        c = "&" + d.join("") +
            "=";
        d = b.split(".");
        b = Number(d[0]) || 0;
        for (var e = [], f = 0, g = 0; g < a.length; g++) {
            var k = a.charCodeAt(g);
            128 > k ? e[f++] = k : (2048 > k ? e[f++] = k >> 6 | 192 : (55296 == (k & 64512) && g + 1 < a.length && 56320 == (a.charCodeAt(g + 1) & 64512) ? (k = 65536 + ((k & 1023) << 10) + (a.charCodeAt(++g) & 1023), e[f++] = k >> 18 | 240, e[f++] = k >> 12 & 63 | 128) : e[f++] = k >> 12 | 224, e[f++] = k >> 6 & 63 | 128), e[f++] = k & 63 | 128)
        }
        a = b;
        for (f = 0; f < e.length; f++) a += e[f], a = wo(a, "+-a^+6");
        a = wo(a, "+-3^+b+-f");
        a ^= Number(d[1]) || 0;
        0 > a && (a = (a & 2147483647) + 2147483648);
        a %= 1E6;
        return c + (a.toString() + "." +
            (a ^ b))
    };
var zo = function(a) {
    Dl(this, a, 4)
};
t(zo, Cl);
var Ao = {
    word_postproc: {
        H: 0,
        J: !1
    },
    score: {
        H: 1,
        J: !1
    },
    has_preceding_space: {
        H: 2,
        J: !1
    },
    attach_to_next_token: {
        H: 3,
        J: !1
    }
};
zo.prototype.za = function() {
    return Ao
};
var Bo = function(a) {
    Dl(this, a, 2)
};
t(Bo, Cl);
var Co = {
    begin: {
        H: 0,
        J: !1
    },
    end: {
        H: 1,
        J: !1
    }
};
Bo.prototype.za = function() {
    return Co
};
var Do = function(a) {
    Dl(this, a, 7)
};
t(Do, Cl);
var Eo = {
    src_phrase: {
        H: 0,
        J: !1
    },
    alternative: {
        H: 2,
        va: function(a) {
            return Kl(zo, a)
        },
        sa: function(a) {
            return Jl(new zo(a))
        },
        J: !0
    },
    srcunicodeoffsets: {
        H: 3,
        va: function(a) {
            return Kl(Bo, a)
        },
        sa: function(a) {
            return Jl(new Bo(a))
        },
        J: !0
    },
    raw_src_segment: {
        H: 4,
        J: !1
    },
    start_pos: {
        H: 5,
        J: !1
    },
    end_pos: {
        H: 6,
        J: !1
    }
};
Do.prototype.za = function() {
    return Eo
};
var Fo = function(a, b) {
        return new zo(Hl(a, 2, b))
    },
    Go = function(a, b) {
        return new Bo(Hl(a, 3, b))
    };
var Ho = function(a) {
    Dl(this, a, 8)
};
t(Ho, Cl);
var Io = {
    word: {
        H: 0,
        J: !1
    },
    styles: {
        H: 1,
        J: !0
    },
    has_preceding_space: {
        H: 2,
        J: !1
    },
    attach_to_next_token: {
        H: 3,
        J: !1
    },
    confidence: {
        H: 4,
        J: !1
    },
    start_pos: {
        H: 5,
        J: !1
    },
    end_pos: {
        H: 6,
        J: !1
    },
    not_from_first_segment: {
        H: 7,
        J: !1
    }
};
Ho.prototype.za = function() {
    return Io
};
var Jo = function(a) {
    Dl(this, a, 3)
};
t(Jo, Cl);
var Ko = {
    gloss: {
        H: 0,
        J: !1
    },
    definition_id: {
        H: 1,
        J: !1
    },
    example: {
        H: 2,
        J: !1
    }
};
Jo.prototype.za = function() {
    return Ko
};
var Lo = function(a) {
    Dl(this, a, 3)
};
t(Lo, Cl);
var Mo = {
    pos: {
        H: 0,
        J: !1
    },
    entry: {
        H: 1,
        va: function(a) {
            return Kl(Jo, a)
        },
        sa: function(a) {
            return Jl(new Jo(a))
        },
        J: !0
    },
    base_form: {
        H: 2,
        J: !1
    }
};
Lo.prototype.za = function() {
    return Mo
};
Lo.prototype.a = function() {
    return H(this, 1)
};
Lo.prototype.b = function(a) {
    return new Jo(Hl(this, 1, a))
};
var No = function(a) {
    Dl(this, a, 6)
};
t(No, Cl);
var Oo = {
    word: {
        H: 0,
        J: !1
    },
    reverse_translation: {
        H: 1,
        J: !0
    },
    synset_id: {
        H: 2,
        J: !0
    },
    score: {
        H: 3,
        J: !1
    },
    previous_word: {
        H: 4,
        J: !1
    },
    gender: {
        H: 5,
        J: !1
    }
};
No.prototype.za = function() {
    return Oo
};
No.prototype.Rc = function() {
    return El(this, 5, 0)
};
var Po = function(a) {
    Dl(this, a, 5)
};
t(Po, Cl);
var Qo = {
    pos: {
        H: 0,
        J: !1
    },
    terms: {
        H: 1,
        J: !0
    },
    entry: {
        H: 2,
        va: function(a) {
            return Kl(No, a)
        },
        sa: function(a) {
            return Jl(new No(a))
        },
        J: !0
    },
    base_form: {
        H: 3,
        J: !1
    },
    pos_enum: {
        H: 4,
        J: !1
    }
};
Po.prototype.za = function() {
    return Qo
};
var Ro = function(a, b) {
    return Gh(a, 1, b)
};
Po.prototype.a = function() {
    return H(this, 2)
};
Po.prototype.b = function(a) {
    return new No(Hl(this, 2, a))
};
var So = function(a) {
    Dl(this, a, 17)
};
t(So, Cl);
var To = {
    animacy: {
        H: 0,
        J: !1
    },
    inflection_aspect: {
        H: 1,
        J: !1
    },
    grammatical_case: {
        H: 2,
        J: !1
    },
    degree: {
        H: 3,
        J: !1
    },
    gender: {
        H: 4,
        J: !1
    },
    mood: {
        H: 5,
        J: !1
    },
    nonfinite_form: {
        H: 6,
        J: !1
    },
    number: {
        H: 7,
        J: !1
    },
    person: {
        H: 8,
        J: !1
    },
    polarity: {
        H: 9,
        J: !1
    },
    referent: {
        H: 10,
        J: !1
    },
    strength: {
        H: 11,
        J: !1
    },
    tense: {
        H: 12,
        J: !1
    },
    imperfect_suffix: {
        H: 13,
        J: !1
    },
    voice: {
        H: 14,
        J: !1
    },
    infinitive_number: {
        H: 15,
        J: !1
    },
    precedes: {
        H: 16,
        J: !1
    }
};
So.prototype.za = function() {
    return To
};
So.prototype.Rc = function() {
    return El(this, 4, 0)
};
var Uo = function(a) {
    Dl(this, a, 2)
};
t(Uo, Cl);
var Vo = {
    written_form: {
        H: 0,
        J: !1
    },
    features: {
        H: 1,
        va: function(a) {
            return Kl(So, a)
        },
        sa: function(a) {
            return Jl(new So(a))
        },
        J: !1
    }
};
Uo.prototype.za = function() {
    return Vo
};
var Wo = function(a) {
    Dl(this, a, 4)
};
t(Wo, Cl);
var Xo = {
    title: {
        H: 0,
        J: !1
    },
    description: {
        H: 1,
        J: !1
    },
    image_url: {
        H: 2,
        J: !1
    },
    image_ref_url: {
        H: 3,
        J: !1
    }
};
Wo.prototype.za = function() {
    return Xo
};
var Yo = function(a) {
    Dl(this, a, 4)
};
t(Yo, Cl);
var Zo = {
    srclangs: {
        H: 0,
        J: !0
    },
    extended_srclangs: {
        H: 3,
        J: !0
    },
    detected_target: {
        H: 1,
        J: !1
    },
    srclangs_confidences: {
        H: 2,
        J: !0
    }
};
Yo.prototype.za = function() {
    return Zo
};
var $o = function(a) {
    Dl(this, a, 1)
};
t($o, Cl);
var ap = {
    word: {
        H: 0,
        J: !0
    }
};
$o.prototype.za = function() {
    return ap
};
var bp = function(a) {
    Dl(this, a, 6)
};
t(bp, Cl);
var cp = {
    spell_html_res: {
        H: 0,
        J: !1
    },
    spell_res: {
        H: 1,
        J: !1
    },
    correction_type: {
        H: 2,
        J: !0
    },
    correction_translation: {
        H: 3,
        J: !1
    },
    related: {
        H: 4,
        J: !1
    },
    confident: {
        H: 5,
        J: !1
    }
};
bp.prototype.za = function() {
    return cp
};
var dp = function(a) {
    Dl(this, a, 2)
};
t(dp, Cl);
var ep = {
    synonym: {
        H: 0,
        J: !0
    },
    definition_id: {
        H: 1,
        J: !1
    }
};
dp.prototype.za = function() {
    return ep
};
var fp = function(a) {
    Dl(this, a, 3)
};
t(fp, Cl);
var gp = {
    pos: {
        H: 0,
        J: !1
    },
    entry: {
        H: 1,
        va: function(a) {
            return Kl(dp, a)
        },
        sa: function(a) {
            return Jl(new dp(a))
        },
        J: !0
    },
    base_form: {
        H: 2,
        J: !1
    }
};
fp.prototype.za = function() {
    return gp
};
fp.prototype.a = function() {
    return H(this, 1)
};
fp.prototype.b = function(a) {
    return new dp(Hl(this, 1, a))
};
var hp = function(a) {
    Dl(this, a, 6)
};
t(hp, Cl);
var ip = {
    text: {
        H: 0,
        J: !1
    },
    source: {
        H: 1,
        J: !1
    },
    link: {
        H: 2,
        J: !1
    },
    translation: {
        H: 3,
        J: !1
    },
    source_type: {
        H: 4,
        J: !1
    },
    definition_id: {
        H: 5,
        J: !1
    }
};
hp.prototype.za = function() {
    return ip
};
hp.prototype.Be = function() {
    return I(this, 1)
};
hp.prototype.tb = function() {
    return I(this, 3)
};
var jp = function(a) {
    Dl(this, a, 1)
};
t(jp, Cl);
var kp = {
    example: {
        H: 0,
        va: function(a) {
            return Kl(hp, a)
        },
        sa: function(a) {
            return Jl(new hp(a))
        },
        J: !0
    }
};
jp.prototype.za = function() {
    return kp
};
var lp = function(a) {
    Dl(this, a, 19)
};
t(lp, Cl);
var mp = {
    sentences: {
        H: 0,
        va: function(a) {
            return Kl(Zl, a)
        },
        sa: function(a) {
            return Jl(new Zl(a))
        },
        J: !0
    },
    dict: {
        H: 1,
        va: function(a) {
            return Kl(Po, a)
        },
        sa: function(a) {
            return Jl(new Po(a))
        },
        J: !0
    },
    src: {
        H: 2,
        J: !1
    },
    err: {
        H: 3,
        J: !1
    },
    styled_words: {
        H: 4,
        va: function(a) {
            return Kl(Ho, a)
        },
        sa: function(a) {
            return Jl(new Ho(a))
        },
        J: !0
    },
    alternative_translations: {
        H: 5,
        va: function(a) {
            return Kl(Do, a)
        },
        sa: function(a) {
            return Jl(new Do(a))
        },
        J: !0
    },
    confidence: {
        H: 6,
        J: !1
    },
    spell: {
        H: 7,
        va: function(a) {
            return Kl(bp, a)
        },
        sa: function(a) {
            return Jl(new bp(a))
        },
        J: !1
    },
    autocorrection: {
        H: 10,
        J: !1
    },
    ld_result: {
        H: 8,
        va: function(a) {
            return Kl(Yo, a)
        },
        sa: function(a) {
            return Jl(new Yo(a))
        },
        J: !1
    },
    server_time: {
        H: 9,
        J: !1
    },
    synsets: {
        H: 11,
        va: function(a) {
            return Kl(fp, a)
        },
        sa: function(a) {
            return Jl(new fp(a))
        },
        J: !0
    },
    definitions: {
        H: 12,
        va: function(a) {
            return Kl(Lo, a)
        },
        sa: function(a) {
            return Jl(new Lo(a))
        },
        J: !0
    },
    examples: {
        H: 13,
        va: function(a) {
            return Kl(jp, a)
        },
        sa: function(a) {
            return Jl(new jp(a))
        },
        J: !1
    },
    related_words: {
        H: 14,
        va: function(a) {
            return Kl($o, a)
        },
        sa: function(a) {
            return Jl(new $o(a))
        },
        J: !1
    },
    knowledge_results: {
        H: 15,
        va: function(a) {
            return Kl(Wo, a)
        },
        sa: function(a) {
            return Jl(new Wo(a))
        },
        J: !0
    },
    query_inflections: {
        H: 16,
        va: function(a) {
            return Kl(Uo, a)
        },
        sa: function(a) {
            return Jl(new Uo(a))
        },
        J: !0
    },
    target_inflections: {
        H: 17,
        va: function(a) {
            return Kl(Uo, a)
        },
        sa: function(a) {
            return Jl(new Uo(a))
        },
        J: !0
    },
    gendered_translation_result: {
        H: 18,
        va: function(a) {
            return Kl(cm, a)
        },
        sa: function(a) {
            return Jl(new cm(a))
        },
        J: !1
    }
};
lp.prototype.za = function() {
    return mp
};
var np = function(a) {
        return new bp(a.Wa[7])
    },
    op = function(a) {
        return new $o(a.Wa[14])
    };
lp.prototype.jc = function() {
    return H(this, 0)
};
lp.prototype.cb = function(a) {
    return new Zl(Hl(this, 0, a))
};
var Dh = function(a, b) {
        return new Po(Hl(a, 1, b))
    },
    pp = function(a, b) {
        return new Do(Hl(a, 5, b))
    };
var qp = function(a, b) {
        this.b = a;
        this.a = "";
        b && (this.a = b);
        this.c = 0;
        this.F = K.M()
    },
    rp = function(a) {
        a = a.Wb("q").join("");
        return yo(a)
    },
    sp = function(a, b, c, d, e, f) {
        c = c.toString();
        c += rp(d);
        d = d.toString();
        var g = "POST";
        b += "?" + c;
        2E3 > b.length + d.length && (g = "GET", b += "&" + d, d = "");
        ++a.c;
        return Qj(b, function(k) {
            --a.c;
            e(k)
        }, g, d, void 0, f)
    },
    tp = function(a, b, c, d, e, f, g, k, l) {
        var m = a.a + "/translate_a/t",
            q = new Zm,
            r = new Zm;
        q.set("client", a.b);
        q.set("sl", b);
        q.set("tl", c);
        q.set("hl", d);
        q.set("v", "1.0");
        null != g && q.set("source", g);
        k &&
            q.g(k);
        (b = !Ia(e) || Ia(e) && 1 == e.length) ? r.set("q", e): gn(r, "q", e);
        e = p(a.h, a, b, f);
        return sp(a, m, q, r, e, l)
    },
    up = function(a, b, c, d) {
        var e = new Zm,
            f = new Zm;
        e.set("client", a.b);
        e.set("sl", c);
        c = a.a + "/translate_a/single";
        e.set("dt", "rm");
        f.set("q", b);
        sp(a, c, e, f, p(a.o, a, d), void 0)
    },
    vp = function(a, b, c, d, e, f, g, k, l, m, q) {
        var r = a.a + "/translate_a/single",
            u = new Zm,
            z = new Zm;
        u.set("client", a.b);
        u.set("sl", b);
        u.set("tl", c);
        u.set("hl", d);
        gn(u, "dt", f);
        null != k && (u.set("ie", k), u.set("oe", k));
        m && u.set("dj", "1");
        l && u.g(l);
        z.set("q",
            e);
        sp(a, r, u, z, p(a.g, a, g, q), void 0)
    },
    wp = function(a, b, c, d, e, f, g, k, l, m) {
        var q = "at bd ex ld md qc rw rm ss t".split(" ");
        g && (q = "at bd ex ld md qca rw rm ss t".split(" "));
        oo && q.push("kr");
        qo && ro[c] && (ro[c][b] || "auto" === b) && q.push("gt");
        vp(a, b, c, d, e, q, f, k, l, void 0, m)
    };
qp.prototype.o = function(a, b) {
    b = b.target;
    xp(b) && (b = yp(b, "handleTransliterationResult_"), b = new lp(b), 0 < b.jc() && a(I(b.cb(0), 3)))
};
qp.prototype.g = function(a, b, c) {
    c = c.target;
    xp(c) ? (b = yp(c, "handleSingleResult_"), Ia(b) && (b = new lp(b)), a(b)) : (zp(this, c), b && b(c.Sc()))
};
qp.prototype.h = function(a, b, c) {
    c = c.target;
    if (ak(c)) {
        c = yp(c, "handleTextResult_");
        var d = [];
        if (a) d.push(Ia(c) ? c[0] : c);
        else if (Ia(c))
            for (a = 0; a < c.length; ++a) d.push(Ia(c[a]) ? c[a][0] : c[a]);
        b(d)
    } else zp(this, c), b(null, c.Bd)
};
var yp = function(a, b) {
        return uo(bk(a), {
            "class": "trans.common.TranslationAPI",
            func: b,
            url: String(a.Yd)
        })
    },
    xp = function(a) {
        return ak(a) && ("[" == bk(a)[0] || "{" == bk(a)[0])
    },
    Ap = {},
    Bp = (Ap[1] = 15, Ap[2] = 16, Ap[3] = 17, Ap[4] = 18, Ap[5] = 19, Ap[6] = 20, Ap[7] = 21, Ap[8] = 22, Ap[9] = 23, Ap),
    zp = function(a, b) {
        var c = b.Bd;
        mm(a.F, 156, c in Bp ? Bp[c] : 0);
        a = Gm.M();
        c = String(b.Yd);
        b = bk(b);
        a.log("invalidResponse", {
            q: c.substring(0, 500),
            ql: c.length,
            r: b.substring(0, 500),
            rl: b.length
        })
    };
qp.prototype.m = function() {
    return this.c
};
var Cp, Dp = {
    Mo: "activedescendant",
    Ro: "atomic",
    So: "autocomplete",
    Uo: "busy",
    Xo: "checked",
    Yo: "colindex",
    cp: "controls",
    fp: "describedby",
    ip: "disabled",
    kp: "dropeffect",
    lp: "expanded",
    mp: "flowto",
    pp: "grabbed",
    tp: "haspopup",
    vp: "hidden",
    xp: "invalid",
    yp: "label",
    zp: "labelledby",
    Ap: "level",
    Fp: "live",
    Vp: "multiline",
    Wp: "multiselectable",
    $p: "orientation",
    aq: "owns",
    bq: "posinset",
    eq: "pressed",
    iq: "readonly",
    kq: "relevant",
    lq: "required",
    pq: "rowindex",
    tq: "selected",
    vq: "setsize",
    SORT: "sort",
    Kq: "valuemax",
    Lq: "valuemin",
    Mq: "valuenow",
    Nq: "valuetext"
};
var Ep = {
    No: "alert",
    Oo: "alertdialog",
    Po: "application",
    Qo: "article",
    To: "banner",
    Vo: "button",
    Wo: "checkbox",
    Zo: "columnheader",
    $o: "combobox",
    ap: "complementary",
    bp: "contentinfo",
    ep: "definition",
    gp: "dialog",
    hp: "directory",
    jp: "document",
    np: "form",
    qp: "grid",
    rp: "gridcell",
    sp: "group",
    up: "heading",
    wp: "img",
    Bp: "link",
    Cp: "list",
    Dp: "listbox",
    Ep: "listitem",
    Gp: "log",
    Hp: "main",
    Ip: "marquee",
    Jp: "math",
    Kp: "menu",
    Lp: "menubar",
    Mp: "menuitem",
    Np: "menuitemcheckbox",
    Op: "menuitemradio",
    Xp: "navigation",
    Yp: "note",
    Zp: "option",
    cq: "presentation",
    fq: "progressbar",
    gq: "radio",
    hq: "radiogroup",
    jq: "region",
    mq: "row",
    nq: "rowgroup",
    oq: "rowheader",
    qq: "scrollbar",
    rq: "search",
    uq: "separator",
    wq: "slider",
    xq: "spinbutton",
    yq: "status",
    zq: "tab",
    Aq: "tablist",
    Bq: "tabpanel",
    Cq: "textbox",
    Dq: "textinfo",
    Eq: "timer",
    Fq: "toolbar",
    Gq: "tooltip",
    Hq: "tree",
    Iq: "treegrid",
    Jq: "treeitem"
};
Yb("A AREA BUTTON HEAD INPUT LINK MENU META OPTGROUP OPTION PROGRESS STYLE SELECT SOURCE TEXTAREA TITLE TRACK".split(" "));
var Fp = "combobox grid group listbox menu menubar radiogroup row rowgroup tablist textbox toolbar tree treegrid".split(" "),
    Gp = function(a, b) {
        b ? (v(Qb(Ep, b), "No such ARIA role " + b), a.setAttribute("role", b)) : a.removeAttribute("role")
    },
    Ip = function(a, b, c) {
        Ia(c) && (c = c.join(" "));
        var d = Hp(b);
        "" === c || void 0 == c ? (Cp || (Cp = {
            atomic: !1,
            autocomplete: "none",
            dropeffect: "none",
            haspopup: !1,
            live: "off",
            multiline: !1,
            multiselectable: !1,
            orientation: "vertical",
            readonly: !1,
            relevant: "additions text",
            required: !1,
            sort: "none",
            busy: !1,
            disabled: !1,
            hidden: !1,
            invalid: "false"
        }), c = Cp, b in c ? a.setAttribute(d, c[b]) : a.removeAttribute(d)) : a.setAttribute(d, c)
    },
    Jp = function(a, b) {
        a = a.getAttribute(Hp(b));
        return null == a || void 0 == a ? "" : String(a)
    },
    Kp = function(a) {
        var b = Jp(a, "activedescendant");
        return If(a).getElementById(b)
    },
    Lp = function(a, b) {
        var c = "";
        b && (c = b.id, v(c, "The active element should have an id."));
        Ip(a, "activedescendant", c)
    },
    Mp = function(a, b) {
        Ip(a, "label", b)
    },
    Hp = function(a) {
        v(a, "ARIA attribute cannot be empty.");
        v(Qb(Dp, a), "No such ARIA attribute " +
            a);
        return "aria-" + a
    };
var Np = function(a) {
        return "string" == typeof a.className ? a.className : a.getAttribute && a.getAttribute("class") || ""
    },
    Op = function(a) {
        return a.classList ? a.classList : Np(a).match(/\S+/g) || []
    },
    Pp = function(a, b) {
        "string" == typeof a.className ? a.className = b : a.setAttribute && a.setAttribute("class", b)
    },
    Qp = function(a, b) {
        return a.classList ? a.classList.contains(b) : rb(Op(a), b)
    },
    T = function(a, b) {
        if (a.classList) a.classList.add(b);
        else if (!Qp(a, b)) {
            var c = Np(a);
            Pp(a, c + (0 < c.length ? " " + b : b))
        }
    },
    Rp = function(a, b) {
        if (a.classList) w(b,
            function(e) {
                T(a, e)
            });
        else {
            var c = {};
            w(Op(a), function(e) {
                c[e] = !0
            });
            w(b, function(e) {
                c[e] = !0
            });
            b = "";
            for (var d in c) b += 0 < b.length ? " " + d : d;
            Pp(a, b)
        }
    },
    U = function(a, b) {
        a.classList ? a.classList.remove(b) : Qp(a, b) && Pp(a, jb(Op(a), function(c) {
            return c != b
        }).join(" "))
    },
    Sp = function(a, b) {
        a.classList ? w(b, function(c) {
            U(a, c)
        }) : Pp(a, jb(Op(a), function(c) {
            return !rb(b, c)
        }).join(" "))
    },
    V = function(a, b, c) {
        c ? T(a, b) : U(a, b)
    };
var Wp = function(a, b) {
        v(a, "Soy template may not be null.");
        var c = Jf();
        a = a(b || Tp, void 0, void 0);
        a = Up(a);
        Vp(a.ub());
        return bg(c.a, a)
    },
    Xp = function(a, b, c, d) {
        v(a, "Soy template may not be null.");
        a = a(b || Tp, void 0, c);
        d = Hg(d || Jf(), "DIV");
        a = Up(a);
        Vp(a.ub());
        Sd(d, a);
        1 == d.childNodes.length && (a = d.firstChild, 1 == a.nodeType && (d = a));
        return d
    },
    Up = function(a) {
        if (!La(a)) return Cd(String(a));
        if (a instanceof un) return vn(a);
        Ya("Soy template output is unsafe for use as HTML: " + a);
        return Cd("zSoyz")
    },
    Vp = function(a) {
        var b =
            a.match(Yp);
        v(!b, "This template starts with a %s, which cannot be a child of a <div>, as required by soy internals. Consider using goog.soy.renderElement instead.\nTemplate output: %s", b && b[0], a)
    },
    Yp = /^<(body|caption|col|colgroup|head|html|tr|td|th|tbody|thead|tfoot)>/i,
    Tp = {};
var Zp = function(a, b, c, d) {
    this.top = a;
    this.right = b;
    this.bottom = c;
    this.left = d
};
h = Zp.prototype;
h.toString = function() {
    return "(" + this.top + "t, " + this.right + "r, " + this.bottom + "b, " + this.left + "l)"
};
h.contains = function(a) {
    return this && a ? a instanceof Zp ? a.left >= this.left && a.right <= this.right && a.top >= this.top && a.bottom <= this.bottom : a.x >= this.left && a.x <= this.right && a.a >= this.top && a.a <= this.bottom : !1
};
h.ceil = function() {
    this.top = Math.ceil(this.top);
    this.right = Math.ceil(this.right);
    this.bottom = Math.ceil(this.bottom);
    this.left = Math.ceil(this.left);
    return this
};
h.floor = function() {
    this.top = Math.floor(this.top);
    this.right = Math.floor(this.right);
    this.bottom = Math.floor(this.bottom);
    this.left = Math.floor(this.left);
    return this
};
h.round = function() {
    this.top = Math.round(this.top);
    this.right = Math.round(this.right);
    this.bottom = Math.round(this.bottom);
    this.left = Math.round(this.left);
    return this
};
var $p = function(a, b, c, d) {
        this.left = a;
        this.top = b;
        this.width = c;
        this.height = d
    },
    aq = function(a) {
        return new Zp(a.top, a.left + a.width, a.top + a.height, a.left)
    };
h = $p.prototype;
h.toString = function() {
    return "(" + this.left + ", " + this.top + " - " + this.width + "w x " + this.height + "h)"
};
h.contains = function(a) {
    return a instanceof Ef ? a.x >= this.left && a.x <= this.left + this.width && a.a >= this.top && a.a <= this.top + this.height : this.left <= a.left && this.left + this.width >= a.left + a.width && this.top <= a.top && this.top + this.height >= a.top + a.height
};
h.ceil = function() {
    this.left = Math.ceil(this.left);
    this.top = Math.ceil(this.top);
    this.width = Math.ceil(this.width);
    this.height = Math.ceil(this.height);
    return this
};
h.floor = function() {
    this.left = Math.floor(this.left);
    this.top = Math.floor(this.top);
    this.width = Math.floor(this.width);
    this.height = Math.floor(this.height);
    return this
};
h.round = function() {
    this.left = Math.round(this.left);
    this.top = Math.round(this.top);
    this.width = Math.round(this.width);
    this.height = Math.round(this.height);
    return this
};
var cq = function(a, b, c) {
        if ("string" === typeof b)(b = bq(a, b)) && (a.style[b] = c);
        else
            for (var d in b) {
                c = a;
                var e = b[d],
                    f = bq(c, d);
                f && (c.style[f] = e)
            }
    },
    dq = {},
    bq = function(a, b) {
        var c = dq[b];
        if (!c) {
            var d = ne(b);
            c = d;
            void 0 === a.style[d] && (d = (ze ? "Webkit" : ye ? "Moz" : y ? "ms" : ve ? "O" : null) + oe(d), void 0 !== a.style[d] && (c = d));
            dq[b] = c
        }
        return c
    },
    eq = function(a, b) {
        var c = If(a);
        return c.defaultView && c.defaultView.getComputedStyle && (a = c.defaultView.getComputedStyle(a, null)) ? a[b] || a.getPropertyValue(b) || "" : ""
    },
    fq = function(a, b) {
        return eq(a,
            b) || (a.currentStyle ? a.currentStyle[b] : null) || a.style && a.style[b]
    },
    hq = function(a, b, c) {
        if (b instanceof Ef) {
            var d = b.x;
            b = b.a
        } else d = b, b = c;
        a.style.left = gq(d, !1);
        a.style.top = gq(b, !1)
    },
    iq = function(a) {
        a = a ? If(a) : document;
        return !y || Se(9) || Rf(Jf(a).a) ? a.documentElement : a.body
    },
    jq = function(a) {
        var b = a.body;
        a = a.documentElement;
        return new Ef(b.scrollLeft || a.scrollLeft, b.scrollTop || a.scrollTop)
    },
    kq = function(a) {
        try {
            var b = a.getBoundingClientRect()
        } catch (c) {
            return {
                left: 0,
                top: 0,
                right: 0,
                bottom: 0
            }
        }
        y && a.ownerDocument.body &&
            (a = a.ownerDocument, b.left -= a.documentElement.clientLeft + a.body.clientLeft, b.top -= a.documentElement.clientTop + a.body.clientTop);
        return b
    },
    lq = function(a) {
        if (y && !Se(8)) return v(a && "offsetParent" in a), a.offsetParent;
        var b = If(a),
            c = fq(a, "position"),
            d = "fixed" == c || "absolute" == c;
        for (a = a.parentNode; a && a != b; a = a.parentNode)
            if (11 == a.nodeType && a.host && (a = a.host), c = fq(a, "position"), d = d && "static" == c && a != b.documentElement && a != b.body, !d && (a.scrollWidth > a.clientWidth || a.scrollHeight > a.clientHeight || "fixed" == c || "absolute" ==
                    c || "relative" == c)) return a;
        return null
    },
    nq = function(a) {
        for (var b = new Zp(0, Infinity, Infinity, 0), c = Jf(a), d = c.a.body, e = c.a.documentElement, f = Tf(c.a); a = lq(a);)
            if (!(y && 0 == a.clientWidth || ze && 0 == a.clientHeight && a == d) && a != d && a != e && "visible" != fq(a, "overflow")) {
                var g = mq(a),
                    k = new Ef(a.clientLeft, a.clientTop);
                g.x += k.x;
                g.a += k.a;
                b.top = Math.max(b.top, g.a);
                b.right = Math.min(b.right, g.x + a.clientWidth);
                b.bottom = Math.min(b.bottom, g.a + a.clientHeight);
                b.left = Math.max(b.left, g.x)
            } d = f.scrollLeft;
        f = f.scrollTop;
        b.left = Math.max(b.left,
            d);
        b.top = Math.max(b.top, f);
        c = Sf(Ig(c) || window);
        b.right = Math.min(b.right, d + c.width);
        b.bottom = Math.min(b.bottom, f + c.height);
        return 0 <= b.top && 0 <= b.left && b.bottom > b.top && b.right > b.left ? b : null
    },
    qq = function(a, b) {
        b = b || Tf(document);
        var c = b || Tf(document);
        var d = mq(a),
            e = mq(c),
            f = oq(c);
        if (c == Tf(document)) {
            var g = d.x - c.scrollLeft;
            d = d.a - c.scrollTop;
            y && !Se(10) && (g += f.left, d += f.top)
        } else g = d.x - e.x - f.left, d = d.a - e.a - f.top;
        a = pq(a);
        f = c.clientHeight - a.height;
        e = c.scrollLeft;
        var k = c.scrollTop;
        e += Math.min(g, Math.max(g - (c.clientWidth -
            a.width), 0));
        k += Math.min(d, Math.max(d - f, 0));
        c = new Ef(e, k);
        b.scrollLeft = c.x;
        b.scrollTop = c.a
    },
    mq = function(a) {
        var b = If(a);
        bb(a, "Parameter is required");
        var c = new Ef(0, 0),
            d = iq(b);
        if (a == d) return c;
        a = kq(a);
        b = Uf(Jf(b).a);
        c.x = a.left + b.x;
        c.a = a.top + b.a;
        return c
    },
    sq = function(a, b) {
        a = rq(a);
        b = rq(b);
        return new Ef(a.x - b.x, a.a - b.a)
    },
    tq = function(a) {
        a = kq(a);
        return new Ef(a.left, a.top)
    },
    rq = function(a) {
        v(a);
        if (1 == a.nodeType) return tq(a);
        a = a.changedTouches ? a.changedTouches[0] : a;
        return new Ef(a.clientX, a.clientY)
    },
    uq = function(a,
        b, c) {
        if (b instanceof Gf) c = b.height, b = b.width;
        else if (void 0 == c) throw Error("missing height argument");
        a.style.width = gq(b, !0);
        a.style.height = gq(c, !0)
    },
    gq = function(a, b) {
        "number" == typeof a && (a = (b ? Math.round(a) : a) + "px");
        return a
    },
    vq = function(a) {
        var b = pq;
        if ("none" != fq(a, "display")) return b(a);
        var c = a.style,
            d = c.display,
            e = c.visibility,
            f = c.position;
        c.visibility = "hidden";
        c.position = "absolute";
        c.display = "inline";
        a = b(a);
        c.display = d;
        c.position = f;
        c.visibility = e;
        return a
    },
    pq = function(a) {
        var b = a.offsetWidth,
            c = a.offsetHeight,
            d = ze && !b && !c;
        return (void 0 === b || d) && a.getBoundingClientRect ? (a = kq(a), new Gf(a.right - a.left, a.bottom - a.top)) : new Gf(b, c)
    },
    wq = function(a) {
        var b = mq(a);
        a = vq(a);
        return new $p(b.x, b.a, a.width, a.height)
    },
    xq = function(a, b) {
        v(a);
        a = a.style;
        "opacity" in a ? a.opacity = b : "MozOpacity" in a ? a.MozOpacity = b : "filter" in a && (a.filter = "" === b ? "" : "alpha(opacity=" + 100 * Number(b) + ")")
    },
    W = function(a, b) {
        a.style.display = b ? "" : "none"
    },
    yq = function(a) {
        return "none" != a.style.display
    },
    Aq = function(a) {
        var b = Jf(void 0),
            c = b.a;
        if (y && c.createStyleSheet) return b =
            c.createStyleSheet(), zq(b, a), b;
        c = Mf(b.a, "HEAD", void 0, void 0)[0];
        if (!c) {
            var d = Mf(b.a, "BODY", void 0, void 0)[0];
            c = b.b("HEAD");
            d.parentNode.insertBefore(c, d)
        }
        d = b.b("STYLE");
        zq(d, a);
        b.appendChild(c, d);
        return d
    },
    zq = function(a, b) {
        b = md(b);
        y && void 0 !== a.cssText ? a.cssText = b : a.innerHTML = b
    },
    Bq = function(a) {
        return "rtl" == fq(a, "direction")
    },
    Cq = ye ? "MozUserSelect" : ze || we ? "WebkitUserSelect" : null,
    Dq = function(a, b, c) {
        c = c ? null : a.getElementsByTagName("*");
        if (Cq) {
            if (b = b ? "none" : "", a.style && (a.style[Cq] = b), c) {
                a = 0;
                for (var d; d =
                    c[a]; a++) d.style && (d.style[Cq] = b)
            }
        } else if (y || ve)
            if (b = b ? "on" : "", a.setAttribute("unselectable", b), c)
                for (a = 0; d = c[a]; a++) d.setAttribute("unselectable", b)
    },
    Eq = function(a, b, c) {
        a = a.style;
        ye ? a.MozBoxSizing = c : ze ? a.WebkitBoxSizing = c : a.boxSizing = c;
        a.width = Math.max(b.width, 0) + "px";
        a.height = Math.max(b.height, 0) + "px"
    },
    Fq = function(a, b, c, d) {
        if (/^\d+px?$/.test(b)) return parseInt(b, 10);
        var e = a.style[c],
            f = a.runtimeStyle[c];
        a.runtimeStyle[c] = a.currentStyle[c];
        a.style[c] = b;
        b = a.style[d];
        a.style[c] = e;
        a.runtimeStyle[c] =
            f;
        return +b
    },
    Gq = function(a, b) {
        return (b = a.currentStyle ? a.currentStyle[b] : null) ? Fq(a, b, "left", "pixelLeft") : 0
    },
    Hq = function(a, b) {
        if (y) {
            var c = Gq(a, b + "Left"),
                d = Gq(a, b + "Right"),
                e = Gq(a, b + "Top");
            a = Gq(a, b + "Bottom");
            return new Zp(e, d, a, c)
        }
        c = eq(a, b + "Left");
        d = eq(a, b + "Right");
        e = eq(a, b + "Top");
        a = eq(a, b + "Bottom");
        return new Zp(parseFloat(e), parseFloat(d), parseFloat(a), parseFloat(c))
    },
    Iq = function(a) {
        return Hq(a, "padding")
    },
    Jq = {
        thin: 2,
        medium: 4,
        thick: 6
    },
    Kq = function(a, b) {
        if ("none" == (a.currentStyle ? a.currentStyle[b + "Style"] :
                null)) return 0;
        b = a.currentStyle ? a.currentStyle[b + "Width"] : null;
        return b in Jq ? Jq[b] : Fq(a, b, "left", "pixelLeft")
    },
    oq = function(a) {
        if (y && !Se(9)) {
            var b = Kq(a, "borderLeft"),
                c = Kq(a, "borderRight"),
                d = Kq(a, "borderTop");
            a = Kq(a, "borderBottom");
            return new Zp(d, c, a, b)
        }
        b = eq(a, "borderLeftWidth");
        c = eq(a, "borderRightWidth");
        d = eq(a, "borderTopWidth");
        a = eq(a, "borderBottomWidth");
        return new Zp(parseFloat(d), parseFloat(c), parseFloat(a), parseFloat(b))
    };
var Lq = function(a) {
    Jg.call(this);
    this.m = a;
    this.c = {}
};
t(Lq, Jg);
var Mq = [];
Lq.prototype.listen = function(a, b, c, d) {
    return Nq(this, a, b, c, d)
};
var Oq = function(a, b, c, d) {
        Nq(a, b, "click", c, !1, d)
    },
    Nq = function(a, b, c, d, e, f) {
        Ia(c) || (c && (Mq[0] = c.toString()), c = Mq);
        for (var g = 0; g < c.length; g++) {
            var k = G(b, c[g], d || a.handleEvent, e || !1, f || a.m || a);
            if (!k) break;
            a.c[k.key] = k
        }
        return a
    };
Lq.prototype.fh = function(a, b, c, d) {
    return Pq(this, a, b, c, d)
};
var Pq = function(a, b, c, d, e, f) {
    if (Ia(c))
        for (var g = 0; g < c.length; g++) Pq(a, b, c[g], d, e, f);
    else {
        b = hh(b, c, d || a.handleEvent, e, f || a.m || a);
        if (!b) return a;
        a.c[b.key] = b
    }
    return a
};
Lq.prototype.Ga = function(a, b, c, d, e) {
    if (Ia(b))
        for (var f = 0; f < b.length; f++) this.Ga(a, b[f], c, d, e);
    else c = c || this.handleEvent, d = La(d) ? !!d.capture : !!d, e = e || this.m || this, c = ih(c), d = !!d, b = Yg(a) ? a.Ae(b, c, d, e) : a ? (a = kh(a)) ? a.Ae(b, c, d, e) : null : null, b && (ph(b), delete this.c[b.key]);
    return this
};
var Qq = function(a) {
    Jb(a.c, function(b, c) {
        this.c.hasOwnProperty(c) && ph(b)
    }, a);
    a.c = {}
};
Lq.prototype.T = function() {
    Lq.D.T.call(this);
    Qq(this)
};
Lq.prototype.handleEvent = function() {
    throw Error("EventHandler.handleEvent not implemented");
};
var Rq = function() {};
Fa(Rq);
Rq.prototype.a = 0;
var X = function(a) {
    J.call(this);
    this.a = a || Jf();
    this.Na = Sq;
    this.qa = null;
    this.ya = !1;
    this.v = null;
    this.O = void 0;
    this.L = this.o = this.G = this.na = null;
    this.wb = !1
};
t(X, J);
X.prototype.Id = Rq.M();
var Sq = null,
    Tq = function(a, b) {
        switch (a) {
            case 1:
                return b ? "disable" : "enable";
            case 2:
                return b ? "highlight" : "unhighlight";
            case 4:
                return b ? "activate" : "deactivate";
            case 8:
                return b ? "select" : "unselect";
            case 16:
                return b ? "check" : "uncheck";
            case 32:
                return b ? "focus" : "blur";
            case 64:
                return b ? "open" : "close"
        }
        throw Error("Invalid component state");
    },
    Uq = function(a) {
        return a.qa || (a.qa = ":" + (a.Id.a++).toString(36))
    },
    Vq = function(a, b) {
        if (a.G && a.G.L) {
            var c = a.G.L,
                d = a.qa;
            d in c && delete c[d];
            Tb(a.G.L, b, a)
        }
        a.qa = b
    };
X.prototype.j = function() {
    return this.v
};
var Wq = function(a) {
    a = a.v;
    v(a, "Can not call getElementStrict before rendering/decorating.");
    return a
};
X.prototype.wd = function(a) {
    return this.v ? this.a.wd(a, this.v) : null
};
var Y = function(a) {
        a.O || (a.O = new Lq(a));
        return v(a.O)
    },
    Yq = function(a, b) {
        if (a == b) throw Error("Unable to set parent component");
        if (b && a.G && a.qa && Xq(a.G, a.qa) && a.G != b) throw Error("Unable to set parent component");
        a.G = b;
        X.D.Fd.call(a, b)
    };
X.prototype.getParent = function() {
    return this.G
};
X.prototype.Fd = function(a) {
    if (this.G && this.G != a) throw Error("Method not supported");
    X.D.Fd.call(this, a)
};
X.prototype.Ja = function() {
    this.v = Hg(this.a, "DIV")
};
X.prototype.render = function(a) {
    Zq(this, a)
};
var Zq = function(a, b, c) {
    if (a.ya) throw Error("Component already rendered");
    a.v || a.Ja();
    b ? b.insertBefore(a.v, c || null) : a.a.a.body.appendChild(a.v);
    a.G && !a.G.ya || a.aa()
};
h = X.prototype;
h.ba = function(a) {
    if (this.ya) throw Error("Component already rendered");
    if (a && this.Xc(a)) {
        this.wb = !0;
        var b = If(a);
        this.a && this.a.a == b || (this.a = Jf(a));
        this.Da(a);
        this.aa()
    } else throw Error("Invalid element to decorate");
};
h.Xc = function() {
    return !0
};
h.Da = function(a) {
    this.v = a
};
h.aa = function() {
    this.ya = !0;
    $q(this, function(a) {
        !a.ya && a.j() && a.aa()
    })
};
h.bb = function() {
    $q(this, function(a) {
        a.ya && a.bb()
    });
    this.O && Qq(this.O);
    this.ya = !1
};
h.T = function() {
    this.ya && this.bb();
    this.O && (this.O.Ia(), delete this.O);
    $q(this, function(a) {
        a.Ia()
    });
    !this.wb && this.v && jg(this.v);
    this.G = this.na = this.v = this.L = this.o = null;
    X.D.T.call(this)
};
h.jb = function(a, b) {
    this.qd(a, ar(this), b)
};
h.qd = function(a, b, c) {
    v(!!a, "Provided element must not be null.");
    if (a.ya && (c || !this.ya)) throw Error("Component already rendered");
    if (0 > b || b > ar(this)) throw Error("Child component index out of bounds");
    this.L && this.o || (this.L = {}, this.o = []);
    if (a.getParent() == this) {
        var d = Uq(a);
        this.L[d] = a;
        ub(this.o, a)
    } else Tb(this.L, Uq(a), a);
    Yq(a, this);
    Ab(this.o, b, 0, a);
    a.ya && this.ya && a.getParent() == this ? (c = this.Zb(), b = c.childNodes[b] || null, b != a.j() && c.insertBefore(a.j(), b)) : c ? (this.v || this.Ja(), b = br(this, b + 1), Zq(a, this.Zb(),
        b ? b.v : null)) : this.ya && !a.ya && a.v && a.v.parentNode && 1 == a.v.parentNode.nodeType && a.aa()
};
h.Zb = function() {
    return this.v
};
var cr = function(a) {
        null == a.Na && (a.Na = Bq(a.ya ? a.v : a.a.a.body));
        return a.Na
    },
    ar = function(a) {
        return a.o ? a.o.length : 0
    },
    Xq = function(a, b) {
        a.L && b ? (a = a.L, b = (null !== a && b in a ? a[b] : void 0) || null) : b = null;
        return b
    },
    br = function(a, b) {
        return a.o ? a.o[b] || null : null
    },
    $q = function(a, b, c) {
        a.o && w(a.o, b, c)
    },
    dr = function(a, b) {
        return a.o && b ? ib(a.o, b) : -1
    };
X.prototype.removeChild = function(a, b) {
    if (a) {
        var c = "string" === typeof a ? a : Uq(a);
        a = Xq(this, c);
        if (c && a) {
            var d = this.L;
            c in d && delete d[c];
            ub(this.o, a);
            b && (a.bb(), a.v && jg(a.v));
            Yq(a, null)
        }
    }
    if (!a) throw Error("Child is not in parent component");
    return a
};
var fr = function(a, b) {
    J.call(this);
    a && er(this, a, b)
};
t(fr, J);
h = fr.prototype;
h.v = null;
h.Tf = null;
h.dh = null;
h.Uf = null;
h.Fb = -1;
h.vc = -1;
h.Lg = !1;
var gr = {
        3: 13,
        12: 144,
        63232: 38,
        63233: 40,
        63234: 37,
        63235: 39,
        63236: 112,
        63237: 113,
        63238: 114,
        63239: 115,
        63240: 116,
        63241: 117,
        63242: 118,
        63243: 119,
        63244: 120,
        63245: 121,
        63246: 122,
        63247: 123,
        63248: 44,
        63272: 46,
        63273: 36,
        63275: 35,
        63276: 33,
        63277: 34,
        63289: 144,
        63302: 45
    },
    hr = {
        Up: 38,
        Down: 40,
        Left: 37,
        Right: 39,
        Enter: 13,
        F1: 112,
        F2: 113,
        F3: 114,
        F4: 115,
        F5: 116,
        F6: 117,
        F7: 118,
        F8: 119,
        F9: 120,
        F10: 121,
        F11: 122,
        F12: 123,
        "U+007F": 46,
        Home: 36,
        End: 35,
        PageUp: 33,
        PageDown: 34,
        Insert: 45
    },
    ir = !ze || Qe("525"),
    jr = Ce && ye;
fr.prototype.a = function(a) {
    if (ze || we)
        if (17 == this.Fb && !a.ctrlKey || 18 == this.Fb && !a.altKey || Ce && 91 == this.Fb && !a.metaKey) this.vc = this.Fb = -1; - 1 == this.Fb && (a.ctrlKey && 17 != a.keyCode ? this.Fb = 17 : a.altKey && 18 != a.keyCode ? this.Fb = 18 : a.metaKey && 91 != a.keyCode && (this.Fb = 91));
    ir && !yh(a.keyCode, this.Fb, a.shiftKey, a.ctrlKey, a.altKey, a.metaKey) ? this.handleEvent(a) : (this.vc = xh(a.keyCode), jr && (this.Lg = a.altKey))
};
fr.prototype.b = function(a) {
    this.vc = this.Fb = -1;
    this.Lg = a.altKey
};
fr.prototype.handleEvent = function(a) {
    var b = a.b,
        c = b.altKey;
    if (y && "keypress" == a.type) {
        var d = this.vc;
        var e = 13 != d && 27 != d ? b.keyCode : 0
    } else(ze || we) && "keypress" == a.type ? (d = this.vc, e = 0 <= b.charCode && 63232 > b.charCode && vh(d) ? b.charCode : 0) : ve && !ze ? (d = this.vc, e = vh(d) ? b.keyCode : 0) : ("keypress" == a.type ? (jr && (c = this.Lg), b.keyCode == b.charCode ? 32 > b.keyCode ? (d = b.keyCode, e = 0) : (d = this.vc, e = b.charCode) : (d = b.keyCode || this.vc, e = b.charCode || 0)) : (d = b.keyCode || this.vc, e = b.charCode || 0), Ce && 63 == e && 224 == d && (d = 191));
    var f = d = xh(d);
    d ? 63232 <= d && d in gr ? f = gr[d] : 25 == d && a.shiftKey && (f = 9) : b.keyIdentifier && b.keyIdentifier in hr && (f = hr[b.keyIdentifier]);
    ye && ir && "keypress" == a.type && !yh(f, this.Fb, a.shiftKey, a.ctrlKey, c, a.metaKey) || (a = f == this.Fb, this.Fb = f, b = new kr(f, e, a, b), b.altKey = c, this.dispatchEvent(b))
};
fr.prototype.j = function() {
    return this.v
};
var er = function(a, b, c) {
        a.Uf && lr(a);
        a.v = b;
        a.Tf = G(a.v, "keypress", a, c);
        a.dh = G(a.v, "keydown", a.a, c, a);
        a.Uf = G(a.v, "keyup", a.b, c, a)
    },
    lr = function(a) {
        a.Tf && (ph(a.Tf), ph(a.dh), ph(a.Uf), a.Tf = null, a.dh = null, a.Uf = null);
        a.v = null;
        a.Fb = -1;
        a.vc = -1
    };
fr.prototype.T = function() {
    fr.D.T.call(this);
    lr(this)
};
var kr = function(a, b, c, d) {
    Tg.call(this, d);
    this.type = "key";
    this.keyCode = a;
    this.repeat = c
};
t(kr, Tg);
var mr = function() {},
    nr;
Fa(mr);
var or = {
    button: "pressed",
    checkbox: "checked",
    menuitem: "selected",
    menuitemcheckbox: "checked",
    menuitemradio: "checked",
    radio: "checked",
    tab: "selected",
    treeitem: "selected"
};
mr.prototype.$c = function() {};
mr.prototype.mb = function(a) {
    return a.a.b("DIV", pr(this, a).join(" "), a.Sa())
};
mr.prototype.Db = function(a) {
    return a
};
var rr = function(a, b, c) {
    if (a = a.j ? a.j() : a) {
        var d = [b];
        y && !Qe("7") && (d = qr(Op(a), b), d.push(b));
        (c ? Rp : Sp)(a, d)
    }
};
mr.prototype.Zc = function() {
    return !0
};
mr.prototype.Va = function(a, b) {
    b.id && Vq(a, b.id);
    var c = this.Db(b);
    c && c.firstChild ? sr(a, c.firstChild.nextSibling ? xb(c.childNodes) : c.firstChild) : a.ad = null;
    var d = 0,
        e = this.wa(),
        f = this.wa(),
        g = !1,
        k = !1,
        l = !1,
        m = xb(Op(b));
    w(m, function(r) {
        g || r != e ? k || r != f ? d |= this.g(r) : k = !0 : (g = !0, f == e && (k = !0));
        1 == this.g(r) && (eb(c), zg(c) && Ag(c) && xg(c, !1))
    }, this);
    a.bd = d;
    g || (m.push(e), f == e && (k = !0));
    k || m.push(f);
    (a = a.cc) && m.push.apply(m, a);
    if (y && !Qe("7")) {
        var q = qr(m);
        0 < q.length && (m.push.apply(m, q), l = !0)
    }
    g && k && !a && !l || Pp(b, m.join(" "));
    return b
};
mr.prototype.Bf = function(a) {
    cr(a) && this.Qg(a.j(), !0);
    a.isEnabled() && this.Rd(a, a.isVisible())
};
var tr = function(a, b, c) {
        if (a = c || a.$c()) v(b, "The element passed as a first parameter cannot be null."), c = b.getAttribute("role") || null, a != c && Gp(b, a)
    },
    vr = function(a, b, c) {
        v(b);
        v(c);
        var d = b.gb;
        null != d && Mp(c, d);
        b.isVisible() || Ip(c, "hidden", !b.isVisible());
        b.isEnabled() || a.lc(c, 1, !b.isEnabled());
        ur(b, 8) && a.lc(c, 8, b.ah());
        ur(b, 16) && a.lc(c, 16, b.Ea(16));
        ur(b, 64) && a.lc(c, 64, b.Ea(64))
    };
h = mr.prototype;
h.Cf = function(a, b) {
    Dq(a, !b, !y && !ve)
};
h.Qg = function(a, b) {
    rr(a, this.wa() + "-rtl", b)
};
h.Pg = function(a) {
    var b;
    return ur(a, 32) && (b = a.j()) ? zg(b) && Ag(b) : !1
};
h.Rd = function(a, b) {
    var c;
    if (ur(a, 32) && (c = a.j())) {
        if (!b && a.Ea(32)) {
            try {
                c.blur()
            } catch (d) {}
            a.Ea(32) && a.Df(null)
        }(zg(c) && Ag(c)) != b && xg(c, b)
    }
};
h.setVisible = function(a, b) {
    W(a, b);
    a && Ip(a, "hidden", !b)
};
h.yd = function(a, b, c) {
    var d = a.j();
    if (d) {
        var e = this.a(b);
        e && rr(a, e, c);
        this.lc(d, b, c)
    }
};
h.lc = function(a, b, c) {
    nr || (nr = {
        1: "disabled",
        8: "selected",
        16: "checked",
        64: "expanded"
    });
    v(a, "The element passed as a first parameter cannot be null.");
    b = nr[b];
    var d = a.getAttribute("role") || null;
    d && (d = or[d] || b, b = "checked" == b || "selected" == b ? d : b);
    b && Ip(a, b, c)
};
h.Lb = function(a, b) {
    var c = this.Db(a);
    c && (fg(c), b && ("string" === typeof b ? E(c, b) : (a = function(d) {
        if (d) {
            var e = If(c);
            c.appendChild("string" === typeof d ? e.createTextNode(d) : d)
        }
    }, Ia(b) ? w(b, a) : !Ja(b) || "nodeType" in b ? a(b) : w(xb(b), a))))
};
h.wa = function() {
    return "goog-control"
};
var pr = function(a, b) {
        var c = a.wa(),
            d = [c],
            e = a.wa();
        e != c && d.push(e);
        c = b.getState();
        for (e = []; c;) {
            var f = c & -c;
            e.push(a.a(f));
            c &= ~f
        }
        d.push.apply(d, e);
        (a = b.cc) && d.push.apply(d, a);
        y && !Qe("7") && d.push.apply(d, qr(d));
        return d
    },
    qr = function(a, b) {
        var c = [];
        b && (a = vb(a, [b]));
        w([], function(d) {
            !nb(d, Sa(rb, a)) || b && !rb(d, b) || c.push(d.join("_"))
        });
        return c
    };
mr.prototype.a = function(a) {
    this.b || wr(this);
    return this.b[a]
};
mr.prototype.g = function(a) {
    if (!this.O) {
        this.b || wr(this);
        var b = this.b,
            c = {},
            d;
        for (d in b) c[b[d]] = d;
        this.O = c
    }
    a = parseInt(this.O[a], 10);
    return isNaN(a) ? 0 : a
};
var wr = function(a) {
    var b = a.wa(),
        c = !Jc(b.replace(/\xa0|\s/g, " "), " ");
    v(c, "ControlRenderer has an invalid css class: '" + b + "'");
    a.b = {
        1: b + "-disabled",
        2: b + "-hover",
        4: b + "-active",
        8: b + "-selected",
        16: b + "-checked",
        32: b + "-focused",
        64: b + "-open"
    }
};
var xr = function() {};
t(xr, mr);
Fa(xr);
h = xr.prototype;
h.$c = function() {
    return "button"
};
h.lc = function(a, b, c) {
    switch (b) {
        case 8:
        case 16:
            v(a, "The button DOM element cannot be null.");
            Ip(a, "pressed", c);
            break;
        default:
        case 64:
        case 1:
            xr.D.lc.call(this, a, b, c)
    }
};
h.mb = function(a) {
    var b = xr.D.mb.call(this, a);
    yr(b, a.h);
    var c = a.Y();
    c && this.xf(b, c);
    ur(a, 16) && this.lc(b, 16, a.Ea(16));
    return b
};
h.Va = function(a, b) {
    b = xr.D.Va.call(this, a, b);
    var c = this.Y(b);
    a.ia = c;
    a.h = b.title;
    ur(a, 16) && this.lc(b, 16, a.Ea(16));
    return b
};
h.Y = Ea;
h.xf = Ea;
var yr = function(a, b) {
        a && (b ? a.title = b : a.removeAttribute("title"))
    },
    Ar = function(a, b, c) {
        var d = cr(b),
            e = a.wa() + "-collapse-left";
        a = a.wa() + "-collapse-right";
        zr(b, d ? a : e, !!(c & 1));
        zr(b, d ? e : a, !!(c & 2))
    };
xr.prototype.wa = function() {
    return "goog-button"
};
var Cr = function(a, b) {
        if (!a) throw Error("Invalid class name " + a);
        if (!Ka(b)) throw Error("Invalid decorator function " + b);
        Br[a] = b
    },
    Dr = {},
    Br = {};
var Z = function(a, b, c) {
    X.call(this, c);
    if (!b) {
        b = this.constructor;
        for (var d; b;) {
            d = Pa(b);
            if (d = Dr[d]) break;
            b = b.D ? b.D.constructor : null
        }
        b = d ? Ka(d.M) ? d.M() : new d : null
    }
    this.c = b;
    this.ad = void 0 !== a ? a : null;
    this.gb = null
};
t(Z, X);
h = Z.prototype;
h.ad = null;
h.bd = 0;
h.Te = 39;
h.Ac = 255;
h.Se = 0;
h.Ef = !0;
h.cc = null;
h.Ug = !0;
h.Ye = !1;
h.Rg = null;
var Fr = function(a, b) {
        a.ya && b != a.Ug && Er(a, b);
        a.Ug = b
    },
    Gr = function(a, b) {
        b && (a.cc ? rb(a.cc, b) || a.cc.push(b) : a.cc = [b], rr(a, b, !0))
    },
    Hr = function(a, b) {
        b && a.cc && ub(a.cc, b) && (0 == a.cc.length && (a.cc = null), rr(a, b, !1))
    },
    zr = function(a, b, c) {
        c ? Gr(a, b) : Hr(a, b)
    };
Z.prototype.Ja = function() {
    var a = this.c.mb(this);
    this.v = a;
    tr(this.c, a, this.C());
    this.Ye || this.c.Cf(a, !1);
    this.isVisible() || this.c.setVisible(a, !1)
};
Z.prototype.C = function() {
    return this.Rg
};
var Ir = function(a, b) {
    a.gb = b;
    (a = a.j()) && Mp(a, b)
};
Z.prototype.Zb = function() {
    return this.c.Db(this.j())
};
Z.prototype.Xc = function(a) {
    return this.c.Zc(a)
};
Z.prototype.Da = function(a) {
    this.v = a = this.c.Va(this, a);
    tr(this.c, a, this.C());
    this.Ye || this.c.Cf(a, !1);
    this.Ef = "none" != a.style.display
};
Z.prototype.aa = function() {
    Z.D.aa.call(this);
    vr(this.c, this, Wq(this));
    this.c.Bf(this);
    if (this.Te & -2 && (this.Ug && Er(this, !0), ur(this, 32))) {
        var a = this.j();
        if (a) {
            var b = this.w || (this.w = new fr);
            er(b, a);
            Y(this).listen(b, "key", this.Ya).listen(a, "focus", this.bl).listen(a, "blur", this.Df)
        }
    }
};
var Er = function(a, b) {
    var c = Y(a),
        d = a.j();
    b ? (c.listen(d, Sg.Jd, a.vb).listen(d, [Sg.Kd, Sg.me], a.Eb).listen(d, "mouseover", a.Ie).listen(d, "mouseout", a.Vg), a.Me != Ea && c.listen(d, "contextmenu", a.Me), y && (Qe(9) || c.listen(d, "dblclick", a.Bi), a.K || (a.K = new Jr(a), Lg(a, a.K)))) : (c.Ga(d, Sg.Jd, a.vb).Ga(d, [Sg.Kd, Sg.me], a.Eb).Ga(d, "mouseover", a.Ie).Ga(d, "mouseout", a.Vg), a.Me != Ea && c.Ga(d, "contextmenu", a.Me), y && (Qe(9) || c.Ga(d, "dblclick", a.Bi), Kg(a.K), a.K = null))
};
Z.prototype.bb = function() {
    Z.D.bb.call(this);
    this.w && lr(this.w);
    this.isVisible() && this.isEnabled() && this.c.Rd(this, !1)
};
Z.prototype.T = function() {
    Z.D.T.call(this);
    this.w && (this.w.Ia(), delete this.w);
    delete this.c;
    this.K = this.cc = this.ad = null
};
Z.prototype.Sa = function() {
    return this.ad
};
Z.prototype.g = function(a) {
    this.c.Lb(this.j(), a);
    this.ad = a
};
var sr = function(a, b) {
    a.ad = b
};
h = Z.prototype;
h.sb = function() {
    var a = this.Sa();
    if (!a) return "";
    a = "string" === typeof a ? a : Ia(a) ? kb(a, Dg).join("") : Cg(a);
    return ae(a)
};
h.isVisible = function() {
    return this.Ef
};
h.setVisible = function(a, b) {
    return b || this.Ef != a && this.dispatchEvent(a ? "show" : "hide") ? ((b = this.j()) && this.c.setVisible(b, a), this.isEnabled() && this.c.Rd(this, a), this.Ef = a, !0) : !1
};
h.isEnabled = function() {
    return !this.Ea(1)
};
h.oa = function(a) {
    var b = this.getParent();
    b && "function" == typeof b.isEnabled && !b.isEnabled() || !Kr(this, 1, !a) || (a || (Lr(this, !1), this.Mb(!1)), this.isVisible() && this.c.Rd(this, a), Mr(this, 1, !a, !0))
};
h.Mb = function(a) {
    Kr(this, 2, a) && Mr(this, 2, a)
};
h.nb = function() {
    return this.Ea(4)
};
var Lr = function(a, b) {
    Kr(a, 4, b) && Mr(a, 4, b)
};
h = Z.prototype;
h.ah = function() {
    return this.Ea(8)
};
h.dd = function(a) {
    Kr(this, 8, a) && Mr(this, 8, a)
};
h.cd = function(a) {
    Kr(this, 16, a) && Mr(this, 16, a)
};
h.ce = function(a) {
    Kr(this, 32, a) && Mr(this, 32, a)
};
h.Xa = function(a) {
    Kr(this, 64, a) && Mr(this, 64, a)
};
h.getState = function() {
    return this.bd
};
h.Ea = function(a) {
    return !!(this.bd & a)
};
var Mr = function(a, b, c, d) {
        d || 1 != b ? ur(a, b) && c != a.Ea(b) && (a.c.yd(a, b, c), a.bd = c ? a.bd | b : a.bd & ~b) : a.oa(!c)
    },
    ur = function(a, b) {
        return !!(a.Te & b)
    };
Z.prototype.Oa = function(a, b) {
    if (this.ya && this.Ea(a) && !b) throw Error("Component already rendered");
    !b && this.Ea(a) && Mr(this, a, !1);
    this.Te = b ? this.Te | a : this.Te & ~a
};
var Nr = function(a, b) {
        return !!(a.Ac & b) && ur(a, b)
    },
    Kr = function(a, b, c) {
        return ur(a, b) && a.Ea(b) != c && (!(a.Se & b) || a.dispatchEvent(Tq(b, c))) && !a.isDisposed()
    };
h = Z.prototype;
h.Ie = function(a) {
    (!a.relatedTarget || !pg(this.j(), a.relatedTarget)) && this.dispatchEvent("enter") && this.isEnabled() && Nr(this, 2) && this.Mb(!0)
};
h.Vg = function(a) {
    a.relatedTarget && pg(this.j(), a.relatedTarget) || !this.dispatchEvent("leave") || (Nr(this, 4) && Lr(this, !1), Nr(this, 2) && this.Mb(!1))
};
h.Me = Ea;
h.vb = function(a) {
    this.isEnabled() && (Nr(this, 2) && this.Mb(!0), Wg(a) && (Nr(this, 4) && Lr(this, !0), this.c && this.c.Pg(this) && this.j().focus()));
    !this.Ye && Wg(a) && a.preventDefault()
};
h.Eb = function(a) {
    this.isEnabled() && (Nr(this, 2) && this.Mb(!0), this.nb() && this.yc(a) && Nr(this, 4) && Lr(this, !1))
};
h.Bi = function(a) {
    this.isEnabled() && this.yc(a)
};
h.yc = function(a) {
    Nr(this, 16) && this.cd(!this.Ea(16));
    Nr(this, 8) && this.dd(!0);
    Nr(this, 64) && this.Xa(!this.Ea(64));
    var b = new F("action", this);
    a && (b.altKey = a.altKey, b.ctrlKey = a.ctrlKey, b.metaKey = a.metaKey, b.shiftKey = a.shiftKey, b.g = a.g);
    return this.dispatchEvent(b)
};
h.bl = function() {
    Nr(this, 32) && this.ce(!0)
};
h.Df = function() {
    Nr(this, 4) && Lr(this, !1);
    Nr(this, 32) && this.ce(!1)
};
h.Ya = function(a) {
    return this.isVisible() && this.isEnabled() && this.Sd(a) ? (a.preventDefault(), a.stopPropagation(), !0) : !1
};
h.Sd = function(a) {
    return 13 == a.keyCode && this.yc(a)
};
if (!Ka(Z)) throw Error("Invalid component class " + Z);
if (!Ka(mr)) throw Error("Invalid renderer class " + mr);
var Or = Pa(Z);
Dr[Or] = mr;
Cr("goog-control", function() {
    return new Z(null)
});
var Jr = function(a) {
    Jg.call(this);
    this.b = a;
    this.a = !1;
    this.c = new Lq(this);
    Lg(this, this.c);
    a = Wq(this.b);
    this.c.listen(a, Sg.Jd, this.h).listen(a, Sg.Kd, this.o).listen(a, "click", this.g)
};
t(Jr, Jg);
var Pr = !y || Se(9);
Jr.prototype.h = function() {
    this.a = !1
};
Jr.prototype.o = function() {
    this.a = !0
};
var Qr = function(a, b) {
    if (!Pr) return a.button = 0, a.type = b, a;
    var c = document.createEvent("MouseEvents");
    c.initMouseEvent(b, a.bubbles, a.cancelable, a.view || null, a.detail, a.screenX, a.screenY, a.clientX, a.clientY, a.ctrlKey, a.altKey, a.shiftKey, a.metaKey, 0, a.relatedTarget || null);
    return c
};
Jr.prototype.g = function(a) {
    if (this.a) this.a = !1;
    else {
        var b = a.b,
            c = b.button,
            d = b.type,
            e = Qr(b, "mousedown");
        this.b.vb(new Tg(e, a.a));
        e = Qr(b, "mouseup");
        this.b.Eb(new Tg(e, a.a));
        Pr || (b.button = c, b.type = d)
    }
};
Jr.prototype.T = function() {
    this.b = null;
    Jr.D.T.call(this)
};
var Rr = function() {};
t(Rr, xr);
Fa(Rr);
h = Rr.prototype;
h.$c = function() {};
h.mb = function(a) {
    Fr(a, !1);
    a.Ac &= -256;
    a.Oa(32, !1);
    return a.a.b("BUTTON", {
        "class": pr(this, a).join(" "),
        disabled: !a.isEnabled(),
        title: a.h || "",
        value: a.Y() || ""
    }, a.sb() || "")
};
h.Zc = function(a) {
    return "BUTTON" == a.tagName || "INPUT" == a.tagName && ("button" == a.type || "submit" == a.type || "reset" == a.type)
};
h.Va = function(a, b) {
    Fr(a, !1);
    a.Ac &= -256;
    a.Oa(32, !1);
    if (b.disabled) {
        var c = $a(this.a(1));
        T(b, c)
    }
    return Rr.D.Va.call(this, a, b)
};
h.Bf = function(a) {
    Y(a).listen(a.j(), "click", a.yc)
};
h.Cf = Ea;
h.Qg = Ea;
h.Pg = function(a) {
    return a.isEnabled()
};
h.Rd = Ea;
h.yd = function(a, b, c) {
    Rr.D.yd.call(this, a, b, c);
    (a = a.j()) && 1 == b && (a.disabled = c)
};
h.Y = function(a) {
    return a.value
};
h.xf = function(a, b) {
    a && (a.value = b)
};
h.lc = Ea;
var Sr = function(a, b, c) {
    Z.call(this, a, b || Rr.M(), c)
};
t(Sr, Z);
h = Sr.prototype;
h.Y = function() {
    return this.ia
};
h.yf = function(a) {
    this.ia = a;
    this.c.xf(this.j(), a)
};
h.xd = function(a) {
    this.h = a;
    yr(this.j(), a)
};
h.T = function() {
    Sr.D.T.call(this);
    delete this.ia;
    delete this.h
};
h.aa = function() {
    Sr.D.aa.call(this);
    if (ur(this, 32)) {
        var a = this.j();
        a && Y(this).listen(a, "keyup", this.Sd)
    }
};
h.Sd = function(a) {
    return 13 == a.keyCode && "key" == a.type || 32 == a.keyCode && "keyup" == a.type ? this.yc(a) : 32 == a.keyCode
};
Cr("goog-button", function() {
    return new Sr(null)
});
var Tr = function(a) {
    a = a || {};
    var b = a.attributes,
        c = a.content,
        d = a.disabled,
        e = a.id,
        f = a.er,
        g = a.title,
        k = a.Co,
        l = a.value,
        m = Q;
    e = '<div role="button"' + (e ? ' id="' + S(e) + '"' : "") + ' class="';
    var q = a || {};
    a = q.Rq;
    var r = q.disabled,
        u = q.checked,
        z = q.width,
        P = "goog-inline-block jfk-button ";
    q = q.style;
    switch (La(q) ? q.toString() : q) {
        case 0:
            P += "jfk-button-standard";
            break;
        case 2:
            P += "jfk-button-action";
            break;
        case 3:
            P += "jfk-button-primary";
            break;
        case 1:
            P += "jfk-button-default";
            break;
        case 4:
            P += "jfk-button-flat";
            break;
        case 5:
            P += "jfk-button-mini";
            break;
        case 6:
            P += "jfk-button-contrast";
            break;
        default:
            P += "jfk-button-standard"
    }
    P += (Dn(z, 1) ? " jfk-button-narrow" : "") + (u ? " jfk-button-checked" : "") + (a ? " " + a : "") + (r ? " jfk-button-disabled" : "");
    d = e + S(P) + '"' + (d ? ' aria-disabled="true"' : ' tabindex="' + (f ? S(f) : "0") + '"') + (g ? k ? ' data-tooltip="' + S(g) + '"' : ' title="' + S(g) + '"' : "") + (l ? ' value="' + S(l) + '"' : "");
    b ? (Bn(b, sn, zn) ? b = b.Sa().replace(/([^"'\s])$/, "$1 ") : (b = String(b), Zn.test(b) || (Ya("Bad value `%s` for |filterHtmlAttributes", [b]), b = "zSoyz")), b = " " + b) : b = "";
    return m(d +
        b + ">" + R(null != c ? c : "") + "</div>")
};
Tr.a = "jfk.templates.button.strict";
var Ur = function(a, b, c) {
    Jg.call(this);
    this.$b = a;
    this.c = b || 0;
    this.a = c;
    this.b = p(this.Jg, this)
};
t(Ur, Jg);
h = Ur.prototype;
h.qa = 0;
h.T = function() {
    Ur.D.T.call(this);
    this.stop();
    delete this.$b;
    delete this.a
};
h.start = function(a) {
    this.stop();
    this.qa = Ci(this.b, void 0 !== a ? a : this.c)
};
h.stop = function() {
    this.nb() && Di(this.qa);
    this.qa = 0
};
h.nb = function() {
    return 0 != this.qa
};
h.Jg = function() {
    this.qa = 0;
    this.$b && this.$b.call(this.a)
};
var Xr = function(a) {
        return ge(yc(a.replace(Vr, function(b, c) {
            return Wr.test(c) ? "" : " "
        }).replace(/[\t\n ]+/g, " ")))
    },
    Wr = /^(?:abbr|acronym|address|b|em|i|small|strong|su[bp]|u)$/i,
    Vr = /<[!\/]?([a-z0-9]+)([\/ ][^>]*)?>/gi;
var Yr = function() {
    if (De) {
        var a = /Windows NT ([0-9.]+)/;
        return (a = a.exec(pd)) ? a[1] : "0"
    }
    return Ce ? (a = /10[_.][0-9_.]+/, (a = a.exec(pd)) ? a[0].replace(/_/g, ".") : "10") : Ee ? (a = /Android\s+([^\);]+)(\)|;)/, (a = a.exec(pd)) ? a[1] : "") : Fe || Ge || He ? (a = /(?:iPhone|CPU)\s+OS\s+(\S+)/, (a = a.exec(pd)) ? a[1].replace(/_/g, ".") : "") : ""
}();
var bs = function(a, b, c, d, e, f, g, k, l) {
        v(c);
        var m = Zr(c),
            q = wq(a),
            r = nq(a);
        if (r) {
            var u = new $p(r.left, r.top, r.right - r.left, r.bottom - r.top);
            r = Math.max(q.left, u.left);
            var z = Math.min(q.left + q.width, u.left + u.width);
            if (r <= z) {
                var P = Math.max(q.top, u.top);
                u = Math.min(q.top + q.height, u.top + u.height);
                P <= u && (q.left = r, q.top = P, q.width = z - r, q.height = u - P)
            }
        }
        r = Jf(a);
        P = Jf(c);
        if (r.a != P.a) {
            z = r.a.body;
            P = Ig(P);
            u = new Ef(0, 0);
            var L = Vf(If(z));
            if (te(L, "parent")) {
                var Ma = z;
                do {
                    var Kb = L == P ? mq(Ma) : tq(v(Ma));
                    u.x += Kb.x;
                    u.a += Kb.a
                } while (L && L !=
                    P && L != L.parent && (Ma = L.frameElement) && (L = L.parent))
            }
            z = Ff(u, mq(z));
            !y || Se(9) || Rf(r.a) || (z = Ff(z, Uf(r.a)));
            q.left += z.x;
            q.top += z.a
        }
        a = $r(a, b);
        b = q.left;
        a & 4 ? b += q.width : a & 2 && (b += q.width / 2);
        q = new Ef(b, q.top + (a & 1 ? q.height : 0));
        q = Ff(q, m);
        e && (q.x += (a & 4 ? -1 : 1) * e.x, q.a += (a & 1 ? -1 : 1) * e.a);
        if (g)
            if (l) var Ha = l;
            else if (Ha = nq(c)) Ha.top -= m.a, Ha.right -= m.x, Ha.bottom -= m.a, Ha.left -= m.x;
        return as(q, c, d, f, Ha, g, k)
    },
    Zr = function(a) {
        if (a = a.offsetParent) {
            var b = "HTML" == a.tagName || "BODY" == a.tagName;
            if (!b || "static" != fq(a, "position")) {
                var c =
                    mq(a);
                if (!b) {
                    b = Bq(a);
                    var d;
                    if (d = b) {
                        d = Ze && Ck(10);
                        var e = Ie && 0 <= Lc(Yr, 10);
                        d = ye || d || e
                    }
                    b = d ? -a.scrollLeft : !b || xe && Qe("8") || "visible" == fq(a, "overflowX") ? a.scrollLeft : a.scrollWidth - a.clientWidth - a.scrollLeft;
                    c = Ff(c, new Ef(b, a.scrollTop))
                }
            }
        }
        return c || new Ef
    },
    as = function(a, b, c, d, e, f, g) {
        a = new Ef(a.x, a.a);
        var k = $r(b, c);
        c = vq(b);
        g = g ? new Gf(g.width, g.height) : new Gf(c.width, c.height);
        a = new Ef(a.x, a.a);
        g = new Gf(g.width, g.height);
        var l = 0;
        if (d || 0 != k) k & 4 ? a.x -= g.width + (d ? d.right : 0) : k & 2 ? a.x -= g.width / 2 : d && (a.x += d.left),
            k & 1 ? a.a -= g.height + (d ? d.bottom : 0) : d && (a.a += d.top);
        if (f) {
            if (e) {
                d = a;
                k = g;
                l = 0;
                65 == (f & 65) && (d.x < e.left || d.x >= e.right) && (f &= -2);
                132 == (f & 132) && (d.a < e.top || d.a >= e.bottom) && (f &= -5);
                d.x < e.left && f & 1 && (d.x = e.left, l |= 1);
                if (f & 16) {
                    var m = d.x;
                    d.x < e.left && (d.x = e.left, l |= 4);
                    d.x + k.width > e.right && (k.width = Math.min(e.right - d.x, m + k.width - e.left), k.width = Math.max(k.width, 0), l |= 4)
                }
                d.x + k.width > e.right && f & 1 && (d.x = Math.max(e.right - k.width, e.left), l |= 1);
                f & 2 && (l |= (d.x < e.left ? 16 : 0) | (d.x + k.width > e.right ? 32 : 0));
                d.a < e.top && f & 4 && (d.a =
                    e.top, l |= 2);
                f & 32 && (m = d.a, d.a < e.top && (d.a = e.top, l |= 8), d.a + k.height > e.bottom && (k.height = Math.min(e.bottom - d.a, m + k.height - e.top), k.height = Math.max(k.height, 0), l |= 8));
                d.a + k.height > e.bottom && f & 4 && (d.a = Math.max(e.bottom - k.height, e.top), l |= 2);
                f & 8 && (l |= (d.a < e.top ? 64 : 0) | (d.a + k.height > e.bottom ? 128 : 0));
                e = l
            } else e = 256;
            l = e
        }
        f = new $p(0, 0, 0, 0);
        f.left = a.x;
        f.top = a.a;
        f.width = g.width;
        f.height = g.height;
        e = l;
        if (e & 496) return e;
        hq(b, new Ef(f.left, f.top));
        g = new Gf(f.width, f.height);
        c == g || c && g && c.width == g.width && c.height ==
            g.height || (c = g, a = If(b), g = Rf(Jf(a).a), !y || Qe("10") || g && Qe("8") ? Eq(b, c, "border-box") : (a = b.style, g ? (g = Iq(b), b = oq(b), a.pixelWidth = c.width - b.left - g.left - g.right - b.right, a.pixelHeight = c.height - b.top - g.top - g.bottom - b.bottom) : (a.pixelWidth = c.width, a.pixelHeight = c.height)));
        return e
    },
    $r = function(a, b) {
        return (b & 8 && Bq(a) ? b ^ 4 : b) & -9
    };
var cs = function() {};
cs.prototype.b = function() {};
var ds = function(a, b) {
    this.g = a;
    this.m = !!b;
    this.o = {
        0: this.g + "-arrowright",
        1: this.g + "-arrowup",
        2: this.g + "-arrowdown",
        3: this.g + "-arrowleft"
    }
};
t(ds, cs);
h = ds.prototype;
h.Qf = !1;
h.ng = 2;
h.Wh = 20;
h.pg = 3;
h.kh = -5;
h.Xe = !1;
var es = function(a, b, c, d, e) {
    null != b && (a.pg = b);
    null != c && (a.ng = c);
    "number" === typeof d && (a.Wh = Math.max(d, 15));
    "number" === typeof e && (a.kh = e)
};
ds.prototype.b = function(a, b, c) {
    v(this.h, "Must call setElements first.");
    a = this.ng;
    2 == a && (a = 0);
    fs(this, this.pg, a, 2 == this.ng ? gs(this.pg) ? this.a.offsetHeight / 2 : this.a.offsetWidth / 2 : this.Wh, 0, c)
};
var fs = function(a, b, c, d, e, f) {
        if (a.c) {
            var g = hs(b, c);
            var k = a.c;
            var l = vq(k);
            l = (gs(b) ? l.height / 2 : l.width / 2) - d;
            var m = $r(k, g),
                q;
            if (q = nq(k)) k = aq(wq(k)), gs(b) ? k.top < q.top && !(m & 1) ? l -= q.top - k.top : k.bottom > q.bottom && m & 1 && (l -= k.bottom - q.bottom) : k.left < q.left && !(m & 4) ? l -= q.left - k.left : k.right > q.right && m & 4 && (l -= k.right - q.right);
            k = l;
            k = gs(b) ? new Ef(a.kh, k) : new Ef(k, a.kh);
            l = gs(b) ? 6 : 9;
            a.Xe && 2 == e && (l = gs(b) ? 4 : 1);
            m = b ^ 3;
            gs(b) && "rtl" == a.c.dir && (m = b);
            g = bs(a.c, hs(m, c), a.a, g, k, f, a.Qf ? l : 0, void 0, null);
            if (2 != e && g & 496) {
                fs(a, b ^
                    3, c, d, a.Xe && 0 == e ? 1 : 2, f);
                return
            }!a.m || g & 496 || (e = parseFloat(a.a.style.left), f = parseFloat(a.a.style.top), v(!isNaN(e) && !isNaN(f), "Could not parse position."), isFinite(e) && 0 == e % 1 && isFinite(f) && 0 == f % 1 || hq(a.a, Math.round(e), Math.round(f)))
        }
        is(a, b, c, d)
    },
    is = function(a, b, c, d) {
        var e = a.h;
        Jb(a.o, function(f) {
            V(e, f, !1)
        }, a);
        T(e, a.o[b]);
        e.style.top = e.style.left = e.style.right = e.style.bottom = "";
        a.c ? (c = sq(a.c, a.a), d = js(a.c, b), gs(b) ? e.style.top = ks(c.a + d.a, a.a.offsetHeight - 15) + "px" : e.style.left = ks(c.x + d.x, a.a.offsetWidth -
            15) + "px") : e.style[0 == c ? gs(b) ? "top" : "left" : gs(b) ? "bottom" : "right"] = d + "px"
    },
    ks = function(a, b) {
        return 15 > b ? 15 : Math.min(Math.max(a, 15), b)
    },
    hs = function(a, b) {
        switch (a) {
            case 2:
                return 0 == b ? 1 : 5;
            case 1:
                return 0 == b ? 0 : 4;
            case 0:
                return 0 == b ? 12 : 13;
            default:
                return 0 == b ? 8 : 9
        }
    },
    js = function(a, b) {
        var c = 0,
            d = 0;
        a = vq(a);
        switch (b) {
            case 2:
                c = a.width / 2;
                break;
            case 1:
                c = a.width / 2;
                d = a.height;
                break;
            case 0:
                d = a.height / 2;
                break;
            case 3:
                c = a.width, d = a.height / 2
        }
        return new Ef(c, d)
    },
    gs = function(a) {
        return 0 == a || 3 == a
    };
var ls = function(a) {
    Jg.call(this);
    this.b = a || Jf()
};
t(ls, Jg);
ls.prototype.h = function() {
    Gp(this.j(), "tooltip");
    Ip(this.j(), "live", "polite")
};
var ms = function(a) {
    ls.call(this, a);
    this.a = this.b.b("DIV", "jfk-tooltip-contentId");
    this.g = this.b.b("DIV", "jfk-tooltip-arrow", this.b.b("DIV", "jfk-tooltip-arrowimplbefore"), this.b.b("DIV", "jfk-tooltip-arrowimplafter"));
    this.c = this.b.b("DIV", {
        "class": "jfk-tooltip",
        role: "tooltip"
    }, this.a, this.g);
    this.h()
};
t(ms, ls);
ms.prototype.j = function() {
    return this.c
};
ms.prototype.T = function() {
    ms.D.T.call(this);
    this.c && jg(this.c)
};
var ns = function(a) {
    ms.call(this, a)
};
t(ns, ms);
ns.prototype.h = function() {
    Gp(this.j(), "tooltip")
};
var ps = function(a) {
        var b = a.getAttribute("title");
        b && os(a, b)
    },
    os = function(a, b, c) {
        c || (c = b instanceof zd ? Xr(Ad(b).toString()) : b);
        a.removeAttribute("title");
        a.removeAttribute("data-tooltip-contained");
        a.removeAttribute("data-tooltip");
        b ? (b instanceof zd ? a.a = b : (a.setAttribute("data-tooltip", b), a.a = null), a.setAttribute("aria-label", c)) : (a.a = null, a.removeAttribute("aria-label"));
        a = Jf(a) || Jf();
        b = Pa(a.a);
        qs[b] || (qs[b] = new rs(a))
    },
    ss = function(a, b) {
        var c = "";
        switch (b) {
            case 0:
                c += "l";
                break;
            case 2:
                c += "t";
                break;
            case 3:
                c += "r";
                break;
            default:
                c += "b"
        }
        a.setAttribute("data-tooltip-align", c + ",c")
    },
    qs = {},
    rs = function(a) {
        Lq.call(this);
        this.K = a;
        this.L = new Ur(this.X, 0, this);
        Lg(this, this.L);
        var b = Vf();
        this.w = Ka(b.MutationObserver) ? new b.MutationObserver(p(this.V, this)) : null;
        a = a.a;
        this.listen(a, "mouseout mousedown click blur focusout keydown".split(" "), this.R, !0);
        this.listen(a, ["mouseover", "focus", "focusin"], this.na, !0)
    };
t(rs, Lq);
rs.prototype.T = function() {
    ts(this);
    rs.D.T.call(this)
};
var us = function(a, b) {
    switch (b.type) {
        case "mousedown":
        case "mouseover":
        case "mouseout":
        case "click":
            a.O = !1;
            break;
        case "keydown":
            a.O = !0
    }
};
rs.prototype.na = function(a) {
    this.w && this.w.disconnect();
    us(this, a);
    var b = a.target;
    a = "focus" == a.type || "focusin" == a.type;
    var c = this.a && pg(this.a.a, b);
    if (this.O || !a || c) {
        this.W = a;
        if (a = b && b.getAttribute && this.w) a = b.getAttribute("role") || null, a = rb(Fp, a);
        a && (this.w.observe(b, {
            attributes: !0
        }), (a = Kp(b)) && (b = a));
        this.g = b
    } else this.g = null;
    vs(this)
};
rs.prototype.R = function(a) {
    us(this, a);
    var b = a.target;
    a = "mousedown" == a.type || "click" == a.type;
    b = this.a && pg(this.a.a, b);
    a && b || (this.g = null, vs(this))
};
rs.prototype.V = function(a) {
    w(a, p(function(b) {
        var c = Kp(b.target);
        c && "aria-activedescendant" == b.attributeName && (this.g = c, vs(this))
    }, this))
};
var vs = function(a) {
        if (!(a.L.nb() && a.b && a.o)) {
            ts(a);
            var b = null != a.o ? a.o : 50;
            a.L.start(a.b ? b : 300)
        }
    },
    ts = function(a) {
        a.G && (Di(a.G), a.G = 0, a.b = null)
    };
rs.prototype.X = function() {
    if (!this.g) ws(this), this.o = this.b = null;
    else if (!(this.b && this.a && pg(this.a.j(), this.g)) || this.b.getAttribute("data-tooltip-unhoverable")) {
        var a = Eg(this.g, function(k) {
                return k.getAttribute && (k.getAttribute("data-tooltip-contained") || k.getAttribute("data-tooltip") || k.a) && !k.getAttribute("data-tooltip-suspended")
            }),
            b = !1;
        this.b && this.b != a && (ws(this), this.o = this.b = null, b = !0);
        if (!this.b && a && (this.b = a, xs(this, a))) {
            var c = Jd;
            if (a.getAttribute("data-tooltip-contained"))
                for (var d = Nf("jfk-tooltip-data",
                        a), e = 0; e < d.length; e++) {
                    if (d[e].parentNode == a) {
                        c = d[e].cloneNode(!0);
                        break
                    }
                } else c = a.a ? a.a : Dd(a.getAttribute("data-tooltip"));
            d = a.getAttribute("data-tooltip-align");
            e = a.getAttribute("data-tooltip-class");
            var f = a.getAttribute("data-tooltip-offset");
            f = xc(ke(f)) ? -1 : Number(f);
            var g = a.getAttribute("data-tooltip-hide-delay");
            g = xc(ke(g)) ? null : Number(g);
            if (!b && (a = a.getAttribute("data-tooltip-delay"), a = Math.max(0, a - 300))) {
                this.G = Ci(Sa(this.N, this.b, c, d, f, e, g), a, this);
                return
            }
            this.N(this.b, c, d, f, e, g)
        }
    }
};
var xs = function(a, b) {
        return b.getAttribute("data-tooltip-only-on-overflow") && b.offsetWidth >= b.scrollWidth && b.offsetHeight >= b.scrollHeight || a.W && "mouse" == b.getAttribute("data-tooltip-trigger") ? !1 : !0
    },
    ys = function(a) {
        if (a) switch (a.toLowerCase().split(",")[0]) {
            case "l":
                return 0;
            case "t":
                return 2;
            case "r":
                return 3
        }
        return 1
    };
rs.prototype.N = function(a, b, c, d, e, f) {
    this.G = 0;
    this.o = f;
    if (!this.a) {
        this.a = new ns(this.K);
        ws(this);
        dg(this.K.a.body, this.a.j());
        Lg(this, this.a);
        this.h = new ds("jfk-tooltip", !0);
        this.h.Qf = !0;
        this.h.Xe = !0;
        f = this.h;
        var g = this.a.g;
        f.a = this.a.j();
        f.h = g
    }
    a: {
        if (c) switch (c.toLowerCase().split(",")[1]) {
            case "l":
                f = 0;
                break a;
            case "r":
                f = 1;
                break a
        }
        f = 2
    }
    es(this.h, ys(c), f, void 0, d);
    U(this.a.j(), "jfk-tooltip-hide");
    this.C != e && (this.C && !xc(ke(this.C)) && U(this.a.j(), this.C), xc(ke(e)) || T(this.a.j(), e), this.C = e);
    hq(this.a.j(),
        0, 0);
    if (b instanceof zd) Td(this.a.a, b);
    else
        for (fg(this.a.a); c = b.firstChild;) this.a.a.appendChild(c);
    this.h.c = a;
    this.h.b(null, 0)
};
var ws = function(a) {
    a.a && T(a.a.j(), "jfk-tooltip-hide")
};
var As = function(a, b, c, d) {
    Sr.call(this, a, zs.M(), b);
    this.N = c || 0;
    this.m = d || 0;
    this.ab = !1
};
t(As, Sr);
As.prototype.getStyle = function() {
    return this.N
};
var Cs = function(a, b) {
    a.N != b && (a.N = b, Bs(a))
};
h = As.prototype;
h.xd = function(a) {
    this.h = a;
    var b = this.j();
    b && (this.ab ? os(b, a, void 0) : a ? b.title = a : b.removeAttribute("title"))
};
h.oa = function(a) {
    this.isEnabled() != a && (As.D.oa.call(this, a), Bs(this))
};
h.ce = function(a) {
    As.D.ce.call(this, a);
    Ds(this, !1)
};
h.vb = function(a) {
    As.D.vb.call(this, a);
    this.isEnabled() && Ds(this, !0)
};
h.Eb = function(a) {
    As.D.Eb.call(this, a);
    this.isEnabled() && Ds(this, !0)
};
var Ds = function(a, b) {
        a.j() && V(a.j(), "jfk-button-clear-outline", b)
    },
    Bs = function(a) {
        a.j() && Es(a.c, a)
    },
    zs = function() {
        this.K = this.wa() + "-standard";
        this.c = this.wa() + "-action";
        this.L = this.wa() + "-primary";
        this.m = this.wa() + "-default";
        this.w = this.wa() + "-flat";
        this.C = this.wa() + "-narrow";
        this.G = this.wa() + "-mini";
        this.o = this.wa() + "-contrast"
    };
t(zs, xr);
Fa(zs);
h = zs.prototype;
h.fd = function(a, b, c) {
    a && Cs(c, a);
    b && c.m != b && (c.m = b, Bs(c))
};
h.wa = function() {
    return "jfk-button"
};
h.mb = function(a) {
    gb(a, As, "Button is expected to be instance of jfk.Button");
    var b = a.a,
        c = Xp(Tr, {
            disabled: !a.isEnabled(),
            checked: a.Ea(16),
            style: a.getStyle(),
            title: a.h,
            Co: a.ab,
            value: a.Y(),
            width: a.m
        }, void 0, b);
    b.ni(c, a.Sa());
    this.Va(a, c);
    return c
};
h.Va = function(a, b) {
    zs.D.Va.call(this, a, b);
    this.h || (this.h = Xb(this.K, Sa(this.fd, 0, null), this.c, Sa(this.fd, 2, null), this.L, Sa(this.fd, 3, null), this.m, Sa(this.fd, 1, null), this.w, Sa(this.fd, 4, null), this.G, Sa(this.fd, 5, null), this.o, Sa(this.fd, 6, null), this.C, Sa(this.fd, null, 1)));
    for (var c = Op(b), d = 0; d < c.length; ++d) {
        var e = this.h[c[d]];
        e && e(a)
    }
    if (c = b.getAttribute("data-tooltip")) a.h = c, a.ab = !0;
    return b
};
h.Y = function(a) {
    return a.getAttribute("value") || ""
};
h.xf = function(a, b) {
    a && a.setAttribute("value", b)
};
var Es = function(a, b) {
    function c(g, k) {
        (g ? d : e).push(k)
    }
    v(b.j(), "Button element must already exist when updating style.");
    var d = [],
        e = [],
        f = b.getStyle();
    c(0 == f, a.K);
    c(2 == f, a.c);
    c(3 == f, a.L);
    c(4 == f, a.w);
    c(5 == f, a.G);
    c(1 == f, a.m);
    c(6 == f, a.o);
    c(1 == b.m, a.C);
    c(!b.isEnabled(), a.wa() + "-disabled");
    Sp(b.j(), e);
    Rp(b.j(), d)
};
var Fs = function(a, b) {
    X.call(this);
    this.W = b;
    this.Ra = a;
    this.cf = this.text = this.Ma = this.Ba = "";
    this.data = null;
    this.ob = Gm.M()
};
t(Fs, X);
h = Fs.prototype;
h.update = function(a, b, c, d) {
    this.text = a;
    this.Ba = b;
    this.Ma = c;
    this.data = d;
    this.setVisible(!1);
    return !1
};
h.setVisible = function(a) {
    var b = this.j();
    b && W(b, a)
};
h.isVisible = function() {
    var a = this.j();
    return a ? yq(a) : !1
};
h.wj = function() {
    return {}
};
h.Kb = function() {
    return this.W
};
h.log = function(a, b) {
    var c = {};
    c.dt = this.W;
    c.sl = this.Ba;
    c.tl = this.Ma;
    c.hl = this.Ra;
    c.q = this.text;
    c.e = a;
    null != b && Wb(c, b);
    Wb(c, this.wj());
    this.ob.log("lexicon", c);
    b = this.Ba;
    c = this.Ma;
    window.__gaTracker && (__gaTracker("set", "dimension1", this.Ra), __gaTracker("set", "dimension2", b + "|" + c), __gaTracker("set", "dimension3", b), __gaTracker("set", "dimension4", c));
    Ch("lexicon", this.W + ":" + a, "", 1)
};
var Gs = function(a, b, c, d, e) {
    Fs.call(this, a, b);
    this.Oc = this.b = null;
    this.V = c;
    this.uj = d;
    this.X = e;
    this.N = this.h = null;
    this.m = !1;
    this.ia = "More";
    this.sc = !1;
    this.Ca = "Less";
    this.xb = [];
    new qp("mt");
    this.Uh = !1;
    this.F = K.M();
    this.c = []
};
t(Gs, Fs);
h = Gs.prototype;
h.Ja = function() {
    Gs.D.Ja.call(this);
    this.Da($f("DIV"))
};
h.Da = function(a) {
    Gs.D.Da.call(this, a);
    T(this.j(), "gt-cd");
    T(this.j(), "gt-cd-" + this.W);
    xg(this.j(), !0);
    this.j().appendChild(Wp(go));
    this.Oc = B("gt-cd-tl", this.j());
    this.b = B("gt-cd-c", this.j());
    this.h = B("cd-expand-button", this.j());
    this.N = B("cd-expand-label", this.j());
    W(this.h, !1)
};
h.T = function() {
    this.Ed();
    Gs.D.T.call(this)
};
h.Nd = function() {
    return this.X
};
h.ze = function() {
    return this.c.length
};
h.Gg = function(a) {
    return this.c.indexOf(a)
};
h.Ed = function() {
    this.c = []
};
h.fb = function() {
    return this.ze()
};
h.update = function(a, b, c, d) {
    Gs.D.update.call(this, a, b, c, d);
    this.m = this.sc = !1;
    jg(null);
    W(this.h, !1);
    U(this.h, "collapse");
    Hs(this, a);
    return !1
};
h.aa = function() {
    var a = this;
    Gs.D.aa.call(this);
    this.h && Bh(this.h, this.$n.bind(this));
    Y(this).listen(this, "a", p(this.Si, this, "clks"), !1);
    Y(this).listen(this, "b", p(this.Si, this, "clkt"), !1);
    this.j() && (Y(this).listen(this.j(), "focusout", function(b) {
        pg(a.j(), b.relatedTarget) || U(a.j(), "clear-outline")
    }), Y(this).listen(this.j(), "mousedown", function() {
        T(a.j(), "clear-outline")
    }), Y(this).listen(this.j(), "mouseup", function() {
        T(a.j(), "clear-outline")
    }))
};
h.$n = function() {
    this.m = !this.m;
    this.fe(this.m);
    if (this.m) T(this.h, "collapse"), E(this.N, this.Ca), this.log("expand"), hm(this.F, this.X, this.fb());
    else {
        U(this.h, "collapse");
        E(this.N, this.ia);
        this.log("collapse");
        var a = this.F,
            b = this.fb();
        M(a, em(a, 189, this.X, b, !0, 0))
    }
};
h.Si = function(a, b) {
    b = b.target;
    var c = this.F;
    M(c, em(c, 79, this.X, this.ze(), this.sc, this.Gg(b) + 1));
    b = Cg(b);
    this.log(a, {
        clk: b
    })
};
var Hs = function(a, b) {
        var c = D("DIV"),
            d = a.V.indexOf("%1$s");
        if (-1 != d) {
            var e = a.V.slice(0, d);
            d = a.V.slice(d + 4, a.V.length);
            e && eg(c, e);
            e = D("SPAN", {
                "class": "gt-card-ttl-txt"
            });
            cq(e, "direction", jc(a.Ba) ? "rtl" : "ltr");
            E(e, b);
            c.appendChild(e);
            d && eg(c, d);
            a.Oc && (fg(a.Oc), a.Oc.appendChild(c))
        } else a.Oc && E(a.Oc, a.uj)
    },
    Is = function(a, b, c) {
        a.sc = !0;
        W(a.h, !0);
        null != b && (a.ia = b);
        null != c && (a.Ca = c);
        E(a.N, a.ia)
    };
Gs.prototype.fe = function(a) {
    for (var b, c, d = Nf("gt-card-expand-wrapper", this.j()), e = 0; e < d.length; e++) {
        b = d[e];
        cq(b, "max-height", eq(b, "height"));
        c = b.firstChild;
        var f = Hq(c, "margin");
        c = vq(c).height + f.top + f.bottom;
        cq(b, "max-height", a ? c + "px" : 0);
        a ? (U(b, "gt-card-collapsed"), T(b, "gt-card-expanded"), Ip(b, "hidden", !1), hh(b, Rg, function(g) {
            cq(g.target, "max-height", "unset")
        }, !1)) : (U(b, "gt-card-expanded"), T(b, "gt-card-collapsed"), Ip(b, "hidden", !0))
    }
};
var Js = function(a, b) {
        if (b) return a;
        a = D("DIV", {
            "class": "gt-card-expand-wrapper gt-card-collapsed"
        }, a);
        Ip(a, "hidden", !0);
        return a
    },
    Ks = function(a, b, c) {
        a.xb.push([b, c])
    };
var Ms = function(a, b) {
        var c = Array.prototype.slice.call(arguments),
            d = c.shift();
        if ("undefined" == typeof d) throw Error("[goog.string.format] Template required");
        return d.replace(/%([0\- \+]*)(\d+)?(\.(\d+))?([%sfdiu])/g, function(e, f, g, k, l, m, q, r) {
            if ("%" == m) return "%";
            var u = c.shift();
            if ("undefined" == typeof u) throw Error("[goog.string.format] Not enough arguments");
            arguments[0] = u;
            return Ls[m].apply(null, arguments)
        })
    },
    Ls = {
        s: function(a, b, c) {
            return isNaN(c) || "" == c || a.length >= Number(c) ? a : a = -1 < b.indexOf("-", 0) ?
                a + je(" ", Number(c) - a.length) : je(" ", Number(c) - a.length) + a
        },
        f: function(a, b, c, d, e) {
            d = a.toString();
            isNaN(e) || "" == e || (d = parseFloat(a).toFixed(e));
            var f = 0 > Number(a) ? "-" : 0 <= b.indexOf("+") ? "+" : 0 <= b.indexOf(" ") ? " " : "";
            0 <= Number(a) && (d = f + d);
            if (isNaN(c) || d.length >= Number(c)) return d;
            d = isNaN(e) ? Math.abs(Number(a)).toString() : Math.abs(Number(a)).toFixed(e);
            a = Number(c) - d.length - f.length;
            return d = 0 <= b.indexOf("-", 0) ? f + d + je(" ", a) : f + je(0 <= b.indexOf("0", 0) ? "0" : " ", a) + d
        },
        d: function(a, b, c, d, e, f, g, k) {
            return Ls.f(parseInt(a,
                10), b, c, d, 0, f, g, k)
        }
    };
Ls.i = Ls.d;
Ls.u = Ls.d;
var Ns = function(a, b, c, d, e, f, g) {
    Gs.call(this, a, null != c && c ? "mbd" : "bd", MSG_TRANSLATIONS_OF, "", 11);
    this.g = c;
    this.R = null != d ? d : !1;
    this.xa = "";
    this.xa = this.g && this.R ? "gt-baf-cell gt-baf-word" : this.g ? "gt-baf-cell gt-baf-word-clickable" : "gt-baf-word-clickable";
    this.C = this.R ? null : "gt-baf-back";
    this.ac = f || "";
    this.bc = g || "";
    this.w = null;
    this.ra = !1;
    this.Z = null != e ? e : !0;
    this.K = {};
    this.K[1] = b[2];
    this.K[2] = b[1];
    this.K[3] = b[0];
    this.Ta = b[3]
};
t(Ns, Gs);
Ns.prototype.update = function(a, b, c, d) {
    Ns.D.update.call(this, a, b, c, d);
    if (!d || 0 == H(d, 1)) return !1;
    fg(this.b);
    this.Ed();
    this.w = new Kh(d);
    Os(this, this.w);
    a = D("TBODY");
    b = D("TABLE", {
        "class": "gt-baf-table"
    }, a);
    c = this.w.a;
    for (var e = 0; e < c.length; e++) {
        var f = c[e],
            g = Ps(this, f, this.g && this.Z && 0 === e);
        dg(a, g);
        f = f.a;
        for (var k = g = 0; k < f.length; k++) {
            var l = f[k];
            if (!this.g && this.w.b && 0 < k) {
                var m = Oh(l);
                var q = D("DIV", {
                    "class": "gt-baf-cell gt-baf-sep"
                });
                m = Js(q, m);
                this.g || (m = D("TD", {
                    colspan: 4
                }, m), m = D("TR", null, m));
                dg(a, m)
            }
            l =
                l.a;
            for (m = 0; m < l.length; m++) {
                q = l[m];
                var r = d.cb(0).Tc();
                q = Qs(this, q, r, g);
                a.appendChild(q);
                g++
            }
        }
        this.b.appendChild(b);
        0 < Lh(this.w) && (f = this.Ta.replace("%1$s", Lh(this.w).toLocaleString(this.Ra)), Is(this, f, MSG_FEWER_TRANSLATIONS_LABEL))
    }
    this.setVisible(!0);
    return !0
};
Ns.prototype.aa = function() {
    Ns.D.aa.call(this);
    T(this.j(), "gt-cd-baf");
    Y(this).listen(this.j(), "click", this.Ob);
    Y(this).listen(this.j(), "mouseover", this.gb);
    Y(this).listen(this.j(), "mouseout", this.ab)
};
var Os = function(a, b) {
        var c = Mh(b);
        c = c.sort(function(g, k) {
            return k.Pb - g.Pb
        });
        var d = 0;
        a.ra = !1;
        for (var e = 0; e < c.length; e++) {
            var f = c[e]; - 1 < f.Pb && (a.ra = !0);
            f.b = .05 <= f.Pb ? 3 : .0025 <= f.Pb ? 2 : 1;
            f.a = 12 > e || 3 == f.b;
            d += f.a ? 0 : 1
        }
        if (4 >= d)
            for (e = 0; e < c.length; e++) c[e].a = !0;
        b.b && Nh(b)
    },
    Us = function(a, b) {
        for (var c = [], d = 0; d < b.length; d++) {
            var e = D("SPAN", null, b[d]);
            null != a.C && (T(e, a.C), a.c.push(e));
            c.push(e);
            d < b.length - 1 && c.push(ag(", "))
        }
        return c
    },
    Ps = function(a, b, c) {
        var d = b.c;
        d && (a.cf = d, Hs(a, d));
        b = Xp(jo, {
            Dk: c,
            Vk: a.ac,
            Wk: a.bc,
            fn: b.g,
            Hd: Ph(b)
        });
        if (c) {
            c = C("tlid-frequency-help-icon", b);
            var e = C("tlid-frequency-help-icon-container", b),
                f = C("tlid-frequency-help-tooltip", b);
            Y(a).listen(c, "click", function() {
                V(e, "show-tooltip", !Qp(e, "show-tooltip"))
            });
            Y(a).listen(document, "click", function(g) {
                var k = eb(g.target);
                Qp(e, "show-tooltip") && (g = k.classList.contains("tlid-frequency-help-icon"), k = pg(f, k), g || k || U(e, "show-tooltip"))
            })
        }
        a = D("TD", {
            colspan: 4
        }, b);
        return D("TR", null, a)
    },
    Vs = function(a, b) {
        return jc(b) !== jc(a.Ra) ? jc(b) ? "rtl" : "ltr" : ""
    },
    Qs = function(a, b, c, d) {
        if (a.g) {
            var e = b.text,
                f = null != b.Qe ? b.Qe : "",
                g = e === c;
            c = b.a;
            d = a.R ? "gt-baf-entry-clickable" : "gt-baf-entry";
            g && (d += " gt-baf-entry-selected");
            d = D("TR", {
                "class": d
            });
            var k = D("TD");
            e = Xp(ko, {
                ah: g,
                Qe: f,
                Un: Vs(a, a.Ma),
                Hd: c,
                Ho: e,
                Io: a.xa
            });
            dg(k, e);
            e = D("TD");
            f = Xp(lo, {
                ef: null != a.C ? a.C : "",
                Ak: Vs(a, a.Ba),
                cg: b.cg,
                Hd: c
            });
            dg(e, f);
            dg(d, k);
            dg(d, e);
            k = b.b;
            b = a.K[b.b];
            a.g && a.Z && k && b && (b = Xp(no, {
                Pb: k,
                zc: b,
                Hd: c
            }), c = D("TD"), dg(c, b), dg(d, c));
            a.C && (b = Nf(a.C, d), w(b, function(l) {
                this.c.push(l)
            }, a));
            b = a.R ? C("gt-baf-word",
                d) : C("gt-baf-word-clickable", d);
            a.c.push(b);
            return d
        }
        f = b.text;
        g = b.Qe;
        e = b.a;
        c = Ws(a, b.b, e);
        k = null;
        g && (k = Xs(g, e));
        f = Ys(a, f, g, e);
        b = Us(a, b.cg);
        b = Zs(a, b, e);
        b = D("TR", null, c, k, f, b);
        jc(a.Ba) != jc(a.Ra) && 1 == d % 2 && T(b, "gt-baf-translations-alt");
        return b
    },
    Ws = function(a, b, c) {
        if (!a.ra || !a.Z) return a = D("DIV", {
            "class": "gt-baf-cell"
        }), c = Js(a, c), D("TD", null, c);
        a = D("DIV", {
            "class": "gt-baf-cell gt-baf-marker-container",
            title: a.K[b]
        });
        b = Ms("width: %dpx", 8 * b);
        b = D("DIV", {
            "class": "gt-baf-cts",
            style: b
        });
        dg(a, b);
        c = Js(a, c);
        return D("TD",
            null, c)
    },
    Xs = function(a, b) {
        var c = D("DIV", {
            "class": "gt-baf-cell gt-baf-previous-word"
        });
        E(c, a);
        a = Js(c, b);
        return D("TD", null, a)
    },
    Ys = function(a, b, c, d) {
        var e = "";
        jc(a.Ma) !== jc(a.Ra) && (e = Ms("direction: %s", jc(a.Ma) ? "rtl" : "ltr"));
        b = D("SPAN", a.xa, b);
        a.c.push(b);
        a = D("DIV", "gt-baf-cell", b);
        a = Js(a, d);
        d || T(a, "gt-card-widen-wrapper");
        return D("TD", c ? null : {
            colspan: 2,
            style: e
        }, a)
    },
    Zs = function(a, b, c) {
        a = jc(a.Ba) !== jc(a.Ra) ? Ms("direction: %s", jc(a.Ba) ? "rtl" : "ltr") : "";
        b = D("DIV", {
            "class": "gt-baf-cell gt-baf-translations",
            style: a
        }, b);
        c = Js(b, c);
        return D("TD", {
            style: "width: 100%"
        }, c)
    };
Ns.prototype.fe = function(a) {
    Ns.D.fe.call(this, a);
    for (var b = Nf("gt-card-widen-wrapper", this.j()), c = 0; c < b.length; c++) {
        var d = b[c],
            e = B("gt-baf-cell", d),
            f = Hq(e, "margin");
        e = e.scrollWidth + f.left + f.right + 1;
        cq(d, "max-width", a ? e + "px" : 0)
    }
};
Ns.prototype.Ob = function(a) {
    var b = Fg(a.target);
    null != b ? (a = B("gt-baf-word", b), null != a && this.dispatchEvent(new F("b", a))) : Qp(a.target, "gt-baf-word-clickable") ? this.dispatchEvent(new F("b", a.target)) : Qp(a.target, "gt-baf-back") && this.dispatchEvent(new F("a", a.target))
};
Ns.prototype.gb = function(a) {
    if (Qp(a.target, "gt-baf-back")) {
        var b = Mf(document, null, "gt-baf-back", this.j());
        a = Cg(a.target);
        for (var c = 0; c < b.length; c++) Cg(b[c]) == a && T(b[c], "gt-baf-hl")
    }
};
Ns.prototype.ab = function() {
    for (var a = Mf(document, null, "gt-baf-hl", this.j()), b = 0; b < a.length; b++) U(a[b], "gt-baf-hl")
};
var at = function(a) {
        this.a = null != a ? new Zm($s(a)) : new Zm;
        this.b = "home";
        on(this.a, "view") && (this.b = this.a.get("view"), nn(this.a, "view"))
    },
    bt = function(a, b) {
        a.b = b;
        return a
    },
    dt = function(a, b, c, d) {
        ct(a);
        a.a.set("op", "translate").set("sl", b).set("tl", c);
        null == d || xc(d) || a.a.set("text", d)
    },
    et = function(a, b, c, d) {
        ct(a);
        a.a.set("op", "star").set("sl", b).set("tl", c).set("text", d)
    },
    ct = function(a) {
        nn(a.a, "op");
        nn(a.a, "sl");
        nn(a.a, "tl");
        nn(a.a, "text")
    };
at.prototype.Pa = function() {
    return ft(this, "sl")
};
at.prototype.ma = function() {
    return ft(this, "tl")
};
var ft = function(a, b) {
        var c = "";
        on(a.a, b) && (c = a.a.get(b), c = ce(c));
        return c
    },
    gt = function(a, b) {
        return on(a.a, "op") && a.a.get("op") === b
    };
at.prototype.toString = function() {
    var a = "view=" + this.b,
        b = this.a;
    ln(b);
    0 == b.b || (a += "&" + this.a.toString());
    return a
};

function $s(a) {
    if (a.startsWith("view=")) return a;
    var b = new at;
    if (a.startsWith("op=")) switch (a = new Zm(a), a.get("op")) {
        case "showhistory":
            return bt(b, "history").toString();
        case "showsaved":
            return bt(b, "saved").toString();
        case "star":
            if (on(a, "sl") && on(a, "tl") && on(a, "text") && on(a, "page")) {
                switch (a.get("page")) {
                    case "history":
                        bt(b, "history");
                        break;
                    default:
                        bt(b, "home")
                }
                et(b, a.get("sl"), a.get("tl"), a.get("text"))
            }
            return b.toString();
        default:
            return bt(b, "home").toString()
    } else {
        a = a.split(/[|\/]/);
        bt(b, "home");
        var c = "",
            d = "",
            e = "";
        0 < a.length && 0 < a[0].length && (c = a[0]);
        1 < a.length && 0 < a[1].length && (d = a[1]);
        2 < a.length && 0 < a[2].length && (e = a[2]);
        0 < c.length && 0 < d.length && (0 < e.length ? dt(b, c, d, e) : dt(b, c, d), 3 < a.length && "share" === a[3] && b.a.set("op", "share"));
        return b.toString()
    }
};
var ht = function(a, b) {
    F.call(this, "navigate");
    this.Ah = a;
    this.om = b
};
t(ht, F);
var jt = function() {
        return !it() && (x("iPod") || x("iPhone") || x("Android") || x("IEMobile"))
    },
    it = function() {
        return x("iPad") || x("Android") && !x("Mobile") || x("Silk")
    },
    kt = function() {
        return !jt() && !it()
    };
var lt = function(a, b) {
    a = [a];
    for (var c = b.length - 1; 0 <= c; --c) a.push(typeof b[c], b[c]);
    return a.join("\x0B")
};
var qt = function(a, b, c, d) {
    J.call(this);
    if (a && !b) throw Error("Can't use invisible history without providing a blank page.");
    if (c) var e = c;
    else {
        e = "history_state" + mt;
        var f = Id("input", {
            type: "text",
            name: e,
            id: e,
            style: dc("display:none")
        });
        document.write(Ad(f));
        e = Kf(e)
    }
    this.w = e;
    this.a = c ? Vf(If(c)) : window;
    this.G = b;
    y && !b && (this.G = "https" == window.location.protocol ? tc(cc(dc("https:///"))) : tc(cc(dc('javascript:""'))));
    this.b = new Ai(150);
    Lg(this, this.b);
    this.g = !a;
    this.c = new Lq(this);
    if (a || nt) {
        if (d) var g = d;
        else {
            a =
                "history_iframe" + mt;
            d = this.G;
            b = {
                id: a,
                style: dc("display:none"),
                sandbox: void 0
            };
            d && rc(d);
            c = {};
            c.src = d || null;
            c.srcdoc = null;
            d = {
                sandbox: ""
            };
            e = {};
            for (g in c) v(g.toLowerCase() == g, "Must be lower case"), e[g] = c[g];
            for (g in d) v(g.toLowerCase() == g, "Must be lower case"), e[g] = d[g];
            if (b)
                for (g in b) {
                    f = g.toLowerCase();
                    if (f in c) throw Error('Cannot override "' + f + '" attribute, got "' + g + '" with value "' + b[g] + '"');
                    f in d && delete e[f];
                    e[g] = b[g]
                }
            g = Hd("iframe", e, void 0);
            document.write(Ad(g));
            g = Kf(a)
        }
        this.C = g;
        this.N = !0
    }
    nt &&
        (this.c.listen(this.a, "load", this.Vm), this.O = this.L = !1);
    this.g ? ot(this, this.getToken(), !0) : pt(this, this.w.value);
    mt++
};
t(qt, J);
qt.prototype.m = !1;
qt.prototype.o = !1;
qt.prototype.h = null;
var rt = function(a, b) {
        var c = b || lt;
        return function() {
            var d = this || n;
            d = d.closure_memoize_cache_ || (d.closure_memoize_cache_ = {});
            var e = c(Pa(a), arguments);
            return d.hasOwnProperty(e) ? d[e] : d[e] = a.apply(this, arguments)
        }
    }(function() {
        return y ? Se(8) : "onhashchange" in n
    }),
    nt = y && !Se(8);
h = qt.prototype;
h.Zd = null;
h.T = function() {
    qt.D.T.call(this);
    this.c.Ia();
    this.oa(!1)
};
h.oa = function(a) {
    if (a != this.m)
        if (nt && !this.L) this.O = a;
        else if (a)
        if (ve ? this.c.listen(this.a.document, st, this.R) : ye && this.c.listen(this.a, "pageshow", this.$m), rt() && this.g) this.c.listen(this.a, "hashchange", this.Xm), this.m = !0, this.dispatchEvent(new ht(this.getToken(), !1));
        else {
            if (!y || jt() || this.L) this.c.listen(this.b, "tick", p(this.K, this, !0)), this.m = !0, nt || (this.h = this.getToken(), this.dispatchEvent(new ht(this.getToken(), !1))), this.b.start()
        }
    else this.m = !1, Qq(this.c), this.b.stop()
};
h.Vm = function() {
    this.L = !0;
    this.w.value && pt(this, this.w.value, !0);
    this.oa(this.O)
};
h.$m = function(a) {
    a.b.persisted && (this.oa(!1), this.oa(!0))
};
h.Xm = function() {
    var a = tt(this.a);
    a != this.h && ut(this, a, !0)
};
h.getToken = function() {
    return null != this.Zd ? this.Zd : this.g ? tt(this.a) : vt(this) || ""
};
var tt = function(a) {
        a = a.location.href;
        var b = a.indexOf("#");
        return 0 > b ? "" : a.substring(b + 1)
    },
    wt = function(a, b, c) {
        a.getToken() != b && (a.g ? (ot(a, b, c), rt() || y && !jt() && pt(a, b, c, void 0), a.m && a.K(!1)) : (pt(a, b, c), a.Zd = a.h = a.w.value = b, a.dispatchEvent(new ht(b, !1))))
    },
    ot = function(a, b, c) {
        a = a.a.location;
        var d = a.href.split("#")[0],
            e = Jc(a.href, "#");
        if (nt || e || b) d += "#" + b;
        d != a.href && (b = d, d = dc("URL taken from location.href."), $a(cc(d), "must provide justification"), v(!xc(cc(d)), "must provide non-empty justification"), b =
            new Oc(Mc, b), c ? Yd(a, b) : Xd(a, b))
    },
    pt = function(a, b, c, d) {
        if (a.N || b != vt(a))
            if (a.N = !1, b = be(b), y) {
                var e = ug(a.C);
                e.open("text/html", c ? "replace" : void 0);
                c = Ld(Id("title", {}, d || a.a.document.title), Id("body", {}, b));
                e.write(Ad(c));
                e.close()
            } else gb(a.G, pc, "this.iframeSrc_ must be set on calls to setIframeToken_"), e = rc(a.G) + "#" + b, (a = a.C.contentWindow) && (c ? Yd(a.location, e) : Xd(a.location, e))
    },
    vt = function(a) {
        if (y) return a = ug(a.C), a.body ? ce(a.body.innerHTML) : null;
        var b = a.C.contentWindow;
        if (b) {
            try {
                var c = ce(tt(b))
            } catch (d) {
                return a.o ||
                    (1 != a.o && Bi(a.b, 1E4), a.o = !0), null
            }
            a.o && (0 != a.o && Bi(a.b, 150), a.o = !1);
            return c || null
        }
        return null
    };
qt.prototype.K = function(a) {
    if (this.g) {
        var b = tt(this.a);
        b != this.h && ut(this, b, a)
    }
    if (!this.g || nt)
        if (b = vt(this) || "", null == this.Zd || b == this.Zd) this.Zd = null, b != this.h && ut(this, b, a)
};
var ut = function(a, b, c) {
    a.h = a.w.value = b;
    a.g ? (nt && pt(a, b), ot(a, b)) : pt(a, b);
    a.dispatchEvent(new ht(a.getToken(), c))
};
qt.prototype.R = function() {
    this.b.stop();
    this.b.start()
};
var st = ["mousedown", "keydown", "mousemove"],
    mt = 0;
var xt = function(a, b, c) {
    var d = this;
    J.call(this);
    this.b = new qt(!1, void 0, b, c);
    this.c = null;
    this.h = 0;
    this.g = a || !1;
    G(this.b, "navigate", function(e) {
        e.om && d.dispatchEvent({
            type: "c",
            Ah: e.Ah
        })
    }, !1)
};
t(xt, J);
var zt = function(a, b, c, d) {
        var e = "",
            f = "",
            g = "";
        if (a.g) b = new at(b), e = b.Pa(), f = b.ma(), g = ft(b, "text");
        else {
            var k = [];
            w(b.split(/[|\/]/), function(l) {
                k.push(ce(l))
            });
            e = ke(k[0]);
            f = ke(k[1]);
            2 < k.length && (g = k[2])
        }!xc(e) && !xc(f) && 0 <= c.indexOf(e) && ("auto" === f || 0 <= d.indexOf(f)) ? yt(a.c, e, f, g, "bh") : yt(a.c, "", "", "", "bh")
    },
    At = function(a, b, c, d) {
        var e = new at(b);
        b = e.Pa();
        e = e.ma();
        !xc(b) && !xc(e) && 0 <= c.indexOf(b) && ("auto" === e || 0 <= d.indexOf(e)) ? yt(a.c, b, e, "", "bh") : yt(a.c, "", "", "", "bh")
    },
    Ct = function(a, b, c, d, e) {
        b = null != b ? b :
            "auto";
        c = null != c ? c : "en";
        a.g ? (a = Bt(a), dt(a, b, c, d), null != e && "share" === e && a.a.set("op", "share"), b = a.toString()) : (b = b + "/" + c + "/" + be(d), e && (b += "/" + e));
        return b
    },
    Bt = function(a) {
        if (!a.g) throw Error("Should never be invoked without new URL fragment schema");
        return new at(a.b.getToken())
    },
    Dt = function(a, b, c, d, e, f) {
        a.a(Ct(a, b, c, d, f), !e || null != f)
    };
xt.prototype.a = function(a, b) {
    var c = (new Date).getTime();
    2E3 < c - this.h ? wt(this.b, a, !1) : wt(this.b, a, !0);
    this.h = b ? 0 : c
};
var Et = function() {};
t(Et, xr);
Fa(Et);
h = Et.prototype;
h.mb = function(a) {
    var b = pr(this, a);
    b = a.a.b("DIV", "goog-inline-block " + b.join(" "), this.ff(a.Sa(), a.a));
    yr(b, a.h);
    return b
};
h.$c = function() {
    return "button"
};
h.Db = function(a) {
    return a && a.firstChild && a.firstChild.firstChild
};
h.ff = function(a, b) {
    return b.b("DIV", "goog-inline-block " + (this.wa() + "-outer-box"), b.b("DIV", "goog-inline-block " + (this.wa() + "-inner-box"), a))
};
h.Zc = function(a) {
    return "DIV" == a.tagName
};
h.Va = function(a, b) {
    v(b);
    Ft(b, !0);
    Ft(b, !1);
    a: {
        var c = a.a.ki(b);
        var d = this.wa() + "-outer-box";
        if (c && Qp(c, d) && (c = a.a.ki(c), d = this.wa() + "-inner-box", c && Qp(c, d))) {
            c = !0;
            break a
        }
        c = !1
    }
    c || b.appendChild(this.ff(b.childNodes, a.a));
    Rp(b, ["goog-inline-block", this.wa()]);
    return Et.D.Va.call(this, a, b)
};
h.wa = function() {
    return "goog-custom-button"
};
var Ft = function(a, b) {
    if (a)
        for (var c = b ? a.firstChild : a.lastChild, d; c && c.parentNode == a;) {
            d = b ? c.nextSibling : c.previousSibling;
            if (3 == c.nodeType) {
                var e = c.nodeValue;
                if ("" == yc(e)) a.removeChild(c);
                else {
                    c.nodeValue = b ? e.replace(/^[\s\xa0]+/, "") : e.replace(/[\s\xa0]+$/, "");
                    break
                }
            } else break;
            c = d
        }
};
var Gt = function(a, b, c) {
    Sr.call(this, a, b || Et.M(), c);
    this.Oa(16, !0)
};
t(Gt, Sr);
Cr("goog-toggle-button", function() {
    return new Gt(null)
});
var Ht = function(a, b, c, d) {
    Gt.call(this, a, c || xr.M(), d);
    this.N = a;
    this.m = b || null;
    this.b = null
};
t(Ht, Gt);
Ht.prototype.cd = function(a) {
    Ht.D.cd.call(this, a);
    It(this)
};
Ht.prototype.oa = function(a) {
    Ht.D.oa.call(this, a);
    It(this)
};
var It = function(a) {
        a.isEnabled() ? null != a.m && a.g(a.Ea(16) ? a.m : a.N) : a.b ? (a.g(a.b), a.b = null) : a.g("")
    },
    Kt = function() {
        As.call(this);
        this.b = !1;
        Jt(this)
    };
t(Kt, As);
var Lt = function(a, b) {
        a.b = b;
        Jt(a)
    },
    Jt = function(a) {
        a.b ? (Hr(a, "unstarred"), Gr(a, "starred")) : (Hr(a, "starred"), Gr(a, "unstarred"))
    },
    Mt = function() {};
t(Mt, xr);
Fa(Mt);
Mt.prototype.mb = function(a) {
    var b = a.a.b("DIV", pr(this, a).join(" ")),
        c = a.a.b("SPAN"),
        d = a.a.b("SPAN");
    T(b, "gt-icon-c");
    Pp(d, "gt-icon-text");
    Pp(c, "gt-icon");
    b.appendChild(c);
    a.Sa() && (b.appendChild(d), this.Lb(b, a.Sa()));
    return b
};
Mt.prototype.Lb = function(a, b) {
    a && (a = void 0 !== a.lastElementChild ? a.lastElementChild : lg(a.lastChild, !1)) && E(a, b)
};
Mt.prototype.wa = function() {
    return "trans-tool-button"
};
Mt.prototype.Va = function(a, b) {
    var c = a.Sa();
    b = Mt.D.Va.call(this, a, b);
    a.ad = c;
    c = a.a.b("SPAN");
    var d = a.a.b("SPAN");
    T(b, "gt-icon-c");
    Pp(d, "gt-icon-text");
    Pp(c, "gt-icon");
    fg(b);
    b.appendChild(c);
    a.Sa() && (b.appendChild(d), this.Lb(b, a.Sa()));
    return b
};
var Nt = function(a, b) {
    this.c = a;
    this.h = b || !1
};
t(Nt, xr);
Nt.prototype.mb = function(a) {
    var b = a.a.b("DIV", pr(this, a).join(" ") + " goog-inline-block"),
        c = a.a.b("SPAN");
    this.c && T(b, this.c);
    Pp(c, "jfk-button-img");
    b.appendChild(c);
    a.Sa() && this.Lb(b, a.Sa());
    return b
};
Nt.prototype.Lb = function(a, b) {
    a && !this.h && (os(a, b, void 0), ss(a, 2))
};
Nt.prototype.wa = function() {
    return "goog-toolbar-button"
};
Nt.prototype.Va = function(a, b) {
    var c = a.a.b("SPAN");
    this.c && T(b, this.c);
    Pp(c, "jfk-button-img");
    fg(b);
    b.appendChild(c);
    a.Sa() && this.Lb(b, a.Sa());
    return b = Nt.D.Va.call(this, a, b)
};
var Ot = function(a, b, c, d) {
        this.text = a;
        this.Ba = b;
        this.Ma = c;
        this.data = d
    },
    Pt = function(a, b, c, d) {
        this.g = a;
        this.c = b;
        this.h = c;
        this.o = d;
        this.a = [];
        this.b = -1;
        G(this.g, "action", this.hn, !1, this);
        G(this.c, "action", this.Om, !1, this);
        G(this.h, "action", this.bo, !1, this)
    };
h = Pt.prototype;
h.push = function(a, b, c, d) {
    this.a.splice(++this.b);
    this.a.push(new Ot(a, b, c, d));
    Qt(this)
};
h.reset = function() {
    this.a = [];
    this.b = -1
};
h.hn = function() {
    0 < this.b && (--this.b, Qt(this));
    Gm.M().log("lxprev")
};
h.Om = function() {
    this.b < this.a.length - 1 && (++this.b, Qt(this));
    Gm.M().log("lxnext")
};
h.bo = function() {
    1 < this.a.length && (this.a.splice(1), this.b = 0, Qt(this));
    Gm.M().log("lxclear")
};
var Qt = function(a) {
    var b = a.a[a.b];
    a.o.update(b.text, b.Ba, b.Ma, b.data);
    a.g.oa(1 < a.b);
    a.c.oa(a.b < a.a.length - 1)
};
var Rt = function() {
    this.b = 0;
    this.a = []
};
Fa(Rt);
Rt.prototype.c = function(a) {
    var b = new Image,
        c = this.b++;
    this.a[c] = b;
    b.onload = b.onerror = function() {
        delete Rt.M().a[c]
    };
    b.src = a;
    b = null
};
var St = !1,
    Tt = function(a) {
        if (a = a.match(/[\d]+/g)) a.length = 3
    };
(function() {
    if (navigator.plugins && navigator.plugins.length) {
        var a = navigator.plugins["Shockwave Flash"];
        if (a && (St = !0, a.description)) {
            Tt(a.description);
            return
        }
        if (navigator.plugins["Shockwave Flash 2.0"]) {
            St = !0;
            return
        }
    }
    if (navigator.mimeTypes && navigator.mimeTypes.length && (a = navigator.mimeTypes["application/x-shockwave-flash"], St = !(!a || !a.enabledPlugin))) {
        Tt(a.enabledPlugin.description);
        return
    }
    if ("undefined" != typeof ActiveXObject) {
        try {
            var b = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.7");
            St = !0;
            Tt(b.GetVariable("$version"));
            return
        } catch (c) {}
        try {
            b = new ActiveXObject("ShockwaveFlash.ShockwaveFlash.6");
            St = !0;
            return
        } catch (c) {}
        try {
            b = new ActiveXObject("ShockwaveFlash.ShockwaveFlash"), St = !0, Tt(b.GetVariable("$version"))
        } catch (c) {}
    }
})();
var Ut = St;
var Vt = function() {
    J.call(this);
    this.url = ""
};
t(Vt, J);
Vt.prototype.ge = function() {
    this.dispatchEvent(new Wt(this.url))
};
Vt.prototype.play = function(a) {
    this.url = a
};
Vt.prototype.c = function() {
    this.dispatchEvent(new Xt(this.url))
};
var Yt = function(a) {
    F.call(this, "sound_play_start");
    this.url = a
};
t(Yt, F);
var Zt = function(a) {
    F.call(this, "sound_finished");
    this.url = a
};
t(Zt, F);
var Wt = function(a) {
    F.call(this, "sound_interrupted");
    this.url = a
};
t(Wt, F);
var Xt = function(a) {
    F.call(this, "sound_error");
    this.url = a
};
t(Xt, F);
var $t = function() {
    Vt.call(this);
    this.o = Audio;
    this.a = new this.o;
    this.b = {}
};
t($t, Vt);
$t.prototype.Bh = function() {
    return !this.a.paused
};
$t.prototype.ge = function() {
    $t.D.ge.call(this);
    this.a.pause()
};
$t.prototype.play = function(a) {
    $t.D.play.call(this, a);
    au(this, this.a);
    this.a = null;
    null != this.b[a] ? (this.a = this.b[a], this.b[a] = null, this.a.play()) : (this.a = bu(this, a), this.a.autoplay = !0)
};
$t.prototype.Cj = function(a) {
    n.setTimeout(p(this.m, this, a), 1E3)
};
var bu = function(a, b) {
        var c = new a.o;
        c.setAttribute("src", b);
        G(c, "play", a.h, !1, a);
        G(c, "ended", a.g, !1, a);
        G(c, "error", a.c, !1, a);
        c.load();
        return c
    },
    au = function(a, b) {
        oh(b, "play", a.h);
        oh(b, "ended", a.g)
    };
$t.prototype.m = function(a) {
    null != this.b[a] && (au(this, this.b[a]), this.b[a] = null);
    this.b[a] = bu(this, a)
};
$t.prototype.h = function() {
    oh(this.a, "play", this.h);
    this.dispatchEvent(new Yt(this.url))
};
$t.prototype.g = function() {
    oh(this.a, "ended", this.g);
    this.dispatchEvent(new Zt(this.url))
};
var cu = function(a) {
    Vt.call(this);
    this.a = a;
    this.b = !1
};
t(cu, Vt);
h = cu.prototype;
h.Bh = function() {
    return this.b
};
h.ge = function() {
    this.b = !1;
    null != this.a.o && this.a.o();
    du();
    cu.D.ge.call(this)
};
h.play = function(a) {
    cu.D.play.call(this, a);
    n.setTimeout(p(this.nn, this), 0)
};
h.nn = function() {
    this.b = !0;
    var a = p(this.fo, this);
    n.SoundStopCB_ = a;
    null != this.a.g && this.a.g("SoundStopCB_");
    try {
        if (null != this.a.c) this.a.c(this.xj());
        else {
            this.b = !1;
            du();
            this.c();
            return
        }
        var b = p(this.xj, this);
        n._TTSSoundFile = b
    } catch (c) {
        this.b = !1;
        du();
        this.c();
        return
    }
    null != this.a.h ? this.a.h() : (this.b = !1, du(), this.c())
};
h.Cj = function(a) {
    var b = Rt.M();
    n.setTimeout(p(b.c, b, a), 1E3)
};
h.xj = function() {
    return this.url.substring(1)
};
h.fo = function() {
    this.b = !1;
    du();
    this.dispatchEvent(new Zt(this.url))
};
var du = function() {
        n.SoundStopCB_ = null
    },
    eu = function() {
        this.a = "";
        this.b = null;
        this.c = !1;
        this.F = null
    };
Fa(eu);
eu.prototype.get = function() {
    if (null != this.a && 0 != this.a.length) {
        var a = Kf(this.a);
        if (!this.c && (fu("audio/mpeg") ? (this.b = new $t, a = "html5") : null != a && "OBJECT" == a.tagName && Ut ? (this.b = new cu(a), a = "flash") : (this.b = null, a = "none"), this.c = !0, !this.g && this.F)) {
            this.g = !0;
            var b = fu("audio/mpeg") ? 1 : 0,
                c = fu("audio/ogg") ? 1 : 0,
                d = fu("audio/wav") ? 1 : 0;
            a: {
                try {
                    var e = D("AUDIO");
                    if (null != e && null != e.volume) {
                        var f = e.volume;
                        break a
                    }
                } catch (g) {}
                f = -1
            }
            this.F.log("ttsaudio", {
                mp3: b,
                ogg: c,
                wav: d,
                vol: f,
                type: a
            })
        }
    }
    return this.b
};
var fu = function(a) {
    try {
        var b = D("AUDIO");
        return null != b && null != b.canPlayType && null != b.load && null != b.play && null != b.paused && null != b.pause && "no" != b.canPlayType(a) && "" != b.canPlayType(a)
    } catch (c) {
        return !1
    }
};
var gu = function(a, b, c) {
    J.call(this);
    this.K = b;
    this.m = c ? c : 0;
    this.F = K.M();
    this.C = eu.M();
    this.C.a = a;
    this.C.F = b;
    this.b = this.C.get();
    this.G = this.c = null;
    this.a = this.o = 0;
    this.g = {};
    this.h = 0;
    this.w = !1;
    this.O = null
};
t(gu, J);
gu.prototype.set = function(a, b, c, d, e) {
    this.c = a;
    this.o = b;
    this.G = c;
    null != d && (this.O = d);
    null != e && (this.g = Ub(e));
    this.g.total = a.length;
    this.g.ttslocation = this.m;
    hu(this)
};
gu.prototype.start = function() {
    this.b.Bh() && this.b.ge();
    G(this.b, "sound_play_start", this.V, !1, this);
    G(this.b, "sound_finished", this.R, !1, this);
    G(this.b, "sound_interrupted", this.L, !1, this);
    G(this.b, "sound_error", this.N, !1, this);
    this.h = (new Date).getTime();
    iu(this, "ttsstart", this.g);
    var a = this.F,
        b = this.m,
        c = this.o,
        d = this.c.length,
        e = this.O;
    null != e ? zm(a, 31, b, c, d, void 0, void 0, e) : zm(a, 31, b, c, d);
    this.b.play(this.c[this.a]);
    ju(this)
};
gu.prototype.stop = function() {
    if (this.c && this.b.Bh()) {
        var a = Ub(this.g);
        a.idx = this.a;
        a.time = (new Date).getTime() - this.h;
        iu(this, "ttsstop", a);
        zm(this.F, 32, this.m, this.o, this.c.length, this.G[this.a], this.a);
        hu(this);
        this.b.ge();
        ku(this)
    }
};
var hu = function(a) {
        a.a = 0;
        a.w = !1;
        oh(a.b, "sound_play_start", a.V, !1, a);
        oh(a.b, "sound_finished", a.R, !1, a);
        oh(a.b, "sound_interrupted", a.L, !1, a);
        oh(a.b, "sound_error", a.N, !1, a)
    },
    iu = function(a, b, c) {
        a.K && a.K.log(b, c)
    };
gu.prototype.V = function() {
    if (!this.w) {
        this.dispatchEvent(new lu(this.c));
        var a = Ub(this.g);
        a.idx = this.a;
        a.time = (new Date).getTime() - this.h;
        iu(this, "ttsplaystart", a);
        zm(this.F, 33, this.m, this.o, this.c.length, this.G[this.a], this.a);
        this.w = !0
    }
};
gu.prototype.R = function() {
    this.a += 1;
    if (this.a < this.c.length) this.b.play(this.c[this.a]), ju(this);
    else {
        ku(this);
        hu(this);
        var a = Ub(this.g);
        a.idx = this.a;
        a.time = (new Date).getTime() - this.h;
        iu(this, "ttsfinish", a);
        zm(this.F, 34, this.m, this.o, this.c.length)
    }
};
gu.prototype.L = function() {
    var a = Ub(this.g);
    a.idx = this.a;
    a.time = (new Date).getTime() - this.h;
    iu(this, "ttsinterrupted", a);
    ku(this);
    hu(this)
};
gu.prototype.N = function() {
    var a = Ub(this.g);
    a.idx = this.a;
    a.time = (new Date).getTime() - this.h;
    iu(this, "ttserror", a);
    mm(this.F, 155);
    ku(this);
    hu(this)
};
var ku = function(a) {
        a.dispatchEvent(new mu(a.c))
    },
    ju = function(a) {
        var b = a.c[a.a + 1];
        null != b && a.b.Cj(b)
    },
    lu = function() {
        F.call(this, "play_start_playlist")
    };
t(lu, F);
var mu = function() {
    F.call(this, "stop_playlist")
};
t(mu, F);
var nu = function(a) {
    this.F = a
};
nu.prototype.g = function(a, b, c) {
    ou(a, b, c, p(this.b, this), p(this.c, this))
};
var ou = function(a, b, c, d, e) {
    var f = [];
    d(f, b);
    b = "";
    for (d = 0; d < f.length; d++) {
        var g = yc(b + f[d]);
        g.length <= c ? b += f[d] : (xc(b) || (a.push(yc(b)), b = ""), g = yc(f[d]), g.length <= c ? b = f[d] : e(a, g, c))
    }
    xc(b) || a.push(yc(b))
};
nu.prototype.c = function(a, b, c) {
    for (var d = 0; d < b.length; d += c) a.push(b.substr(d, c))
};
var pu = / /g,
    qu = /([?.,;:!][ ]+)|([\u3001\u3002\uff01\uff08\uff09\uff0c\uff0e\uff1a\uff1b\uff1f][ ]?)/g;
nu.prototype.b = function(a, b) {
    ru(a, b, pu)
};
nu.prototype.a = function(a, b) {
    ru(a, b, qu);
    for (b = 0; b < a.length; b++) {
        var c = {
            length: a[b].length
        };
        this.F && this.F.log("tbphrase", c)
    }
};
var ru = function(a, b, c) {
    for (var d = 0; c.test(b);) {
        var e = c.lastIndex;
        e > d && a.push(b.substr(d, e - d));
        d = e
    }
    b.length > d && a.push(b.substr(d))
};
var su = [0, 200],
    tu = {
        af: 1,
        ar: 1,
        bn: 1,
        bs: 1,
        ca: 1,
        cs: 1,
        cy: 1,
        da: 1,
        de: 1,
        el: 1,
        en: 1,
        eo: 1,
        es: 1,
        et: 1,
        fi: 1,
        fr: 1,
        gu: 1,
        hi: 1,
        hr: 1,
        hu: 1,
        hy: 1,
        id: 1,
        is: 1,
        it: 1,
        ja: 1,
        jw: 1,
        km: 1,
        kn: 1,
        ko: 1,
        la: 1,
        lv: 1,
        mk: 1,
        ml: 1,
        mr: 1,
        my: 1,
        ne: 1,
        nl: 1,
        no: 1,
        pl: 1,
        pt: 1,
        ro: 1,
        ru: 1,
        si: 1,
        sk: 1,
        sq: 1,
        sr: 1,
        su: 1,
        sv: 1,
        sw: 1,
        ta: 1,
        te: 1,
        th: 1,
        tl: 1,
        tr: 1,
        vi: 1,
        uk: 1,
        ur: 1,
        zh: 1,
        "zh-cn": 1,
        "zh-tw": 1
    };
var uu = function(a, b) {
        this.a = b;
        for (var c = [], d = !0, e = a.length - 1; 0 <= e; e--) {
            var f = a[e] | 0;
            d && f == b || (c[e] = f, d = !1)
        }
        this.b = c
    },
    vu = {},
    wu = function(a) {
        return -128 <= a && 128 > a ? ue(vu, a, function(b) {
            return new uu([b | 0], 0 > b ? -1 : 0)
        }) : new uu([a | 0], 0 > a ? -1 : 0)
    },
    zu = function(a) {
        if (isNaN(a) || !isFinite(a)) return xu;
        if (0 > a) return yu(zu(-a));
        for (var b = [], c = 1, d = 0; a >= c; d++) b[d] = a / c | 0, c *= 4294967296;
        return new uu(b, 0)
    },
    Au = function(a, b) {
        if (0 == a.length) throw Error("number format error: empty string");
        b = b || 10;
        if (2 > b || 36 < b) throw Error("radix out of range: " +
            b);
        if ("-" == a.charAt(0)) return yu(Au(a.substring(1), b));
        if (0 <= a.indexOf("-")) throw Error('number format error: interior "-" character');
        for (var c = zu(Math.pow(b, 8)), d = xu, e = 0; e < a.length; e += 8) {
            var f = Math.min(8, a.length - e),
                g = parseInt(a.substring(e, e + f), b);
            8 > f ? (f = zu(Math.pow(b, f)), d = Bu(d, f).add(zu(g))) : (d = Bu(d, c), d = d.add(zu(g)))
        }
        return d
    },
    xu = wu(0),
    Cu = wu(1),
    Du = wu(16777216),
    Eu = function(a) {
        if (-1 == a.a) return -Eu(yu(a));
        for (var b = 0, c = 1, d = 0; d < a.b.length; d++) b += Fu(a, d) * c, c *= 4294967296;
        return b
    };
uu.prototype.toString = function(a) {
    a = a || 10;
    if (2 > a || 36 < a) throw Error("radix out of range: " + a);
    if (Gu(this)) return "0";
    if (-1 == this.a) return "-" + yu(this).toString(a);
    for (var b = zu(Math.pow(a, 6)), c = this, d = "";;) {
        var e = Hu(c, b).a;
        c = Iu(c, Bu(e, b));
        var f = ((0 < c.b.length ? c.b[0] : c.a) >>> 0).toString(a);
        c = e;
        if (Gu(c)) return f + d;
        for (; 6 > f.length;) f = "0" + f;
        d = "" + f + d
    }
};
var Ju = function(a, b) {
        return 0 > b ? 0 : b < a.b.length ? a.b[b] : a.a
    },
    Fu = function(a, b) {
        a = Ju(a, b);
        return 0 <= a ? a : 4294967296 + a
    },
    Gu = function(a) {
        if (0 != a.a) return !1;
        for (var b = 0; b < a.b.length; b++)
            if (0 != a.b[b]) return !1;
        return !0
    },
    Ku = function(a, b) {
        a = Iu(a, b);
        return -1 == a.a ? -1 : Gu(a) ? 0 : 1
    },
    yu = function(a) {
        for (var b = a.b.length, c = [], d = 0; d < b; d++) c[d] = ~a.b[d];
        return (new uu(c, ~a.a)).add(Cu)
    };
uu.prototype.abs = function() {
    return -1 == this.a ? yu(this) : this
};
uu.prototype.add = function(a) {
    for (var b = Math.max(this.b.length, a.b.length), c = [], d = 0, e = 0; e <= b; e++) {
        var f = d + (Ju(this, e) & 65535) + (Ju(a, e) & 65535),
            g = (f >>> 16) + (Ju(this, e) >>> 16) + (Ju(a, e) >>> 16);
        d = g >>> 16;
        f &= 65535;
        g &= 65535;
        c[e] = g << 16 | f
    }
    return new uu(c, c[c.length - 1] & -2147483648 ? -1 : 0)
};
var Iu = function(a, b) {
        return a.add(yu(b))
    },
    Bu = function(a, b) {
        if (Gu(a) || Gu(b)) return xu;
        if (-1 == a.a) return -1 == b.a ? Bu(yu(a), yu(b)) : yu(Bu(yu(a), b));
        if (-1 == b.a) return yu(Bu(a, yu(b)));
        if (0 > Ku(a, Du) && 0 > Ku(b, Du)) return zu(Eu(a) * Eu(b));
        for (var c = a.b.length + b.b.length, d = [], e = 0; e < 2 * c; e++) d[e] = 0;
        for (e = 0; e < a.b.length; e++)
            for (var f = 0; f < b.b.length; f++) {
                var g = Ju(a, e) >>> 16,
                    k = Ju(a, e) & 65535,
                    l = Ju(b, f) >>> 16,
                    m = Ju(b, f) & 65535;
                d[2 * e + 2 * f] += k * m;
                Lu(d, 2 * e + 2 * f);
                d[2 * e + 2 * f + 1] += g * m;
                Lu(d, 2 * e + 2 * f + 1);
                d[2 * e + 2 * f + 1] += k * l;
                Lu(d, 2 * e + 2 * f + 1);
                d[2 * e + 2 * f + 2] += g * l;
                Lu(d, 2 * e + 2 * f + 2)
            }
        for (e = 0; e < c; e++) d[e] = d[2 * e + 1] << 16 | d[2 * e];
        for (e = c; e < 2 * c; e++) d[e] = 0;
        return new uu(d, 0)
    },
    Lu = function(a, b) {
        for (;
            (a[b] & 65535) != a[b];) a[b + 1] += a[b] >>> 16, a[b] &= 65535, b++
    },
    Mu = function(a, b) {
        this.a = a;
        this.b = b
    },
    Hu = function(a, b) {
        if (Gu(b)) throw Error("division by zero");
        if (Gu(a)) return new Mu(xu, xu);
        if (-1 == a.a) return b = Hu(yu(a), b), new Mu(yu(b.a), yu(b.b));
        if (-1 == b.a) return b = Hu(a, yu(b)), new Mu(yu(b.a), b.b);
        if (30 < a.b.length) {
            if (-1 == a.a || -1 == b.a) throw Error("slowDivide_ only works with positive integers.");
            for (var c = Cu, d = b; 0 >= Ku(d, a);) c = Nu(c, 1), d = Nu(d, 1);
            var e = Ou(c, 1),
                f = Ou(d, 1);
            d = Ou(d, 2);
            for (c = Ou(c, 2); !Gu(d);) {
                var g = f.add(d);
                0 >= Ku(g, a) && (e = e.add(c), f = g);
                d = Ou(d, 1);
                c = Ou(c, 1)
            }
            b = Iu(a, Bu(e, b));
            return new Mu(e, b)
        }
        for (e = xu; 0 <= Ku(a, b);) {
            c = Math.max(1, Math.floor(Eu(a) / Eu(b)));
            d = Math.ceil(Math.log(c) / Math.LN2);
            d = 48 >= d ? 1 : Math.pow(2, d - 48);
            f = zu(c);
            for (g = Bu(f, b); - 1 == g.a || 0 < Ku(g, a);) c -= d, f = zu(c), g = Bu(f, b);
            Gu(f) && (f = Cu);
            e = e.add(f);
            a = Iu(a, g)
        }
        return new Mu(e, a)
    };
uu.prototype.and = function(a) {
    for (var b = Math.max(this.b.length, a.b.length), c = [], d = 0; d < b; d++) c[d] = Ju(this, d) & Ju(a, d);
    return new uu(c, this.a & a.a)
};
uu.prototype.or = function(a) {
    for (var b = Math.max(this.b.length, a.b.length), c = [], d = 0; d < b; d++) c[d] = Ju(this, d) | Ju(a, d);
    return new uu(c, this.a | a.a)
};
uu.prototype.xor = function(a) {
    for (var b = Math.max(this.b.length, a.b.length), c = [], d = 0; d < b; d++) c[d] = Ju(this, d) ^ Ju(a, d);
    return new uu(c, this.a ^ a.a)
};
var Nu = function(a, b) {
        var c = b >> 5;
        b %= 32;
        for (var d = a.b.length + c + (0 < b ? 1 : 0), e = [], f = 0; f < d; f++) e[f] = 0 < b ? Ju(a, f - c) << b | Ju(a, f - c - 1) >>> 32 - b : Ju(a, f - c);
        return new uu(e, a.a)
    },
    Ou = function(a, b) {
        var c = b >> 5;
        b %= 32;
        for (var d = a.b.length - c, e = [], f = 0; f < d; f++) e[f] = 0 < b ? Ju(a, f + c) >>> b | Ju(a, f + c + 1) << 32 - b : Ju(a, f + c);
        return new uu(e, a.a)
    };
var Pu = function(a) {
        this.a = a
    },
    Su = function(a) {
        this.b = null;
        var b = xu;
        if (a instanceof uu) {
            if (0 != a.a || 0 > Ku(a, xu) || 0 < Ku(a, Qu)) throw Error("The address does not look like an IPv4.");
            b = Ub(a)
        } else {
            if (!Ru.test(a)) throw Error(a + " does not look like an IPv4 address.");
            var c = a.split(".");
            if (4 != c.length) throw Error(a + " does not look like an IPv4 address.");
            for (var d = 0; d < c.length; d++) {
                var e = me(c[d]);
                if (isNaN(e) || 0 > e || 255 < e || 1 != c[d].length && vc(c[d], "0")) throw Error("In " + a + ", octet " + d + " is not valid");
                e = zu(e);
                b =
                    Nu(b, 8).or(e)
            }
        }
        this.a = b
    };
t(Su, Pu);
var Ru = /^[0-9.]*$/,
    Qu = Iu(Nu(Cu, 32), Cu);
Su.prototype.toString = function() {
    if (this.b) return this.b;
    for (var a = Fu(this.a, 0), b = [], c = 3; 0 <= c; c--) b[c] = String(a & 255), a >>>= 8;
    return this.b = b.join(".")
};
var Wu = function(a) {
    this.b = null;
    var b = xu;
    if (a instanceof uu) {
        if (0 != a.a || 0 > Ku(a, xu) || 0 < Ku(a, Tu)) throw Error("The address does not look like a valid IPv6.");
        b = Ub(a)
    } else {
        if (!Uu.test(a)) throw Error(a + " is not a valid IPv6 address.");
        var c = a.split(":");
        if (-1 != c[c.length - 1].indexOf(".")) {
            a = Fu(Ub((new Su(c[c.length - 1])).a), 0);
            var d = [];
            d.push((a >>> 16 & 65535).toString(16));
            d.push((a & 65535).toString(16));
            tb(c, c.length - 1);
            yb(c, d);
            a = c.join(":")
        }
        d = a.split("::");
        if (2 < d.length || 1 == d.length && 8 != c.length) throw Error(a +
            " is not a valid IPv6 address.");
        if (1 < d.length) {
            c = d[0].split(":");
            d = d[1].split(":");
            1 == c.length && "" == c[0] && (c = []);
            1 == d.length && "" == d[0] && (d = []);
            var e = 8 - (c.length + d.length);
            if (1 > e) c = [];
            else {
                for (var f = [], g = 0; g < e; g++) f[g] = "0";
                c = wb(c, f, d)
            }
        }
        if (8 != c.length) throw Error(a + " is not a valid IPv6 address");
        for (d = 0; d < c.length; d++) {
            e = Au(c[d], 16);
            if (0 > Ku(e, xu) || 0 < Ku(e, Vu)) throw Error(c[d] + " in " + a + " is not a valid hextet.");
            b = Nu(b, 16).or(e)
        }
    }
    this.a = b
};
t(Wu, Pu);
var Uu = /^([a-fA-F0-9]*:){2}[a-fA-F0-9:.]*$/,
    Vu = wu(65535),
    Tu = Iu(Nu(Cu, 128), Cu);
Wu.prototype.toString = function() {
    if (this.b) return this.b;
    for (var a = [], b = 3; 0 <= b; b--) {
        var c = Fu(this.a, b),
            d = c & 65535;
        a.push((c >>> 16).toString(16));
        a.push(d.toString(16))
    }
    c = b = -1;
    for (var e = d = 0, f = 0; f < a.length; f++) "0" == a[f] ? (e++, -1 == c && (c = f), e > d && (d = e, b = c)) : (c = -1, e = 0);
    0 < d && (b + d == a.length && a.push(""), a.splice(b, d, ""), 0 == b && (a = [""].concat(a)));
    return this.b = a.join(":")
};
var Xu = function() {},
    Yu, Zu = {
        http: 1,
        https: 1,
        ftp: 1
    },
    $u = function(a, b) {
        try {
            var c = jn(a)
        } catch (l) {
            return !1
        }
        if (!(a = c.c && !Zu[c.c.toLowerCase()] || !c.b)) {
            c = c.b;
            a: {
                a = c.split(".");
                for (var d = 0; d < a.length; d++)
                    if (!a[d]) {
                        var e = !1;
                        break a
                    } if (1 < a.length) {
                    b = a[a.length - 1].toLowerCase();
                    if (!Yu) {
                        try {
                            e = xf
                        } catch (l) {
                            throw Error("Variable CFG_twsfe_likelyurl_module_file has not been loaded. This is probaly due the configuration data not being properly included.");
                        }
                        a = {};
                        var f = e.ascii_tlds;
                        for (d = 0; d < f.length; d++) {
                            var g = f[d];
                            a[g.toLowerCase()] = 1
                        }
                        e = e.unicode_tlds;
                        for (d = 0; d < e.length; d++) g = e[d], a[g.toLowerCase()] = 1;
                        Yu = a
                    }
                    e = !!Yu[b]
                } else e = !b
            }
            if (!e) {
                try {
                    var k = vc(c, "[") && wc(c, "]") ? new Wu(c.substring(1, c.length - 1)) : new Su(c)
                } catch (l) {
                    k = null
                }
                e = null != k
            }
            a = !e
        }
        return a ? !1 : !0
    },
    av = function(a) {
        a = yc(a);
        if (0 <= a.search(/[\s\xa0@]/)) return !1;
        if ($u(a, !1)) return !0;
        var b = a.replace(/%([0-9A-Fa-f][0-9A-Fa-f])/g, function(c, d) {
            return String.fromCharCode(Number("0x" + d))
        });
        return $u(b, !1) ? !0 : $u("http://" + a, !0) || $u("http://" + b, !0)
    };
Xu.prototype.a = function(a, b) {
    if ("string" != typeof a) throw Error("Pattern is not a string.");
    var c = arguments;
    return a.replace(/%(\d+)\$\w/g, function(d, e) {
        e = parseInt(e, 10);
        return 0 < e && e < c.length ? c[e] : d
    })
};
var bv = function() {
        var a = (new Rm(n.location.href)).a,
            b = a.get("e");
        a = a.get("expid");
        var c = "";
        b && (c += "e=" + b);
        "ForceExperiment" == b && a && (c += "&expid=" + a);
        return c
    },
    cv = function(a) {
        for (var b = "", c = 0; c < H(a, 5); c++) {
            var d = pp(a, c);
            Eh(d, 4) && 0 < I(d, 4).length ? b = I(d, 4) : (new Do(d.zb())).Wa[4] = b
        }
    },
    dv = function(a) {
        var b = DATA.DisplayLanguage,
            c = DATA.LoginUrl,
            d = jn(n.location.href),
            e = d.toString();
        a && (d.h = a, 2E3 >= be(d.toString()).length && (e = d.toString()));
        d = c + "/Login?hl=" + b + "&continue=" + be(e);
        a = {
            target: "_top"
        };
        b = window;
        c = d instanceof
        Oc ? d : Tc("undefined" != typeof d.href ? d.href : String(d));
        d = a.target || d.target;
        e = [];
        for (var f in a) switch (f) {
            case "width":
            case "height":
            case "top":
            case "left":
                e.push(f + "=" + a[f]);
                break;
            case "target":
            case "noopener":
            case "noreferrer":
                break;
            default:
                e.push(f + "=" + (a[f] ? 1 : 0))
        }
        f = e.join(",");
        if (qe() && b.navigator && b.navigator.standalone && d && "_self" != d) f = $f("A"), Ud(f, c), f.setAttribute("target", d), a.noreferrer && f.setAttribute("rel", "noreferrer"), a = document.createEvent("MouseEvent"), a.initMouseEvent("click", !0, !0,
            b, 1), f.dispatchEvent(a);
        else if (a.noreferrer) {
            if (f = b.open("", d, f), a = Pc(c), f && (xe && Jc(a, ";") && (a = "'" + a.replace(/'/g, "%27") + "'"), f.opener = null, a = Od(dc("b/12014412, meta tag with sanitized URL"), '<meta name="referrer" content="no-referrer"><meta http-equiv="refresh" content="0; url=' + de(a) + '">'), f = f.document)) f.write(Ad(a)), f.close()
        } else(f = b.open(Pc(c), d, f)) && a.noopener && (f.opener = null)
    },
    ev = function(a) {
        a = jb(Array.from(Il(a, 0, Zl)), function(b) {
            return b.Hi()
        });
        a = kb(a, function(b) {
            return b.mf()
        });
        return lb(a,
            function(b, c) {
                return b && 1 == c
            }, 0 < a.length)
    };
var fv = function(a, b, c, d, e, f, g) {
    J.call(this);
    this.a = a;
    this.Z = Gm.M();
    this.F = K.M();
    this.ia = new nu(this.Z);
    this.Na = b;
    this.N = this.W = this.h = this.c = "";
    this.V = 0;
    this.m = !1;
    this.b = new gu("tts", Gm.M(), c);
    this.X = null != this.b.b && (Ee && Jc(pd, "UCBrowser") ? !1 : !0);
    this.G = We || Ve;
    G(this.b, "stop_playlist", this.O, !1, this);
    G(this.a, "action", this.Bj, !1, this);
    null != this.a.j() && G(this.a.j(), "click", this.po, !1, this);
    this.R = (a = /(sa=[^#&]+)/.exec(window.location.href)) ? a[0] : null;
    this.C = (a = /ttsspeed=([^&]+)/.exec(window.location.href)) ?
        a[0] : null;
    this.K = (a = /gl=([^&]+)/.exec(window.location.href)) ? a[0] : null;
    this.g = 0;
    this.ra = !!d;
    this.xa = !!e;
    this.L = f || null;
    this.na = g || null;
    this.o = "";
    this.Ca = new Xu;
    this.w = null
};
t(fv, J);
fv.prototype.T = function() {
    fv.D.T.call(this);
    oh(this.b, "stop_playlist", this.O, !1, this);
    oh(this.a, "action", this.Bj, !1, this)
};
fv.prototype.O = function() {
    this.a.cd(!1)
};
var gv = function(a, b, c, d, e, f) {
    b = le("/translate_tts?ie=UTF-8&q=", be(b), "&tl=", c, "&total=", d, "&idx=", e, "&textlen=", b.length, yo(b), a.Na, f);
    a.K && (b += "&" + a.K);
    return b
};
h = fv.prototype;
h.update = function(a, b, c, d, e) {
    var f = /([^?.,;:!"#$%&'()*+\-/<=>?@[\]^_`{|}~\u3001\u3002\uff01\uff08\uff09\uff0c\uff0e\uff1a\uff1b\uff1f])/;
    this.o = "";
    if (null != c)
        for (var g = 0; g < H(c, 5); g++) {
            var k = pp(c, g),
                l = Ih(Go(k, 0), 0),
                m = Ih(Go(k, 0), 1);
            l = I(k, 4).substring(l, m);
            k = I(Fo(k, 0), 0);
            if (l == k && f.test(l)) {
                this.o = I(c, 2);
                break
            }
        }
    this.g = 0;
    this.X ? xc(a) ? (hv(this, !1), this.a.oa(!1)) : (a != this.c || b != this.h || e != this.w ? (this.c = a, this.h = b, this.w = e || null, c = !1) : c = !0, c || (this.b.stop(), this.m = !this.X || !b || xc(a) || this.G && a.length > su[tu[b.toLowerCase()]] ?
        !1 : b.toLowerCase() in tu), hv(this, this.xa || this.m), this.a.oa(this.m)) : (hv(this, !1), this.a.oa(!1));
    null != d && (this.a.isEnabled() && null != this.L ? this.a.j().setAttribute("data-tooltip", this.L) : this.a.isEnabled() || null == this.na || this.a.j().setAttribute("data-tooltip", this.Ca.a(this.na, d)))
};
h.play = function() {
    if (this.c != this.W || this.h != this.N || this.g != this.V) {
        if (this.G) var a = [this.c];
        else {
            a = su[tu[this.h.toLowerCase()]];
            var b = [],
                c = this.ia,
                d = this.c.replace(/[ \u3000\n\r\t\s]+/g, " ");
            ou(b, d, a, p(c.a, c), p(c.g, c));
            a = b
        }
        b = [];
        c = [];
        d = "";
        null != this.R && (d += "&" + this.R);
        null != this.C ? d += "&ttsspeed=" + this.C : 0 != this.g && (d += "&ttsspeed=" + this.g);
        this.o && (d += "&hint=" + this.o);
        for (var e = 0; e < a.length; e++) b.push(gv(this, a[e], this.h, a.length, e, d)), c.push(a[e].length);
        this.b.set(b, this.c.length, c, this.w, {
            textlen: this.c.length,
            tl: this.h
        });
        this.W = this.c;
        this.N = this.h;
        this.V = this.g
    }
    this.b.start();
    this.ra && (this.g = 0 === this.g ? .24 : 0)
};
h.stop = function() {
    this.b.stop()
};
h.Bj = function() {
    this.a.Ea(16) ? this.play() : this.stop()
};
h.po = function(a) {
    this.a.isEnabled() || (a.stopPropagation(), this.dispatchEvent("userInteractionWhileDisabled"), a = this.F, M(a, N(a, 306)), O(this.Z, "webapp", "dia", "click", {
        dias: "vo"
    }))
};
var hv = function(a, b) {
    a.a.setVisible(b);
    b || a.b.stop()
};
var iv = function(a) {
        if (0 == a) return 0;
        if (1 == a) return 1;
        var b = .4 * a,
            c = .4 + -.2 * a;
        b += a * (c - b);
        return b + a * (c + a * (.2 + .8 * a - c) - b)
    },
    jv = function(a) {
        if (0 == a) return 0;
        if (1 == a) return 1;
        var b = 0 * a,
            c = 1 * a;
        b += a * (c - b);
        return b + a * (c + a * (1 + 0 * a - c) - b)
    },
    kv = function(a) {
        var b = a - 0;
        if (0 >= b) return 0;
        if (1 <= b) return 1;
        for (var c = 0, d = 1, e = 0, f = 0; 8 > f; f++) {
            e = iv(b);
            var g = (iv(b + 1E-6) - e) / 1E-6;
            if (1E-6 > Math.abs(e - a)) return b;
            if (1E-6 > Math.abs(g)) break;
            else e < a ? c = b : d = b, b -= (e - a) / g
        }
        for (f = 0; 1E-6 < Math.abs(e - a) && 8 > f; f++) e < a ? (c = b, b = (b + d) / 2) : (d = b, b = (b +
            c) / 2), e = iv(b);
        return b
    };
var lv = function(a) {
        var b = [];
        if (a.sentences)
            for (var c = 0, d; d = a.sentences[c]; c++) d.trans && b.push(d.trans);
        return b.join("")
    },
    mv = function() {
        for (var a = Array(51), b = 0; 51 > b; b++) a[b] = jv(kv(b / 50));
        return function(c) {
            if (0 >= c) return 0;
            if (1 <= c) return 1;
            var d = 50 * c;
            c = Math.floor(d);
            d -= c;
            return a[c] * (1 - d) + a[c + 1] * d
        }
    };
var nv = function(a, b) {
    Fs.call(this, a, "ttl");
    this.b = this.c = null;
    this.g = new Ht(MSG_LISTEN, void 0, new Nt("trans-listen-button"));
    this.h = new fv(this.g, "&client=" + (b ? b : "webapp") + "&prev=lc", 7)
};
t(nv, Fs);
nv.prototype.Ja = function() {
    nv.D.Ja.call(this);
    this.Da($f("DIV"))
};
nv.prototype.Da = function(a) {
    nv.D.Da.call(this, a);
    this.j().appendChild(Wp(ho));
    this.c = B("gt-ct-text", this.j());
    a = B("gt-ct-tts", this.j());
    this.b = B("gt-ct-translit", this.j());
    this.g.ba(a)
};
nv.prototype.update = function(a, b, c, d) {
    nv.D.update.call(this, a, b, c, d);
    E(this.c, a);
    this.h.update(a, b);
    if (this.data) {
        a = [];
        if (0 < this.data.jc())
            for (b = 0; b < this.data.jc(); b++) c = this.data.cb(b), Eh(c, 3) && "" != I(c, 3) && a.push(I(c, 3));
        0 < a.length ? (E(this.b, a.join(" ")), W(this.b, !0)) : W(this.b, !1)
    }
    this.setVisible(!0);
    return !0
};
var ov = function(a, b, c, d, e) {
    Fs.call(this, a, "cm");
    this.Z = b;
    this.C = new nv(a, e ? e : "webapp");
    this.w = null;
    this.ra = c;
    this.b = new X;
    this.jb(this.b);
    this.c = new X;
    this.jb(this.c);
    this.g = this.m = this.K = this.N = this.R = null;
    this.h = [];
    this.X = !!d;
    this.ia = tl.M();
    this.F = K.M()
};
t(ov, Fs);
h = ov.prototype;
h.Ja = function() {
    ov.D.Ja.call(this);
    this.Da($f("DIV"))
};
h.Da = function(a) {
    ov.D.Da.call(this, a);
    this.j().appendChild(Wp(fo));
    this.C.ba(B("gt-cc-tc", this.j()));
    this.w = B("gt-cc-t", this.j());
    W(this.w, !1);
    this.b.ba(B("gt-cc-l-i", this.j()));
    this.c.ba(B("gt-cc-r-i", this.j()));
    a = B("gt-cc-bc", this.j());
    this.R = new Sr("", new Nt("prev-button"));
    this.R.render(a);
    this.N = new Sr("", new Nt("next-button"));
    this.N.render(a);
    this.K = new Sr("", new Nt("big-clear-button"));
    this.K.render(a);
    this.m = B("gt-cc-exp", this.j());
    this.g = new Pt(this.R, this.N, this.K, this)
};
h.aa = function() {
    ov.D.aa.call(this);
    Y(this).listen(this, "a", this.Ll);
    Y(this).listen(this, "b", this.Ul);
    Y(this).listen(this.m, "click", this.Dl)
};
h.Dl = function() {
    W(this.m, !1);
    w(this.h, function(c) {
        c.setVisible(!0)
    });
    var a = {},
        b = this.F;
    $q(this.b, function(c) {
        c.isVisible() && (im(b, c.Nd(), c.fb(), c.sc), a[c.Kb()] = c.sc ? "e" : "ne")
    });
    hm(this.F, 15, ar(this.b));
    this.log("expand", a)
};
h.Ll = function(a) {
    a = Cg(a.target);
    pv(this, this.Ba, this.Ma, a, !1, "clks")
};
h.Ul = function(a) {
    a = Cg(a.target);
    pv(this, this.Ma, this.Ba, a, !1, "clkt")
};
h.Jl = function(a) {
    var b = a.text;
    if (!(50 < b.length)) {
        var c = this.g.a[0];
        a.o ? pv(this, c.Ma, c.Ba, b, !0, "sel") : pv(this, c.Ba, c.Ma, b, !0, "sel")
    }
};
var pv = function(a, b, c, d, e, f) {
    if (d != a.text || b != a.Ba) "zh-TW" == b && (b = "zh-CN"), wl(a.ia, f), e ? (E(a.C.c, "..."), wp(a.Z, b, c, a.Ra, d, p(a.V, a, d, b, c), !1, "UTF-8", new Zm("source=" + f))) : (a.dispatchEvent("translationRefreshed"), yt(a.ra, b, c, d, f))
};
ov.prototype.setVisible = function(a) {
    var b = this.j();
    b = !(!b || !B("gender-promo-visible", b));
    ov.D.setVisible.call(this, a || b)
};
ov.prototype.update = function(a, b, c, d) {
    ov.D.update.call(this, a, b, c, d);
    var e = 1 != this.g.a.length;
    W(this.w, e);
    V(this.j(), "show-as-one-card", this.X && e);
    var f = 0,
        g = 0,
        k = !0;
    this.h = [];
    $q(this.b, function(r) {
        var u = r.update(a, b, c, d);
        f |= u;
        u && (k ? k = !1 : r.Uh || (r.setVisible(!1), this.h.push(r)))
    }, this);
    qv(this, this.b);
    e = 0 < this.h.length;
    W(this.m, e);
    $q(this.c, function(r) {
        g |= r.update(a, b, c, d)
    }, this);
    var l = f || g;
    this.setVisible(l);
    this.C.update(a, b, c, d);
    if (l) {
        var m = {},
            q = this.F;
        $q(this.b, function(r) {
            r.isVisible() && (im(q, r.Nd(),
                r.fb(), r.sc), m[r.Kb()] = r.sc ? "e" : "ne")
        });
        $q(this.c, function(r) {
            r.isVisible() && (im(q, r.Nd(), r.fb(), r.sc), m[r.Kb()] = r.sc ? "e" : "ne")
        });
        m[this.Kb()] = e ? "e" : "ne";
        this.log("show", m);
        im(this.F, 15, ar(this.b), !0)
    }
    return l
};
ov.prototype.V = function(a, b, c, d) {
    this.g.push(a, b, c, d);
    this.isVisible() || (a = this.g, 1 < a.a.length && (a.a.splice(a.a.length - 1), a.b = a.a.length - 1, Qt(a)))
};
var qv = function(a, b) {
    var c = [];
    $q(b, function(d) {
        if (d.isVisible() || rb(this.h, d)) {
            var e = d.cf || d.text;
            rb(c, e) ? d.Oc && E(d.Oc, d.uj) : c.push(e)
        }
    }, a)
};
var rv = {
        Eh: {
            1E3: {
                other: "0K"
            },
            1E4: {
                other: "00K"
            },
            1E5: {
                other: "000K"
            },
            1E6: {
                other: "0M"
            },
            1E7: {
                other: "00M"
            },
            1E8: {
                other: "000M"
            },
            1E9: {
                other: "0B"
            },
            1E10: {
                other: "00B"
            },
            1E11: {
                other: "000B"
            },
            1E12: {
                other: "0T"
            },
            1E13: {
                other: "00T"
            },
            1E14: {
                other: "000T"
            }
        },
        Ij: {
            1E3: {
                other: "0 thousand"
            },
            1E4: {
                other: "00 thousand"
            },
            1E5: {
                other: "000 thousand"
            },
            1E6: {
                other: "0 million"
            },
            1E7: {
                other: "00 million"
            },
            1E8: {
                other: "000 million"
            },
            1E9: {
                other: "0 billion"
            },
            1E10: {
                other: "00 billion"
            },
            1E11: {
                other: "000 billion"
            },
            1E12: {
                other: "0 trillion"
            },
            1E13: {
                other: "00 trillion"
            },
            1E14: {
                other: "000 trillion"
            }
        }
    },
    sv = rv;
sv = rv;
var tv = {
    AED: [2, "dh", "\u062f.\u0625."],
    ALL: [0, "Lek", "Lek"],
    AUD: [2, "$", "AU$"],
    BDT: [2, "\u09f3", "Tk"],
    BGN: [2, "lev", "lev"],
    BRL: [2, "R$", "R$"],
    CAD: [2, "$", "C$"],
    CDF: [2, "FrCD", "CDF"],
    CHF: [2, "CHF", "CHF"],
    CLP: [0, "$", "CL$"],
    CNY: [2, "\u00a5", "RMB\u00a5"],
    COP: [32, "$", "COL$"],
    CRC: [0, "\u20a1", "CR\u20a1"],
    CZK: [50, "K\u010d", "K\u010d"],
    DKK: [50, "kr.", "kr."],
    DOP: [2, "RD$", "RD$"],
    EGP: [2, "\u00a3", "LE"],
    ETB: [2, "Birr", "Birr"],
    EUR: [2, "\u20ac", "\u20ac"],
    GBP: [2, "\u00a3", "GB\u00a3"],
    HKD: [2, "$", "HK$"],
    HRK: [2, "kn", "kn"],
    HUF: [34,
        "Ft", "Ft"
    ],
    IDR: [0, "Rp", "Rp"],
    ILS: [34, "\u20aa", "IL\u20aa"],
    INR: [2, "\u20b9", "Rs"],
    IRR: [0, "Rial", "IRR"],
    ISK: [0, "kr", "kr"],
    JMD: [2, "$", "JA$"],
    JPY: [0, "\u00a5", "JP\u00a5"],
    KRW: [0, "\u20a9", "KR\u20a9"],
    LKR: [2, "Rs", "SLRs"],
    LTL: [2, "Lt", "Lt"],
    MNT: [0, "\u20ae", "MN\u20ae"],
    MVR: [2, "Rf", "MVR"],
    MXN: [2, "$", "Mex$"],
    MYR: [2, "RM", "RM"],
    NOK: [50, "kr", "NOkr"],
    PAB: [2, "B/.", "B/."],
    PEN: [2, "S/.", "S/."],
    PHP: [2, "\u20b1", "PHP"],
    PKR: [0, "Rs", "PKRs."],
    PLN: [50, "z\u0142", "z\u0142"],
    RON: [2, "RON", "RON"],
    RSD: [0, "din", "RSD"],
    RUB: [50, "\u20bd",
        "RUB"
    ],
    SAR: [2, "Rial", "Rial"],
    SEK: [50, "kr", "kr"],
    SGD: [2, "$", "S$"],
    THB: [2, "\u0e3f", "THB"],
    TRY: [2, "\u20ba", "TRY"],
    TWD: [2, "NT$", "NT$"],
    TZS: [0, "TSh", "TSh"],
    UAH: [2, "\u0433\u0440\u043d.", "UAH"],
    USD: [2, "$", "US$"],
    UYU: [2, "$", "$U"],
    VND: [48, "\u20ab", "VN\u20ab"],
    YER: [0, "Rial", "Rial"],
    ZAR: [2, "R", "ZAR"]
};
var uv = {
        Gh: ".",
        hg: ",",
        Oh: "%",
        kg: "0",
        Uj: "+",
        Kh: "-",
        Hh: "E",
        Ph: "\u2030",
        jg: "\u221e",
        Sj: "NaN",
        Fh: "#,##0.###",
        Vj: "#E0",
        Tj: "#,##0%",
        Jj: "\u00a4#,##0.00",
        gg: "USD"
    },
    vv = uv;
vv = uv;
var yv = function(a) {
        this.L = 40;
        this.b = 1;
        this.Fa = 0;
        this.c = 3;
        this.O = this.g = 0;
        this.R = !1;
        this.K = this.w = "";
        this.h = vv.Kh;
        this.G = "";
        this.a = 1;
        this.m = !1;
        this.o = [];
        this.La = this.N = !1;
        this.C = 0;
        if ("number" == typeof a) switch (a) {
            case 1:
                wv(this, vv.Fh);
                break;
            case 2:
                wv(this, vv.Vj);
                break;
            case 3:
                wv(this, vv.Tj);
                break;
            case 4:
                a = vv.Jj;
                var b = ["0"],
                    c = tv[vv.gg];
                if (c) {
                    c = c[0] & 7;
                    if (0 < c) {
                        b.push(".");
                        for (var d = 0; d < c; d++) b.push("0")
                    }
                    a = a.replace(/0.00/g, b.join(""))
                }
                wv(this, a);
                break;
            case 5:
                xv(this, 1);
                break;
            case 6:
                xv(this, 2);
                break;
            default:
                throw Error("Unsupported pattern type.");
        } else wv(this, a)
    },
    wv = function(a, b) {
        b.replace(/ /g, "\u00a0");
        var c = [0];
        a.w = zv(a, b, c);
        for (var d = c[0], e = -1, f = 0, g = 0, k = 0, l = -1, m = b.length, q = !0; c[0] < m && q; c[0]++) switch (b.charAt(c[0])) {
            case "#":
                0 < g ? k++ : f++;
                0 <= l && 0 > e && l++;
                break;
            case "0":
                if (0 < k) throw Error('Unexpected "0" in pattern "' + b + '"');
                g++;
                0 <= l && 0 > e && l++;
                break;
            case ",":
                0 < l && a.o.push(l);
                l = 0;
                break;
            case ".":
                if (0 <= e) throw Error('Multiple decimal separators in pattern "' + b + '"');
                e = f + g + k;
                break;
            case "E":
                if (a.La) throw Error('Multiple exponential symbols in pattern "' +
                    b + '"');
                a.La = !0;
                a.O = 0;
                c[0] + 1 < m && "+" == b.charAt(c[0] + 1) && (c[0]++, a.R = !0);
                for (; c[0] + 1 < m && "0" == b.charAt(c[0] + 1);) c[0]++, a.O++;
                if (1 > f + g || 1 > a.O) throw Error('Malformed exponential pattern "' + b + '"');
                q = !1;
                break;
            default:
                c[0]--, q = !1
        }
        0 == g && 0 < f && 0 <= e && (g = e, 0 == g && g++, k = f - g, f = g - 1, g = 1);
        if (0 > e && 0 < k || 0 <= e && (e < f || e > f + g) || 0 == l) throw Error('Malformed pattern "' + b + '"');
        k = f + g + k;
        a.c = 0 <= e ? k - e : 0;
        0 <= e && (a.g = f + g - e, 0 > a.g && (a.g = 0));
        a.b = (0 <= e ? e : k) - f;
        a.La && (a.L = f + a.b, 0 == a.c && 0 == a.b && (a.b = 1));
        a.o.push(Math.max(0, l));
        a.N = 0 == e || e ==
            k;
        d = c[0] - d;
        a.K = zv(a, b, c);
        c[0] < b.length && ";" == b.charAt(c[0]) ? (c[0]++, 1 != a.a && (a.m = !0), a.h = zv(a, b, c), c[0] += d, a.G = zv(a, b, c)) : (a.h += a.w, a.G += a.K)
    },
    xv = function(a, b) {
        a.C = b;
        wv(a, vv.Fh);
        a.g = 0;
        a.c = 2;
        if (0 < a.g) throw Error("Can't combine significant digits and minimum fraction digits");
        a.Fa = 2
    };
yv.prototype.parse = function(a, b) {
    b = b || [0];
    if (0 != this.C) throw Error("Parsing of compact numbers is unimplemented");
    a = a.replace(/ |\u202f/g, "\u00a0");
    var c = a.indexOf(this.w, b[0]) == b[0],
        d = a.indexOf(this.h, b[0]) == b[0];
    c && d && (this.w.length > this.h.length ? d = !1 : this.w.length < this.h.length && (c = !1));
    c ? b[0] += this.w.length : d && (b[0] += this.h.length);
    if (a.indexOf(vv.jg, b[0]) == b[0]) {
        b[0] += vv.jg.length;
        var e = Infinity
    } else {
        e = a;
        var f = !1,
            g = !1,
            k = !1,
            l = -1,
            m = 1,
            q = vv.Gh,
            r = vv.hg,
            u = vv.Hh;
        if (0 != this.C) throw Error("Parsing of compact style numbers is not implemented");
        r = r.replace(/\u202f/g, "\u00a0");
        for (var z = ""; b[0] < e.length; b[0]++) {
            var P = e.charAt(b[0]),
                L = Av(P);
            if (0 <= L && 9 >= L) z += L, k = !0;
            else if (P == q.charAt(0)) {
                if (f || g) break;
                z += ".";
                f = !0
            } else if (P == r.charAt(0) && ("\u00a0" != r.charAt(0) || b[0] + 1 < e.length && 0 <= Av(e.charAt(b[0] + 1)))) {
                if (f || g) break
            } else if (P == u.charAt(0)) {
                if (g) break;
                z += "E";
                g = !0;
                l = b[0]
            } else if ("+" == P || "-" == P) {
                if (k && l != b[0] - 1) break;
                z += P
            } else if (1 == this.a && P == vv.Oh.charAt(0)) {
                if (1 != m) break;
                m = 100;
                if (k) {
                    b[0]++;
                    break
                }
            } else if (1 == this.a && P == vv.Ph.charAt(0)) {
                if (1 !=
                    m) break;
                m = 1E3;
                if (k) {
                    b[0]++;
                    break
                }
            } else break
        }
        1 != this.a && (m = this.a);
        e = parseFloat(z) / m
    }
    if (c) {
        if (a.indexOf(this.K, b[0]) != b[0]) return NaN;
        b[0] += this.K.length
    } else if (d) {
        if (a.indexOf(this.G, b[0]) != b[0]) return NaN;
        b[0] += this.G.length
    }
    return d ? -e : e
};
var Iv = function(a, b) {
        if (isNaN(b)) return vv.Sj;
        var c = [];
        var d = b,
            e = b;
        if (0 == a.C) var f = Bv;
        else d = Math.abs(d), e = Math.abs(e), f = Cv(a, 1 >= d ? 0 : Dv(d)).yg, e = Ev(e, -f), Fv(a, e), d = Ev(d, -f), d = Fv(a, d), f = Cv(a, f + Dv(d.Ni));
        b = Ev(b, -f.yg);
        c.push(f.prefix);
        d = 0 > b || 0 == b && 0 > 1 / b;
        c.push(d ? a.h : a.w);
        if (isFinite(b))
            if (b = b * (d ? -1 : 1) * a.a, a.La)
                if (0 == b) Gv(a, b, a.b, c), Hv(a, 0, c);
                else {
                    e = Math.log(b) / Math.log(10);
                    v(!0);
                    e = Math.floor(e + 2E-15);
                    b = Ev(b, -e);
                    var g = a.b;
                    1 < a.L && a.L > a.b ? (g = e % a.L, 0 > g && (g = a.L + g), b = Ev(b, g), e -= g, g = 1) : 1 > a.b ? (e++, b = Ev(b, -1)) :
                        (e -= a.b - 1, b = Ev(b, a.b - 1));
                    Gv(a, b, g, c);
                    Hv(a, e, c)
                }
        else Gv(a, b, a.b, c);
        else c.push(vv.jg);
        c.push(d ? a.G : a.K);
        c.push(f.oj);
        return c.join("")
    },
    Fv = function(a, b) {
        var c = Ev(b, a.c);
        0 < a.Fa && (c = Jv(c, a.Fa, a.c));
        c = Math.round(c);
        isFinite(c) ? (b = Math.floor(Ev(c, -a.c)), a = Math.floor(c - Ev(b, a.c))) : a = 0;
        return {
            Ni: b,
            Uk: a
        }
    },
    Gv = function(a, b, c, d) {
        if (a.g > a.c) throw Error("Min value must be less than max value");
        d || (d = []);
        b = Fv(a, b);
        var e = b.Ni,
            f = b.Uk,
            g = 0 < a.g || 0 < f || !1;
        b = a.g;
        g && (b = a.g);
        for (var k = "", l = e; 1E20 < l;) k = "0" + k, l = Math.round(Ev(l,
            -1));
        k = l + k;
        var m = vv.Gh;
        l = vv.kg.charCodeAt(0);
        var q = k.length,
            r = 0;
        if (0 < e || 0 < c) {
            for (e = q; e < c; e++) d.push(String.fromCharCode(l));
            if (2 <= a.o.length)
                for (c = 1; c < a.o.length; c++) r += a.o[c];
            c = q - r;
            if (0 < c) {
                e = a.o;
                r = q = 0;
                for (var u, z = vv.hg, P = k.length, L = 0; L < P; L++)
                    if (d.push(String.fromCharCode(l + 1 * Number(k.charAt(L)))), 1 < P - L)
                        if (u = e[r], L < c) {
                            var Ma = c - L;
                            (1 === u || 0 < u && 1 === Ma % u) && d.push(z)
                        } else r < e.length && (L === c ? r += 1 : u === L - c - q + 1 && (d.push(z), q += u, r += 1))
            } else {
                c = k;
                k = a.o;
                e = vv.hg;
                u = c.length;
                z = [];
                for (q = k.length - 1; 0 <= q && 0 < u; q--) {
                    r =
                        k[q];
                    for (P = 0; P < r && 0 <= u - P - 1; P++) z.push(String.fromCharCode(l + 1 * Number(c.charAt(u - P - 1))));
                    u -= r;
                    0 < u && z.push(e)
                }
                d.push.apply(d, z.reverse())
            }
        } else g || d.push(String.fromCharCode(l));
        (a.N || g) && d.push(m);
        f = String(f);
        g = f.split("e+");
        2 == g.length && (f = String(Jv(parseFloat(g[0]), a.Fa, 1)), f = f.replace(".", ""), f += je("0", parseInt(g[1], 10) - f.length + 1));
        a.c + 1 > f.length && (f = "1" + je("0", a.c - f.length) + f);
        for (a = f.length;
            "0" == f.charAt(a - 1) && a > b + 1;) a--;
        for (e = 1; e < a; e++) d.push(String.fromCharCode(l + 1 * Number(f.charAt(e))))
    },
    Hv =
    function(a, b, c) {
        c.push(vv.Hh);
        0 > b ? (b = -b, c.push(vv.Kh)) : a.R && c.push(vv.Uj);
        b = "" + b;
        for (var d = vv.kg, e = b.length; e < a.O; e++) c.push(d);
        c.push(b)
    },
    Av = function(a) {
        a = a.charCodeAt(0);
        if (48 <= a && 58 > a) return a - 48;
        var b = vv.kg.charCodeAt(0);
        return b <= a && a < b + 10 ? a - b : -1
    },
    zv = function(a, b, c) {
        for (var d = "", e = !1, f = b.length; c[0] < f; c[0]++) {
            var g = b.charAt(c[0]);
            if ("'" == g) c[0] + 1 < f && "'" == b.charAt(c[0] + 1) ? (c[0]++, d += "'") : e = !e;
            else if (e) d += g;
            else switch (g) {
                case "#":
                case "0":
                case ",":
                case ".":
                case ";":
                    return d;
                case "\u00a4":
                    c[0] +
                        1 < f && "\u00a4" == b.charAt(c[0] + 1) ? (c[0]++, d += vv.gg) : (g = vv.gg, d += g in tv ? tv[g][1] : g);
                    break;
                case "%":
                    if (!a.m && 1 != a.a) throw Error("Too many percent/permill");
                    if (a.m && 100 != a.a) throw Error("Inconsistent use of percent/permill characters");
                    a.a = 100;
                    a.m = !1;
                    d += vv.Oh;
                    break;
                case "\u2030":
                    if (!a.m && 1 != a.a) throw Error("Too many percent/permill");
                    if (a.m && 1E3 != a.a) throw Error("Inconsistent use of percent/permill characters");
                    a.a = 1E3;
                    a.m = !1;
                    d += vv.Ph;
                    break;
                default:
                    d += g
            }
        }
        return d
    },
    Bv = {
        prefix: "",
        oj: "",
        yg: 0
    },
    Cv = function(a,
        b) {
        a = 1 == a.C ? sv.Eh : sv.Ij;
        null == a && (a = sv.Eh);
        if (3 > b) return Bv;
        b = Math.min(14, b);
        var c = a[Ev(1, b)];
        for (--b; !c && 3 <= b;) c = a[Ev(1, b)], b--;
        if (!c) return Bv;
        a = c.other;
        return a && "0" != a ? (a = /([^0]*)(0+)(.*)/.exec(a)) ? {
            prefix: a[1],
            oj: a[3],
            yg: b + 1 - (a[2].length - 1)
        } : Bv : Bv
    },
    Dv = function(a) {
        if (!isFinite(a)) return 0 < a ? a : 0;
        for (var b = 0; 1 <= (a /= 10);) b++;
        return b
    },
    Ev = function(a, b) {
        v(0 == b % 1, 'Cannot shift by fractional digits "%s".', b);
        if (!a || !isFinite(a) || 0 == b) return a;
        a = String(a).split("e");
        return parseFloat(a[0] + "e" + (parseInt(a[1] ||
            0, 10) + b))
    },
    Kv = function(a, b) {
        v(0 == b % 1, 'Cannot round to fractional digits "%s".', b);
        return a && isFinite(a) ? Ev(Math.round(Ev(a, b)), -b) : a
    },
    Jv = function(a, b, c) {
        if (!a) return a;
        b = b - Dv(a) - 1;
        return b < -c ? Kv(a, -c) : Kv(a, b)
    };
var Lv = function(a, b, c) {
    X.call(this);
    this.h = a;
    this.b = b;
    this.c = c;
    this.g = new yv("######")
};
t(Lv, X);
Lv.prototype.Xc = function(a) {
    return a && "DIV" == a.tagName && B("cc-ctr", a) && B("cc-msg", a) ? !0 : !1
};
Lv.prototype.init = function() {
    Mv(this, !1);
    Nv(this, 0)
};
var Nv = function(a, b) {
        b = Iv(a.g, b);
        var c = Iv(a.g, a.h);
        E(B("cc-ctr", a.j()), b + "/" + c)
    },
    Mv = function(a, b) {
        if (b) {
            var c = B("cc-ctr", a.j()),
                d = a.c;
            U(c, a.b);
            T(c, d)
        } else c = B("cc-ctr", a.j()), d = a.b, U(c, a.c), T(c, d);
        W(B("cc-msg", a.j()), b)
    };
var Ov = function(a, b) {
    Jg.call(this);
    this.c = this.b = 0;
    this.$b = a;
    this.g = b;
    this.a = new Ur(p(this.Zk, this), 0, this)
};
t(Ov, Jg);
h = Ov.prototype;
h.T = function() {
    this.a.Ia();
    delete this.$b;
    delete this.g;
    Ov.D.T.call(this)
};
h.start = function(a, b) {
    this.stop();
    b = b || 0;
    this.b = Math.max(a || 0, 0);
    this.c = 0 > b ? -1 : Ta() + b;
    this.a.start(0 > b ? this.b : Math.min(this.b, b))
};
h.stop = function() {
    this.a.stop()
};
h.nb = function() {
    return this.a.nb()
};
h.Zk = function() {
    if (!this.$b.call(this.g))
        if (0 > this.c) this.a.start(this.b);
        else {
            var a = this.c - Ta();
            0 >= a || this.a.start(Math.min(this.b, a))
        }
};
var Qv = function(a) {
    J.call(this);
    this.v = a;
    this.a = this.v.value;
    this.b = new Lq(this);
    this.g = Ta();
    Pv ? this.b.listen(a, "paste", this.Ld) : this.b.listen(a, ["keydown", "blur", "focus", "mouseover", "input"], this.Cl);
    this.c = new Ov(p(this.bi, this))
};
t(Qv, J);
var Pv = ze || y || we || ye && Qe("1.9");
h = Qv.prototype;
h.hc = "init";
h.F = Wi("goog.events.PasteHandler");
h.T = function() {
    Qv.D.T.call(this);
    this.b.Ia();
    this.b = null;
    this.c.Ia();
    this.c = null
};
h.getState = function() {
    return this.hc
};
h.bi = function() {
    if (this.a == this.v.value) return !1;
    Zi(this.F, "detected textchange after paste");
    this.dispatchEvent("after_paste");
    return !0
};
h.Ld = function(a) {
    a = new Tg(a.b);
    a.type = "paste";
    this.dispatchEvent(a);
    Ci(function() {
        this.bi() || this.c.start(50, 200)
    }, 0, this)
};
h.Cl = function(a) {
    switch (this.hc) {
        case "init":
            switch (a.type) {
                case "blur":
                    this.hc = "init";
                    break;
                case "focus":
                    this.hc = "focused";
                    break;
                case "mouseover":
                    this.hc = "init";
                    this.v.value != this.a && (Zi(this.F, "paste by dragdrop while on init!"), this.Ld(a));
                    break;
                default:
                    Xi(this.F, "unexpected event " + a.type + "during init")
            }
            break;
        case "focused":
            switch (a.type) {
                case "input":
                    var b = this.g + 400;
                    if (Ta() > b || "focus" == this.h) Zi(this.F, "paste by textchange while focused!"), this.Ld(a);
                    break;
                case "blur":
                    this.hc = "init";
                    break;
                case "keydown":
                    Zi(this.F,
                        "key down ... looking for ctrl+v");
                    if (Ce && ve && 0 == a.keyCode || Ce && ve && 17 == a.keyCode) break;
                    this.hc = "typing";
                    break;
                case "mouseover":
                    this.v.value != this.a && (Zi(this.F, "paste by dragdrop while focused!"), this.Ld(a));
                    break;
                default:
                    Xi(this.F, "unexpected event " + a.type + " during focused")
            }
            break;
        case "typing":
            switch (a.type) {
                case "input":
                    this.hc = "focused";
                    break;
                case "blur":
                    this.hc = "init";
                    break;
                case "keydown":
                    if (a.ctrlKey && 86 == a.keyCode || a.shiftKey && 45 == a.keyCode || a.metaKey && 86 == a.keyCode) Zi(this.F, "paste by ctrl+v while keypressed!"),
                        this.Ld(a);
                    break;
                case "mouseover":
                    this.v.value != this.a && (Zi(this.F, "paste by dragdrop while keypressed!"), this.Ld(a));
                    break;
                default:
                    Xi(this.F, "unexpected event " + a.type + " during keypressed")
            }
            break;
        default:
            Xi(this.F, "invalid " + this.hc + " state")
    }
    this.g = Ta();
    this.a = this.v.value;
    Zi(this.F, a.type + " -> " + this.hc);
    this.h = a.type
};
var Rv = function() {};
t(Rv, mr);
Fa(Rv);
h = Rv.prototype;
h.$c = function() {};
h.Va = function(a, b) {
    Fr(a, !1);
    a.Ac &= -256;
    a.Oa(32, !1);
    Rv.D.Va.call(this, a, b);
    a.g(b.value);
    return b
};
h.mb = function(a) {
    Fr(a, !1);
    a.Ac &= -256;
    a.Oa(32, !1);
    return a.a.b("TEXTAREA", {
        "class": pr(this, a).join(" "),
        disabled: !a.isEnabled()
    }, a.Sa() || "")
};
h.Zc = function(a) {
    return "TEXTAREA" == a.tagName
};
h.Qg = Ea;
h.Pg = function(a) {
    return a.isEnabled()
};
h.Rd = Ea;
h.yd = function(a, b, c) {
    Rv.D.yd.call(this, a, b, c);
    (a = a.j()) && 1 == b && (a.disabled = c)
};
h.lc = Ea;
h.Lb = function(a, b) {
    a && (a.value = b)
};
h.wa = function() {
    return "goog-textarea"
};
var Sv = function(a, b, c) {
    Z.call(this, a, b || Rv.M(), c);
    Fr(this, !1);
    this.Ye = !0;
    (b = this.j()) && this.c.Cf(b, !0);
    this.Ud = "" != a;
    a || (this.ad = "")
};
t(Sv, Z);
var Tv = !(y && !Se(11));
h = Sv.prototype;
h.Vd = !1;
h.Nf = !1;
h.Ud = !1;
h.Jc = 0;
h.hh = 0;
h.Ii = !1;
h.Wf = !1;
h.qh = !1;
h.ph = !1;
h.Dd = "";
var Uv = function(a) {
        return a.m.top + a.m.bottom + a.W.top + a.W.bottom
    },
    Vv = function(a) {
        var b = a.hh,
            c = a.j();
        b && c && a.Wf && (b -= Uv(a));
        return b
    };
Sv.prototype.b = function(a) {
    this.g(String(a))
};
Sv.prototype.Y = function() {
    return this.j().value != this.Dd || Wv(this) || this.Ud ? this.j().value : ""
};
Sv.prototype.g = function(a) {
    Sv.D.g.call(this, a);
    this.Ud = "" != a;
    Xv(this)
};
Sv.prototype.oa = function(a) {
    Sv.D.oa.call(this, a);
    this.j().disabled = !a
};
var Xv = function(a) {
        a.j() && a.N()
    },
    Wv = function(a) {
        v(a.j());
        return "placeholder" in a.j()
    },
    Yv = function(a) {
        a.Dd && (Wv(a) ? a.j().placeholder = a.Dd : !a.j() || a.Ud || a.Nf || (T(v(a.j()), "textarea-placeholder-input"), a.j().value = a.Dd))
    };
Sv.prototype.aa = function() {
    Sv.D.aa.call(this);
    var a = this.j();
    cq(a, {
        overflowY: "hidden",
        overflowX: "auto",
        boxSizing: "border-box",
        MsBoxSizing: "border-box",
        WebkitBoxSizing: "border-box",
        MozBoxSizing: "border-box"
    });
    this.m = Iq(a);
    this.W = oq(a);
    Y(this).listen(a, "scroll", this.N).listen(a, "focus", this.N).listen(a, "keyup", this.N).listen(a, "mouseup", this.ac).listen(a, "blur", this.Ta);
    Yv(this);
    Xv(this)
};
var Zv = function(a) {
        if (!a.Ii) {
            var b = a.j().cloneNode(!1);
            cq(b, {
                position: "absolute",
                height: "auto",
                top: "-9999px",
                margin: "0",
                padding: "1px",
                border: "1px solid #000",
                overflow: "hidden"
            });
            dg(a.a.a.body, b);
            var c = b.scrollHeight;
            b.style.padding = "10px";
            var d = b.scrollHeight;
            a.qh = d > c;
            b.style.borderWidth = "10px";
            a.ph = b.scrollHeight > d;
            b.style.height = "100px";
            100 != b.offsetHeight && (a.Wf = !0);
            jg(b);
            a.Ii = !0
        }
        b = a.j();
        isNaN(a.m.top) && (a.m = Iq(b), a.W = oq(b));
        c = a.j().scrollHeight;
        var e = a.j();
        d = e.offsetHeight - e.clientHeight;
        if (!a.qh) {
            var f =
                a.m;
            d -= f.top + f.bottom
        }
        a.ph || (e = oq(e), d -= e.top + e.bottom);
        c += 0 < d ? d : 0;
        a.Wf ? c -= Uv(a) : (a.qh || (d = a.m, c += d.top + d.bottom), a.ph || (a = oq(b), c += a.top + a.bottom));
        return c
    },
    $v = function(a, b) {
        a.Jc != b && (a.Jc = b, a.j().style.height = b + "px")
    },
    aw = function(a) {
        var b = a.j();
        b.style.height = "auto";
        var c = b.value.match(/\n/g) || [];
        b.rows = c.length + 1;
        a.Jc = 0
    };
Sv.prototype.Ta = function() {
    Wv(this) || (this.Nf = !1, "" == this.j().value && (this.Ud = !1, Yv(this)))
};
Sv.prototype.N = function(a) {
    if (!this.Vd) {
        var b = this.j();
        !Wv(this) && a && "focus" == a.type && (b.value == this.Dd && this.Dd && !this.Nf && (U(b, "textarea-placeholder-input"), b.value = ""), this.Nf = !0, this.Ud = "" != b.value);
        var c = !1;
        this.Vd = !0;
        a = this.Jc;
        if (b.scrollHeight) {
            var d = !1,
                e = !1,
                f = Zv(this),
                g = b.offsetHeight,
                k = Vv(this);
            var l = 0;
            var m = this.j();
            l && m && this.Wf && (l -= Uv(this));
            k && f < k ? ($v(this, k), d = !0) : l && f > l ? ($v(this, l), b.style.overflowY = "", e = !0) : g != f ? $v(this, f) : this.Jc || (this.Jc = f);
            d || e || !Tv || (c = !0)
        } else aw(this);
        this.Vd = !1;
        c && (b = this.j(), this.Vd || (this.Vd = !0, (e = b.scrollHeight) ? (f = Zv(this), c = Vv(this), c && f <= c || (d = this.m, b.style.paddingBottom = d.bottom + 1 + "px", Zv(this) == f && (b.style.paddingBottom = d.bottom + e + "px", b.scrollTop = 0, e = Zv(this) - e, e >= c ? $v(this, e) : $v(this, c)), b.style.paddingBottom = d.bottom + "px")) : aw(this), this.Vd = !1));
        a != this.Jc && this.dispatchEvent("resize")
    }
};
Sv.prototype.ac = function() {
    var a = this.j(),
        b = a.offsetHeight;
    a.filters && a.filters.length && (a = a.filters.item("DXImageTransform.Microsoft.DropShadow")) && (b -= a.offX);
    b != this.Jc && (this.Jc = this.hh = b)
};
var bw = function(a, b) {
    Sv.call(this, a);
    this.bc = !!b;
    this.ra = "";
    this.xa = null;
    this.R = 0;
    this.X = this.Z = !1;
    this.Ca = null
};
t(bw, Sv);
bw.prototype.b = function(a) {
    bw.D.b.call(this, a);
    this.V("set")
};
bw.prototype.aa = function() {
    bw.D.aa.call(this);
    G(this.j(), "compositionstart", p(this.xb, this), !1, this);
    G(this.j(), "compositionend", p(this.ob, this), !1, this);
    this.Ca = new fr(this.j());
    G(this.Ca, "key", function(a) {
        cw(this, "key", {
            keyCode: a.keyCode
        })
    }, !1, this);
    G(this.j(), "input", function() {
        cw(this, "input")
    }, !1, this);
    G(new Qv(this.j()), "paste", function() {
        this.Z = !0;
        cw(this, "paste")
    }, !1, this);
    G(this.j(), "drop", function() {
        cw(this, "drop")
    }, !1, this);
    this.xa = new Ai(1E3);
    G(this.xa, "tick", function() {
            this.V("timer")
        },
        !1, this);
    this.xa.start()
};
bw.prototype.xb = function() {
    this.X = !0
};
bw.prototype.ob = function() {
    this.X = !1;
    cw(this, "input")
};
var cw = function(a, b, c) {
    Ci(p(a.V, a, b, c), 0, a)
};
bw.prototype.V = function(a, b) {
    if (!this.X)
        if (this.bc && "key" == a && b && 13 == b.keyCode) this.dispatchEvent("enter");
        else {
            var c = this.Y();
            "" == c.trim() && c != this.ra && this.dispatchEvent("clear");
            c != this.ra && (this.R += 1, this.ra = c, c = new F("change"), this.Z && (this.Z = !1, a = "paste"), c.changeType = a, null != b && Wb(c, b), this.dispatchEvent(c))
        }
};
var dw = function(a) {
        return yc(a.Y())
    },
    ew = function(a) {
        var b = a.R;
        a.R = 0;
        return b
    };
var fw = function(a, b) {
    J.call(this);
    this.ud = a;
    this.a = [];
    null != b && this.Fd(b)
};
t(fw, J);
fw.prototype.update = function(a, b) {
    for (var c = this.a.length = 0; c < a.length; ++c) this.a.push(a[c]);
    this.dispatchEvent({
        type: this.ud,
        data: this.a,
        selected: null != b ? b : null
    })
};
var gw = function(a, b) {
    J.call(this);
    this.R = !!b;
    this.a = "";
    this.V = a;
    this.c = this.b = "";
    this.L = new fw("srcSuggestionUpdated", this);
    this.K = new fw("staticSrcSuggestionUpdated", this);
    this.O = new fw("staticTgtSuggestionUpdated", this);
    this.W = [];
    this.ia = new fw("srcEmphasizeUpdated", this);
    this.X = new fw("tgtEmphasizeUpdated", this);
    this.Z = this.na = 0;
    this.o = [];
    this.m = [];
    this.C = [];
    this.N = [];
    this.G = !1;
    this.w = ""
};
t(gw, J);
var hw = function(a, b) {
        var c = [];
        if (b) {
            for (var d = "auto" == a.a ? a.c : a.a, e = -1, f = 0; f < b.length; ++f) b[f] == d ? "auto" != a.a && (e = f) : c.push(b[f]);
            b = -1 != e && 3 > e
        } else b = !1;
        b || a.G || a.L.update(c ? c.slice(0, 3) : [])
    },
    jw = function(a) {
        var b = a.K,
            c = a.a;
        a = iw(a.C, a.o);
        b.update(a, c)
    },
    kw = function(a) {
        var b = a.O,
            c = a.b;
        a = iw(a.N, a.m);
        b.update(a, c)
    };
gw.prototype.g = function(a, b) {
    b = null != b ? b : 0;
    if (3 == b || 4 == b || 5 == b) this.G = !0;
    6 == b && (this.w = a);
    "zh-TW" == a && (a = "zh-CN");
    "auto" != a && lw(this, "");
    if (this.a != a) {
        mw(this, this.K, a, this.o);
        var c = this.a;
        this.a = a;
        this.R && nw(this.a, this.o);
        this.V && c != this.a && this.V(jc(this.a) ? "rtl" : "ltr");
        a = "auto" == c ? void 0 : p(this.h, this, c, 6);
        this.na = b;
        ow(this, this.a, "srcLanguageUpdated", b, a)
    }
};
gw.prototype.h = function(a, b) {
    b = null != b ? b : 0;
    6 != b && 5 != b || "zh-CN" != a || "zh-TW" != this.w || (a = "zh-TW");
    5 == b && (this.w = this.b);
    mw(this, this.O, a, this.m);
    if (this.b != a) {
        var c = this.b;
        this.b = a;
        this.R && nw(this.b, this.m);
        this.Z = b;
        ow(this, this.b, "tgtLanguageUpdated", b, p(this.g, this, c, 6))
    }
};
var mw = function(a, b, c, d) {
        for (var e = xb(b.a), f = "auto" != c, g = 0; g < e.length; g++)
            if (c == e[g]) {
                f = !1;
                break
            } if (a.R && "auto" != c) {
            g = e.length;
            d = e = [c].concat(d instanceof Array ? d : ca(ba(d)), e instanceof Array ? e : ca(ba(e)));
            a = {};
            for (var k = f = 0; k < d.length;) {
                var l = d[k++];
                var m = l;
                m = La(m) ? "o" + Pa(m) : (typeof m).charAt(0) + m;
                Object.prototype.hasOwnProperty.call(a, m) || (a[m] = !0, d[f++] = l)
            }
            d.length = f;
            e.length = g
        } else if (f)
            for (a = {}, 0 < d.length && (a[d[0]] = !0), 1 < d.length && (a[d[1]] = !0), g = e.length - 1; 0 <= g; g--)
                if (!a[e[g]]) {
                    e[g] = c;
                    break
                } b.update(e,
            c)
    },
    lw = function(a, b) {
        "auto" == b && (b = "");
        a.c != b && (a.c = b, a.dispatchEvent({
            type: "detectSrcUpdated",
            data: a.c
        }))
    },
    pw = function(a) {
        for (var b = DATA.RecentLanguages.recent_sl, c = 0; c < b.length; ++c) a.o.push(b[c])
    },
    qw = function(a) {
        for (var b = DATA.RecentLanguages.recent_tl, c = 0; c < b.length; ++c) a.m.push(b[c])
    },
    rw = function(a) {
        a.C = [];
        a.N = [];
        for (var b = window.DEFAULT_SOURCES || [], c = window.DEFAULT_TARGETS || [], d = 0; d < b.length; d++) sb(a.C, b[d]);
        for (b = 0; b < c.length; b++) sb(a.N, c[b])
    },
    sw = function(a) {
        if (!a || 0 == a.length) return "";
        for (var b = [], c = 0; c < a.length; ++c) b.push(a[c]);
        return b.join("|")
    },
    ow = function(a, b, c, d, e) {
        a.dispatchEvent({
            type: c,
            data: b,
            Zh: 6 == d
        });
        e && (3 == d || 4 == d) && a.a == a.b && "zh-CN" != a.a && e();
        4 != d && 3 != d || a.dispatchEvent("languageSelected")
    },
    tw = function(a, b) {
        for (var c = [], d = 0; d < a.length && !(a[d] != b && c.push(a[d]), 3 <= c.length); ++d);
        return c
    },
    nw = function(a, b) {
        if ("auto" != a) {
            for (var c = 0; c < b.length && b[c] != a; ++c);
            c == b.length ? (b.unshift(a), 10 < b.length && b.pop()) : (b.splice(c, 1), b.unshift(a))
        }
    },
    iw = function(a, b) {
        for (var c = {}, d = [], e = 0; e < b.length &&
            3 > d.length; e++) d.push(b[e]), c[b[e]] = !0;
        for (e = 0; e < a.length && 3 > d.length; e++) null == c[a[e]] && (c[a[e]] = !0, d.push(a[e]));
        return d
    };
var xw = function(a, b) {
        var c = 0,
            d = 0;
        if (uw(a)) c = a.selectionStart, d = b ? -1 : a.selectionEnd;
        else if (vw()) {
            var e = ww(a),
                f = e[0];
            e = e[1];
            if (f.inRange(e)) {
                f.setEndPoint("EndToStart", e);
                if ("textarea" == a.type) {
                    a = e.duplicate();
                    var g = f.text;
                    c = g;
                    e = d = a.text;
                    for (var k = !1; !k;) 0 == f.compareEndPoints("StartToEnd", f) ? k = !0 : (f.moveEnd("character", -1), f.text == g ? c += "\r\n" : k = !0);
                    if (b) b = [c.length, -1];
                    else {
                        for (b = !1; !b;) 0 == a.compareEndPoints("StartToEnd", a) ? b = !0 : (a.moveEnd("character", -1), a.text == d ? e += "\r\n" : b = !0);
                        b = [c.length, c.length +
                            e.length
                        ]
                    }
                    return b
                }
                c = f.text.length;
                d = b ? -1 : f.text.length + e.text.length
            }
        }
        return [c, d]
    },
    ww = function(a) {
        var b = a.ownerDocument || a.document,
            c = b.selection.createRange();
        "textarea" == a.type ? (b = b.body.createTextRange(), b.moveToElementText(a)) : b = a.createTextRange();
        return [b, c]
    },
    yw = function(a, b) {
        "textarea" == a.type && (b = $d(a.value.substring(0, b)).length);
        return b
    },
    uw = function(a) {
        try {
            return "number" == typeof a.selectionStart
        } catch (b) {
            return !1
        }
    },
    vw = function() {
        return y && !Qe("9")
    };
var zw = function(a, b, c, d) {
    var e = DATA.DisplayLanguage,
        f = DATA.MaxSingleQueryLength;
    this.b = a;
    this.h = b;
    this.L = e;
    this.g = c;
    this.c = f;
    this.a = d || null;
    this.o = !1;
    this.m = new Gm;
    this.m.c = "webapp";
    this.F = K.M()
};
zw.prototype.init = function() {
    G(this.b, "change", this.w, !1, this);
    G(document, "selectionchange", this.C, !1, this);
    G(new Qv(this.b.j()), "paste", this.G, !1, this)
};
zw.prototype.w = function(a) {
    var b = this.b.Y().length;
    this.a && Nv(this.a, b);
    var c = "set" == a.changeType;
    a = "key" == a.changeType;
    if (b > this.c) {
        if (!yq(this.g.j()) && !a || c) this.g.setVisible(!0), a = this.h.c, "" == a && (a = this.h.a), c = b - this.c, O(this.m, "webapp", "ov", "1", {
            sl: this.h.a,
            tl: this.h.b,
            dl: a,
            hl: this.L,
            ql: b,
            ol: c
        }), a = this.F, M(a, pm(a, 250, b, c)), this.a && Mv(this.a, !0), b = this.b.Y().substring(this.c), this.g.g = b, b = this.g, c = {
            maximum_input_count: Iv(b.W, this.c)
        }, a = Aw(b.V, c), E(B("snck-msg", b.j()), a), c = Aw(b.X, c), E(B("ovfl-xlt",
            b.j()), c);
        this.b.g(this.b.Y().substring(0, this.c));
        this.a && Nv(this.a, this.c)
    } else b < this.c && this.a && Mv(this.a, !1), (c || 0 == b) && Bw(this)
};
var Bw = function(a) {
    a.g.g = "";
    a.g.setVisible(!1);
    a.a && Mv(a.a, !1)
};
zw.prototype.C = function() {
    var a = xw(this.b.j(), !1),
        b = this.b.Y().length;
    this.o = 0 != b && 0 == a[0] && a[1] == b
};
zw.prototype.G = function() {
    this.o && Bw(this)
};
var Cw = function(a, b, c, d, e, f, g, k) {
    X.call(this);
    this.c = Gm.M();
    this.R = a;
    this.N = b;
    this.W = c;
    this.V = d;
    this.X = e;
    this.b = f;
    this.m = g;
    this.h = null != k ? k : null;
    this.F = K.M();
    this.w = !1
};
t(Cw, X);
Cw.prototype.setVisible = function(a) {
    a && !this.w ? (this.c.log("community-promo", "show-" + this.b), sm(this.F, this.m), W(this.g, !0)) : W(this.g, !1)
};
Cw.prototype.Da = function(a) {
    Cw.D.Da.call(this, a);
    this.g = Wp(ao, {
        vm: this.R,
        um: this.N,
        Yn: this.W,
        Pn: this.V,
        url: this.X,
        id: this.b
    });
    a.appendChild(this.g);
    var b = B("cp-dismiss", a);
    Y(this).listen(b, "click", this.C);
    a = B("cp-promo-href", a);
    Y(this).listen(a, "click", this.K)
};
Cw.prototype.C = function() {
    this.c.log("community-promo", "dismiss-" + this.b);
    Km(this.c, "/translate/uc?ua=dcp&uav=" + this.b);
    var a = this.F;
    M(a, rm(a, 74, this.m));
    this.setVisible(!1);
    this.w = !0
};
Cw.prototype.K = function(a) {
    this.c.log("community-promo", "click-" + this.b);
    tm(this.F, this.m);
    this.h && this.h.a() && (this.h.reset(), a.preventDefault(), a.stopPropagation())
};
var Dw = function(a, b) {
    this.a = a;
    this.b = b || null
};
Dw.prototype.Ua = function() {
    return this.a
};
Dw.prototype.tb = function() {
    return this.b
};
var Ew = function() {};
t(Ew, mr);
Fa(Ew);
h = Ew.prototype;
h.$c = function() {
    return "menuitem"
};
h.mb = function(a) {
    var b = D("DIV", null, a.Ua());
    T(b, "gt-is-sg");
    var c = D("DIV", null, "");
    T(c, a.ii ? "gt-is-ld-top" : "gt-is-ld");
    c = ["DIV", pr(this, a), c];
    var d = D("SPAN");
    if (a.Pc) {
        var e = new Sr(null, new Nt);
        e.render(d);
        T(e.j(), "gt-is-flag");
        os(e.j(), a.Dg, void 0);
        e.setVisible(!1);
        a.Vb = e;
        d.id = Uq(e)
    }
    e = D("DIV");
    T(e, "gt-is-ca");
    var f = new Sr;
    f.v = e;
    a.rc = f;
    c = c.concat([b, d, e]);
    a.un && (b = D("DIV", null, a.tb()), c.push(b), T(b, "gt-is-tr"));
    b = D.apply(null, c);
    b.id = Uq(a);
    return a.v = b
};
h.Zc = function(a) {
    return "DIV" == a.tagName
};
h.wa = function() {
    return "gt-is-itm"
};
h.yd = function(a, b, c) {
    Ew.D.yd.call(this, a, b, c);
    2 == b && a.Pc && a.Vb && !a.Md && a.Vb.setVisible(c)
};
var Fw = function(a, b, c, d, e, f, g) {
    Z.call(this, a.Ua(), f || Ew.M(), g);
    this.$d = a;
    this.Pc = b;
    this.Dg = c;
    this.rc = null;
    this.ii = d;
    this.un = e;
    this.Md = !1;
    this.Oa(1, !1)
};
t(Fw, Z);
Fw.prototype.Ua = function() {
    return this.$d.Ua()
};
Fw.prototype.tb = function() {
    return this.$d.tb()
};
Fw.prototype.vb = function(a) {
    this.Pc && pg(this.Vb.j(), a.target) ? (this.Md = !0, this.Vb.vb(a)) : this.rc && pg(this.rc.j(), a.target) ? this.rc.vb(a) : Fw.D.vb.call(this, a)
};
Fw.prototype.Eb = function(a) {
    if (this.rc && pg(this.rc.j(), a.target)) this.rc.Eb(a);
    else if (this.Pc && pg(this.Vb.j(), a.target) && this.Md) this.Vb.Eb(a), this.Md = !1, this.Ea(2) || this.Vb.setVisible(!1);
    else {
        if (this.Pc) {
            var b = this.getParent();
            w(b.b, function(c) {
                c.Md && (c.Md = !1, Lr(c.Vb, !1));
                c != this && c.Vb.setVisible(!1)
            })
        }
        Fw.D.Eb.call(this, a)
    }
};
var Gw = function(a, b, c, d) {
    var e = "md";
    null != d && d && (e = "m" + e);
    Gs.call(this, a, e, MSG_DEFINITIONS_OF, "", 7);
    this.K = b;
    this.C = null != c ? c : !0
};
t(Gw, Gs);
Gw.prototype.update = function(a, b, c, d) {
    Gw.D.update.call(this, a, b, c, d);
    if (!d || 0 == H(d, 12) && 0 == H(d, 15)) return !1;
    fg(this.b);
    this.Ed();
    this.g = 0;
    a = H(d, 12);
    b = 3 > a;
    for (var e = c = 0; e < H(d, 12); e++) c += (new Lo(Hl(d, 12, e))).a();
    c = 5 > c ? c : 3;
    for (e = this.w = 0; e < a; ++e) {
        var f = new Lo(Hl(d, 12, e)),
            g = I(new Lo(Hl(d, 12, e)), 2),
            k = D("DIV", {
                "class": "gt-cd-pos"
            });
        this.b.appendChild(k);
        E(k, I(f, 0));
        k = d;
        var l = b,
            m = c,
            q = Math.ceil(m / a),
            r = D("DIV", {
                "class": "gt-def-list"
            }),
            u = jc(this.Ba) ? "rtl" : "ltr";
        cq(r, {
            direction: u
        });
        for (u = 0; u < f.a(); ++u) {
            var z =
                f.b(u),
                P = I(z, 0),
                L = I(z, 2);
            var Ma = k;
            for (var Kb = [], Ha = 0; Ha < H(Ma, 11); ++Ha)
                for (var Lb = new fp(Hl(Ma, 11, Ha)), yg = 0; yg < Lb.a(); ++yg) {
                    var Be = Lb.b(yg);
                    if (I(z, 1) == I(Be, 1)) {
                        for (var Um = [], Uj = 0; Uj < H(Be, 0); ++Uj) sb(Um, Gh(Be, 0, Uj));
                        sb(Kb, Um)
                    }
                }
            Ma = Kb;
            if (z = 1 > u || l && u < q && this.w < m) this.w += 1;
            P = Hw(this, u + 1, P, L, Ma, z);
            r.appendChild(P);
            this.g += 1
        }
        this.b.appendChild(r)
    }
    for (e = 0; e < H(d, 15); e++) l = new Wo(Hl(d, 15, e)), m = I(l, 1), k = I(l, 2), f = D("DIV", {
        "class": "gt-def-row"
    }), m = D("DIV", {
        "class": "gt-kp-desc"
    }, m), q = D("A"), q.setAttribute("href",
        I(l, 3)), q.setAttribute("target", "_blank"), l = D("IMG", {
        "class": "gt-kp-image"
    }), l.setAttribute("src", k), q.appendChild(l), f.appendChild(q), f.appendChild(m), this.b.appendChild(f);
    g && (this.cf = g, Hs(this, g));
    if (!b && this.g > 1 * a || b && this.g > c) d = MSG_N_MORE_DEFINITIONS_LABEL.replace("%1$s", (this.g - this.w).toLocaleString(this.Ra)), Is(this, d, MSG_FEWER_DEFINITIONS_LABEL);
    else
        for (d = Nf("gt-card-expand-wrapper", this.j()), g = 0; g < d.length; g++) a = d[g], B("gt-def-synonym", a) && U(a, "gt-card-expand-wrapper");
    this.setVisible(!0);
    return !0
};
Gw.prototype.aa = function() {
    Gw.D.aa.call(this);
    Y(this).listen(this.j(), "click", this.R)
};
Gw.prototype.Da = function(a) {
    Gw.D.Da.call(this, a)
};
var Hw = function(a, b, c, d, e, f) {
    var g = jc(a.Ma) ? "rtl" : "ltr";
    b = Xp(io, {
        yk: b.toLocaleString(a.Ra),
        Mj: a.K,
        zk: c,
        Pk: d,
        Sn: MSG_SYNONYMS_LOWERCASE,
        Rn: e,
        Ch: g,
        lk: a.C,
        Ba: a.Ba
    });
    a.C && w(Nf("gt-cd-cl", b), function(k) {
        this.c.push(k)
    }, a);
    Ks(a, B("gt-mt-md", b), c);
    (c = B("gt-ex-mt", b)) && Ks(a, c, d);
    (d = B("gt-def-synonym-title", b)) && jc(a.Ra) != jc(a.Ba) && (a = jc(a.Ra), cq(d, "direction", a ? "rtl" : "ltr"), cq(d, "padding-" + (a ? "left" : "right"), "8px"));
    return Js(b, f)
};
Gw.prototype.R = function(a) {
    Qp(a.target, "gt-cd-cl") && this.dispatchEvent(new F("a", a.target))
};
Gw.prototype.fb = function() {
    return this.C ? this.ze() : this.g
};
var Jw = function(a) {
        Iw();
        return kd(a)
    },
    Kw = function(a) {
        Iw();
        return tc(a)
    },
    Iw = Ea;
var Lw = function(a, b, c) {
    var d = "ex";
    null != c && c && (d = "m" + d);
    this.K = b;
    Gs.call(this, a, d, MSG_EXAMPLES_OF, MSG_EXAMPLES, 9);
    this.g = new jp;
    this.C = this.w = "ltr"
};
t(Lw, Gs);
Lw.prototype.update = function(a, b, c, d) {
    Lw.D.update.call(this, a, b, c, d);
    fg(this.b);
    this.g = new jp(d.Wa[13]);
    if (0 == H(this.g, 0)) return !1;
    this.setVisible(!0);
    3 <= H(this.g, 0) && (a = MSG_N_MORE_EXAMPLES_LABEL.replace("%1$s", (H(this.g, 0) - 1).toLocaleString(this.Ra)), Is(this, a, MSG_FEWER_EXAMPLES_LABEL));
    this.w = jc(this.Ba) ? "rtl" : "ltr";
    this.C = jc(this.Ma) ? "rtl" : "ltr";
    for (a = 0; a < H(this.g, 0); ++a) {
        b = 0 == a || 1 == a && 2 == H(this.g, 0);
        d = new hp(Hl(this.g, 0, a));
        var e = I(d, 0);
        c = d.Be();
        d = I(d, 2);
        var f = MSG_MT_FROM_GOOGLE,
            g = this.w;
        Iw();
        e = Md(e, null);
        c = Xp(co, {
            Mn: g,
            Zf: e,
            rm: d,
            tm: c,
            Ch: this.C,
            Ao: f,
            Jn: this.K
        });
        b = Js(c, b);
        this.b.appendChild(b)
    }
    return !0
};
Lw.prototype.wj = function() {
    var a = {};
    a.total = H(this.g, 0);
    return a
};
Lw.prototype.fb = function() {
    return H(this.g, 0)
};
var Mw = function() {};
Fa(Mw);
var Nw = function(a) {
        a: {
            var b = a.changedTouches[0];
            switch (a.type) {
                case "touchstart":
                    var c = "mousedown";
                    break;
                case "touchmove":
                    c = "mousemove";
                    break;
                case "touchend":
                    c = "mouseup";
                    break;
                default:
                    b = null;
                    break a
            }
            var d = document.createEvent("MouseEvent");d.initMouseEvent(c, !0, !0, window, 1, b.screenX, b.screenY, b.clientX, b.clientY, !1, !1, !1, !1, 0, null);b = d
        }
        null != b && (a.changedTouches[0].target.dispatchEvent(b), a.preventDefault())
    },
    Ow = Ve || We || Xe,
    Pw = function(a, b) {
        Ow && (b.addEventListener("touchstart", Nw, !0), b.addEventListener("touchmove",
            Nw, !0), b.addEventListener("touchend", Nw, !0), b.addEventListener("touchcancel", Nw, !0))
    };
var Qw = function(a) {
    this.a = a
};
Fa(Qw);
var Rw = function(a, b) {
    a && (a.tabIndex = b ? 0 : -1)
};
Qw.prototype.c = function(a) {
    return a.a.b("DIV", Sw(this, a).join(" "))
};
Qw.prototype.b = function(a) {
    return a
};
Qw.prototype.zf = function(a) {
    return "DIV" == a.tagName
};
var Vw = function(a, b, c) {
        c.id && Vq(b, c.id);
        var d = a.Ee(),
            e = !1,
            f = Op(c);
        f && w(f, function(g) {
            g == d ? e = !0 : g && (g == d + "-disabled" ? b.oa(!1) : g == d + "-horizontal" ? Tw(b, "horizontal") : g == d + "-vertical" && Tw(b, "vertical"))
        }, a);
        e || T(c, d);
        Uw(a, b, a.b(c));
        return c
    },
    Uw = function(a, b, c) {
        if (c)
            for (var d = c.firstChild, e; d && d.parentNode == c;) {
                e = d.nextSibling;
                if (1 == d.nodeType) {
                    var f = a.Ig(d);
                    f && (f.v = d, b.isEnabled() || f.oa(!1), b.jb(f), f.ba(d))
                } else d.nodeValue && "" != yc(d.nodeValue) || c.removeChild(d);
                d = e
            }
    };
Qw.prototype.Ig = function(a) {
    a: {
        v(a);a = Op(a);
        for (var b = 0, c = a.length; b < c; b++) {
            var d = a[b];
            if (d = d in Br ? Br[d]() : null) {
                a = d;
                break a
            }
        }
        a = null
    }
    return a
};
Qw.prototype.Ng = function(a) {
    a = a.j();
    v(a, "The container DOM element cannot be null.");
    Dq(a, !0, ye);
    y && (a.hideFocus = !0);
    var b = this.a;
    b && Gp(a, b)
};
Qw.prototype.Ee = function() {
    return "goog-container"
};
var Sw = function(a, b) {
        a = a.Ee();
        var c = [a, "horizontal" == b.Cd ? a + "-horizontal" : a + "-vertical"];
        b.isEnabled() || c.push(a + "-disabled");
        return c
    },
    Ww = function() {
        return "vertical"
    };
var Xw = function(a, b, c) {
    X.call(this, c);
    this.Gc = b || Qw.M();
    this.Cd = a || Ww()
};
t(Xw, X);
h = Xw.prototype;
h.Xd = null;
h.He = null;
h.Gc = null;
h.Cd = null;
h.Hc = !0;
h.Yc = !0;
h.vd = !0;
h.Ka = -1;
h.$a = null;
h.Kc = !1;
h.Bc = null;
var Yw = function(a) {
        return a.Xd || a.j()
    },
    ax = function(a, b) {
        if (a.vd) {
            var c = Yw(a),
                d = a.ya;
            a.Xd = b;
            var e = Yw(a);
            d && (a.Xd = c, Zw(a, !1), a.Xd = b, er($w(a), e), Zw(a, !0))
        } else throw Error("Can't set key event target for container that doesn't support keyboard focus!");
    },
    $w = function(a) {
        return a.He || (a.He = new fr(Yw(a)))
    };
h = Xw.prototype;
h.Ja = function() {
    this.v = this.Gc.c(this)
};
h.Zb = function() {
    return this.Gc.b(this.j())
};
h.Xc = function(a) {
    return this.Gc.zf(a)
};
h.Da = function(a) {
    this.v = Vw(this.Gc, this, a);
    "none" == a.style.display && (this.Hc = !1)
};
h.aa = function() {
    Xw.D.aa.call(this);
    $q(this, function(b) {
        b.ya && bx(this, b)
    }, this);
    var a = this.j();
    this.Gc.Ng(this);
    this.setVisible(this.Hc, !0);
    Y(this).listen(this, "enter", this.Sg).listen(this, "highlight", this.Fe).listen(this, "unhighlight", this.Og).listen(this, "open", this.Hl).listen(this, "close", this.al).listen(a, Sg.Jd, this.vb).listen(If(a), [Sg.Kd, Sg.me], this.yl).listen(a, [Sg.Jd, Sg.Kd, Sg.me, "mouseover", "mouseout", "contextmenu"], this.jl);
    this.vd && Zw(this, !0)
};
var Zw = function(a, b) {
    var c = Y(a),
        d = Yw(a);
    b ? c.listen(d, "focus", a.wi).listen(d, "blur", a.Af).listen($w(a), "key", a.Ya) : c.Ga(d, "focus", a.wi).Ga(d, "blur", a.Af).Ga($w(a), "key", a.Ya)
};
h = Xw.prototype;
h.bb = function() {
    this.Qb(-1);
    this.$a && this.$a.Xa(!1);
    this.Kc = !1;
    Xw.D.bb.call(this)
};
h.T = function() {
    Xw.D.T.call(this);
    this.He && (this.He.Ia(), this.He = null);
    this.Gc = this.$a = this.Bc = this.Xd = null
};
h.Sg = function() {
    return !0
};
h.Fe = function(a) {
    var b = dr(this, a.target);
    if (-1 < b && b != this.Ka) {
        var c = cx(this);
        c && c.Mb(!1);
        this.Ka = b;
        c = cx(this);
        this.Kc && Lr(c, !0);
        this.$a && c != this.$a && (ur(c, 64) ? c.Xa(!0) : this.$a.Xa(!1))
    }
    b = this.j();
    v(b, "The DOM element for the container cannot be null.");
    null != a.target.j() && Ip(b, "activedescendant", a.target.j().id)
};
h.Og = function(a) {
    a.target == cx(this) && (this.Ka = -1);
    a = this.j();
    v(a, "The DOM element for the container cannot be null.");
    a.removeAttribute(Hp("activedescendant"))
};
h.Hl = function(a) {
    (a = a.target) && a != this.$a && a.getParent() == this && (this.$a && this.$a.Xa(!1), this.$a = a)
};
h.al = function(a) {
    a.target == this.$a && (this.$a = null);
    var b = this.j(),
        c = a.target.j();
    b && a.target.Ea(2) && c && Lp(b, c)
};
h.vb = function(a) {
    this.Yc && (this.Kc = !0);
    var b = Yw(this);
    b && zg(b) && Ag(b) ? b.focus() : a.preventDefault()
};
h.yl = function() {
    this.Kc = !1
};
h.jl = function(a) {
    a: {
        var b = a.target;
        if (this.Bc)
            for (var c = this.j(); b && b !== c;) {
                var d = b.id;
                if (d in this.Bc) {
                    b = this.Bc[d];
                    break a
                }
                b = b.parentNode
            }
        b = null
    }
    if (b) switch (a.type) {
        case Sg.Jd:
            b.vb(a);
            break;
        case Sg.Kd:
        case Sg.me:
            b.Eb(a);
            break;
        case "mouseover":
            b.Ie(a);
            break;
        case "mouseout":
            b.Vg(a);
            break;
        case "contextmenu":
            b.Me(a)
    }
};
h.wi = function() {};
h.Af = function() {
    this.Qb(-1);
    this.Kc = !1;
    this.$a && this.$a.Xa(!1)
};
h.Ya = function(a) {
    return this.isEnabled() && this.isVisible() && (0 != ar(this) || this.Xd) && this.Ge(a) ? (a.preventDefault(), a.stopPropagation(), !0) : !1
};
h.Ge = function(a) {
    var b = cx(this);
    if (b && "function" == typeof b.Ya && b.Ya(a) || this.$a && this.$a != b && "function" == typeof this.$a.Ya && this.$a.Ya(a)) return !0;
    if (a.shiftKey || a.ctrlKey || a.metaKey || a.altKey) return !1;
    switch (a.keyCode) {
        case 27:
            if (this.vd) Yw(this).blur();
            else return !1;
            break;
        case 36:
            dx(this);
            break;
        case 35:
            ex(this);
            break;
        case 38:
            if ("vertical" == this.Cd) fx(this);
            else return !1;
            break;
        case 37:
            if ("horizontal" == this.Cd) cr(this) ? gx(this) : fx(this);
            else return !1;
            break;
        case 40:
            if ("vertical" == this.Cd) gx(this);
            else return !1;
            break;
        case 39:
            if ("horizontal" == this.Cd) cr(this) ? fx(this) : gx(this);
            else return !1;
            break;
        default:
            return !1
    }
    return !0
};
var bx = function(a, b) {
    var c = b.j();
    c = c.id || (c.id = Uq(b));
    a.Bc || (a.Bc = {});
    a.Bc[c] = b
};
Xw.prototype.jb = function(a, b) {
    gb(a, Z, "The child of a container must be a control");
    Xw.D.jb.call(this, a, b)
};
Xw.prototype.qd = function(a, b, c) {
    gb(a, Z);
    a.Se |= 2;
    a.Se |= 64;
    a.Oa(32, !1);
    Fr(a, !1);
    var d = a.getParent() == this ? dr(this, a) : -1;
    Xw.D.qd.call(this, a, b, c);
    a.ya && this.ya && bx(this, a);
    a = d; - 1 == a && (a = ar(this));
    a == this.Ka ? this.Ka = Math.min(ar(this) - 1, b) : a > this.Ka && b <= this.Ka ? this.Ka++ : a < this.Ka && b > this.Ka && this.Ka--
};
Xw.prototype.removeChild = function(a, b) {
    a = "string" === typeof a ? Xq(this, a) : a;
    gb(a, Z);
    if (a) {
        var c = dr(this, a); - 1 != c && (c == this.Ka ? (a.Mb(!1), this.Ka = -1) : c < this.Ka && this.Ka--);
        var d = a.j();
        d && d.id && this.Bc && (c = this.Bc, d = d.id, d in c && delete c[d])
    }
    a = Xw.D.removeChild.call(this, a, b);
    Fr(a, !0);
    return a
};
var Tw = function(a, b) {
    if (a.j()) throw Error("Component already rendered");
    a.Cd = b
};
Xw.prototype.isVisible = function() {
    return this.Hc
};
Xw.prototype.setVisible = function(a, b) {
    if (b || this.Hc != a && this.dispatchEvent(a ? "show" : "hide")) {
        this.Hc = a;
        var c = this.j();
        c && (W(c, a), this.vd && Rw(Yw(this), this.Yc && this.Hc), b || this.dispatchEvent(this.Hc ? "aftershow" : "afterhide"));
        return !0
    }
    return !1
};
Xw.prototype.isEnabled = function() {
    return this.Yc
};
Xw.prototype.oa = function(a) {
    this.Yc != a && this.dispatchEvent(a ? "enable" : "disable") && (a ? (this.Yc = !0, $q(this, function(b) {
        b.Ej ? delete b.Ej : b.oa(!0)
    })) : ($q(this, function(b) {
        b.isEnabled() ? b.oa(!1) : b.Ej = !0
    }), this.Kc = this.Yc = !1), this.vd && Rw(Yw(this), a && this.Hc))
};
var hx = function(a, b) {
    b != a.vd && a.ya && Zw(a, b);
    a.vd = b;
    a.Yc && a.Hc && Rw(Yw(a), b)
};
Xw.prototype.Qb = function(a) {
    (a = br(this, a)) ? a.Mb(!0): -1 < this.Ka && cx(this).Mb(!1)
};
var cx = function(a) {
        return br(a, a.Ka)
    },
    dx = function(a) {
        ix(a, function(b, c) {
            return (b + 1) % c
        }, ar(a) - 1)
    },
    ex = function(a) {
        ix(a, function(b, c) {
            b--;
            return 0 > b ? c - 1 : b
        }, 0)
    },
    gx = function(a) {
        ix(a, function(b, c) {
            return (b + 1) % c
        }, a.Ka)
    },
    fx = function(a) {
        ix(a, function(b, c) {
            b--;
            return 0 > b ? c - 1 : b
        }, a.Ka)
    },
    ix = function(a, b, c) {
        c = 0 > c ? dr(a, a.$a) : c;
        var d = ar(a);
        c = b.call(a, c, d);
        for (var e = 0; e <= d;) {
            var f = br(a, c);
            if (f && a.$h(f)) {
                a.Qb(c);
                break
            }
            e++;
            c = b.call(a, c, d)
        }
    };
Xw.prototype.$h = function(a) {
    return a.isVisible() && a.isEnabled() && ur(a, 2)
};
var jx = function() {};
t(jx, mr);
Fa(jx);
jx.prototype.wa = function() {
    return "goog-menuheader"
};
var kx = function(a, b, c) {
    Z.call(this, a, c || jx.M(), b);
    this.Oa(1, !1);
    this.Oa(2, !1);
    this.Oa(4, !1);
    this.Oa(32, !1);
    this.bd = 1
};
t(kx, Z);
Cr("goog-menuheader", function() {
    return new kx(null)
});
var lx = function() {
    this.c = []
};
t(lx, mr);
Fa(lx);
var mx = function(a, b) {
    var c = a.c[b];
    if (!c) {
        switch (b) {
            case 0:
                c = a.wa() + "-highlight";
                break;
            case 1:
                c = a.wa() + "-checkbox";
                break;
            case 2:
                c = a.wa() + "-content"
        }
        a.c[b] = c
    }
    return c
};
h = lx.prototype;
h.$c = function() {
    return "menuitem"
};
h.mb = function(a) {
    var b = a.a.b("DIV", pr(this, a).join(" "), nx(this, a.Sa(), a.a));
    ox(this, a, b, ur(a, 8) || ur(a, 16));
    return b
};
h.Db = function(a) {
    return a && a.firstChild
};
h.Va = function(a, b) {
    v(b);
    var c = mg(b),
        d = mx(this, 2);
    c && Qp(c, d) || b.appendChild(nx(this, b.childNodes, a.a));
    Qp(b, "goog-option") && (a.Oa(16, !0), a && b && ox(this, a, b, !0));
    return lx.D.Va.call(this, a, b)
};
h.Lb = function(a, b) {
    var c = this.Db(a),
        d = px(this, a) ? c.firstChild : null;
    lx.D.Lb.call(this, a, b);
    d && !px(this, a) && c.insertBefore(d, c.firstChild || null)
};
var nx = function(a, b, c) {
        a = mx(a, 2);
        return c.b("DIV", a, b)
    },
    px = function(a, b) {
        return (b = a.Db(b)) ? (b = b.firstChild, a = mx(a, 1), !!b && ng(b) && Qp(b, a)) : !1
    },
    ox = function(a, b, c, d) {
        tr(a, c, b.C());
        vr(a, b, c);
        d != px(a, c) && (V(c, "goog-option", d), c = a.Db(c), d ? (a = mx(a, 1), c.insertBefore(b.a.b("DIV", a), c.firstChild || null)) : c.removeChild(c.firstChild))
    };
lx.prototype.a = function(a) {
    switch (a) {
        case 2:
            return mx(this, 0);
        case 16:
        case 8:
            return "goog-option-selected";
        default:
            return lx.D.a.call(this, a)
    }
};
lx.prototype.g = function(a) {
    var b = mx(this, 0);
    switch (a) {
        case "goog-option-selected":
            return 16;
        case b:
            return 2;
        default:
            return lx.D.g.call(this, a)
    }
};
lx.prototype.wa = function() {
    return "goog-menuitem"
};
var qx = function(a, b, c, d) {
    Z.call(this, a, d || lx.M(), c);
    this.na = b
};
t(qx, Z);
h = qx.prototype;
h.Y = function() {
    var a = this.na;
    return null != a ? a : this.sb()
};
h.Oa = function(a, b) {
    qx.D.Oa.call(this, a, b);
    switch (a) {
        case 8:
            this.Ea(16) && !b && this.cd(!1);
            (a = this.j()) && this && a && ox(this.c, this, a, b);
            break;
        case 16:
            (a = this.j()) && this && a && ox(this.c, this, a, b)
    }
};
h.sb = function() {
    var a = this.Sa();
    return Ia(a) ? (a = kb(a, function(b) {
        return ng(b) && (Qp(b, "goog-menuitem-accel") || Qp(b, "goog-menuitem-mnemonic-separator")) ? "" : Dg(b)
    }).join(""), ae(a)) : qx.D.sb.call(this)
};
h.Eb = function(a) {
    var b = this.getParent();
    if (b) {
        var c = b.X;
        b.X = null;
        if (b = c && "number" === typeof a.clientX) b = new Ef(a.clientX, a.clientY), b = c == b ? !0 : c && b ? c.x == b.x && c.a == b.a : !1;
        if (b) return
    }
    qx.D.Eb.call(this, a)
};
h.Sd = function(a) {
    return a.keyCode == this.ih && this.yc(a) ? !0 : qx.D.Sd.call(this, a)
};
h.Yk = function() {
    return this.ih
};
Cr("goog-menuitem", function() {
    return new qx(null)
});
qx.prototype.C = function() {
    return ur(this, 16) ? "menuitemcheckbox" : ur(this, 8) ? "menuitemradio" : qx.D.C.call(this)
};
qx.prototype.getParent = function() {
    return Z.prototype.getParent.call(this)
};
qx.prototype.Od = function() {
    return Z.prototype.Od.call(this)
};
var rx = function() {};
t(rx, mr);
Fa(rx);
rx.prototype.mb = function(a) {
    return a.a.b("DIV", this.wa())
};
rx.prototype.Va = function(a, b) {
    b.id && Vq(a, b.id);
    if ("HR" == b.tagName) {
        var c = b;
        b = this.mb(a);
        gg(b, c);
        jg(c)
    } else T(b, this.wa());
    return b
};
rx.prototype.Lb = function() {};
rx.prototype.wa = function() {
    return "goog-menuseparator"
};
var sx = function(a, b) {
    Z.call(this, null, a || rx.M(), b);
    this.Oa(1, !1);
    this.Oa(2, !1);
    this.Oa(4, !1);
    this.Oa(32, !1);
    this.bd = 1
};
t(sx, Z);
sx.prototype.aa = function() {
    sx.D.aa.call(this);
    var a = this.j();
    v(a, "The DOM element for the separator cannot be null.");
    Gp(a, "separator")
};
Cr("goog-menuseparator", function() {
    return new sx
});
var ux = function(a) {
    this.a = a || "menu"
};
t(ux, Qw);
Fa(ux);
h = ux.prototype;
h.zf = function(a) {
    return "UL" == a.tagName || ux.D.zf.call(this, a)
};
h.Ig = function(a) {
    return "HR" == a.tagName ? new sx : ux.D.Ig.call(this, a)
};
h.oc = function(a, b) {
    return pg(a.j(), b)
};
h.Ee = function() {
    return "goog-menu"
};
h.Ng = function(a) {
    ux.D.Ng.call(this, a);
    a = a.j();
    v(a, "The menu DOM element cannot be null.");
    Ip(a, "haspopup", "true")
};
var vx = function(a) {
    sx.call(this, rx.M(), a)
};
t(vx, sx);
Cr("goog-menuseparator", function() {
    return new sx
});
var wx = function(a, b) {
    Xw.call(this, "vertical", b || ux.M(), a);
    hx(this, !1)
};
t(wx, Xw);
h = wx.prototype;
h.oe = !0;
h.oc = function(a) {
    if (this.Gc.oc(this, a)) return !0;
    for (var b = 0, c = ar(this); b < c; b++) {
        var d = br(this, b);
        if ("function" == typeof d.oc && d.oc(a)) return !0
    }
    return !1
};
h.fb = function() {
    return ar(this)
};
h.setVisible = function(a, b, c) {
    (b = wx.D.setVisible.call(this, a, b)) && a && this.ya && this.oe && Yw(this).focus();
    a && c && "number" === typeof c.clientX ? this.X = new Ef(c.clientX, c.clientY) : this.X = null;
    return b
};
h.Sg = function(a) {
    this.oe && Yw(this).focus();
    return wx.D.Sg.call(this, a)
};
h.Ki = function(a) {
    var b = new RegExp("^" + ie(a), "i");
    ix(this, function(c, d) {
        var e = 0 > c ? 0 : c,
            f = !1;
        do {
            ++c;
            c == d && (c = 0, f = !0);
            var g = br(this, c).sb();
            if (g && g.match(b)) return c
        } while (!f || c != e);
        return this.Ka
    }, this.Ka)
};
h.$h = function(a) {
    return a.isEnabled() && a.isVisible() && ur(a, 2)
};
h.Da = function(a) {
    for (var b = this.Gc, c = Mf(this.a.a, "DIV", b.Ee() + "-content", a), d = c.length, e = 0; e < d; e++) Uw(b, this, c[e]);
    wx.D.Da.call(this, a)
};
h.Ge = function(a) {
    var b = wx.D.Ge.call(this, a);
    b || $q(this, function(c) {
        !b && c.Yk && c.ih == a.keyCode && (this.isEnabled() && this.Qb(dr(this, c)), b = c.Ya(a))
    }, this);
    return b
};
h.Qb = function(a) {
    wx.D.Qb.call(this, a);
    (a = br(this, a)) && qq(a.j(), this.j())
};
var xx = function(a, b, c) {
    qx.call(this, a, b, c);
    this.Oa(8, !0)
};
t(xx, qx);
xx.prototype.yc = function() {
    return this.dispatchEvent("action")
};
Cr("goog-option", function() {
    return new xx(null)
});
var yx = function(a, b, c) {
    this.a = a;
    this.g = b;
    this.w = c
};
t(yx, cs);
yx.prototype.b = function(a, b, c) {
    bs(this.a, this.g, a, b, void 0, c, this.w)
};
var zx = function(a, b, c, d) {
    yx.call(this, a, b);
    this.h = c ? 5 : 0;
    this.o = d || void 0
};
t(zx, yx);
zx.prototype.m = function() {
    return this.h
};
zx.prototype.c = function(a) {
    this.h = a
};
zx.prototype.b = function(a, b, c, d) {
    var e = bs(this.a, this.g, a, b, null, c, 10, d, this.o);
    if (e & 496) {
        var f = Ax(e, this.g);
        b = Ax(e, b);
        e = bs(this.a, f, a, b, null, c, 10, d, this.o);
        e & 496 && (f = Ax(e, f), b = Ax(e, b), bs(this.a, f, a, b, null, c, this.h, d, this.o))
    }
};
var Ax = function(a, b) {
    a & 48 && (b ^= 4);
    a & 192 && (b ^= 1);
    return b
};
var Bx = function(a, b, c, d) {
    zx.call(this, a, b, c || d);
    (c || d) && this.c(65 | (d ? 32 : 132))
};
t(Bx, zx);
var Cx = function() {};
t(Cx, Et);
Fa(Cx);
Cx.prototype.Db = function(a) {
    return Cx.D.Db.call(this, a && a.firstChild)
};
Cx.prototype.Va = function(a, b) {
    var c = Mf(document, "*", "goog-menu", b)[0];
    if (c) {
        W(c, !1);
        dg(If(c).body, c);
        var d = new wx;
        d.ba(c);
        a.Ke(d)
    }
    return Cx.D.Va.call(this, a, b)
};
Cx.prototype.ff = function(a, b) {
    return Cx.D.ff.call(this, [b.b("DIV", "goog-inline-block " + (this.wa() + "-caption"), a), b.b("DIV", "goog-inline-block " + (this.wa() + "-dropdown"), "\u00a0")], b)
};
Cx.prototype.wa = function() {
    return "goog-menu-button"
};
var Dx = function() {
    this.c = []
};
t(Dx, lx);
Fa(Dx);
Dx.prototype.mb = function(a) {
    var b = Dx.D.mb.call(this, a);
    v(b);
    T(b, "goog-submenu");
    Ex(this, a, b);
    return b
};
Dx.prototype.Va = function(a, b) {
    b = Dx.D.Va.call(this, a, b);
    v(b);
    T(b, "goog-submenu");
    Ex(this, a, b);
    var c = Mf(document, "DIV", "goog-menu", b);
    if (c.length) {
        var d = new wx(a.a);
        c = c[0];
        W(c, !1);
        a.a.a.body.appendChild(c);
        d.ba(c);
        Fx(a, d)
    }
    return b
};
Dx.prototype.Lb = function(a, b) {
    var c = this.Db(a),
        d = c && c.lastChild;
    Dx.D.Lb.call(this, a, b);
    d && c.lastChild != d && Qp(d, "goog-submenu-arrow") && c.appendChild(d)
};
Dx.prototype.Bf = function(a) {
    Dx.D.Bf.call(this, a);
    var b = a.Zb(),
        c = Mf(a.a.a, "SPAN", "goog-submenu-arrow", b)[0];
    Gx(a, c);
    c != b.lastChild && b.appendChild(c);
    a = a.j();
    v(a, "The sub menu DOM element cannot be null.");
    Ip(a, "haspopup", "true")
};
var Ex = function(a, b, c) {
        var d = b.a.b("SPAN");
        d.className = "goog-submenu-arrow";
        Gx(b, d);
        a.Db(c).appendChild(d)
    },
    Gx = function(a, b) {
        v(b);
        cr(a) ? (T(b, "goog-submenu-arrow-rtl"), E(b, "\u25c4")) : (U(b, "goog-submenu-arrow-rtl"), E(b, "\u25ba"))
    };
var Hx = function(a, b, c, d) {
    qx.call(this, a, b, c, d || Dx.M())
};
t(Hx, qx);
h = Hx.prototype;
h.we = null;
h.uh = null;
h.gh = !1;
h.eb = null;
h.lf = !1;
h.aa = function() {
    Hx.D.aa.call(this);
    Y(this).listen(this.getParent(), "hide", this.Yi);
    this.eb && Ix(this, this.eb, !0)
};
h.bb = function() {
    Y(this).Ga(this.getParent(), "hide", this.Yi);
    this.eb && (Ix(this, this.eb, !1), this.lf || (this.eb.bb(), jg(this.eb.j())));
    Hx.D.bb.call(this)
};
h.T = function() {
    this.eb && !this.lf && this.eb.Ia();
    this.eb = null;
    Hx.D.T.call(this)
};
h.Mb = function(a) {
    Hx.D.Mb.call(this, a);
    a || (this.we && Di(this.we), this.we = Ci(this.Cc, 218, this))
};
h.sh = function() {
    var a = this.getParent();
    a && cx(a) == this && (Jx(this, !0), Kx(this))
};
h.Cc = function() {
    var a = this.eb;
    a && a.getParent() == this && (Jx(this, !1), $q(a, function(b) {
        "function" == typeof b.Cc && b.Cc()
    }))
};
var Lx = function(a) {
    a.we && Di(a.we);
    a.uh && Di(a.uh)
};
Hx.prototype.setVisible = function(a, b) {
    (a = Hx.D.setVisible.call(this, a, b)) && !this.isVisible() && this.Cc();
    return a
};
var Kx = function(a) {
    $q(a.getParent(), function(b) {
        b != this && "function" == typeof b.Cc && (b.Cc(), Lx(b))
    }, a)
};
h = Hx.prototype;
h.Ya = function(a) {
    var b = a.keyCode,
        c = cr(this) ? 37 : 39,
        d = cr(this) ? 39 : 37;
    if (!this.gh) {
        if (!this.isEnabled() || b != c && 13 != b && b != this.ih) return !1;
        this.sh();
        dx(Mx(this));
        Lx(this)
    } else if (!Mx(this).Ya(a))
        if (b == d) this.Cc();
        else return !1;
    a.preventDefault();
    return !0
};
h.Tm = function() {
    if (this.eb.getParent() == this) {
        Lx(this);
        var a = this.Od();
        a.Qb(dr(a, this));
        Kx(this)
    }
};
h.Yi = function(a) {
    a.target == this.Od() && (this.Cc(), Lx(this))
};
h.Ie = function(a) {
    this.isEnabled() && (Lx(this), this.uh = Ci(this.sh, 218, this));
    Hx.D.Ie.call(this, a)
};
h.yc = function(a) {
    Lx(this);
    if (ur(this, 8) || ur(this, 16)) return Hx.D.yc.call(this, a);
    this.sh();
    return !0
};
var Jx = function(a, b) {
        !b && Mx(a) && Mx(a).Qb(-1);
        a.dispatchEvent(Tq(64, b));
        var c = Mx(a);
        b != a.gh && V(v(a.j()), "goog-submenu-open", b);
        if (b != c.isVisible() && (b && (c.ya || c.render(), c.Qb(-1)), c.setVisible(b), b)) {
            c = new zx(a.j(), 12, !1);
            var d = Mx(a),
                e = d.j();
            d.isVisible() || (e.style.visibility = "hidden", W(e, !0));
            c.b(e, 8);
            d.isVisible() || (W(e, !1), e.style.visibility = "visible")
        }
        a.gh = b
    },
    Ix = function(a, b, c) {
        var d = Y(a);
        (c ? d.listen : d.Ga).call(d, b, "enter", a.Tm)
    };
Hx.prototype.fb = function() {
    return ar(Mx(this))
};
var Mx = function(a) {
        a.eb ? a.lf && a.eb.getParent() != a && Yq(a.eb, a) : Fx(a, new wx(a.a));
        a.eb.j() || a.eb.Ja();
        return a.eb
    },
    Fx = function(a, b) {
        var c = a.eb;
        b != c && (c && (a.Cc(), a.ya && Ix(a, c, !1)), a.eb = b, a.lf = !1, b && (Yq(b, a), b.setVisible(!1, !0), b.oe = !1, hx(b, !1), a.ya && Ix(a, b, !0)))
    };
Hx.prototype.oc = function(a) {
    return Mx(this).oc(a)
};
Cr("goog-submenu", function() {
    return new Hx(null)
});
var Nx = function(a, b, c, d, e) {
    Sr.call(this, a, c || Cx.M(), d);
    this.Oa(64, !0);
    this.m = new Bx(null, 9);
    b && this.Ke(b);
    this.ra = null;
    this.N = new Ai(500);
    !Ve && !We || Qe("533.17.9") || (this.Rf = !0);
    this.nd = e || ux.M()
};
t(Nx, Sr);
h = Nx.prototype;
h.Rf = !1;
h.aa = function() {
    Nx.D.aa.call(this);
    Ox(this, !0);
    this.b && Px(this, this.b, !0);
    Ip(Wq(this), "haspopup", !!this.b)
};
h.bb = function() {
    Nx.D.bb.call(this);
    Ox(this, !1);
    if (this.b) {
        this.Xa(!1);
        this.b.bb();
        Px(this, this.b, !1);
        var a = this.b.j();
        a && jg(a)
    }
};
h.T = function() {
    Nx.D.T.call(this);
    this.b && (this.b.Ia(), delete this.b);
    delete this.xb;
    this.N.Ia()
};
h.vb = function(a) {
    Nx.D.vb.call(this, a);
    this.nb() && (this.Xa(!this.Ea(64), a), this.b && (this.b.Kc = this.Ea(64)))
};
h.Eb = function(a) {
    Nx.D.Eb.call(this, a);
    this.b && !this.nb() && (this.b.Kc = !1)
};
h.yc = function() {
    Lr(this, !1);
    return !0
};
h.xl = function(a) {
    this.b && this.b.isVisible() && !this.oc(a.target) && this.Xa(!1)
};
h.oc = function(a) {
    return a && pg(this.j(), a) || this.b && this.b.oc(a) || !1
};
h.Sd = function(a) {
    if (32 == a.keyCode) {
        if (a.preventDefault(), "keyup" != a.type) return !0
    } else if ("key" != a.type) return !1;
    if (this.b && this.b.isVisible()) {
        var b = 13 == a.keyCode || 32 == a.keyCode,
            c = this.b.Ya(a);
        return c && this.b && this.b.$a instanceof Hx || 27 != a.keyCode && !b ? c : (this.Xa(!1), !0)
    }
    return 40 == a.keyCode || 38 == a.keyCode || 32 == a.keyCode || 13 == a.keyCode ? (this.Xa(!0, a), !0) : !1
};
h.Tg = function() {
    this.Xa(!1)
};
h.Fl = function() {
    this.nb() || this.Xa(!1)
};
h.Df = function(a) {
    this.Rf || this.Xa(!1);
    Nx.D.Df.call(this, a)
};
var Qx = function(a) {
    a.b || a.Ke(new wx(a.a, a.nd));
    return a.b || null
};
Nx.prototype.Ke = function(a) {
    var b = this.b;
    if (a != b && (b && (this.Xa(!1), this.ya && Px(this, b, !1), delete this.b), this.ya && Ip(Wq(this), "haspopup", !!a), a)) {
        this.b = a;
        Yq(a, this);
        a.setVisible(!1);
        var c = this.Rf;
        (a.oe = c) && hx(a, !0);
        this.ya && Px(this, a, !0)
    }
    return b
};
var Rx = function(a, b) {
        b && (a.m = b, a.xb = b.a)
    },
    Sx = function(a, b) {
        a.ra = b
    };
h = Nx.prototype;
h.Je = function(a) {
    Qx(this).jb(a, !0)
};
h.fb = function() {
    return this.b ? ar(this.b) : 0
};
h.setVisible = function(a, b) {
    (a = Nx.D.setVisible.call(this, a, b)) && !this.isVisible() && this.Xa(!1);
    return a
};
h.oa = function(a) {
    Nx.D.oa.call(this, a);
    this.isEnabled() || this.Xa(!1)
};
h.Xa = function(a, b) {
    Nx.D.Xa.call(this, a);
    if (this.b && this.Ea(64) == a) {
        if (a) this.b.ya || this.b.render(), this.X = nq(this.j()), this.ob = wq(this.j()), Tx(this), !b || 40 != b.keyCode && 38 != b.keyCode ? this.b.Qb(-1) : dx(this.b);
        else {
            Lr(this, !1);
            this.b.Kc = !1;
            var c = this.j();
            c && (Ip(c, "activedescendant", ""), Ip(c, "owns", ""));
            null != this.R && (this.R = void 0, (c = this.b.j()) && uq(c, "", ""))
        }
        this.b.setVisible(a, !1, b);
        this.isDisposed() || (b = Y(this), c = a ? b.listen : b.Ga, c.call(b, this.a.a, "mousedown", this.xl, !0), this.Rf && c.call(b, this.b, "blur",
            this.Fl), c.call(b, this.N, "tick", this.kd), a ? this.N.start() : this.N.stop())
    }
    this.b && this.b.j() && Wq(this.b).removeAttribute(Hp("hidden"))
};
var Tx = function(a) {
    if (a.b.ya) {
        var b = a.m;
        a.m.a = a.xb || a.j();
        var c = a.b.j();
        a.b.isVisible() || (c.style.visibility = "hidden", W(c, !0));
        !a.R && a.m.m && a.m.h & 32 && (a.R = vq(c));
        b.b(c, b.g ^ 1, a.ra, a.R);
        a.b.isVisible() || (W(c, !1), c.style.visibility = "visible")
    }
};
Nx.prototype.kd = function() {
    var a = wq(this.j()),
        b = nq(this.j());
    var c = this.ob;
    (c = !(c == a || c && a && c.left == a.left && c.width == a.width && c.top == a.top && c.height == a.height)) || (c = this.X, c = !(c == b || c && b && c.top == b.top && c.right == b.right && c.bottom == b.bottom && c.left == b.left));
    if (c) {
        if (c = this.b.ya && b && this.X) c = this.X, c = b.right - b.left < c.right - c.left;
        c && (c = this.b.j(), this.b.isVisible() || (c.style.visibility = "hidden", W(c, !0)), hq(c, new Ef(0, 0)));
        this.ob = a;
        this.X = b;
        Tx(this)
    }
};
var Px = function(a, b, c) {
        var d = Y(a);
        c = c ? d.listen : d.Ga;
        c.call(d, b, "action", a.Tg);
        c.call(d, b, "close", a.bc);
        c.call(d, b, "highlight", a.hd);
        c.call(d, b, "unhighlight", a.jd)
    },
    Ox = function(a, b) {
        var c = Y(a);
        (b ? c.listen : c.Ga).call(c, a.j(), "keydown", a.ld)
    };
Nx.prototype.hd = function(a) {
    (a = a.target.j()) && Ux(this, a)
};
Nx.prototype.ld = function(a) {
    ur(this, 32) && this.j() && this.b && this.b.isVisible() && a.stopPropagation()
};
Nx.prototype.jd = function() {
    if (!cx(this.b)) {
        var a = this.j();
        v(a, "The menu button DOM element cannot be null.");
        Ip(a, "activedescendant", "");
        Ip(a, "owns", "")
    }
};
Nx.prototype.bc = function(a) {
    if (this.Ea(64) && a.target instanceof qx) {
        a = a.target;
        var b = a.j();
        a.isVisible() && a.Ea(2) && null != b && Ux(this, b)
    }
};
var Ux = function(a, b) {
    a = a.j();
    v(a, "The menu button DOM element cannot be null.");
    b = Kp(b) || b;
    if (!b.id) {
        var c = Rq.M();
        b.id = ":" + (c.a++).toString(36)
    }
    Lp(a, b);
    Ip(a, "owns", b.id)
};
Cr("goog-menu-button", function() {
    return new Nx(null)
});
var Wx = function(a) {
    J.call(this);
    this.a = [];
    Vx(this, a)
};
t(Wx, J);
Wx.prototype.b = null;
Wx.prototype.fb = function() {
    return this.a.length
};
var Vx = function(a, b) {
        b && (w(b, function(c) {
            Xx(c, !1)
        }, a), yb(a.a, b))
    },
    Yx = function(a, b, c) {
        b && (Xx(b, !1), Ab(a.a, c, 0, b))
    },
    Zx = function(a) {
        var b = a.b;
        return b ? ib(a.a, b) : -1
    },
    $x = function(a) {
        var b = a.a;
        if (!Ia(b))
            for (var c = b.length - 1; 0 <= c; c--) delete b[c];
        b.length = 0;
        a.b = null
    };
Wx.prototype.T = function() {
    Wx.D.T.call(this);
    delete this.a;
    this.b = null
};
var Xx = function(a, b) {
    a && "function" == typeof a.dd && a.dd(b)
};
var ay = function(a, b, c, d, e) {
    Nx.call(this, a, b, c, d, e || new ux("listbox"));
    this.Z = this.Sa();
    this.xa = null;
    this.Rg = "listbox"
};
t(ay, Nx);
h = ay.prototype;
h.Ha = null;
h.aa = function() {
    ay.D.aa.call(this);
    by(this);
    cy(this)
};
h.Da = function(a) {
    ay.D.Da.call(this, a);
    (a = this.sb()) ? (this.Z = a, by(this)) : dy(this) || ey(this, 0)
};
h.T = function() {
    ay.D.T.call(this);
    this.Ha && (this.Ha.Ia(), this.Ha = null);
    this.Z = null
};
h.Tg = function(a) {
    fy(this, a.target);
    ay.D.Tg.call(this, a);
    a.stopPropagation();
    this.dispatchEvent("action")
};
h.Kl = function() {
    var a = dy(this);
    ay.D.yf.call(this, a && a.Y());
    by(this)
};
h.Ke = function(a) {
    var b = ay.D.Ke.call(this, a);
    a != b && (this.Ha && $x(this.Ha), a && (this.Ha ? $q(a, function(c) {
        gy(c);
        var d = this.Ha;
        Yx(d, c, d.fb())
    }, this) : hy(this, a)));
    return b
};
h.Je = function(a) {
    gy(a);
    ay.D.Je.call(this, a);
    if (this.Ha) {
        var b = this.Ha;
        Yx(b, a, b.fb())
    } else hy(this, Qx(this));
    iy(this)
};
var fy = function(a, b) {
        if (a.Ha) {
            var c = dy(a),
                d = a.Ha;
            b != d.b && (Xx(d.b, !1), d.b = b, Xx(b, !0));
            d.dispatchEvent("select");
            b != c && a.dispatchEvent("change")
        }
    },
    ey = function(a, b) {
        a.Ha && fy(a, a.Ha.a[b] || null)
    };
ay.prototype.yf = function(a) {
    if (null != a && this.Ha)
        for (var b = 0, c; c = this.Ha.a[b] || null; b++)
            if (c && "function" == typeof c.Y && c.Y() == a) {
                fy(this, c);
                return
            } fy(this, null)
};
ay.prototype.Y = function() {
    var a = dy(this);
    return a ? a.Y() : null
};
var dy = function(a) {
        return a.Ha ? a.Ha.b : null
    },
    hy = function(a, b) {
        a.Ha = new Wx;
        b && $q(b, function(c) {
            gy(c);
            var d = this.Ha;
            Yx(d, c, d.fb())
        }, a);
        cy(a)
    },
    cy = function(a) {
        a.Ha && Y(a).listen(a.Ha, "select", a.Kl)
    },
    by = function(a) {
        var b = dy(a);
        a.g(b ? b.sb() : a.Z);
        var c = a.c.Db(a.j());
        c && a.a.mm(c) && (null == a.xa && (a.xa = Jp(c, "label")), b = b ? b.j() : null, Mp(c, b ? Jp(b, "label") : a.xa), iy(a))
    },
    iy = function(a) {
        var b = a.c;
        if (b && (b = b.Db(a.j()))) {
            var c = Wq(a);
            b.id || (b.id = ":" + (Rq.M().a++).toString(36));
            Gp(b, "option");
            Ip(c, "activedescendant", b.id);
            a.Ha && (c = xb(a.Ha.a), Ip(b, "setsize", jy(c)), a = Zx(a.Ha), Ip(b, "posinset", 0 <= a ? jy(zb(c, 0, a + 1)) : 0))
        }
    },
    jy = function(a) {
        return ob(a, function(b) {
            return b instanceof qx
        })
    },
    gy = function(a) {
        a.Rg = a instanceof qx ? "option" : "separator"
    };
ay.prototype.Xa = function(a, b) {
    ay.D.Xa.call(this, a, b);
    this.Ea(64) ? Qx(this).Qb(this.Ha ? Zx(this.Ha) : -1) : iy(this)
};
Cr("goog-select", function() {
    return new ay(null)
});
var my = function(a, b, c, d, e, f, g, k, l) {
    c = new ky(c);
    ay.call(this, "", c, g, k);
    this.m.c && this.m.c(33);
    this.Ta = a;
    this.ac = a.id;
    Vq(c, this.ac + "-menu");
    this.W = [];
    this.V = null;
    this.Ca = null != f ? f : "";
    this.md = !!l;
    for (a = 0; a < b.length; a++) {
        var m;
        f = null != d && a < d.length && null != d[a] ? d[a] : b[a];
        "separator" != f ? m = new xx(b[a], f) : m = new vx;
        this.Je(m)
    }
    this.ba(this.Ta);
    a: {
        b = null != e ? e : ly(this, 0);
        for (e = 0; d = this.b ? br(this.b, e) : null; e++)
            if (d instanceof qx && d.Y() == b) {
                b = e;
                break a
            } b = -1
    }
    0 <= b && ey(this, b)
};
t(my, ay);
my.prototype.g = function(a) {
    this.md ? a = this.Ca : this.Ca && (a = this.Ca + " " + a);
    my.D.g.call(this, a)
};
var ny = function(a) {
    a.V && (Di(a.V), a.V = null);
    a.V = Ci(function() {
        a.W = []
    }, 1E3)
};
my.prototype.T = function() {
    jg(this.Ta);
    this.Ta = null;
    my.D.T.call(this)
};
my.prototype.Ya = function(a) {
    if (!this.Ea(64) && 48 <= a.keyCode && 90 >= a.keyCode) {
        ny(this);
        this.W.push(String.fromCharCode(a.keyCode));
        a = this.W.join("");
        var b = new RegExp("^" + ie(a), "i"),
            c = this.Ha ? Zx(this.Ha) : -1,
            d = c; - 1 < d && 1 < a.length && d--;
        var e = this.fb(),
            f = 0 > d ? 0 : d,
            g = !1,
            k = !1;
        do {
            ++d;
            d == e && (d = 0, g = !0);
            var l = this.b ? br(this.b, d) : null;
            if (l instanceof qx && (l = l.sb()) && l.match(b)) {
                k = !0;
                break
            }
            g && d == f && 3 == a.length && (l = a.split(""), l[1] == l[2] && (b = new RegExp("^" + l[1], "i"), this.W = [l[1]], g = !1))
        } while (!g || d != f);
        k && d != c && ey(this,
            d);
        return !0
    }
    return my.D.Ya.call(this, a)
};
var ly = function(a, b) {
    var c = "";
    a = a.b ? br(a.b, b) : null;
    a instanceof qx && (c = a.Y());
    return c
};
my.prototype.Y = function() {
    var a = this.Ha ? Zx(this.Ha) : -1;
    return -1 != a ? ly(this, a) : ""
};
var ky = function(a, b, c) {
    this.b = a;
    this.m = [];
    this.K = [];
    wx.call(this, b, c)
};
t(ky, wx);
h = ky.prototype;
h.zi = D("DIV", {
    id: "goog-menuitem-group-",
    "class": "goog-menuitem-group"
});
h.Wg = !1;
h.Gd = 0;
h.Ja = function() {
    ky.D.Ja.call(this);
    this.j().id = Uq(this)
};
h.qd = function(a, b, c) {
    this.Wg && (this.c = b == ar(this) ? this.g[b - 1] : this.g[b]);
    ky.D.qd.call(this, a, b, c);
    this.c && (this.c = null, oy(this))
};
h.removeChild = function(a, b) {
    "string" === typeof a && (a = Xq(this, a));
    var c = dr(this, a);
    this.Wg && (this.c = 0 == c ? this.g[c + 1] : this.g[c]);
    a = ky.D.removeChild.call(this, a, b);
    this.c && (this.c = null, oy(this));
    return a
};
h.Zb = function() {
    var a;
    this.c ? a = this.c : a = ky.D.Zb.call(this);
    return a
};
h.render = function(a) {
    ky.D.render.call(this, a);
    oy(this);
    Pw(Mw.M(), this.j())
};
h.ba = function(a) {
    ky.D.ba.call(this, a);
    oy(this);
    Pw(Mw.M(), this.j())
};
var oy = function(a) {
        a.Wg = !0;
        py(a);
        var b = a.j();
        b.innerHTML = "";
        var c = [],
            d = 0;
        var e = document.createElement("table");
        var f = e.insertRow(-1);
        for (var g = 0, k; k = a.h[g]; g++) {
            var l = f.insertCell(f.cells.length);
            l.appendChild(k);
            Qp(k, "goog-groupmenu-separator") ? (c.push(l), f = e.insertRow(e.rows.length)) : d++
        }
        for (g = 0; l = c[g]; g++) l.setAttribute("colspan", d);
        b.appendChild(e)
    },
    qy = function(a, b, c) {
        rb(a.h, b.Tb) || a.h.push(b.Tb);
        br(a, c + 1) && (b.Tb = a.zi.cloneNode(!0), b.Tb.id += b.Vi, b.Vi++, b.Kf = 1);
        return b
    },
    py = function(a) {
        a.h = [];
        a.g = {};
        var b = a.zi.cloneNode(!0);
        b.id += 1;
        var c = {
            Tb: b,
            Vi: 2,
            Kf: 1
        };
        $q(a, function(d, e) {
            c.Tb.appendChild(d.j());
            this.g[e] = c.Tb;
            c.Kf == this.b ? c = qy(this, c, e) : d instanceof qx && c.Kf++;
            rb(this.K, e) && (U(c.Tb, "goog-menuitem-group"), T(c.Tb, "goog-groupmenu-separator"), this.g[e] = c.Tb, c = qy(this, c, e))
        }, a);
        1 == c.Kf || rb(a.h, c.Tb) || a.h.push(c.Tb)
    };
ky.prototype.setVisible = function(a, b, c) {
    (a = ky.D.setVisible.call(this, a, b, c)) && this.Gd && (Di(this.Gd), this.Gd = 0);
    return a
};
ky.prototype.Ge = function(a) {
    var b = ky.D.Ge.call(this, a);
    if (b) return b;
    switch (a.keyCode) {
        case 37:
            return ix(this, p(this.w, this), this.Ka), !0;
        case 39:
            return ix(this, p(this.C, this), this.Ka), !0;
        default:
            return 48 <= a.keyCode && 90 >= a.keyCode ? (ry(this), this.m.push(String.fromCharCode(a.keyCode)), this.Ki(this.m.join("")), !0) : !1
    }
};
var ry = function(a) {
    a.Gd && (Di(a.Gd), a.Gd = 0);
    a.Gd = Ci(function() {
        this.m = []
    }, 1E3, a)
};
ky.prototype.Ki = function(a) {
    var b = new RegExp("^" + ie(a), "i"),
        c = this.Ka; - 1 < c && 1 < a.length && c--;
    ix(this, function(d, e) {
        var f = 0 > d ? 0 : d,
            g = !1;
        do {
            ++d;
            d == e && (d = 0, g = !0);
            var k = br(this, d).sb();
            if (k && k.match(b)) return d
        } while (!g || d != f);
        return this.Ka
    }, c)
};
ky.prototype.w = function(a, b) {
    a -= this.b;
    var c;
    0 > a && (c = a + b + (Math.ceil(b / this.b) * this.b - b) + this.b);
    return c || a
};
ky.prototype.C = function(a, b) {
    a += this.b;
    var c;
    a > b && (c = a - b - (Math.ceil(b / this.b) * this.b - b) - this.b);
    return c || a
};
var ty = function(a, b) {
        this.a = sy;
        this.b = a;
        this.c = Yb(b)
    },
    sy = null,
    vy = function(a, b) {
        var c = ["sl", "tl", "src", "trg", "ts"];
        if (!sy && "openDatabase" in window) try {
            sy = window.openDatabase("GoogleTranslateMobileWebApp", "1.0", "Google Translate Mobile Web App", 5E5)
        } catch (e) {}
        if (sy) {
            var d = new ty(a, c);
            uy(d, a, c, function(e) {
                b && b(e, d)
            })
        } else b && b(!1, null)
    },
    wy = function(a) {
        return function(b) {
            a && a(!1, b.code)
        }
    },
    uy = function(a, b, c, d) {
        var e = [];
        e.push("CREATE TABLE IF NOT EXISTS", b);
        b = [];
        for (var f = 0, g = c.length; f < g; f++) b.push(c[f] +
            " TEXT");
        e.push("(", b.join(","), ")");
        a.a.transaction(function(k) {
            k.executeSql(e.join(" "))
        }, wy(d), d ? Sa(d, !0, null) : Ea)
    },
    xy = function(a, b) {
        for (var c in b)
            if (!Pb(a.c, c)) return !1;
        return !0
    },
    zy = function(a, b, c, d) {
        var e = [
            ["ts"]
        ];
        if (xy(a, b)) {
            var f = [];
            f.push("SELECT * FROM", a.b);
            var g = [],
                k = [];
            yy(b, g, k);
            g.length && f.push("WHERE", g.join(" AND "));
            if (e && 0 < e.length) {
                b = [];
                for (g = 0; g < e.length; ++g) b.push(e[g][0] + " " + (e[g][1] ? "ASC" : "DESC"));
                f.push("ORDER BY", b.join(","))
            }
            c && f.push("LIMIT", c);
            var l = [];
            a.a.transaction(function(m) {
                m.executeSql(f.join(" "),
                    k,
                    function(q, r) {
                        q = 0;
                        for (var u = r.rows.length; q < u; q++) l.push(r.rows.item(q))
                    })
            }, wy(d), d ? Sa(d, !0, l || null) : Ea)
        } else d && d(!1, -1)
    },
    By = function(a, b, c) {
        Ay(a, [b], c)
    },
    Ay = function(a, b, c) {
        for (var d = 0, e = b.length; d < e; d++)
            if (!xy(a, b[d])) {
                c && c(!1, -1);
                return
            } var f = [];
        d = 0;
        for (e = b.length; d < e; d++) {
            var g = b[d],
                k = [],
                l = [],
                m = [],
                q;
            for (q in g) k.push(q), l.push(g[q]), m.push("?");
            f.push([
                ["INSERT INTO", a.b, "(", k.join(","), ") VALUES (", m.join(","), ")"].join(" "), l
            ])
        }
        a.a.transaction(function(r) {
            for (var u = 0, z = f.length; u < z; u++) r.executeSql(f[u][0],
                f[u][1])
        }, wy(c), c ? Sa(c, !0, null) : Ea)
    },
    Cy = function(a, b, c) {
        if (xy(a, b)) {
            var d = [];
            d.push("DELETE FROM", a.b);
            var e = [],
                f = [];
            yy(b, e, f);
            e.length && d.push("WHERE", e.join(" AND "));
            a.a.transaction(function(g) {
                g.executeSql(d.join(" "), f)
            }, wy(c), c ? Sa(c, !0, null) : Ea)
        } else c && c(!1, -1)
    },
    yy = function(a, b, c) {
        for (var d in a) b.push(d + "=?"), c.push(a[d])
    };
var Dy = function(a) {
        this.a = a
    },
    Ey = function(a, b) {
        vy(a, function(c, d) {
            var e = null;
            c && (e = new Dy(d));
            b && b(c, e)
        })
    },
    Hy = function(a, b, c, d) {
        var e = Fy.a;
        Gy(e, a, b, c, function(f) {
            f && (f = {}, f.sl = a, f.tl = b, f.src = c, f.trg = ej(d), f.ts = (new Date).getTime(), By(e.a, f, function() {}))
        })
    },
    Gy = function(a, b, c, d, e) {
        var f = {};
        b && (f.sl = b);
        c && (f.tl = c);
        d && (f.src = d);
        Cy(a.a, f, function(g) {
            e && e(g)
        })
    },
    Iy = function(a, b, c, d, e, f) {
        var g = {};
        b && (g.sl = b);
        c && (g.tl = c);
        d && (g.src = d);
        zy(a.a, g, e, function(k, l) {
            var m = [];
            if (k)
                for (var q = 0, r = l.length; q < r; q++) {
                    var u = {},
                        z;
                    for (z in l[q]) u[z] = l[q][z];
                    var P = uo(u.trg, {
                        "class": "trans.common.WebSqlTranslations"
                    });
                    u.trg = P;
                    m.push(u)
                }
            f && f(k, m)
        })
    },
    Jy = function(a, b, c, d, e, f) {
        Iy(a, b, c, d, e, function(g, k) {
            f && f(g, k)
        })
    };
var Ky = function(a) {
        this.a = a
    },
    Ly = function(a) {
        Ey("TranslationHistory", function(b, c) {
            c = b ? new Ky(c) : null;
            a && a(b, c)
        })
    };
var My = dc("//www.gstatic.com/inputtools/js/ita/inputtools_3.js"),
    Ny = dc("//www.gstatic.com/inputtools/js/ita/inputtools_d_3.js");
/*
 Portions of this code are from MochiKit, received by
 The Closure Authors under the MIT license. All other code is Copyright
 2005-2009 The Closure Authors. All Rights Reserved.
*/
var Py = function(a) {
    var b = Oy;
    this.h = [];
    this.O = b;
    this.K = a || null;
    this.g = this.a = !1;
    this.c = void 0;
    this.G = this.C = this.m = !1;
    this.o = 0;
    this.b = null;
    this.w = 0
};
Py.prototype.cancel = function(a) {
    if (this.a) this.c instanceof Py && this.c.cancel();
    else {
        if (this.b) {
            var b = this.b;
            delete this.b;
            a ? b.cancel(a) : (b.w--, 0 >= b.w && b.cancel())
        }
        this.O ? this.O.call(this.K, this) : this.G = !0;
        this.a || Qy(this, new Ry(this))
    }
};
Py.prototype.L = function(a, b) {
    this.m = !1;
    Sy(this, a, b)
};
var Sy = function(a, b, c) {
        a.a = !0;
        a.c = c;
        a.g = !b;
        Ty(a)
    },
    Vy = function(a) {
        if (a.a) {
            if (!a.G) throw new Uy(a);
            a.G = !1
        }
    };
Py.prototype.re = function(a) {
    Vy(this);
    Wy(a);
    Sy(this, !0, a)
};
var Qy = function(a, b) {
        Vy(a);
        Wy(b);
        Sy(a, !1, b)
    },
    Wy = function(a) {
        v(!(a instanceof Py), "An execution sequence may not be initiated with a blocking Deferred.")
    },
    Xy = function(a, b, c, d) {
        v(!a.C, "Blocking Deferreds can not be re-used");
        a.h.push([b, c, d]);
        a.a && Ty(a)
    };
Py.prototype.then = function(a, b, c) {
    var d, e, f = new ji(function(g, k) {
        d = g;
        e = k
    });
    Xy(this, d, function(g) {
        g instanceof Ry ? f.cancel() : e(g)
    });
    return f.then(a, b, c)
};
Py.prototype.$goog_Thenable = !0;
var Yy = function(a) {
        return mb(a.h, function(b) {
            return Ka(b[1])
        })
    },
    Ty = function(a) {
        if (a.o && a.a && Yy(a)) {
            var b = a.o,
                c = Zy[b];
            c && (n.clearTimeout(c.qa), delete Zy[b]);
            a.o = 0
        }
        a.b && (a.b.w--, delete a.b);
        b = a.c;
        for (var d = c = !1; a.h.length && !a.m;) {
            var e = a.h.shift(),
                f = e[0],
                g = e[1];
            e = e[2];
            if (f = a.g ? g : f) try {
                var k = f.call(e || a.K, b);
                void 0 !== k && (a.g = a.g && (k == b || k instanceof Error), a.c = b = k);
                if (gi(b) || "function" === typeof n.Promise && b instanceof n.Promise) d = !0, a.m = !0
            } catch (l) {
                b = l, a.g = !0, Yy(a) || (c = !0)
            }
        }
        a.c = b;
        d && (k = p(a.L, a, !0), d =
            p(a.L, a, !1), b instanceof Py ? (Xy(b, k, d), b.C = !0) : b.then(k, d));
        c && (b = new $y(b), Zy[b.qa] = b, a.o = b.qa)
    },
    Uy = function() {
        Ua.call(this)
    };
t(Uy, Ua);
Uy.prototype.message = "Deferred has already fired";
Uy.prototype.name = "AlreadyCalledError";
var Ry = function() {
    Ua.call(this)
};
t(Ry, Ua);
Ry.prototype.message = "Deferred was canceled";
Ry.prototype.name = "CanceledError";
var $y = function(a) {
    this.qa = n.setTimeout(p(this.a, this), 0);
    this.kf = a
};
$y.prototype.a = function() {
    v(Zy[this.qa], "Cannot throw an error that is not scheduled.");
    delete Zy[this.qa];
    throw this.kf;
};
var Zy = {};
var dz = function(a, b) {
        var c = b || {};
        b = c.document || document;
        var d = rc(a),
            e = $f("SCRIPT"),
            f = {
                ej: e,
                ed: void 0
            },
            g = new Py(f),
            k = null,
            l = null != c.timeout ? c.timeout : 5E3;
        0 < l && (k = window.setTimeout(function() {
            az(e, !0);
            Qy(g, new bz(1, "Timeout reached for loading script " + d))
        }, l), f.ed = k);
        e.onload = e.onreadystatechange = function() {
            e.readyState && "loaded" != e.readyState && "complete" != e.readyState || (az(e, c.jk || !1, k), g.re(null))
        };
        e.onerror = function() {
            az(e, !0, k);
            Qy(g, new bz(0, "Error while loading script " + d))
        };
        f = c.attributes || {};
        Wb(f, {
            type: "text/javascript",
            charset: "UTF-8"
        });
        Qf(e, f);
        Wd(e, a);
        cz(b).appendChild(e);
        return g
    },
    cz = function(a) {
        var b = Lf("HEAD", a);
        return b && 0 != b.length ? b[0] : a.documentElement
    },
    Oy = function() {
        if (this && this.ej) {
            var a = this.ej;
            a && "SCRIPT" == a.tagName && az(a, !0, this.ed)
        }
    },
    az = function(a, b, c) {
        null != c && n.clearTimeout(c);
        a.onload = Ea;
        a.onerror = Ea;
        a.onreadystatechange = Ea;
        b && window.setTimeout(function() {
            jg(a)
        }, 0)
    },
    bz = function(a, b) {
        var c = "Jsloader error (code #" + a + ")";
        b && (c += ": " + b);
        Ua.call(this, c);
        this.code = a
    };
t(bz, Ua);
var ez = function() {
    this.c = this.b = !1;
    this.a = []
};
Fa(ez);
var fz = dc("//www.gstatic.cn/inputtools/js/ita/inputtools_1.js"),
    gz = dc("//www.gstatic.cn/inputtools/js/ita/inputtools_d_1.js");
ez.prototype.g = function() {
    this.c = !0;
    for (var a = 0; a < this.a.length; ++a) this.a[a]()
};
ez.prototype.load = function(a, b) {
    this.b ? this.b && !this.c ? this.a.push(a) : a() : (this.b = !0, this.a.push(a), a = 0 <= n.location.href.indexOf("?deb=static") || 0 <= n.location.href.indexOf("&deb=static"), dz(tc(cc(b ? a ? gz : fz : a ? Ny : My))).then(p(this.g, this)))
};
var iz = function() {
    this.g = Dk.M();
    this.c = {};
    this.b = {};
    this.a = {};
    this.a["gt-input-tool"] = new hz
};
Fa(iz);
var kz = function(a, b, c) {
        b = jz(a, b, c);
        if (void 0 !== b) a = b.Ri;
        else {
            a: {
                a = Gk(a.g, c);
                if (null != a)
                    for (c = 0; c < a.length; c++)
                        if (Ik(a[c])) {
                            a = a[c];
                            break a
                        } a = ""
            }
            a = a || ""
        }
        return a
    },
    jz = function(a, b, c) {
        if (a = lz(a, b)) return a.a[c]
    },
    lz = function(a, b, c) {
        var d = a.a[b];
        c && void 0 === d && (d = new hz, a.a[b] = d);
        return d
    },
    mz = function(a, b, c) {
        var d = {
            ua: "itui"
        };
        d.uav = "string" === typeof a ? a : a ? 1 : 0;
        d.sl = b;
        d.tl = "und";
        d.hl = c;
        var e = new Image;
        e.src = "/translate/uc?" + Ej(d);
        e.onload = function() {
            e.onload = null
        }
    },
    hz = function() {
        this.a = {};
        for (var a in nz) this.a[a] =
            new oz(nz[a], "")
    },
    nz = {
        iw: !1,
        ja: !1,
        vi: !1,
        "zh-CN": !1
    };
hz.prototype.update = function(a, b, c) {
    var d = this.a[a];
    void 0 !== d ? (d.isEnabled = b, d.Ri = c) : this.a[a] = new oz(b, c)
};
var oz = function(a, b) {
    this.isEnabled = a;
    this.Ri = b
};
var pz = function(a, b, c, d, e, f) {
    J.call(this);
    this.C = Dk.M();
    this.h = a;
    this.W = c;
    this.Z = b;
    this.g = this.b = null;
    this.o = this.L = "";
    this.G = this.h.id;
    this.a = "";
    this.m = this.c = !1;
    Gm.M();
    this.O = d;
    this.V = e;
    this.X = jc(d) ? [5, 4] : [1, 0];
    this.na = [30, 0, 0, 0];
    this.w = iz.M();
    this.N = tl.M();
    this.F = K.M();
    this.K = !0;
    null != f && f.a(this, "change")
};
t(pz, J);
var sz = function(a, b) {
        if (null == a.b) a.o = b, (null != Ek[b] || a.C.a && null != Fk[b]) && a.K && (a.K = !1, ez.M().load(p(a.ia, a), a.V));
        else if (a.L != b)
            if (a.L = b, null != Ek[b] || a.C.a && null != Fk[b]) {
                var c = Gk(a.C, b),
                    d = kz(a.w, a.G, b),
                    e = a.w,
                    f = a.G,
                    g = jz(e, f, b);
                b = void 0 !== g ? g.isEnabled : Ik(kz(e, f, b));
                a.m = !0;
                a.a = rb(c, d) ? d : c[0];
                a.b.disableCurrentInputTool();
                a.c = b;
                a.b.setInputTools(c);
                a.b.activateInputTool(a.a);
                a.c ? a.b.enableCurrentInputTool() : a.b.disableCurrentInputTool();
                null == a.g && (a.g = a.b.showControl({
                    ui: "kd",
                    container: a.h
                }));
                a.b.localize(a.O);
                a.g.show();
                qz(a);
                rz(a);
                a.m = !1;
                xl(a.N, a.c ? a.a : "")
            } else a.b.disableCurrentInputTool(), null != a.g && a.g.hide()
    },
    qz = function(a) {
        null != a.b && a.b.repositionKeyboard(a.W, a.X, a.na)
    };
pz.prototype.isEnabled = function() {
    return null != this.b && this.c
};
var tz = function(a) {
    return a.isEnabled() && Ik(a.a)
};
pz.prototype.R = function(a) {
    qz(this);
    if (!this.m && (this.a != a.currInputToolName || this.c != a.currInputToolActive)) {
        this.a = a.currInputToolName;
        this.c = a.currInputToolActive;
        rz(this);
        a = this.c;
        var b = this.L,
            c = this.O,
            d = this.G,
            e = this.a;
        lz(this.w, d, !0).update(b, a, e);
        mz((a ? "1" : "0") + "." + d + "." + e, b, c);
        xl(this.N, this.c ? this.a : "");
        this.c && (0 <= this.a.indexOf("-k0-") ? (a = this.F, M(a, N(a, 171))) : Ik(this.a) ? (a = this.F, M(a, N(a, 172))) : Hk(this.a) && (a = this.F, M(a, N(a, 146))))
    }
    this.dispatchEvent("change")
};
pz.prototype.ia = function() {
    var a = new google.elements.inputtools.InputToolsController;
    a.setAutoDirection(!1);
    a.setApplicationName("translate");
    a.addPageElements([this.Z]);
    a.addEventListener(google.elements.inputtools.EventType.INPUT_TOOL_ENABLED, this.R, this);
    this.b = a;
    "" != this.o && (sz(this, this.o), this.o = "")
};
var rz = function(a) {
    var b = B("ita-kd-inputtool-icon", a.h);
    if (null != b) {
        var c = Ik(a.a) ? a.isEnabled() ? window.MSG_IME_OFF || "" : window.MSG_IME_ON || "" : 0 <= a.a.indexOf("-k0-") ? a.isEnabled() ? window.MSG_VK_OFF || "" : window.MSG_VK_ON || "" : Hk(a.a) ? a.isEnabled() ? window.MSG_HW_OFF || "" : window.MSG_HW_ON || "" : "";
        os(b, c, void 0);
        ss(b, 2)
    }
    a = B("ita-kd-dropdown", a.h);
    null != a && (os(a, window.MSG_CHANGE_ITA || "", void 0), ss(a, 2))
};
Wi("goog.dom.SavedRange");
var vz = function(a, b, c, d, e) {
    this.c = !!b;
    this.h = null;
    this.g = 0;
    this.L = !1;
    this.K = !c;
    a && uz(this, a, d);
    this.depth = void 0 != e ? e : this.g || 0;
    this.c && (this.depth *= -1)
};
t(vz, pj);
var uz = function(a, b, c, d) {
    if (a.h = b) a.g = "number" === typeof c ? c : 1 != a.h.nodeType ? 0 : a.c ? -1 : 1;
    "number" === typeof d && (a.depth = d)
};
vz.prototype.next = function() {
    if (this.L) {
        if (!this.h || this.K && 0 == this.depth) throw oj;
        var a = this.h;
        var b = this.c ? -1 : 1;
        if (this.g == b) {
            var c = this.c ? a.lastChild : a.firstChild;
            c ? uz(this, c) : uz(this, a, -1 * b)
        } else(c = this.c ? a.previousSibling : a.nextSibling) ? uz(this, c) : uz(this, a.parentNode, -1 * b);
        this.depth += this.g * (this.c ? -1 : 1)
    } else this.L = !0;
    a = this.h;
    if (!this.h) throw oj;
    return a
};
vz.prototype.splice = function(a) {
    var b = this.h,
        c = this.c ? 1 : -1;
    this.g == c && (this.g = -1 * c, this.depth += this.g * (this.c ? -1 : 1));
    this.c = !this.c;
    vz.prototype.next.call(this);
    this.c = !this.c;
    c = Ja(arguments[0]) ? arguments[0] : arguments;
    for (var d = c.length - 1; 0 <= d; d--) hg(c[d], b);
    jg(b)
};
var wz = function() {},
    xz = function(a) {
        if (a.getSelection) return a.getSelection();
        a = a.document;
        var b = a.selection;
        if (b) {
            try {
                var c = b.createRange();
                if (c.parentElement) {
                    if (c.parentElement().document != a) return null
                } else if (!c.length || c.item(0).document != a) return null
            } catch (d) {
                return null
            }
            return b
        }
        return null
    },
    yz = function(a) {
        for (var b = [], c = 0, d = a.De(); c < d; c++) b.push(a.Pd(c));
        return b
    },
    zz = function(a) {
        return a.$g() ? a.Xb() : a.tc()
    };
wz.prototype.$g = function() {
    return !1
};
var Az = function(a, b) {
    vz.call(this, a, b, !0)
};
t(Az, vz);
var Bz = function(a, b, c, d, e) {
    this.b = this.a = null;
    this.G = this.C = 0;
    this.o = !!e;
    if (a) {
        this.a = a;
        this.C = b;
        this.b = c;
        this.G = d;
        if (1 == a.nodeType && "BR" != a.tagName)
            if (a = a.childNodes, b = a[b]) this.a = b, this.C = 0;
            else {
                a.length && (this.a = hb(a));
                var f = !0
            } 1 == c.nodeType && ((this.b = c.childNodes[d]) ? this.G = 0 : this.b = c)
    }
    vz.call(this, this.o ? this.b : this.a, this.o, !0);
    if (f) try {
        this.next()
    } catch (g) {
        if (g != oj) throw g;
    }
};
t(Bz, Az);
Bz.prototype.w = function() {
    return this.a
};
Bz.prototype.m = function() {
    return this.L && (this.h != (this.o ? this.a : this.b) ? !1 : this.o ? this.C ? -1 != this.g : 1 == this.g : !this.G || 1 != this.g)
};
Bz.prototype.next = function() {
    if (this.m()) throw oj;
    return Bz.D.next.call(this)
};
var Cz = function() {},
    Dz = function(a, b) {
        b = b.ye();
        try {
            return 0 <= a.nc(b, 0, 0) && 0 >= a.nc(b, 1, 1)
        } catch (c) {
            if (!y) throw c;
            return !1
        }
    };
Cz.prototype.mc = function() {
    return new Bz(this.dc(), this.Fc(), this.Ec(), this.Uc())
};
var Ez = function(a) {
    this.a = a
};
t(Ez, Cz);
var Gz = function(a) {
        var b = If(a).createRange();
        if (3 == a.nodeType) b.setStart(a, 0), b.setEnd(a, a.length);
        else if (Fz(a)) {
            for (var c, d = a;
                (c = d.firstChild) && Fz(c);) d = c;
            b.setStart(d, 0);
            for (d = a;
                (c = d.lastChild) && Fz(c);) d = c;
            b.setEnd(d, 1 == d.nodeType ? d.childNodes.length : d.length)
        } else c = a.parentNode, a = ib(c.childNodes, a), b.setStart(c, a), b.setEnd(c, a + 1);
        return b
    },
    Hz = function(a, b, c, d) {
        var e = If(a).createRange();
        e.setStart(a, b);
        e.setEnd(c, d);
        return e
    };
h = Ez.prototype;
h.ye = function() {
    return this.a
};
h.Kg = function() {
    return this.a.commonAncestorContainer
};
h.dc = function() {
    return this.a.startContainer
};
h.Fc = function() {
    return this.a.startOffset
};
h.Ec = function() {
    return this.a.endContainer
};
h.Uc = function() {
    return this.a.endOffset
};
h.nc = function(a, b, c) {
    return this.a.compareBoundaryPoints(1 == c ? 1 == b ? n.Range.START_TO_START : n.Range.START_TO_END : 1 == b ? n.Range.END_TO_START : n.Range.END_TO_END, a)
};
h.fc = function() {
    return this.a.collapsed
};
h.ti = function() {
    return this.a.toString()
};
h.select = function(a) {
    var b = Vf(If(this.dc()));
    this.Re(b.getSelection(), a)
};
h.Re = function(a) {
    a.removeAllRanges();
    a.addRange(this.a)
};
var Iz = function(a) {
    this.a = a
};
t(Iz, Ez);
Iz.prototype.Re = function(a, b) {
    !b || this.fc() ? Iz.D.Re.call(this, a, b) : (a.collapse(this.Ec(), this.Uc()), a.extend(this.dc(), this.Fc()))
};
var Jz = function(a) {
    this.b = this.a = this.o = null;
    this.h = this.g = -1;
    this.c = a
};
t(Jz, Cz);
var Kz = Wi("goog.dom.browserrange.IeRange"),
    Lz = function(a) {
        var b = If(a).body.createTextRange();
        if (1 == a.nodeType) b.moveToElementText(a), Fz(a) && !a.childNodes.length && b.collapse(!1);
        else {
            for (var c = 0, d = a; d = d.previousSibling;) {
                var e = d.nodeType;
                if (3 == e) c += d.length;
                else if (1 == e) {
                    b.moveToElementText(d);
                    break
                }
            }
            d || b.moveToElementText(a.parentNode);
            b.collapse(!d);
            c && b.move("character", c);
            b.moveEnd("character", a.length)
        }
        return b
    };
Jz.prototype.ye = function() {
    return this.c
};
Jz.prototype.Kg = function() {
    if (!this.o) {
        var a = this.c.text,
            b = this.c.duplicate(),
            c = a.replace(/ +$/, "");
        (c = a.length - c.length) && b.moveEnd("character", -c);
        c = b.parentElement();
        b = b.htmlText.replace(/(\r\n|\r|\n)+/g, " ").length;
        if (this.fc() && 0 < b) return this.o = c;
        for (; b > c.outerHTML.replace(/(\r\n|\r|\n)+/g, " ").length;) c = c.parentNode;
        for (; 1 == c.childNodes.length && c.innerText == Mz(c.firstChild) && Fz(c.firstChild);) c = c.firstChild;
        0 == a.length && (c = Nz(this, c));
        this.o = c
    }
    return this.o
};
var Nz = function(a, b) {
    for (var c = b.childNodes, d = 0, e = c.length; d < e; d++) {
        var f = c[d];
        if (Fz(f)) {
            var g = Lz(f),
                k = g.htmlText != f.outerHTML;
            if (a.fc() && k ? 0 <= a.nc(g, 1, 1) && 0 >= a.nc(g, 1, 0) : a.c.inRange(g)) return Nz(a, f)
        }
    }
    return b
};
h = Jz.prototype;
h.dc = function() {
    this.a || (this.a = Oz(this, 1), this.fc() && (this.b = this.a));
    return this.a
};
h.Fc = function() {
    0 > this.g && (this.g = Pz(this, 1), this.fc() && (this.h = this.g));
    return this.g
};
h.Ec = function() {
    if (this.fc()) return this.dc();
    this.b || (this.b = Oz(this, 0));
    return this.b
};
h.Uc = function() {
    if (this.fc()) return this.Fc();
    0 > this.h && (this.h = Pz(this, 0), this.fc() && (this.g = this.h));
    return this.h
};
h.nc = function(a, b, c) {
    return this.c.compareEndPoints((1 == b ? "Start" : "End") + "To" + (1 == c ? "Start" : "End"), a)
};
var Oz = function(a, b, c) {
        c = c || a.Kg();
        if (!c || !c.firstChild) return c;
        for (var d = 1 == b, e = 0, f = c.childNodes.length; e < f; e++) {
            var g = d ? e : f - e - 1,
                k = c.childNodes[g];
            try {
                var l = Qz(k)
            } catch (q) {
                continue
            }
            var m = l.ye();
            if (a.fc())
                if (!Fz(k)) {
                    if (0 == a.nc(m, 1, 1)) {
                        a.g = a.h = g;
                        break
                    }
                } else {
                    if (Dz(l, a)) return Oz(a, b, k)
                }
            else {
                if (Dz(a, l)) {
                    if (!Fz(k)) {
                        d ? a.g = g : a.h = g + 1;
                        break
                    }
                    return Oz(a, b, k)
                }
                if (0 > a.nc(m, 1, 0) && 0 < a.nc(m, 0, 1)) return Oz(a, b, k)
            }
        }
        return c
    },
    Pz = function(a, b) {
        var c = 1 == b,
            d = c ? a.dc() : a.Ec();
        if (1 == d.nodeType) {
            d = d.childNodes;
            for (var e =
                    d.length, f = c ? 1 : -1, g = c ? 0 : e - 1; 0 <= g && g < e; g += f) {
                var k = d[g];
                if (!Fz(k) && 0 == a.c.compareEndPoints((1 == b ? "Start" : "End") + "To" + (1 == b ? "Start" : "End"), Qz(k).ye())) return c ? g : g + 1
            }
            return -1 == g ? 0 : g
        }
        a = a.c.duplicate();
        b = Lz(d);
        a.setEndPoint(c ? "EndToEnd" : "StartToStart", b);
        a = a.text.length;
        return c ? d.length - a : a
    },
    Mz = function(a) {
        return 3 == a.nodeType ? a.nodeValue : a.innerText
    };
Jz.prototype.fc = function() {
    return 0 == this.c.compareEndPoints("StartToEnd", this.c)
};
Jz.prototype.ti = function() {
    return this.c.text
};
Jz.prototype.select = function() {
    this.c.select()
};
var Rz = function(a) {
    this.a = a
};
t(Rz, Ez);
Rz.prototype.Re = function(a) {
    a.collapse(this.dc(), this.Fc());
    this.Ec() == this.dc() && this.Uc() == this.Fc() || a.extend(this.Ec(), this.Uc());
    0 == a.rangeCount && a.addRange(this.a)
};
var Sz = function(a) {
    this.a = a
};
t(Sz, Ez);
Sz.prototype.nc = function(a, b, c) {
    return Qe("528") ? Sz.D.nc.call(this, a, b, c) : this.a.compareBoundaryPoints(1 == c ? 1 == b ? n.Range.START_TO_START : n.Range.END_TO_START : 1 == b ? n.Range.START_TO_END : n.Range.END_TO_END, a)
};
Sz.prototype.Re = function(a, b) {
    b ? a.setBaseAndExtent(this.Ec(), this.Uc(), this.dc(), this.Fc()) : a.setBaseAndExtent(this.dc(), this.Fc(), this.Ec(), this.Uc())
};
var Tz = function(a) {
        return Cf ? new Jz(a, If(a.parentElement())) : ze ? new Sz(a) : ye ? new Iz(a) : ve ? new Rz(a) : new Ez(a)
    },
    Qz = function(a) {
        if (y && !Se(9)) {
            var b = new Jz(Lz(a), If(a));
            if (Fz(a)) {
                for (var c, d = a;
                    (c = d.firstChild) && Fz(c);) d = c;
                b.a = d;
                b.g = 0;
                for (d = a;
                    (c = d.lastChild) && Fz(c);) d = c;
                b.b = d;
                b.h = 1 == d.nodeType ? d.childNodes.length : d.length;
                b.o = a
            } else b.a = b.b = b.o = a.parentNode, b.g = ib(b.o.childNodes, a), b.h = b.g + 1;
            a = b
        } else a = ze ? new Sz(Gz(a)) : ye ? new Iz(Gz(a)) : ve ? new Rz(Gz(a)) : new Ez(Gz(a));
        return a
    },
    Fz = function(a) {
        return cg(a) ||
            3 == a.nodeType
    };
var Uz = function() {
    this.c = this.b = this.h = this.a = this.o = null;
    this.g = !1
};
t(Uz, wz);
var Vz = function(a, b) {
        var c = new Uz;
        c.o = a;
        c.g = !!b;
        return c
    },
    Wz = function(a, b) {
        return Vz(Qz(a), b)
    };
Uz.prototype.Kb = function() {
    return "text"
};
Uz.prototype.Fg = function() {
    return Xz(this).ye()
};
Uz.prototype.De = function() {
    return 1
};
Uz.prototype.Pd = function() {
    return this
};
var Xz = function(a) {
    var b;
    if (!(b = a.o)) {
        b = a.Xb();
        var c = a.Yb(),
            d = a.tc(),
            e = a.uc();
        if (y && !Se(9)) {
            var f = b,
                g = c,
                k = d,
                l = e,
                m = !1;
            1 == f.nodeType && (g > f.childNodes.length && Xi(Kz, "Cannot have startOffset > startNode child count"), g = f.childNodes[g], m = !g, f = g || f.lastChild || f, g = 0);
            var q = Lz(f);
            g && q.move("character", g);
            f == k && g == l ? q.collapse(!0) : (m && q.collapse(!1), m = !1, 1 == k.nodeType && (l > k.childNodes.length && Xi(Kz, "Cannot have endOffset > endNode child count"), k = (g = k.childNodes[l]) || k.lastChild || k, l = 0, m = !g), f = Lz(k), f.collapse(!m),
                l && f.moveEnd("character", l), q.setEndPoint("EndToEnd", f));
            l = new Jz(q, If(b));
            l.a = b;
            l.g = c;
            l.b = d;
            l.h = e;
            b = l
        } else b = ze ? new Sz(Hz(b, c, d, e)) : ye ? new Iz(Hz(b, c, d, e)) : ve ? new Rz(Hz(b, c, d, e)) : new Ez(Hz(b, c, d, e));
        b = a.o = b
    }
    return b
};
h = Uz.prototype;
h.sf = function() {
    return Xz(this).Kg()
};
h.Xb = function() {
    return this.a || (this.a = Xz(this).dc())
};
h.Yb = function() {
    return null != this.h ? this.h : this.h = Xz(this).Fc()
};
h.tc = function() {
    return this.b || (this.b = Xz(this).Ec())
};
h.uc = function() {
    return null != this.c ? this.c : this.c = Xz(this).Uc()
};
h.$g = function() {
    return this.g
};
h.uf = function() {
    return Xz(this).fc()
};
h.tf = function() {
    return Xz(this).ti()
};
h.mc = function() {
    return new Bz(this.Xb(), this.Yb(), this.tc(), this.uc())
};
h.select = function() {
    Xz(this).select(this.g)
};
var Yz = function() {};
t(Yz, wz);
var Zz = function() {
    this.c = this.b = this.a = null
};
t(Zz, Yz);
h = Zz.prototype;
h.Kb = function() {
    return "control"
};
h.Fg = function() {
    return this.a || document.body.createControlRange()
};
h.De = function() {
    return this.a ? this.a.length : 0
};
h.Pd = function(a) {
    return Wz(this.a.item(a))
};
h.sf = function() {
    return tg.apply(null, $z(this))
};
h.Xb = function() {
    return aA(this)[0]
};
h.Yb = function() {
    return 0
};
h.tc = function() {
    var a = aA(this),
        b = hb(a);
    return pb(a, function(c) {
        return pg(c, b)
    })
};
h.uc = function() {
    return this.tc().childNodes.length
};
var $z = function(a) {
        if (!a.b && (a.b = [], a.a))
            for (var b = 0; b < a.a.length; b++) a.b.push(a.a.item(b));
        return a.b
    },
    aA = function(a) {
        a.c || (a.c = $z(a).concat(), a.c.sort(function(b, c) {
            return b.sourceIndex - c.sourceIndex
        }));
        return a.c
    };
Zz.prototype.uf = function() {
    return !this.a || !this.a.length
};
Zz.prototype.tf = function() {
    return ""
};
Zz.prototype.mc = function() {
    return new bA(this)
};
Zz.prototype.select = function() {
    this.a && this.a.select()
};
var bA = function(a) {
    this.o = this.b = this.a = null;
    a && (this.o = aA(a), this.a = this.o.shift(), this.b = hb(this.o) || this.a);
    vz.call(this, this.a, !1, !0)
};
t(bA, Az);
bA.prototype.w = function() {
    return this.a
};
bA.prototype.m = function() {
    return !this.depth && !this.o.length
};
bA.prototype.next = function() {
    if (this.m()) throw oj;
    if (!this.depth) {
        var a = this.o.shift();
        uz(this, a, 1, 1);
        return a
    }
    return bA.D.next.call(this)
};
var cA = function() {
    this.F = Wi("goog.dom.MultiRange");
    this.a = [];
    this.g = [];
    this.c = this.b = null
};
t(cA, Yz);
h = cA.prototype;
h.Kb = function() {
    return "mutli"
};
h.Fg = function() {
    1 < this.a.length && Yi(this.F, "getBrowserRangeObject called on MultiRange with more than 1 range");
    return this.a[0]
};
h.De = function() {
    return this.a.length
};
h.Pd = function(a) {
    this.g[a] || (this.g[a] = Vz(Tz(this.a[a]), void 0));
    return this.g[a]
};
h.sf = function() {
    if (!this.c) {
        for (var a = [], b = 0, c = this.De(); b < c; b++) a.push(this.Pd(b).sf());
        this.c = tg.apply(null, a)
    }
    return this.c
};
var eA = function(a) {
    a.b || (a.b = yz(a), a.b.sort(function(b, c) {
        var d = b.Xb();
        b = b.Yb();
        var e = c.Xb();
        c = c.Yb();
        return d == e && b == c ? 0 : dA(d, b, e, c) ? 1 : -1
    }));
    return a.b
};
h = cA.prototype;
h.Xb = function() {
    return eA(this)[0].Xb()
};
h.Yb = function() {
    return eA(this)[0].Yb()
};
h.tc = function() {
    return hb(eA(this)).tc()
};
h.uc = function() {
    return hb(eA(this)).uc()
};
h.uf = function() {
    return 0 == this.a.length || 1 == this.a.length && this.Pd(0).uf()
};
h.tf = function() {
    return kb(yz(this), function(a) {
        return a.tf()
    }).join("")
};
h.mc = function() {
    return new fA(this)
};
h.select = function() {
    var a = xz(Vf(If(y ? this.sf() : this.Xb())));
    a.removeAllRanges();
    for (var b = 0, c = this.De(); b < c; b++) a.addRange(this.Pd(b).Fg())
};
var fA = function(a) {
    this.a = null;
    this.b = 0;
    a && (this.a = kb(eA(a), function(b) {
        return qj(b)
    }));
    vz.call(this, a ? this.w() : null, !1, !0)
};
t(fA, Az);
fA.prototype.w = function() {
    return this.a[0].w()
};
fA.prototype.m = function() {
    return this.a[this.b].m()
};
fA.prototype.next = function() {
    try {
        var a = this.a[this.b],
            b = a.next();
        uz(this, a.h, a.g, a.depth);
        return b
    } catch (c) {
        if (c !== oj || this.a.length - 1 == this.b) throw c;
        this.b++;
        return this.next()
    }
};
var hA = function() {
        var a = xz(window);
        return a && gA(a)
    },
    gA = function(a) {
        var b = !1;
        if (a.createRange) try {
            var c = a.createRange()
        } catch (e) {
            return null
        } else if (a.rangeCount) {
            if (1 < a.rangeCount) {
                b = new cA;
                c = 0;
                for (var d = a.rangeCount; c < d; c++) b.a.push(a.getRangeAt(c));
                return b
            }
            c = a.getRangeAt(0);
            b = dA(a.anchorNode, a.anchorOffset, a.focusNode, a.focusOffset)
        } else return null;
        (a = c) && a.addElement ? (b = new Zz, b.a = a, a = b) : a = Vz(Tz(a), b);
        return a
    },
    dA = function(a, b, c, d) {
        if (a == c) return d < b;
        var e;
        if (1 == a.nodeType && b)
            if (e = a.childNodes[b]) a =
                e, b = 0;
            else if (pg(a, c)) return !0;
        if (1 == c.nodeType && d)
            if (e = c.childNodes[d]) c = e, d = 0;
            else if (pg(c, a)) return !1;
        return 0 < (sg(a, c) || b - d)
    };
var iA = function() {
        var a = hA();
        return null != a && !a.uf() && 0 < a.tf().length
    },
    jA = function(a) {
        hA();
        Wz(a, void 0).select();
        a.setAttribute("tabIndex", "-1")
    },
    kA = function(a) {
        var b = D("TEXTAREA", {
            id: "hdt"
        });
        cq(b, {
            position: "absolute",
            top: Uf(document).a + "px",
            left: "-1000px"
        });
        dg(document.body, b);
        b.focus();
        E(b, a);
        a = 0;
        if (uw(b)) b.selectionStart = a;
        else if (vw()) {
            var c = ww(b),
                d = c[0];
            d.inRange(c[1]) && (a = yw(b, a), d.collapse(!0), d.move("character", a), d.select())
        }
        a = b.value.length;
        uw(b) ? b.selectionEnd = a : vw() && (d = ww(b), c = d[1], d[0].inRange(c) &&
            (a = yw(b, a), d = yw(b, xw(b, !0)[0]), c.collapse(!0), c.moveEnd("character", a - d), c.select()));
        return b
    };
var lA = function(a, b, c, d, e, f, g) {
    g = void 0 === g ? function() {} : g;
    this.L = Gm.M();
    this.G = b;
    this.g = c;
    this.C = d;
    this.o = e || null;
    this.w = f;
    this.m = g;
    this.b = this.c = this.a = 0;
    this.F = K.M();
    this.delay = new Ur(this.Vf, 3E3, this);
    this.h = a;
    G(a, "copy", this.zj, !1, this);
    G(a, "mouseup", this.Aj, !1, this);
    G(a, "contextmenu", this.Ai, !1, this);
    G(a, "click", this.yj, !1, this);
    G(n, "blur", this.flush, !1, this);
    G(n, "beforeunload", this.flush, !1, this)
};
t(lA, Jg);
h = lA.prototype;
h.flush = function() {
    this.delay.stop();
    0 < this.a + this.c + this.b && this.Vf()
};
h.T = function() {
    this.flush();
    this.delay.Ia();
    oh(this.h, "copy", this.zj, !1, this);
    oh(this.h, "mouseup", this.Aj, !1, this);
    oh(this.h, "contextmenu", this.Ai, !1, this);
    oh(this.h, "click", this.yj, !1, this);
    oh(n, "blur", this.flush, !1, this);
    oh(n, "beforeunload", this.flush, !1, this);
    lA.D.T.call(this)
};
h.zj = function() {
    this.delay.stop();
    if (void 0 !== this.w) {
        var a = this.w().length,
            b = null != n.getSelection ? n.getSelection().toString().length : document.selection && "Control" != document.selection.type ? document.selection.createRange().text.length : 0;
        this.Vf(1, a, b);
        gm(this.F, this.g, this.m(), a, b)
    } else this.Vf(1), gm(this.F, this.g, this.m())
};
h.Vf = function(a, b, c) {
    a = {
        cpy: a || 0,
        clk: this.a,
        sel: this.c,
        ctx: this.b
    };
    null != b && null != c && (a.ql = b, a.cpl = c);
    null != this.o && (a.sl = this.o.a(), a.tl = this.o.b());
    O(this.L, this.C, "ilog", this.G, a);
    this.b = this.c = this.a = 0
};
h.Aj = function() {
    if (iA()) {
        this.c++;
        var a = this.F;
        M(a, em(a, 211, this.g));
        59 <= this.c ? this.flush() : this.delay.start()
    }
};
h.yj = function(a) {
    Wg(a) && (this.a++, a = this.F, M(a, em(a, 212, this.g)), 59 <= this.a ? this.flush() : this.delay.start())
};
h.Ai = function() {
    this.b++;
    var a = this.F;
    M(a, em(a, 210, this.g));
    59 <= this.b ? this.flush() : this.delay.start()
};
var mA = {
    8: "backspace",
    9: "tab",
    13: "enter",
    16: "shift",
    17: "ctrl",
    18: "alt",
    19: "pause",
    20: "caps-lock",
    27: "esc",
    32: "space",
    33: "pg-up",
    34: "pg-down",
    35: "end",
    36: "home",
    37: "left",
    38: "up",
    39: "right",
    40: "down",
    45: "insert",
    46: "delete",
    48: "0",
    49: "1",
    50: "2",
    51: "3",
    52: "4",
    53: "5",
    54: "6",
    55: "7",
    56: "8",
    57: "9",
    59: "semicolon",
    61: "equals",
    65: "a",
    66: "b",
    67: "c",
    68: "d",
    69: "e",
    70: "f",
    71: "g",
    72: "h",
    73: "i",
    74: "j",
    75: "k",
    76: "l",
    77: "m",
    78: "n",
    79: "o",
    80: "p",
    81: "q",
    82: "r",
    83: "s",
    84: "t",
    85: "u",
    86: "v",
    87: "w",
    88: "x",
    89: "y",
    90: "z",
    93: "context",
    96: "num-0",
    97: "num-1",
    98: "num-2",
    99: "num-3",
    100: "num-4",
    101: "num-5",
    102: "num-6",
    103: "num-7",
    104: "num-8",
    105: "num-9",
    106: "num-multiply",
    107: "num-plus",
    109: "num-minus",
    110: "num-period",
    111: "num-division",
    112: "f1",
    113: "f2",
    114: "f3",
    115: "f4",
    116: "f5",
    117: "f6",
    118: "f7",
    119: "f8",
    120: "f9",
    121: "f10",
    122: "f11",
    123: "f12",
    186: "semicolon",
    187: "equals",
    189: "dash",
    188: ",",
    190: ".",
    191: "/",
    192: "`",
    219: "open-square-bracket",
    220: "\\",
    221: "close-square-bracket",
    222: "single-quote",
    224: "win"
};
var nA = function(a, b, c, d, e, f, g, k, l) {
        this.a = a;
        this.h = b;
        this.G = c;
        this.c = d;
        this.g = e;
        this.o = f;
        this.m = g;
        this.w = k;
        this.b = l
    },
    tA = function(a) {
        var b = a.b;
        b = (b = b && "composed" in b && b && "composedPath" in b && b.composed && b.composedPath()) && 0 < b.length ? b[0] : a.target;
        return oA(pA(qA(rA((new sA).keyCode(a.keyCode || 0).key(a.key || "").shiftKey(!!a.shiftKey).altKey(!!a.altKey).ctrlKey(!!a.ctrlKey).metaKey(!!a.metaKey).target(a.target), b), function() {
            return a.preventDefault()
        }), function() {
            return a.stopPropagation()
        }))
    },
    sA = function() {
        this.c =
            null;
        this.g = "";
        this.G = this.o = this.m = this.C = this.h = this.b = this.a = this.w = null
    };
h = sA.prototype;
h.keyCode = function(a) {
    this.c = a;
    return this
};
h.key = function(a) {
    this.g = a;
    return this
};
h.shiftKey = function(a) {
    this.w = a;
    return this
};
h.altKey = function(a) {
    this.a = a;
    return this
};
h.ctrlKey = function(a) {
    this.b = a;
    return this
};
h.metaKey = function(a) {
    this.h = a;
    return this
};
h.target = function(a) {
    this.C = a;
    return this
};
var rA = function(a, b) {
        a.m = b;
        return a
    },
    qA = function(a, b) {
        a.o = b;
        return a
    },
    pA = function(a, b) {
        a.G = b;
        return a
    },
    oA = function(a) {
        return new nA(Za(a.c), a.g, db(a.w), db(a.a), db(a.b), db(a.h), v(a.C), v(a.m), ab(a.o), ab(a.G))
    };
var wA = function(a) {
        J.call(this);
        this.b = this.c = {};
        this.h = 0;
        this.N = Yb(uA);
        this.V = Yb(vA);
        this.m = !0;
        this.o = null;
        this.a = a;
        G(this.a, "keydown", this.w, void 0, this);
        G(this.a, "synthetic-keydown", this.C, void 0, this);
        De && (G(this.a, "keypress", this.K, void 0, this), G(this.a, "synthetic-keypress", this.O, void 0, this));
        G(this.a, "keyup", this.G, void 0, this);
        G(this.a, "synthetic-keyup", this.L, void 0, this)
    },
    xA;
t(wA, J);
var yA = function(a) {
        this.a = a || null;
        this.next = a ? null : {}
    },
    uA = [27, 112, 113, 114, 115, 116, 117, 118, 119, 120, 121, 122, 123, 19],
    vA = "color date datetime datetime-local email month number password search tel text time url week".split(" ");
wA.prototype.R = function(a, b) {
    zA(this.c, AA(arguments), a)
};
var AA = function(a) {
    if ("string" === typeof a[1]) a = kb(BA(a[1]), function(d) {
        Za(d.keyCode, "A non-modifier key is needed in each stroke.");
        return CA(d.key || "", d.keyCode, d.Im)
    });
    else {
        var b = a,
            c = 1;
        Ia(a[1]) && (b = a[1], c = 0);
        for (a = []; c < b.length; c += 2) a.push(CA("", b[c], b[c + 1]))
    }
    return a
};
wA.prototype.T = function() {
    wA.D.T.call(this);
    this.c = {};
    oh(this.a, "keydown", this.w, !1, this);
    oh(this.a, "synthetic-keydown", this.C, !1, this);
    De && (oh(this.a, "keypress", this.K, !1, this), oh(this.a, "synthetic-keypress", this.O, !1, this));
    oh(this.a, "keyup", this.G, !1, this);
    oh(this.a, "synthetic-keyup", this.L, !1, this);
    this.a = null
};
var BA = function(a) {
    a = a.replace(/[ +]*\+[ +]*/g, "+").replace(/[ ]+/g, " ").toLowerCase();
    a = a.split(" ");
    for (var b = [], c, d = 0; c = a[d]; d++) {
        var e = c.split("+"),
            f = null,
            g = null;
        c = 0;
        for (var k, l = 0; k = e[l]; l++) {
            switch (k) {
                case "shift":
                    c |= 1;
                    continue;
                case "ctrl":
                    c |= 2;
                    continue;
                case "alt":
                    c |= 4;
                    continue;
                case "meta":
                    c |= 8;
                    continue
            }
            null !== g && Ya("At most one non-modifier key can be in a stroke.");
            e = void 0;
            f = k;
            if (!xA) {
                g = {};
                for (e in mA) g[mA[e]] = xh(parseInt(e, 10));
                xA = g
            }
            g = xA[f];
            Za(g, "Key name not found in goog.events.KeyNames: " +
                k);
            f = k;
            break
        }
        b.push({
            key: f,
            keyCode: g,
            Im: c
        })
    }
    return b
};
wA.prototype.G = function(a) {
    a = tA(a);
    ye && DA(this, a);
    De && !this.g && EA(a) && FA(this, a, !0)
};
wA.prototype.L = function(a) {
    a = a.b();
    ye && DA(this, a);
    De && !this.g && EA(a) && FA(this, a, !0)
};
var DA = function(a, b) {
        32 == a.o && 32 == b.a && (0, b.b)();
        a.o = null
    },
    EA = function(a) {
        return De && a.g && a.c
    };
wA.prototype.K = function(a) {
    a = tA(a);
    32 < a.a && EA(a) && (this.g = !0)
};
wA.prototype.O = function(a) {
    a = a.b();
    32 < a.a && EA(a) && (this.g = !0)
};
var zA = function(a, b, c) {
        var d = b.shift();
        w(d, function(e) {
            if ((e = a[e]) && (0 == b.length || e.a)) throw Error("Keyboard shortcut conflicts with existing shortcut");
        });
        b.length ? w(d, function(e) {
            e = e.toString();
            var f = new yA;
            e = e in a ? a[e] : a[e] = f;
            f = b.slice(0);
            zA(v(e.next, "An internal node must have a next map"), f, c)
        }) : w(d, function(e) {
            a[e] = new yA(c)
        })
    },
    GA = function(a, b) {
        for (var c = 0; c < b.length; c++) {
            var d = a[b[c]];
            if (d) return d
        }
    },
    CA = function(a, b, c) {
        c = c || 0;
        b = ["c_" + b + "_" + c];
        "" != a && b.push("n_" + a + "_" + c);
        return b
    };
wA.prototype.w = function(a) {
    FA(this, tA(a))
};
wA.prototype.C = function(a) {
    FA(this, a.b())
};
var FA = function(a, b, c) {
        a: {
            var d = b.a;
            if ("" != b.h) {
                var e = b.h;
                if ("Control" == e || "Shift" == e || "Meta" == e || "AltGraph" == e) {
                    d = !1;
                    break a
                }
            } else if (16 == d || 17 == d || 18 == d) {
                d = !1;
                break a
            }
            e = b.w;
            var f = "TEXTAREA" == e.tagName || "INPUT" == e.tagName || "BUTTON" == e.tagName || "SELECT" == e.tagName,
                g = !f && (e.isContentEditable || e.ownerDocument && "on" == e.ownerDocument.designMode);d = !f && !g || a.N[d] ? !0 : g ? !1 : b.c || b.g || b.o ? !0 : "INPUT" == e.tagName && a.V[e.type] ? 13 == d : "INPUT" == e.tagName || "BUTTON" == e.tagName ? 32 != d : !1
        }
        d && (!c && EA(b) ? a.g = !1 : (c = xh(b.a),
            d = CA(b.h, c, (b.G ? 1 : 0) | (b.g ? 2 : 0) | (b.c ? 4 : 0) | (b.o ? 8 : 0)), (e = GA(a.b, d)) && (e = !(1500 <= Ta() - a.h)), e || (a.b = a.c, a.h = Ta()), (e = GA(a.b, d)) && e.next && (a.b = e.next, a.h = Ta()), e && (e.next ? (0, b.b)() : (a.b = a.c, a.h = Ta(), a.m && (0, b.b)(), d = $a(e.a, "A terminal node must have a string shortcut identifier."), e = a.dispatchEvent(new HA("shortcut", d, b.m)), (e &= a.dispatchEvent(new HA("shortcut_" + d, d, b.m))) || (0, b.b)(), ye && (a.o = c)))))
    },
    HA = function(a, b, c) {
        F.call(this, a, c);
        this.identifier = b
    };
t(HA, F);
var IA = function(a) {
    this.c = a;
    this.g = Gm.M();
    this.F = K.M();
    this.a = new wA(document);
    this.a.m = !1;
    this.a.R("CTRL_SHIFT_S", 83, (Ce ? 8 : 2) | 1);
    G(this.a, "shortcut", this.b, !1, this)
};
t(IA, Jg);
IA.prototype.T = function() {
    IA.D.T.call(this);
    oh(this.a, "shortcut", this.b, !1, this)
};
IA.prototype.b = function(a) {
    "CTRL_SHIFT_S" == a.identifier && (th(this.c.b, "action"), a = this.F, M(a, N(a, 289)), this.g.log("swaplang"))
};
var KA = function(a, b, c, d, e, f) {
    J.call(this);
    this.v = a;
    this.b = D("DIV", "sl-sugg-button-container");
    this.C = b;
    a = B("sl-sugg-button-container", this.v) ? kg(this.v.firstElementChild) : kg(this.v);
    this.g = c ? c : a.length;
    fg(this.v);
    this.c = !!d;
    this.o = !!e;
    this.a = [];
    c = this.c ? this.g + 1 : this.g;
    for (d = 0; d < c; ++d) e = new As(""), e.Oa(16, !0), G(e, "action", this.O, !1, this), e.render(this.b), Ar(e.c, e, 0 == d ? 2 : 3), this.a.push(e);
    this.v.appendChild(this.b);
    this.h = [];
    this.m = D("DIV", "ls-left-arrow");
    this.w = D("DIV", "ls-right-arrow");
    this.G = 0;
    f && (this.v.insertBefore(this.m, this.v.firstChild), this.v.appendChild(this.w), G(this.m, "mouseover", function() {
        JA(this, 2)
    }, !1, this), G(this.m, "mouseout", function() {
        clearTimeout(this.G)
    }, !1, this), G(this.w, "mouseover", function() {
        JA(this, -2)
    }, !1, this), G(this.w, "mouseout", function() {
        clearTimeout(this.G)
    }, !1, this));
    this.F = K.M()
};
t(KA, J);
var JA = function(a, b) {
    a.b.scrollLeft -= b;
    a.G = setTimeout(function() {
        JA(a, b)
    }, 10)
};
KA.prototype.L = function(a) {
    this.render(a.data, a.selected)
};
KA.prototype.O = function(a) {
    var b = a.a.Y();
    if (a.a.Ea(16)) {
        a: {
            var c = a.a;
            for (var d = 0, e = 0; d < this.a.length; d++) {
                var f = this.a[d];
                if (f && f.isVisible()) {
                    if (c == f) {
                        c = e;
                        break a
                    }
                    e++
                }
            }
            c = -1
        }
        om(this.F, this.c, 2, b, c, "")
    }
    else a.a.cd(!0);
    qq(a.a.j(), this.v);
    this.dispatchEvent({
        type: "click",
        data: b
    })
};
KA.prototype.render = function(a, b) {
    a = a.slice(0, this.g);
    var c = this.h.slice();
    c.length = this.g;
    a: {
        c = xb(c).sort();
        var d = xb(a).sort();
        if (Ja(c) && Ja(d) && c.length == d.length) {
            for (var e = c.length, f = 0; f < e; f++)
                if (c[f] !== d[f]) {
                    c = !1;
                    break a
                } c = !0
        } else c = !1
    }
    c = !c;
    this.h = a;
    a = 0;
    this.c && this.o && (a = 1);
    for (d = 0; d < this.h.length; d++) {
        e = this.a[a];
        f = this.h[d];
        if (c) {
            e.yf(f);
            var g = this.C(f);
            e.g(g)
        }
        LA(this, e, e.Y() == b, f);
        a++
    }
    for (; a < this.g; a++) this.a[a].setVisible(!1);
    this.c && (a = this.a[this.o ? 0 : this.a.length - 1], a.yf("auto"), a.g(detect_language),
        LA(this, a, a.Y() == b));
    W(this.v, !0)
};
var LA = function(a, b, c, d) {
    b.setVisible(!0);
    b.cd(c);
    c && qq(b.j(), a.b);
    d && (b.j().id = "sugg-item-" + d)
};
KA.prototype.K = function(a) {
    if (this.c) {
        var b = this.a[this.o ? 0 : this.a.length - 1];
        "" == a.data ? b.g(detect_language) : (a = source_language_detected.replace(/%\d\$s/g, this.C(a.data)), b.g(a))
    }
};
var MA = function(a) {
        this.a = a;
        this.b = this.m = this.h = this.o = this.g = null;
        this.O = !1;
        this.c = null;
        this.C = function() {
            return ""
        };
        this.w = Gm.M();
        this.W = tl.M();
        this.F = K.M();
        this.G = null
    },
    PA = function(a, b) {
        b.ij && (a.g = b.ij, NA(a.g, a.La, a), OA(a, a.a, "srcLanguageUpdated", a.Ml), OA(a, a.a, "detectSrcUpdated", a.wl));
        b.rj && (a.o = b.rj, NA(a.o, a.N, a), OA(a, a.a, "tgtLanguageUpdated", a.Vl));
        b.fj && (a.K = b.fj, OA(a, a.K, "action", a.Fa));
        b.hj && (a.R = b.hj, OA(a, a.R, "action", p(a.L, a, "src", !0)));
        b.qj && (a.V = b.qj, OA(a, a.V, "action", p(a.L, a, "tgt",
            !1)));
        if (b.jj) {
            a.h = b.jj;
            OA(a, a.h, "click", a.Nl);
            var c = a.h;
            G(a.a, "staticSrcSuggestionUpdated", c.L, !1, c);
            c = a.h;
            G(a.a, "detectSrcUpdated", c.K, !1, c)
        }
        b.sj && (a.m = b.sj, OA(a, a.m, "click", a.Wl), c = a.m, G(a.a, "staticTgtSuggestionUpdated", c.L, !1, c));
        b.Nc && (a.b = b.Nc, OA(a, a.b, "action", a.Tl));
        b.tj && (a.c = b.tj, OA(a, new fr(a.c.j()), "key", a.Fi), OA(a, new Qv(a.c.j()), "paste", a.Fi));
        b.Za && (a.C = b.Za)
    },
    RA = function(a, b) {
        (a.O = b) && a.b ? a.b.oa(!1) : QA(a)
    },
    OA = function(a, b, c, d) {
        b && G(b, c, d, !1, a)
    };
MA.prototype.La = function() {
    var a = this.g,
        b = this.a.g;
    var c = sw(this.a.W);
    SA(this, a, b, c, "slc")
};
MA.prototype.N = function() {
    var a = this.o,
        b = this.a.h;
    var c = sw(this.a.X.a);
    SA(this, a, b, c, "tlc", !0)
};
var TA = function(a, b, c) {
    var d = {};
    d.lpk = c;
    a.G = d;
    a.G.lsa = b;
    O(a.w, "webapp", "lsa", b, d)
};
MA.prototype.Fa = function() {
    this.g && this.g.isVisible() ? (TA(this, "lso", "src"), nm(this.F, 217)) : this.o && this.o.isVisible() && (TA(this, "lso", "tgt"), nm(this.F, 219))
};
MA.prototype.L = function(a, b) {
    TA(this, "lsc", a);
    nm(this.F, b ? 218 : 220)
};
var SA = function(a, b, c, d, e, f) {
    var g = b.Y(),
        k = UA(a),
        l = VA(a, f);
    c.call(a.a, g, 4);
    null != b.O && Wb(k, b.O);
    "" != d && (k.emphlang = d);
    b = sw(a.a.L.a);
    f || "" == b || (k.bslang = b);
    "" != l && (k.sugglang = l);
    a.G = k;
    a.G[e] = g;
    O(a.w, "webapp", e, g, k)
};
h = MA.prototype;
h.Ml = function(a) {
    this.g.Y() != a.data && WA(this.g, a.data);
    QA(this);
    a.Zh && (XA(this, "slauto", UA(this)), nm(this.F, 221))
};
h.wl = function() {
    QA(this)
};
h.Vl = function(a) {
    this.o.Y() != a.data && WA(this.o, a.data);
    QA(this);
    a.Zh && (XA(this, "tlauto", UA(this)), nm(this.F, 222))
};
h.Nl = function(a) {
    if (a.data == this.a.a) a.target.dispatchEvent({
        type: "clickSelected"
    }), a.preventDefault();
    else {
        var b = this.a.g,
            c = VA(this),
            d = UA(this, a.data);
        b.call(this.a, a.data, 3);
        d.sugglang = c;
        XA(this, "ssuggclick", d)
    }
};
h.Wl = function(a) {
    if (a.data == this.a.b) a.target.dispatchEvent({
        type: "clickSelected"
    }), a.preventDefault();
    else {
        var b = this.a.h,
            c = VA(this, !0),
            d = UA(this, a.data);
        b.call(this.a, a.data, 3);
        d.sugglang = c;
        XA(this, "tsuggclick", d)
    }
};
h.Tl = function() {
    var a = UA(this),
        b = this.a.a,
        c = this.a.b,
        d = b;
    if ("auto" == b && (d = this.a.c, !d)) return;
    (b = this.C()) && this.c && (this.c.b(b), wl(this.W, 28));
    XA(this, "swapclick", a);
    a = this.a;
    a.g(c, 5);
    a.h(d, 5);
    a.dispatchEvent("languageSelected");
    Nm(this.w, "swap", 1, "accumulate");
    c = this.F;
    d = N(c, 89);
    a = Zk();
    lf(d, 46, a);
    M(c, d)
};
h.Fi = function(a) {
    if ("paste" == a.type || 2 > yc(this.c.Y()).length) this.a.G = !1
};
var UA = function(a, b) {
        var c = {};
        c.sl = a.a.a;
        c.tl = a.a.b;
        b && (c.val = b);
        (b = a.a.c) && (c.dsl = b);
        a.c && (c.ql = yc(a.c.Y()).length);
        return c
    },
    YA = function(a) {
        Nm(a.w, "ssel", a.a.na);
        Nm(a.w, "tsel", a.a.Z)
    },
    XA = function(a, b, c) {
        a.G = c;
        a.w.log(b, c)
    },
    VA = function(a, b) {
        return b ? sw(a.a.O.a) : sw(a.a.K.a)
    },
    QA = function(a) {
        if (a.b && !a.O) {
            var b = a.a.a;
            "auto" == b && (b = a.a.c);
            "zh-CN" == b && "zh-TW" == a.a.w && (b = "zh-TW");
            "" == b || b == a.a.b ? a.b.oa(!1) : a.b.oa(!0)
        }
    };
var ZA = 0,
    $A = /^[a-zA-Z0-9_\-]*$/,
    aB = function(a) {
        v(a.match($A), "ControlType.create contains invalid characters" + a);
        return a + "+" + ZA++
    };
var bB = function(a, b) {
    Jg.call(this);
    this.c = null;
    this.g = b;
    this.a = [];
    if (a > this.g) throw Error("[goog.structs.SimplePool] Initial cannot be greater than max");
    for (b = 0; b < a; b++) this.a.push(this.b())
};
t(bB, Jg);
var cB = function(a, b) {
        a.c = b
    },
    eB = function(a, b) {
        a.a.length < a.g ? a.a.push(b) : dB(b)
    };
bB.prototype.b = function() {
    return this.c ? this.c() : {}
};
var dB = function(a) {
    if (La(a))
        if (Ka(a.Ia)) a.Ia();
        else
            for (var b in a) delete a[b]
};
bB.prototype.T = function() {
    bB.D.T.call(this);
    for (var a = this.a; a.length;) dB(a.pop());
    delete this.a
};
var hB = function() {
    this.a = [];
    this.b = new tj;
    this.L = this.K = this.O = this.m = 0;
    this.c = new tj;
    this.o = this.C = 0;
    this.Fa = 1;
    this.g = new bB(0, 4E3);
    this.g.b = function() {
        return new fB
    };
    this.G = new bB(0, 50);
    this.G.b = function() {
        return new gB
    };
    var a = this;
    this.w = new bB(0, 2E3);
    cB(this.w, function() {
        return a.Fa++
    });
    this.h = {}
};
hB.prototype.F = Wi("goog.debug.Trace");
var gB = function() {
    this.Dh = this.time = this.count = 0
};
gB.prototype.toString = function() {
    var a = [];
    a.push(this.type, " ", this.count, " (", Math.round(10 * this.time) / 10, " ms)");
    this.Dh && a.push(" [VarAlloc = ", this.Dh, "]");
    return a.join("")
};
var fB = function() {},
    kB = function(a, b, c, d) {
        var e = []; - 1 == c ? e.push("    ") : e.push(iB(a.b - c));
        e.push(" ", jB(a.b - b));
        0 == a.a ? e.push(" Start        ") : 1 == a.a ? (e.push(" Done "), e.push(iB(a.h - a.startTime), " ms ")) : e.push(" Comment      ");
        e.push(d, a);
        0 < a.g && e.push("[VarAlloc ", a.g, "] ");
        return e.join("")
    };
fB.prototype.toString = function() {
    return null == this.type ? v(this.c) : "[" + this.type + "] " + this.c
};
var lB = {
    jr: !0
};
hB.prototype.nh = function() {
    this.h = {}
};
var mB = function(a) {
    a.h.stop && rj(a.b, function(b) {
        this.h.stop(b.id, lB)
    }, a);
    a.b.Wc()
};
hB.prototype.reset = function() {
    mB(this);
    for (var a = 0; a < this.a.length; a++) {
        var b = this.a[a];
        b.id ? wj(this.b, b.id) || (eB(this.w, b.id), eB(this.g, b)) : eB(this.g, b)
    }
    this.a.length = 0;
    this.m = Ta();
    this.o = this.C = this.L = this.K = this.O = 0;
    a = this.c.Cb();
    for (b = 0; b < a.length; b++) {
        var c = this.c.get(a[b]);
        c.count = 0;
        c.time = 0;
        c.Dh = 0;
        eB(this.G, c)
    }
    this.c.Wc()
};
hB.prototype.toString = function() {
    for (var a = [], b = -1, c = [], d = 0; d < this.a.length; d++) {
        var e = this.a[d];
        1 == e.a && c.pop();
        a.push(" ", kB(e, this.m, b, c.join("")));
        b = e.b;
        a.push("\n");
        0 == e.a && c.push("|  ")
    }
    if (0 != this.b.Hg()) {
        var f = Ta();
        a.push(" Unstopped timers:\n");
        rj(this.b, function(g) {
            a.push("  ", g, " (", f - g.startTime, " ms, started at ", jB(g.startTime), ")\n")
        })
    }
    b = this.c.Cb();
    for (d = 0; d < b.length; d++) c = this.c.get(b[d]), 1 < c.count && a.push(" TOTAL ", c, "\n");
    a.push("Total tracers created ", this.C, "\n", "Total comments created ",
        this.o, "\n", "Overhead start: ", this.O, " ms\n", "Overhead end: ", this.K, " ms\n", "Overhead comment: ", this.L, " ms\n");
    return a.join("")
};
var iB = function(a) {
        a = Math.round(a);
        var b = "";
        1E3 > a && (b = " ");
        100 > a && (b = "  ");
        10 > a && (b = "   ");
        return b + a
    },
    jB = function(a) {
        a = Math.round(a);
        return String(100 + a / 1E3 % 60).substring(1, 3) + "." + String(1E3 + a % 1E3).substring(1, 4)
    };
new hB;
var nB = function() {};
nB.prototype.stopPropagation = function() {
    this.g = !0;
    this.h()
};
nB.prototype.c = function() {
    return this.g || !1
};
var oB = function(a) {
    this.a = [];
    this.name = a
};
oB.prototype.c = Wi("wireless.events.browser.Dispatcher");
oB.prototype.dispatchEvent = function(a, b) {
    var c = "*" == a.a.charAt(0),
        d;
    this.handleEvent(a, b) && (d = !0);
    for (var e = (b || "") + this.name + "->", f = -1, g;
        (!d || c) && (g = this.a[++f]);) d = g.dispatchEvent(a, e) || d;
    d || b || Yi(this.c, "Event not handled: " + a.a + " type: " + (a ? a.type : "none") + " customArg: " + a.b);
    return d
};
var pB = function(a, b) {
    oB.call(this, b);
    this.g = a;
    this.b = [];
    this.C = {}
};
t(pB, oB);
var qB = new pB(void 0, "root");
ya("_e", function(a, b, c, d) {
    a = a || {};
    a.a = b;
    a.b = c;
    a.o = d || a.currentTarget || null;
    a.h = a.stopPropagation;
    a.stopPropagation = nB.prototype.stopPropagation;
    a.c = nB.prototype.c;
    return qB.dispatchEvent(a)
});
var rB = function(a, b, c) {
    v(b, a.name + " - registerHandler: Missing controlType.");
    v(c, a.name + " - registerHandler: Missing handlerFunc. controlType: " + b);
    v(!a.C[b], a.name + " - registerHandler: Handler already defined. controlType: " + b);
    c = a.b.push(c, a.g) - 2;
    a.C[b] = c
};
pB.prototype.handleEvent = function(a, b) {
    var c = this.C[a.a];
    if (void 0 !== c) return sB(this, a, a.a, a.b, b), this.b[c].call(this.b[c + 1], a, a.a, a.b), !0
};
var sB = function(a, b, c, d, e) {
    ")" == c.slice(-1) || Zi(a.c, p(function() {
        var f = "";
        b && (f = "BrowserType=" + b.type, b.which && (f += " key=" + b.which), f = " (" + f + ")");
        var g = "";
        void 0 !== d && (g = " customArg: " + d);
        return (e || "") + this.name + " handling event: " + c + g + f
    }, a))
};
var tB = function(a, b) {
        this.Code = a;
        this.Name = b
    },
    xB = function(a, b, c) {
        this.qa = b.qa + "_" + a.Code;
        "rcnt" == c ? this.qa += "_r" : "srch" == c && (this.qa += "_s");
        uB[this.qa] = this;
        this.b = b;
        this.a = c;
        this.Nb = a.Name;
        this.code = a.Code;
        this.v = Xp(vB, {
            id: this.qa,
            name: a.Name,
            code: a.Code,
            re: wB
        })
    },
    yB = {},
    zB = (yB.rglr = 0, yB.rcnt = 2, yB.srch = 3, yB);
xB.prototype.j = function() {
    return this.v
};
xB.prototype.ue = function(a) {
    this.b.ue(this.Nb, this.code, this.a, a)
};
var uB = {},
    AB = function(a) {
        if (a && a.parentNode && a.parentNode.children)
            for (var b = 0, c = 0, d = a.parentNode; b < d.children.length; b++) {
                var e = d.children[b];
                if (yq(e) && Qp(e, "language_list_item_wrapper")) {
                    if (a == e) return c;
                    c++
                }
            }
        return -1
    },
    BB = function(a, b, c) {
        (b = uB[c]) && b.ue(AB(a.currentTarget))
    },
    CB = null,
    wB = aB("changeLanguage"),
    DB = aB("searchEdited"),
    HB = function(a, b) {
        Jg.call(this);
        this.a = [];
        this.c = [];
        this.g = [];
        this.qa = a;
        this.C = null;
        this.L = [];
        this.ra = new J;
        this.v = D("DIV", "language-list");
        this.h = b;
        this.o = Xp(EB, {
            re: DB,
            wm: this.qa,
            xm: this.h.o
        });
        dg(this.v, this.o);
        W(this.o, !1);
        this.G = new As;
        this.G.ba(B("back-image-black", this.o));
        this.G.xd(this.h.b);
        Ir(this.G, this.h.b);
        G(this.G, "action", this.ia, !1, this);
        if (b = B("clear-image-black", this.o)) this.N = new As, this.N.ba(b), this.N.xd(this.h.a), Ir(this.N, this.h.a), G(this.N, "action", this.W, !1, this), W(b, !1);
        this.m = D("DIV", "language-list-unfiltered-langs-" + this.qa);
        this.Z = D("DIV", "language_list_languages language_list_" + a);
        dg(this.Z, this.m);
        dg(this.v, this.Z);
        this.b = D("DIV", "language_list_languages language_list_" +
            a);
        dg(this.v, this.b);
        W(this.b, !1);
        this.R = "";
        this.w = FB(this.h.h, this.m);
        W(this.w, !1);
        this.Ca = FB(this.h.c, this.m);
        GB[this.qa] = this;
        this.xa = 0;
        this.F = K.M();
        this.Na = "";
        this.O = {}
    };
t(HB, Jg);
var GB = {},
    NA = function(a, b, c) {
        G(a.ra, "returned", b, !1, c)
    },
    WA = function(a, b) {
        for (var c = 0; c < a.a.length; c++)
            if (a.a[c].code === b) {
                null != a.C && (a.C.setAttribute("aria-label", a.a[c].Nb), E(a.C, a.a[c].Nb));
                a.V(a.a[c].Nb, a.a[c].code);
                a.R = b;
                break
            }
    };
HB.prototype.Y = function() {
    return this.R
};
var JB = function(a, b, c) {
        IB(GB[c], (new Tg(a)).target.value)
    },
    IB = function(a, b) {
        var c = B("clear-image-black", a.o);
        a.Na = b;
        if ("" === b) W(a.m.parentElement, !0), W(a.b, !1), c && W(c, !1);
        else
            for (W(a.m.parentElement, !1), W(a.b, !0), c && W(c, !0), a = kg(a.b), c = 0; c < a.length; c++) {
                var d = a[c],
                    e = b,
                    f = Cg(d),
                    g = 0 == zc(e, f.substr(0, e.length));
                W(d, g);
                d = B("language_list_item", d);
                d.innerHTML = f;
                g && (e = f.substr(0, e.length), f = f.replace(e, "<b>" + e + "</b>"), d.innerHTML = f)
            }
    };
HB.prototype.ue = function(a, b, c, d) {
    WA(this, b);
    om(this.F, "sl_list" == this.qa, zB[c], b, d, "srch" == c ? this.Na : "");
    this.O.ct = (Ta() - this.xa).toString();
    this.O.stp = c;
    this.close()
};
HB.prototype.V = function(a, b) {
    if ("auto" != b) {
        a = new tB(b, a);
        for (var c = 0; c < this.c.length; c++)
            if (this.c[c].code === b) {
                KB(this, c, 1);
                break
            } b = new xB(a, this, "rcnt");
        ig(this.w, b.j(), 1);
        this.c.splice(0, 0, b);
        5 < this.c.length && KB(this, 5, this.c.length - 5);
        W(this.w, !0)
    }
};
var MB = function(a) {
    a.xa = Ta();
    a.ia();
    LB(a, a.a);
    LB(a, a.c);
    LB(a, a.g);
    for (var b = 0; b < a.a.length; b++) {
        var c = a.a[b],
            d = a.L.includes(c.code);
        V(c.j(), "item-emphasized", d)
    }
    nm(a.F, "sl_list" === a.qa ? 82 : 83)
};
HB.prototype.close = function() {
    th(this.ra, "returned")
};
var LB = function(a, b) {
        for (var c = 0; c < b.length; c++) {
            V(b[c].j(), "item-selected", b[c].code === a.R);
            var d = B("language_list_item", b[c].j()),
                e = "";
            b[c].code === a.R && (e = a.h.g.replace("%1$s", b[c].Nb));
            d.setAttribute("aria-label", e)
        }
    },
    KB = function(a, b, c) {
        for (var d = b; d < b + c; d++) jg(a.c[d].j());
        a.c.splice(b, c);
        W(a.w, 0 < a.c.length)
    },
    OB = function(a, b) {
        KB(a, 0, a.c.length);
        W(a.w, 0 < b.length);
        for (var c = 0; c < b.length && 5 > c; c++) {
            for (var d = new tB(b[c], ""), e = 0; e < a.a.length; e++) a.a[e].code === b[c] && (d.Name = a.a[e].Nb);
            d = NB(a, d, a.w, "rcnt");
            a.c.push(d)
        }
        a.L = b
    },
    QB = function(a) {
        W(a.o, !0);
        a.W();
        PB(a).focus()
    },
    RB = function(a) {
        !yq(a.o) && QB(a)
    };
HB.prototype.ia = function() {
    this.W();
    W(this.o, !1)
};
HB.prototype.setVisible = function(a) {
    W(this.v, a)
};
HB.prototype.isVisible = function() {
    return yq(this.v)
};
HB.prototype.W = function() {
    PB(this).value = "";
    IB(this, "")
};
var PB = function(a) {
        return eb(a.v.querySelector("#" + a.qa + "-search-box"))
    },
    NB = function(a, b, c, d) {
        d = new xB(b, a, d);
        "auto" === b.Code ? ig(a.m, d.j(), 0) : dg(c, d.j());
        return d
    },
    FB = function(a, b) {
        a = Xp(SB, {
            text: a
        });
        dg(b, a);
        return a
    };
HB.prototype.K = function(a) {
    for (var b = 0; b < this.a.length; b++) jg(this.a[b].j());
    for (b = 0; b < this.g.length; b++) jg(this.g[b].j());
    this.a = [];
    this.g = [];
    if (null != a)
        for (b = 0; b < a.length; b++) {
            var c = NB(this, a[b], this.Ca, "rglr");
            this.a.push(c);
            "auto" != a[b].Code && (c = NB(this, a[b], this.b, "srch"), this.g.push(c))
        }
};
HB.prototype.T = function() {
    HB.D.T.call(this)
};
HB.prototype.j = function() {
    return this.v
};
var TB = function(a) {
    this.a = a
};
TB.prototype.tb = function() {
    return null
};
TB.prototype.Ua = function() {
    return this.a
};
var UB = {
        "* ARIA-CHECKED": !0,
        "* ARIA-COLCOUNT": !0,
        "* ARIA-COLINDEX": !0,
        "* ARIA-DESCRIBEDBY": !0,
        "* ARIA-DISABLED": !0,
        "* ARIA-GOOG-EDITABLE": !0,
        "* ARIA-LABEL": !0,
        "* ARIA-LABELLEDBY": !0,
        "* ARIA-MULTILINE": !0,
        "* ARIA-MULTISELECTABLE": !0,
        "* ARIA-ORIENTATION": !0,
        "* ARIA-PLACEHOLDER": !0,
        "* ARIA-READONLY": !0,
        "* ARIA-REQUIRED": !0,
        "* ARIA-ROLEDESCRIPTION": !0,
        "* ARIA-ROWCOUNT": !0,
        "* ARIA-ROWINDEX": !0,
        "* ARIA-SELECTED": !0,
        "* ABBR": !0,
        "* ACCEPT": !0,
        "* ACCESSKEY": !0,
        "* ALIGN": !0,
        "* ALT": !0,
        "* AUTOCOMPLETE": !0,
        "* AXIS": !0,
        "* BGCOLOR": !0,
        "* BORDER": !0,
        "* CELLPADDING": !0,
        "* CELLSPACING": !0,
        "* CHAROFF": !0,
        "* CHAR": !0,
        "* CHECKED": !0,
        "* CLEAR": !0,
        "* COLOR": !0,
        "* COLSPAN": !0,
        "* COLS": !0,
        "* COMPACT": !0,
        "* COORDS": !0,
        "* DATETIME": !0,
        "* DIR": !0,
        "* DISABLED": !0,
        "* ENCTYPE": !0,
        "* FACE": !0,
        "* FRAME": !0,
        "* HEIGHT": !0,
        "* HREFLANG": !0,
        "* HSPACE": !0,
        "* ISMAP": !0,
        "* LABEL": !0,
        "* LANG": !0,
        "* MAX": !0,
        "* MAXLENGTH": !0,
        "* METHOD": !0,
        "* MULTIPLE": !0,
        "* NOHREF": !0,
        "* NOSHADE": !0,
        "* NOWRAP": !0,
        "* OPEN": !0,
        "* READONLY": !0,
        "* REQUIRED": !0,
        "* REL": !0,
        "* REV": !0,
        "* ROLE": !0,
        "* ROWSPAN": !0,
        "* ROWS": !0,
        "* RULES": !0,
        "* SCOPE": !0,
        "* SELECTED": !0,
        "* SHAPE": !0,
        "* SIZE": !0,
        "* SPAN": !0,
        "* START": !0,
        "* SUMMARY": !0,
        "* TABINDEX": !0,
        "* TITLE": !0,
        "* TYPE": !0,
        "* VALIGN": !0,
        "* VALUE": !0,
        "* VSPACE": !0,
        "* WIDTH": !0
    },
    VB = {
        "* USEMAP": !0,
        "* ACTION": !0,
        "* CITE": !0,
        "* HREF": !0,
        "* LONGDESC": !0,
        "* SRC": !0,
        "LINK HREF": !0,
        "* FOR": !0,
        "* HEADERS": !0,
        "* NAME": !0,
        "A TARGET": !0,
        "* CLASS": !0,
        "* ID": !0,
        "* STYLE": !0
    };
var WB = {};

function XB(a) {
    if (y && !Qe(9)) return [0, 0, 0, 0];
    var b = WB.hasOwnProperty(a) ? WB[a] : null;
    if (b) return b;
    65536 < Object.keys(WB).length && (WB = {});
    var c = [0, 0, 0, 0];
    b = YB(a, /\\[0-9A-Fa-f]{6}\s?/g);
    b = YB(b, /\\[0-9A-Fa-f]{1,5}\s/g);
    b = YB(b, /\\./g);
    b = b.replace(/:not\(([^\)]*)\)/g, "     $1 ");
    b = b.replace(/{[^]*/gm, "");
    b = ZB(b, c, /(\[[^\]]+\])/g, 2);
    b = ZB(b, c, /(#[^\#\s\+>~\.\[:]+)/g, 1);
    b = ZB(b, c, /(\.[^\s\+>~\.\[:]+)/g, 2);
    b = ZB(b, c, /(::[^\s\+>~\.\[:]+|:first-line|:first-letter|:before|:after)/gi, 3);
    b = ZB(b, c, /(:[\w-]+\([^\)]*\))/gi, 2);
    b = ZB(b, c, /(:[^\s\+>~\.\[:]+)/g, 2);
    b = b.replace(/[\*\s\+>~]/g, " ");
    b = b.replace(/[#\.]/g, " ");
    ZB(b, c, /([^\s\+>~\.\[:]+)/g, 3);
    b = c;
    return WB[a] = b
}

function ZB(a, b, c, d) {
    return a.replace(c, function(e) {
        b[d] += 1;
        return Array(e.length + 1).join(" ")
    })
}

function YB(a, b) {
    return a.replace(b, function(c) {
        return Array(c.length + 1).join("A")
    })
};
var $B = {
        rgb: !0,
        rgba: !0,
        alpha: !0,
        rect: !0,
        image: !0,
        "linear-gradient": !0,
        "radial-gradient": !0,
        "repeating-linear-gradient": !0,
        "repeating-radial-gradient": !0,
        "cubic-bezier": !0,
        matrix: !0,
        perspective: !0,
        rotate: !0,
        rotate3d: !0,
        rotatex: !0,
        rotatey: !0,
        steps: !0,
        rotatez: !0,
        scale: !0,
        scale3d: !0,
        scalex: !0,
        scaley: !0,
        scalez: !0,
        skew: !0,
        skewx: !0,
        skewy: !0,
        translate: !0,
        translate3d: !0,
        translatex: !0,
        translatey: !0,
        translatez: !0
    },
    aC = /[\n\f\r"'()*<>]/g,
    bC = {
        "\n": "%0a",
        "\f": "%0c",
        "\r": "%0d",
        '"': "%22",
        "'": "%27",
        "(": "%28",
        ")": "%29",
        "*": "%2a",
        "<": "%3c",
        ">": "%3e"
    };

function cC(a) {
    return v(bC[a])
}
var dC = function(a, b, c) {
    b = yc(b);
    if ("" == b) return null;
    if (0 == zc("url(", b.substr(0, 4))) {
        if (!b.endsWith(")") || 1 < (b ? b.split("(").length - 1 : 0) || 1 < (b ? b.split(")").length - 1 : 0) || !c) a = null;
        else {
            a: {
                b = b.substring(4, b.length - 1);
                for (var d = 0; 2 > d; d++) {
                    var e = "\"'".charAt(d);
                    if (b.charAt(0) == e && b.charAt(b.length - 1) == e) {
                        b = b.substring(1, b.length - 1);
                        break a
                    }
                }
            }
            a = c ? (a = c(b, a)) && "about:invalid#zClosurez" != Pc(a) ? 'url("' + Pc(a).replace(aC, cC) + '")' : null : null
        }
        return a
    }
    if (0 < b.indexOf("(")) {
        if (/"|'/.test(b)) return null;
        for (a = /([\-\w]+)\(/g; c =
            a.exec(b);)
            if (!(c[1] in $B)) return null
    }
    return b
};

function eC(a, b) {
    a = n[a];
    return a && a.prototype ? (b = Object.getOwnPropertyDescriptor(a.prototype, b)) && b.get || null : null
}

function fC(a, b) {
    return (a = n[a]) && a.prototype && a.prototype[b] || null
}
var gC = eC("Element", "attributes") || eC("Node", "attributes"),
    hC = fC("Element", "hasAttribute"),
    iC = fC("Element", "getAttribute"),
    jC = fC("Element", "setAttribute"),
    kC = fC("Element", "removeAttribute"),
    lC = fC("Element", "getElementsByTagName"),
    mC = fC("Element", "matches") || fC("Element", "msMatchesSelector"),
    nC = eC("Node", "nodeName"),
    oC = eC("Node", "nodeType"),
    pC = eC("Node", "parentNode"),
    qC = eC("HTMLElement", "style") || eC("Element", "style"),
    rC = eC("HTMLStyleElement", "sheet"),
    sC = fC("CSSStyleDeclaration", "getPropertyValue"),
    tC = fC("CSSStyleDeclaration", "setProperty");

function uC(a, b, c, d) {
    if (a) return a.apply(b);
    a = b[c];
    if (!d(a)) throw Error("Clobbering detected");
    return a
}

function vC(a, b, c, d) {
    if (a) return a.apply(b, d);
    if (y && 10 > document.documentMode) {
        if (!b[c].call) throw Error("IE Clobbering detected");
    } else if ("function" != typeof b[c]) throw Error("Clobbering detected");
    return b[c].apply(b, d)
}

function wC(a) {
    return uC(gC, a, "attributes", function(b) {
        return b instanceof NamedNodeMap
    })
}

function xC(a, b, c) {
    try {
        vC(jC, a, "setAttribute", [b, c])
    } catch (d) {
        if (-1 == d.message.indexOf("A security problem occurred")) throw d;
    }
}

function yC(a) {
    zC(a);
    return uC(qC, a, "style", function(b) {
        return b instanceof CSSStyleDeclaration
    })
}

function zC(a) {
    if (!(a instanceof HTMLElement)) throw Error("Not an HTMLElement");
}

function AC(a) {
    zC(a);
    return uC(rC, a, "sheet", function(b) {
        return b instanceof CSSStyleSheet
    })
}

function BC(a) {
    return uC(nC, a, "nodeName", function(b) {
        return "string" == typeof b
    })
}

function CC(a) {
    return uC(oC, a, "nodeType", function(b) {
        return "number" == typeof b
    })
}

function DC(a) {
    return uC(pC, a, "parentNode", function(b) {
        return !(b && "string" == typeof b.name && b.name && "parentnode" == b.name.toLowerCase())
    })
}

function EC(a, b) {
    return vC(sC, a, a.getPropertyValue ? "getPropertyValue" : "getAttribute", [b]) || ""
}

function FC(a, b, c) {
    vC(tC, a, a.setProperty ? "setProperty" : "setAttribute", [b, c])
};
var GC = y && 10 > document.documentMode ? null : /\s*([^\s'",]+[^'",]*(('([^'\r\n\f\\]|\\[^])*')|("([^"\r\n\f\\]|\\[^])*")|[^'",])*)/g,
    HC = {
        "-webkit-border-horizontal-spacing": !0,
        "-webkit-border-vertical-spacing": !0
    },
    KC = function(a, b, c) {
        var d = [];
        a = IC(xb(a.cssRules));
        w(a, function(e) {
            if (b && !/[a-zA-Z][\w-:\.]*/.test(b)) throw Error("Invalid container id");
            if (!(b && y && 10 == document.documentMode && /\\['"]/.test(e.selectorText))) {
                var f = b ? e.selectorText.replace(GC, "#" + b + " $1") : e.selectorText;
                d.push(ld(f, JC(e.style, c)))
            }
        });
        return nd(d)
    },
    IC = function(a) {
        return jb(a, function(b) {
            return b instanceof CSSStyleRule || b.type == CSSRule.STYLE_RULE
        })
    },
    MC = function(a, b, c) {
        a = LC("<style>" + a + "</style>");
        return null == a || null == a.sheet ? od : KC(a.sheet, void 0 != b ? b : null, c)
    },
    LC = function(a) {
        if (y && !Qe(10) || "function" != typeof n.DOMParser) return null;
        a = Od(dc("Never attached to DOM."), "<html><head></head><body>" + a + "</body></html>");
        return (new DOMParser).parseFromString(Ad(a), "text/html").body.children[0]
    },
    JC = function(a, b) {
        if (!a) return Zc;
        var c = document.createElement("div").style,
            d = NC(a);
        w(d, function(e) {
            var f = ze && e in HC ? e : e.replace(/^-(?:apple|css|epub|khtml|moz|mso?|o|rim|wap|webkit|xv)-(?=[a-z])/i, "");
            vc(f, "--") || vc(f, "var") || (e = EC(a, e), e = dC(f, e, b), null != e && FC(c, f, e))
        });
        return Pd(c.cssText || "")
    },
    PC = function(a) {
        var b = Array.from(vC(lC, a, "getElementsByTagName", ["STYLE"])),
            c = Bb(b, function(e) {
                return xb(AC(e).cssRules)
            });
        c = IC(c);
        c.sort(function(e, f) {
            e = XB(e.selectorText);
            a: {
                f = XB(f.selectorText);
                for (var g = Math.min(e.length, f.length), k = 0; k < g; k++) {
                    var l = e[k];
                    var m = f[k];
                    l = l > m ? 1 : l <
                        m ? -1 : 0;
                    if (0 != l) {
                        e = l;
                        break a
                    }
                }
                e = e.length;f = f.length;e = e > f ? 1 : e < f ? -1 : 0
            }
            return -e
        });
        a = document.createTreeWalker(a, NodeFilter.SHOW_ELEMENT, null, !1);
        for (var d; d = a.nextNode();) w(c, function(e) {
            vC(mC, d, d.matches ? "matches" : "msMatchesSelector", [e.selectorText]) && e.style && OC(d, e.style)
        });
        w(b, jg)
    },
    OC = function(a, b) {
        var c = NC(a.style),
            d = NC(b);
        w(d, function(e) {
            if (!(0 <= c.indexOf(e))) {
                var f = EC(b, e);
                FC(a.style, e, f)
            }
        })
    },
    NC = function(a) {
        Ja(a) ? a = xb(a) : (a = Ob(a), ub(a, "cssText"));
        return a
    };
var QC = "undefined" != typeof WeakMap && -1 != WeakMap.toString().indexOf("[native code]"),
    RC = 0,
    SC = function() {
        this.c = [];
        this.b = [];
        this.a = "data-elementweakmap-index-" + RC++
    };
SC.prototype.set = function(a, b) {
    if (vC(hC, a, "hasAttribute", [this.a])) {
        var c = parseInt(vC(iC, a, "getAttribute", [this.a]) || null, 10);
        this.b[c] = b
    } else c = this.b.push(b) - 1, xC(a, this.a, c.toString()), this.c.push(a);
    return this
};
SC.prototype.get = function(a) {
    if (vC(hC, a, "hasAttribute", [this.a])) return a = parseInt(vC(iC, a, "getAttribute", [this.a]) || null, 10), this.b[a]
};
SC.prototype.clear = function() {
    this.c.forEach(function(a) {
        vC(kC, a, "removeAttribute", [this.a])
    }, this);
    this.c = [];
    this.b = []
};
var TC = Wi("goog.html.sanitizer.SafeDomTreeProcessor"),
    UC = !y || Se(10),
    VC = !y || null == document.documentMode,
    WC = function() {};
var XC = {
    APPLET: !0,
    AUDIO: !0,
    BASE: !0,
    BGSOUND: !0,
    EMBED: !0,
    FORM: !0,
    IFRAME: !0,
    ISINDEX: !0,
    KEYGEN: !0,
    LAYER: !0,
    LINK: !0,
    META: !0,
    OBJECT: !0,
    SCRIPT: !0,
    SVG: !0,
    STYLE: !0,
    TEMPLATE: !0,
    VIDEO: !0
};
var YC = {
    A: !0,
    ABBR: !0,
    ACRONYM: !0,
    ADDRESS: !0,
    AREA: !0,
    ARTICLE: !0,
    ASIDE: !0,
    B: !0,
    BDI: !0,
    BDO: !0,
    BIG: !0,
    BLOCKQUOTE: !0,
    BR: !0,
    BUTTON: !0,
    CAPTION: !0,
    CENTER: !0,
    CITE: !0,
    CODE: !0,
    COL: !0,
    COLGROUP: !0,
    DATA: !0,
    DATALIST: !0,
    DD: !0,
    DEL: !0,
    DETAILS: !0,
    DFN: !0,
    DIALOG: !0,
    DIR: !0,
    DIV: !0,
    DL: !0,
    DT: !0,
    EM: !0,
    FIELDSET: !0,
    FIGCAPTION: !0,
    FIGURE: !0,
    FONT: !0,
    FOOTER: !0,
    FORM: !0,
    H1: !0,
    H2: !0,
    H3: !0,
    H4: !0,
    H5: !0,
    H6: !0,
    HEADER: !0,
    HGROUP: !0,
    HR: !0,
    I: !0,
    IMG: !0,
    INPUT: !0,
    INS: !0,
    KBD: !0,
    LABEL: !0,
    LEGEND: !0,
    LI: !0,
    MAIN: !0,
    MAP: !0,
    MARK: !0,
    MENU: !0,
    METER: !0,
    NAV: !0,
    NOSCRIPT: !0,
    OL: !0,
    OPTGROUP: !0,
    OPTION: !0,
    OUTPUT: !0,
    P: !0,
    PRE: !0,
    PROGRESS: !0,
    Q: !0,
    S: !0,
    SAMP: !0,
    SECTION: !0,
    SELECT: !0,
    SMALL: !0,
    SOURCE: !0,
    SPAN: !0,
    STRIKE: !0,
    STRONG: !0,
    STYLE: !0,
    SUB: !0,
    SUMMARY: !0,
    SUP: !0,
    TABLE: !0,
    TBODY: !0,
    TD: !0,
    TEXTAREA: !0,
    TFOOT: !0,
    TH: !0,
    THEAD: !0,
    TIME: !0,
    TR: !0,
    TT: !0,
    U: !0,
    UL: !0,
    VAR: !0,
    WBR: !0
};
var ZC = {
        "ANNOTATION-XML": !0,
        "COLOR-PROFILE": !0,
        "FONT-FACE": !0,
        "FONT-FACE-SRC": !0,
        "FONT-FACE-URI": !0,
        "FONT-FACE-FORMAT": !0,
        "FONT-FACE-NAME": !0,
        "MISSING-GLYPH": !0
    },
    cD = function(a) {
        a = a || new $C;
        aD(a);
        this.a = Ub(a.a);
        this.h = Ub(a.L);
        this.c = Ub(a.K);
        this.w = a.G;
        w(a.m, function(b) {
                if (!vc(b, "data-")) throw new Wa('Only "data-" attributes allowed, got: %s.', [b]);
                if (vc(b, "data-sanitizer-")) throw new Wa('Attributes with "%s" prefix are not allowed, got: %s.', ["data-sanitizer-", b]);
                this.a["* " + b.toUpperCase()] = bD
            },
            this);
        w(a.o, function(b) {
            b = b.toUpperCase();
            if (!Jc(b, "-") || ZC[b]) throw new Wa("Only valid custom element tag names allowed, got: %s.", [b]);
            this.c[b] = !0
        }, this);
        this.m = a.c;
        this.g = a.C;
        this.b = null;
        this.o = a.w
    };
t(cD, WC);
var dD = function(a) {
        return function(b, c) {
            return (b = a(yc(b), c)) && "about:invalid#zClosurez" != Pc(b) ? Pc(b) : null
        }
    },
    $C = function() {
        this.a = {};
        w([UB, VB], function(a) {
            w(Ob(a), function(b) {
                this.a[b] = bD
            }, this)
        }, this);
        this.b = {};
        this.m = [];
        this.o = [];
        this.L = Ub(XC);
        this.K = Ub(YC);
        this.G = !1;
        this.La = Tc;
        this.Fa = this.h = this.O = this.c = Gb;
        this.C = null;
        this.g = this.w = !1
    },
    eD = function(a, b) {
        return function(c, d, e, f) {
            c = a(c, d, e, f);
            return null == c ? null : b(c, d, e, f)
        }
    },
    fD = function(a, b, c, d) {
        a[c] && !b[c] && (a[c] = eD(a[c], d))
    },
    aD = function(a) {
        if (a.g) throw Error("HtmlSanitizer.Builder.build() can only be used once.");
        fD(a.a, a.b, "* USEMAP", gD);
        var b = dD(a.La);
        w(["* ACTION", "* CITE", "* HREF"], function(d) {
            fD(this.a, this.b, d, b)
        }, a);
        var c = dD(a.c);
        w(["* LONGDESC", "* SRC", "LINK HREF"], function(d) {
            fD(this.a, this.b, d, c)
        }, a);
        w(["* FOR", "* HEADERS", "* NAME"], function(d) {
            fD(this.a, this.b, d, Sa(hD, this.O))
        }, a);
        fD(a.a, a.b, "A TARGET", Sa(iD, ["_blank", "_self"]));
        fD(a.a, a.b, "* CLASS", Sa(jD, a.h));
        fD(a.a, a.b, "* ID", Sa(kD, a.h));
        fD(a.a, a.b, "* STYLE", Sa(a.Fa, c));
        a.g = !0
    },
    lD = function(a, b) {
        a || (a = "*");
        return (a + " " + b).toUpperCase()
    },
    bD = function(a) {
        return yc(a)
    },
    iD = function(a, b) {
        b = yc(b);
        return rb(a, b.toLowerCase()) ? b : null
    },
    gD = function(a) {
        return (a = yc(a)) && "#" == a.charAt(0) ? a : null
    },
    hD = function(a, b, c) {
        return a(yc(b), c)
    },
    jD = function(a, b, c) {
        b = b.split(/(?:\s+)/);
        for (var d = [], e = 0; e < b.length; e++) {
            var f = a(b[e], c);
            f && d.push(f)
        }
        return 0 == d.length ? null : d.join(" ")
    },
    kD = function(a, b, c) {
        return a(yc(b), c)
    },
    mD = function(a, b) {
        var c = b.data;
        (b = DC(b)) && "style" == BC(b).toLowerCase() && !("STYLE" in a.h) && "STYLE" in a.c && (c = md(MC(c, a.b, p(function(d, e) {
            return this.m(d, {
                Sq: e
            })
        }, a))));
        return document.createTextNode(c)
    },
    nD = function(a) {
        var b = new $C;
        b = new cD(b);
        var c = !("STYLE" in b.h) && "STYLE" in b.c;
        c = "*" == b.g && c ? "sanitizer-" + (Math.floor(2147483648 * Math.random()).toString(36) + Math.abs(Math.floor(2147483648 * Math.random()) ^ Ta()).toString(36)) : b.g;
        b.b = c;
        if (UC) {
            c = a;
            if (UC) {
                a = $f("SPAN");
                b.b && "*" == b.g && (a.id = b.b);
                b.o && (c = LC("<div>" + c + "</div>"), v(c, "Older browsers that don't support inert parsing should not get to this branch"), PC(c), c = c.innerHTML);
                c = Od(dc("Never attached to DOM."), c);
                var d = document.createElement("template");
                if (VC && "content" in d) Sd(d, c), d = d.content;
                else {
                    var e = document.implementation.createHTMLDocument("x");
                    d = e.body;
                    Sd(e.body, c)
                }
                c = document.createTreeWalker(d, NodeFilter.SHOW_ELEMENT | NodeFilter.SHOW_TEXT, null, !1);
                for (d = QC ? new WeakMap : new SC; e = c.nextNode();) {
                    c: {
                        var f = b;
                        var g = e;
                        var k = CC(g);
                        switch (k) {
                            case 3:
                                g = mD(f, g);
                                break c;
                            case 1:
                                k = g;
                                1 == CC(k) || Ya("Expected Node of type Element but got Node of type %s", CC(k));
                                g = f;
                                f = k;
                                if ("TEMPLATE" == BC(f).toUpperCase()) g = null;
                                else {
                                    k = BC(f).toUpperCase();
                                    if (k in g.h) var l = null;
                                    else g.c[k] ? l = document.createElement(k) : (l = $f("SPAN"), g.w && xC(l, "data-sanitizer-original-tag", k.toLowerCase()));
                                    if (l) {
                                        var m = l,
                                            q = wC(f);
                                        if (null != q)
                                            for (var r = 0; k = q[r]; r++)
                                                if (k.specified) {
                                                    var u = g;
                                                    var z = f,
                                                        P = k,
                                                        L = P.name;
                                                    if (vc(L, "data-sanitizer-")) u = null;
                                                    else {
                                                        var Ma = BC(z);
                                                        P = P.value;
                                                        var Kb = {
                                                                tagName: yc(Ma).toLowerCase(),
                                                                attributeName: yc(L).toLowerCase()
                                                            },
                                                            Ha = {
                                                                vk: void 0
                                                            };
                                                        "style" == Kb.attributeName && (Ha.vk = yC(z));
                                                        z = lD(Ma, L);
                                                        z in u.a ? (u = u.a[z], u = u(P, Kb, Ha)) : (L = lD(null, L), L in u.a ? (u = u.a[L], u = u(P, Kb, Ha)) : u = null)
                                                    }
                                                    null !==
                                                        u && xC(m, k.name, u)
                                                } g = l
                                    } else g = null
                                }
                                break c;
                            default:
                                Yi(TC, "Dropping unknown node type: " + k), g = null
                        }
                    }
                    if (g) {
                        if (1 == CC(g) && d.set(e, g), e = DC(e), f = !1, e) k = CC(e), l = BC(e).toLowerCase(), m = DC(e), 11 != k || m ? "body" == l && m && (k = DC(m)) && !DC(k) && (f = !0) : f = !0, k = null, f || !e ? k = a : 1 == CC(e) && (k = d.get(e)), k.content && (k = k.content), k.appendChild(g)
                    } else fg(e)
                }
                d.clear && d.clear();
                b = a
            } else b = $f("SPAN");
            0 < wC(b).length && (a = $f("SPAN"), a.appendChild(b), b = a);
            b = (new XMLSerializer).serializeToString(b);
            b = b.slice(b.indexOf(">") + 1, b.lastIndexOf("</"))
        } else b =
            "";
        return Od(dc("Output of HTML sanitizer"), b)
    };
var oD = function() {};
t(oD, mr);
Fa(oD);
oD.prototype.$c = function() {
    return "menuitem"
};
oD.prototype.mb = function(a) {
    var b = nD(a.pd);
    b = bg(document, b);
    var c = b.querySelector("div");
    if (!c) throw Error("Invalid item label");
    var d = Cd(a.Ua());
    Td(c, d);
    Rp(c, ["gt-is-sp", "gt-is-cont"]);
    c = ["DIV", pr(this, a)];
    d = D("DIV");
    T(d, "gt-is-ld");
    b = D("DIV", null, b);
    T(b, "gt-is-lb");
    c = c.concat([d, b]);
    if (a.Ob) {
        b = D("A", {
            href: "#"
        }, a.Ob);
        T(b, "gt-is-act");
        var e = new Z;
        e.ba(b);
        Yq(e, a);
        b.addEventListener("mouseup", function(f) {
            e.nb() && f.stopPropagation()
        });
        c.push(b)
    }
    b = D.apply(null, c);
    b.id = Uq(a);
    return a.v = b
};
oD.prototype.Zc = function(a) {
    return "DIV" == a.tagName
};
oD.prototype.wa = function() {
    return "gt-is-itm"
};
var pD = function(a, b, c, d, e) {
    e = void 0 === e ? "" : e;
    Z.call(this, a.Ua(), c || oD.M(), d);
    this.$d = a;
    this.pd = b;
    this.Ob = e;
    this.Oa(1, !1)
};
t(pD, Z);
pD.prototype.Ua = function() {
    return this.$d.Ua()
};
pD.prototype.tb = function() {
    return this.$d.tb()
};
var qD = function(a) {
    F.call(this, a)
};
t(qD, F);
Jf(window.document);
new J;
var rD = function(a) {
        var b = a.getBoundingClientRect();
        if (y) {
            var c = rq(a);
            a = vq(a);
            b.left = c.x;
            b.right = c.x + a.width;
            b.top = c.a;
            b.bottom = c.a + a.height
        }
        return b
    },
    sD = function(a, b) {
        var c = Jf(a),
            d = 0;
        if ("number" === typeof b) d = b;
        else if (y && !Qe(9)) {
            if (b = c.a.selection.createRange()) try {
                var e = a.createTextRange(),
                    f = e.duplicate();
                e.moveToBookmark(b.getBookmark());
                f.setEndPoint("EndToStart", e);
                d = f.text.length
            } catch (m) {}
        } else d = a.selectionStart;
        e = "_h#" + Pa(a);
        var g = c.j(e);
        g ? c.vf(g) : g = c.b("PRE", {
            id: e
        });
        g.parentNode || c.a.body.appendChild(g);
        var k = [];
        w(a.value, function(m, q, r) {
            k.push(" " == m && q + 1 != r.length && " " == r[q + 1] ? "\u00a0" : m)
        });
        k = k.join("");
        c.appendChild(g, c.a.createTextNode(String(k.substring(0, d))));
        e = Hg(c, "SPAN");
        e.appendChild(c.a.createTextNode("\u200b"));
        c.appendChild(g, e);
        c.appendChild(g, c.a.createTextNode(String(k.substring(d) + " ")));
        c = Op(a);
        w(c, function(m) {
            T(g, m)
        });
        var l = "white-space:pre-wrap;word-wrap:pre-wrap;position:absolute;z-index:-9;visibility:hidden;display:block;";
        w("font-family font-size font-weight font-style text-transform text-decoration letter-spacing word-spacing line-height text-align vertical-align direction width height margin-top margin-right margin-bottom margin-left padding-top padding-right padding-bottom padding-left border-top-width border-right-width border-bottom-width border-left-width border-top-style border-right-style border-bottom-style border-left-style overflow-x overflow-y".split(" "),
            function(m) {
                try {
                    var q;
                    (q = eq(a, m) || (a.currentStyle ? a.currentStyle[m] : null) || a.style[m]) && (l += m + ":" + q + ";")
                } catch (r) {}
            });
        g.style.cssText = l;
        c = fq(a, "overflowX");
        g.style.overflowX = c && "visible" != c ? c : "auto";
        c = fq(a, "overflowY");
        g.style.overflowY = c && "visible" != c ? c : "auto";
        g.scrollTop = a.scrollTop;
        g.scrollLeft = a.scrollLeft;
        hq(g, mq(a));
        c = rD(e);
        return "INPUT" == a.tagName.toUpperCase() ? new Ef(c.left, Math.ceil(rq(a).a + vq(a).height)) : new Ef(c.left, Math.ceil(c.bottom))
    };
var tD = function(a, b) {
    X.call(this, b);
    this.c = a
};
t(tD, X);
tD.prototype.b = "info";
tD.prototype.g = !1;
var uD = {
    info: "jfk-butterBar-info",
    error: "jfk-butterBar-error",
    warning: "jfk-butterBar-warning",
    promo: "jfk-butterBar-promo"
};
tD.prototype.Kb = function() {
    return this.b
};
var vD = function(a, b) {
    a.c = b;
    if (b = a.j()) {
        var c = a.a;
        c.vf(b);
        c.ni(b, a.c)
    }
};
tD.prototype.isVisible = function() {
    var a = this.j();
    return null != a && Qp(a, "jfk-butterBar-shown")
};
tD.prototype.setVisible = function(a) {
    v(this.ya, "setVisible must only be called after the butter bar is rendered.");
    V(this.j(), "jfk-butterBar-shown", a)
};
tD.prototype.Ja = function() {
    this.v = this.a.b("DIV", "jfk-butterBar");
    v(this.j(), "The DOM element for the butter bar cannot be null.");
    var a = this.j();
    a && (Ip(a, "live", "assertive"), Ip(a, "atomic", "true"));
    vD(this, this.c);
    this.g = this.g;
    (a = this.j()) && V(a, "jfk-butterBar-mini", this.g);
    a = this.b;
    if (this.Zb()) {
        var b = this.j(),
            c = uD[a];
        U(b, uD[this.b]);
        T(b, c)
    }
    this.b = a
};
var wD = function(a, b, c) {
    J.call(this);
    this.w = c.client;
    this.g = a;
    this.a = b;
    this.o = c.im;
    this.W = !1;
    this.C = c.Gn;
    this.O = c.jm;
    this.ab = c.qk || null;
    this.N = c.ea;
    this.je = c.Ra;
    this.xa = c.Qn;
    this.Ve = c.zo;
    this.K = null;
    this.R = c.vo;
    this.ra = c.Am;
    this.L = 0;
    this.m = {};
    this.Pc = c.hk;
    this.Dg = c.Tk;
    this.md = c.Kn;
    this.Ta = c.Pq;
    this.kd = c.nm;
    this.nd = !!c.$q;
    this.X = !!c.lm;
    this.ia = !!c.Oq;
    this.ie = c.Nn || "Did you mean: <div>%1$s</div>";
    this.pd = c.cr || "Translating <div>%1$s</div>";
    this.he = c.dr || "Undo";
    this.We = c.ir || 500;
    a = new tD("");
    a.render(Kf("gt-bbar"));
    a.setVisible(!1);
    this.V = a;
    this.c = this.b = this.h = "";
    this.G = Gm.M();
    "async_translate_onebox" == this.w && (this.G.o = "/translate");
    this.Z = new Lq(this);
    this.ke = new fr(this.o.j());
    this.Ca = tl.M();
    this.F = K.M();
    this.na = !0;
    this.md && this.Z.listen(this.ke, "key", this.ac).listen(this.o, "change", this.hd);
    this.Z.listen(this.a, "action", this.wb).listen(this.o.j(), "blur", this.Ob).listen(this.o.j(), "focus", this.bc).listen(this.N, "srcLanguageUpdated", this.Na).listen(this.N, "tgtLanguageUpdated", this.Na);
    null != this.O && this.Z.listen(this.O,
        "change", this.jd)
};
t(wD, J);
wD.prototype.update = function() {
    0 != this.h.length || this.ia ? this.na && (yD(this, this.g.a[0]), this.L++, this.m[this.L] = {}, this.m[this.L][0] = Ta(), zD(this.xa, this.h, this.b, this.c, p(this.ld, this, this.h, this.b, this.c, this.L))) : xD(this)
};
var BD = function(a) {
    var b = a.a;
    b.c && b.removeChild(b.c, !0);
    b.c = null;
    AD(a, !!ar(a.a))
};
wD.prototype.jd = function() {
    tz(this.O) && xD(this)
};
wD.prototype.ac = function(a) {
    if (!this.a.isVisible()) return !1;
    if (27 == a.keyCode) {
        var b = CD(this.g.a);
        O(this.G, this.w, "is", "0", {
            q: this.h,
            sl: this.b,
            tl: this.c,
            sn: b.length,
            s: b
        });
        b = this.F;
        var c = DD(this),
            d = ED(this);
        M(b, Em(b, 204, c, d, FD(this), [], null != this.a.h, 0));
        xD(this)
    }
    13 == a.keyCode && -1 == this.a.Ka && (b = CD(this.g.a), O(this.G, this.w, "is", "8", {
        q: this.h,
        sl: this.b,
        tl: this.c,
        sn: b.length,
        s: b
    }), b = this.F, c = DD(this), d = ED(this), M(b, Em(b, 205, c, d, FD(this), [], null != this.a.h, 0)), xD(this));
    if (36 == a.keyCode || 35 == a.keyCode) return !1;
    b = this.a.Ya(a);
    38 != a.keyCode && 40 != a.keyCode || -1 == this.a.Ka || (a = cx(this.a), a != this.a.c && this.o.Y() != a.Ua() && (this.W = !0, wl(this.Ca, "is"), this.o.b(a.Ua()), yD(this)));
    return b
};
wD.prototype.hd = function(a) {
    this.W ? this.W = !1 : this.O && tz(this.O) ? xD(this) : "set" == a.changeType ? xD(this) : Ci(p(this.le, this, a), 0)
};
wD.prototype.le = function() {
    var a = Jc(this.o.Y(), "\n") ? "" : GD(this.o.Y()),
        b = this.N.a,
        c = this.N.b;
    if (a != this.h || b != this.b || c != this.c) this.h = a, this.b = b, this.c = c, this.update()
};
var GD = function(a) {
    return a.replace(/[ \n\t\r\f,\.\?!]+/g, " ").replace(/^ /, "")
};
wD.prototype.wb = function(a) {
    var b = DD(this),
        c = ED(this),
        d = FD(this),
        e = [],
        f = null != this.a.h;
    if (a.target == this.a.h) f = this.F, M(f, Em(f, 185, b, c, d, e, !0, 1)), HD(this, "it", "translationSelected", "");
    else if (a.target == this.a.g) a = this.F, M(a, Em(a, 181, b, c, d, e, f, 1)), HD(this, "ss", "spellingSelected", c);
    else if (a.target.getParent && a.target.getParent() === this.a.g) HD(this, "ss", "ignoreSpellingSuggestion", "");
    else if (a.target == this.a.c) a = this.F, M(a, Em(a, 183, b, c, d, e, f, 1)), HD(this, "ls", "languageSelected", d[0]);
    else {
        a = a.target;
        a: {
            var g = this.a.b;
            for (var k = 0; k < g.length; k++)
                if (g[k] == a) {
                    g = k;
                    break a
                } g = -1
        }
        k = this.F;
        M(k, Em(k, 142, b, c, d, e, f, g + 1));
        ID(this, a.Ua(), "2")
    }
};
var HD = function(a, b, c, d) {
        var e = CD(a.g.a);
        O(a.G, a.w, "is", "b", {
            q: a.h,
            sl: a.b,
            tl: a.c,
            sn: e.length,
            s: e,
            si: 0,
            sy: b
        });
        xD(a);
        a.dispatchEvent(new qD(c, d))
    },
    ID = function(a, b, c) {
        for (var d = CD(a.g.a), e = 0, f = 0; f < d.length; f++)
            if (d[f] == b) {
                e = f + 1;
                break
            } O(a.G, a.w, "is", c, {
            q: a.h,
            sl: a.b,
            tl: a.c,
            sn: d.length,
            s: d,
            si: e
        });
        a.h = GD(b);
        wl(a.Ca, "is");
        a.o.b(b);
        "2" == c ? (xD(a), a.o.j().blur(), a.dispatchEvent("suggestionSelected")) : (a.update(), a.dispatchEvent("suggestionCopied"))
    };
wD.prototype.Na = function() {
    xD(this)
};
wD.prototype.ld = function(a, b, c, d, e) {
    this.m[d][1] = Ta();
    0 == this.h.length && !this.ia || 0 == e.length && !this.X ? xD(this) : 0 == e.length ? JD(this) : this.b != b || this.c != c ? JD(this) : this.R ? (this.m[d][2] = Ta(), this.K && this.K.abort(), this.K = tp(this.Ve, this.b, this.c, this.je, e, p(this.Id, this, a, d, e), "is", void 0, this.We)) : KD(this, a, kb(e, function(f) {
        return new Dw(f)
    }), d)
};
wD.prototype.Id = function(a, b, c, d, e) {
    null == d ? (LD(this, a, c, e), mm(this.F, 145)) : (this.m[b][3] = Ta(), c.length == d.length ? KD(this, a, kb(c, function(f, g) {
        return new Dw(c[g], d[g])
    }), b) : (MD(this), mm(this.F, 146), KD(this, a, kb(c, function(f) {
        return new Dw(f)
    }), b)))
};
var JD = function(a) {
        ND(a.a, []);
        a.g.a = [];
        yD(a);
        var b = a.a;
        b.o && 0 != b.o.length || AD(a, !1)
    },
    xD = function(a) {
        OD(a.xa);
        a.K && a.K.abort();
        AD(a, !1);
        for (var b = a.a, c = []; b.o && 0 != b.o.length;) c.push(b.removeChild(br(b, 0), !0));
        b.b = [];
        b.c = null;
        b.g = null;
        b.h = null;
        b = a.g;
        b.a = [];
        b.b = null;
        b.c = null;
        yD(a)
    },
    KD = function(a, b, c, d) {
        var e = a.m[d][1] - a.m[d][0];
        if (a.R) var f = a.m[d][3] - a.m[d][2];
        delete a.m[d];
        if (0 != c.length) {
            var g = c;
            c.length > a.ra && (g = zb(c, 0, a.ra));
            a.g.a = g;
            c = {};
            a.R && (c.td = f);
            if (a.L > d) PD(a, !1), QD(a, e, b, g, c, !1);
            else {
                var k = [];
                w(g, function(m, q) {
                    q = new Fw(m, this.Pc, this.Dg, 0 == q && !this.X, this.R, this.ab);
                    k.push(q);
                    if ((q = this.g.b) && q.Ua() == m.Ua()) {
                        m = "";
                        var r = void 0 === r ? !1 : r;
                        q = CD(this.g.a);
                        rb(q, m) && (m = "");
                        m ? (m = new TB(m), r = new pD(m, r ? this.pd : this.ie, void 0, void 0, r ? this.he : void 0), this.g.b = m, RD(this.a, r), SD(this.a, !0), AD(this, !0)) : (this.g.b = null, RD(this.a, null), AD(this, !!ar(this.a)))
                    }
                }, a);
                ND(a.a, k);
                6 < TD(a.g) && BD(a);
                a.X && SD(a.a, !!a.a.h);
                yD(a, g[0]);
                if (!a.kd) {
                    d = Uf(Jf(document).a);
                    f = sD(a.o.j(), a.o.Y().length);
                    var l = mq(og(a.a.j()));
                    f.x = 0;
                    f.a += d.a;
                    f.a -= l.a;
                    hq(a.a.j(), f)
                }
                a.Pc && UD(a);
                VD(a);
                AD(a, !0);
                PD(a, !0);
                QD(a, e, b, g, c, !0)
            }
        }
    },
    AD = function(a, b) {
        a.Ta || a.a.setVisible(b)
    },
    DD = function(a) {
        var b = [];
        a = a.a.b;
        for (var c = 0; c < a.length; c++) b.push([a[c].Ua(), a[c].tb()]);
        return b
    },
    ED = function(a) {
        return a.a.g ? a.a.g.Ua() : ""
    },
    FD = function(a) {
        a = a.a.c ? a.a.c.$d.a : "";
        return "" != a ? [a] : []
    },
    PD = function(a, b) {
        var c = a.F,
            d = DD(a),
            e = ED(a);
        M(c, Em(c, b ? 141 : 203, d, e, FD(a), [], null != a.a.h, 0))
    },
    yD = function(a, b) {
        if (a.C)
            if (b) {
                var c = a.o.Y();
                vc(b.Ua(), c) ? a.C.b(b.Ua()) : a.C.b(c)
            } else a.C.b("")
    },
    UD = function(a) {
        w(a.a.b, function(b) {
            b.Vb && G(b.Vb, "action", this.xb, !1, this)
        }, a)
    };
wD.prototype.xb = function(a) {
    var b = this.a.b;
    w(b, function(c, d) {
        if (c.Vb == a.target) {
            var e = D("SPAN", null, (window.MSG_SUGGESTION_FLAGGED || "").replace("%1$s", c.Ua())),
                f = D("SPAN", null, " ");
            c = D("A", {
                href: "javascript:;"
            }, window.MSG_DISMISS || "");
            e = D("DIV", null, e, f, c);
            vD(this.V, e);
            this.V.setVisible(!0);
            G(c, "click", this.ob, !1, this);
            WD(this, d + 1, b)
        }
    }, this)
};
var VD = function(a) {
    w(a.a.b, function(b) {
        b.rc && G(b.rc, "action", this.gb, !1, this)
    }, a)
};
wD.prototype.gb = function(a) {
    w(this.a.b, function(b) {
        b.rc == a.target && ID(this, b.Ua(), "a")
    }, this)
};
wD.prototype.ob = function() {
    this.V.setVisible(!1)
};
wD.prototype.Ob = function() {
    this.a && (this.nd ? (JD(this), this.na = !1) : AD(this, !1));
    this.C && this.C.b("")
};
wD.prototype.bc = function() {
    this.na = !0
};
var WD = function(a, b, c) {
        c = kb(c, function(d) {
            return d.Ua()
        });
        O(a.G, a.w, "is", "3", {
            q: a.h,
            sl: a.b,
            tl: a.c,
            sn: c.length,
            s: c,
            si: b
        })
    },
    CD = function(a) {
        return a ? kb(a, function(b) {
            return b ? b.Ua() : ""
        }) : []
    },
    XD = function(a) {
        if (!a) return [];
        a = kb(a, function(b) {
            return b ? b.tb() : ""
        });
        return jb(a, function(b) {
            return null != b
        })
    },
    QD = function(a, b, c, d, e, f) {
        d = CD(d);
        b = {
            q: c,
            sl: a.b,
            tl: a.c,
            sd: b,
            sn: d.length,
            s: d
        };
        for (var g in e) b[g] = e[g];
        O(a.G, a.w, "is", f ? "1" : "7", b)
    },
    MD = function(a) {
        var b = a.g.a,
            c = CD(b);
        b = XD(b);
        O(a.G, a.w, "is", "6", {
            q: a.h,
            sl: a.b,
            tl: a.c,
            sn: c.length,
            s: c,
            tn: b.length,
            st: b
        })
    },
    LD = function(a, b, c, d) {
        b = {
            q: b,
            sl: a.b,
            tl: a.c,
            sn: c.length,
            s: c
        };
        d && (b.ec = d);
        O(a.G, a.w, "is", "9", b)
    };
var YD = function(a, b, c, d) {
    var e = kt();
    this.g = a;
    this.C = b;
    this.O = c;
    this.w = d;
    this.G = void 0 === e ? !1 : e;
    this.a = "";
    this.b = new Ur(this.K, 300, this);
    this.c = this.h = 0;
    this.m = !1;
    this.o = Gm.M();
    G(this.g, "change", this.L, !1, this);
    this.b.start(void 0)
};
YD.prototype.L = function(a) {
    var b = "";
    a.changeType && (b = a.changeType);
    "paste" == b && (this.h++, Nm(this.o, "pc", 1, "accumulate"));
    "set" == b && this.c++;
    this.b.start(void 0)
};
YD.prototype.K = function() {
    if (this.C) {
        this.b.stop();
        var a = yc(this.g.Y());
        if (a != this.a)
            if (this.w && this.w()) this.b.start(300);
            else if (!(2E3 < be(a).length && 0 == this.h && 0 == this.c) || this.G) {
            this.c = this.h = 0;
            var b = a.substring(0, this.a.length) == this.a;
            (a = this.a.substring(0, a.length) == a) || 0 != this.a.length && b && !this.m ? Nm(this.o, "otf", "2") : Nm(this.o, "otf", "1");
            this.m = a;
            this.O()
        }
    }
};
YD.prototype.reset = function(a) {
    this.b.stop();
    this.a = yc(this.g.Y());
    a || (this.m = !1)
};
var ZD = function() {
    J.call(this);
    this.a = 0;
    this.endTime = this.startTime = null
};
t(ZD, J);
ZD.prototype.c = function() {
    this.b("begin")
};
ZD.prototype.g = function() {
    this.b("end")
};
ZD.prototype.b = function(a) {
    this.dispatchEvent(a)
};
var $D = function(a, b) {
        Ia(b) || (b = [b]);
        v(0 < b.length, "At least one Css3Property should be specified.");
        b = kb(b, function(c) {
            if ("string" === typeof c) return c;
            bb(c, "Expected css3 property to be an object.");
            var d = c.aj + " " + c.duration + "s " + c.timing + " " + c.delay + "s";
            v(c.aj && "number" === typeof c.duration && c.timing && "number" === typeof c.delay, "Unexpected css3 property value: %s", d);
            return d
        });
        cq(a, "transition", b.join(","))
    },
    aE = Ib(function() {
        if (y) return Qe("10.0");
        var a = $f("DIV"),
            b = ze ? "-webkit" : ye ? "-moz" : y ? "-ms" : ve ?
            "-o" : null,
            c = {
                transition: "opacity 1s linear"
            };
        b && (c[b + "-transition"] = "opacity 1s linear");
        Td(a, Id("div", {
            style: c
        }));
        a = a.firstChild;
        v(a.nodeType == Node.ELEMENT_NODE);
        b = a.style[ne("transition")];
        return "" != ("undefined" !== typeof b ? b : a.style[bq(a, "transition")] || "")
    });
var bE = function(a, b, c, d, e) {
    ZD.call(this);
    this.v = a;
    this.m = b;
    this.w = c;
    this.h = d;
    this.G = Ia(e) ? e : [e]
};
t(bE, ZD);
h = bE.prototype;
h.play = function() {
    if (1 == this.a) return !1;
    this.c();
    this.b("play");
    this.startTime = Ta();
    this.a = 1;
    if (aE()) return cq(this.v, this.w), this.o = Ci(this.gn, void 0, this), !0;
    this.Mg(!1);
    return !1
};
h.gn = function() {
    vq(this.v);
    $D(this.v, this.G);
    cq(this.v, this.h);
    this.o = Ci(p(this.Mg, this, !1), 1E3 * this.m)
};
h.stop = function() {
    1 == this.a && this.Mg(!0)
};
h.Mg = function(a) {
    cq(this.v, "transition", "");
    Di(this.o);
    cq(this.v, this.h);
    this.endTime = Ta();
    this.a = 0;
    a ? this.b("stop") : this.b("finish");
    this.g()
};
h.T = function() {
    this.stop();
    bE.D.T.call(this)
};
var dE = function(a, b) {
    J.call(this);
    this.c = new Lq(this);
    a = a || null;
    cE(this);
    this.v = a;
    b && (this.Td = b)
};
t(dE, J);
h = dE.prototype;
h.v = null;
h.Yh = !0;
h.Xh = null;
h.Wd = !1;
h.eh = -1;
h.Td = "toggle_display";
h.Kb = function() {
    return this.Td
};
h.j = function() {
    return this.v
};
h.setAutoHide = function(a) {
    cE(this);
    this.Yh = a
};
var cE = function(a) {
    if (a.Wd) throw Error("Can not change this state of the popup while showing.");
};
dE.prototype.isVisible = function() {
    return this.Wd
};
dE.prototype.setVisible = function(a) {
    this.o && this.o.stop();
    this.h && this.h.stop();
    if (a) {
        if (!this.Wd && this.dispatchEvent("beforeshow")) {
            if (!this.v) throw Error("Caller must call setElement before trying to show the popup");
            this.m();
            a = If(this.v);
            if (this.Yh)
                if (this.c.listen(a, "mousedown", this.Xi, !0), y) {
                    try {
                        var b = a.activeElement
                    } catch (d) {}
                    for (; b && "IFRAME" == b.nodeName;) {
                        try {
                            var c = ug(b)
                        } catch (d) {
                            break
                        }
                        a = c;
                        b = a.activeElement
                    }
                    this.c.listen(a, "mousedown", this.Xi, !0);
                    this.c.listen(a, "deactivate", this.Wi)
                } else this.c.listen(a,
                    "blur", this.Wi);
            "toggle_display" == this.Td ? (this.v.style.visibility = "visible", W(this.v, !0)) : "move_offscreen" == this.Td && this.m();
            this.Wd = !0;
            this.eh = Ta();
            this.o ? (hh(this.o, "end", this.xi, !1, this), this.o.play()) : this.xi()
        }
    } else eE(this)
};
dE.prototype.m = Ea;
var eE = function(a, b) {
    a.Wd && a.dispatchEvent({
        type: "beforehide",
        target: b
    }) && (a.c && Qq(a.c), a.Wd = !1, Ta(), a.h ? (hh(a.h, "end", Sa(a.di, b), !1, a), a.h.play()) : a.di(b))
};
h = dE.prototype;
h.di = function(a) {
    "toggle_display" == this.Td ? this.em() : "move_offscreen" == this.Td && (this.v.style.top = "-10000px");
    this.dispatchEvent({
        type: "hide",
        target: a
    })
};
h.em = function() {
    this.v.style.visibility = "hidden";
    W(this.v, !1)
};
h.xi = function() {
    this.dispatchEvent("show")
};
h.Xi = function(a) {
    a = a.target;
    pg(this.v, a) || fE(this, a) || 150 > Ta() - this.eh || eE(this, a)
};
h.Wi = function(a) {
    var b = If(this.v);
    if ("undefined" != typeof document.activeElement) {
        if (a = b.activeElement, !a || pg(this.v, a) || "BODY" == a.tagName) return
    } else if (a.target != b) return;
    150 > Ta() - this.eh || eE(this)
};
var fE = function(a, b) {
    return mb(a.Xh || [], function(c) {
        return b === c || pg(c, b)
    })
};
dE.prototype.T = function() {
    dE.D.T.call(this);
    this.c.Ia();
    Kg(this.o);
    Kg(this.h);
    delete this.v;
    delete this.c;
    delete this.Xh
};
var gE = function(a, b) {
    this.L = b || void 0;
    dE.call(this, a)
};
t(gE, dE);
gE.prototype.m = function() {
    if (this.L) {
        var a = !this.isVisible() && "move_offscreen" != this.Kb(),
            b = this.j();
        a && (b.style.visibility = "hidden", W(b, !0));
        this.L.b(b, 8, this.Ti);
        a && W(b, !1)
    }
};
var hE = function(a, b) {
    gE.call(this, a);
    this.g = b;
    this.a = 0;
    this.b = null;
    this.w = 0;
    this.setVisible(!0);
    this.setVisible(!1);
    T(this.j(), "round-trip-popup");
    T(this.g, "round-trip-content")
};
t(hE, gE);
hE.prototype.show = function() {
    Di(this.w);
    0 == this.a ? this.w = Ci(p(this.C, this, 1), 300) : this.C(1)
};
hE.prototype.K = function() {
    Di(this.w);
    1 == this.a ? hh(this.b, "finish", p(this.K, this)) : 0 == this.a && (this.w = Ci(p(this.C, this, -1), 200))
};
hE.prototype.C = function(a) {
    if (this.a != a && (0 != this.a || !(this.isVisible() && 1 == a || !this.isVisible() && -1 == a))) {
        var b = this.isVisible();
        this.setVisible(!0);
        var c = -Math.ceil(vq(this.g).width);
        Bq(this.j()) && (c = -c);
        var d = 1 == a ? c : 0;
        c = 1 == a ? 0 : c;
        this.setVisible(b);
        if (aE()) {
            b = .2;
            if (0 != this.a) {
                var e = parseInt(eq(this.g, "left"), 10);
                this.G();
                b *= (c - e) / (c - d);
                d = e
            }
            this.a = a;
            this.b = new bE(this.g, b, {
                left: d + "px"
            }, {
                left: c + "px"
            }, "left " + b + "s");
            this.b.play();
            hh(this.b, "finish", p(this.G, this)); - 1 == a ? hh(this.b, "finish", p(this.setVisible,
                this, !1)) : this.setVisible(!0)
        } else cq(this.g, "left", c + "px"), this.setVisible(1 == a ? !0 : !1)
    }
};
hE.prototype.G = function() {
    0 != this.a && (this.b.stop(), Ci(p(qh, this, this.b)), this.a = 0, this.b = null)
};
var jE = function(a) {
        this.v = a || null;
        this.a = D("DIV", "gt-hl-layer", ag(""));
        this.b = null;
        this.v && (gg(this.a, this.v), iE(this))
    },
    lE = function(a, b, c, d, e) {
        var f = d || "gt-hl-text";
        d = a.v && (a.v.value || Cg(a.v));
        iE(a);
        fg(a.a);
        if (b != c || e) {
            if (0 < b) {
                var g = d.substring(0, b);
                kE(a.a, g, 0, e)
            }
            b < c && (g = d.substring(b, c), f = D("SPAN", f), kE(f, g, b, e), dg(a.a, f));
            c < d.length && (g = d.substring(c), kE(a.a, g, c, e))
        }
    },
    iE = function(a) {
        var b;
        var c = a.v,
            d = If(c);
        (b = y && c.currentStyle) && Rf(Jf(d).a) && "auto" != b.width && "auto" != b.height && !b.boxSizing ? (d = Fq(c,
            b.width, "width", "pixelWidth"), c = Fq(c, b.height, "height", "pixelHeight"), b = new Gf(d, c)) : (b = new Gf(c.offsetWidth, c.offsetHeight), d = Iq(c), c = oq(c), b = new Gf(b.width - c.left - d.left - d.right - c.right, b.height - c.top - d.top - d.bottom - c.bottom));
        c = a.a;
        d = If(c);
        var e = Rf(Jf(d).a);
        !y || Qe("10") || e && Qe("8") ? Eq(c, b, "content-box") : (d = c.style, e ? (d.pixelWidth = b.width, d.pixelHeight = b.height) : (e = Iq(c), c = oq(c), d.pixelWidth = b.width + c.left + e.left + e.right + c.right, d.pixelHeight = b.height + c.top + e.top + e.bottom + c.bottom));
        d = mq(a.v);
        c =
            a.a;
        b = d.x;
        d = d.a;
        e = mq(c);
        b instanceof Ef && (d = b.a, b = b.x);
        b = Za(b) - e.x;
        hq(c, c.offsetLeft + b, c.offsetTop + (Number(d) - e.a));
        c = Iq(a.v);
        cq(a.a, "paddingLeft", c.left + "px");
        cq(a.a, "paddingRight", c.right + "px");
        a.a.dir = a.v.dir
    },
    kE = function(a, b, c, d) {
        d = d || [];
        for (var e = 0, f; f = d[e]; e++)
            if (!(0 > f.xe - c)) {
                if (f.xe - c >= b.length) break;
                if (0 < f.xe - c) {
                    var g = b.substring(0, f.xe - c);
                    mE(a, g)
                }
                var k = f.className || "gt-hl-text";
                g = b.substring(f.xe - c, f.yh - c);
                k = D("SPAN", k);
                mE(k, g);
                dg(a, k);
                b = b.substring(f.yh - c);
                c = f.yh
            } b && mE(a, b)
    },
    mE = function(a,
        b) {
        b = $d(b).split("\n");
        for (var c = 0, d = b.length; c < d; c++) 0 < c && dg(a, D("BR")), dg(a, ag(b[c]))
    };
var nE = function(a, b) {
    this.a = a instanceof Ef ? a : new Ef(a, b)
};
t(nE, cs);
nE.prototype.b = function(a, b, c, d) {
    v(a);
    var e = jq(If(a)),
        f = this.a.x + e.x;
    e = this.a.a + e.a;
    var g = Zr(a);
    f -= g.x;
    e -= g.a;
    as(new Ef(f, e), a, b, c, null, null, d)
};
var oE = function(a, b) {
    nE.call(this, a, b)
};
t(oE, nE);
oE.prototype.g = 0;
oE.prototype.c = function(a) {
    this.g = a
};
oE.prototype.b = function(a, b, c, d) {
    var e = iq(a);
    e = nq(e);
    var f = Tf(Jf(a).a);
    f = new Ef(this.a.x + f.scrollLeft, this.a.a + f.scrollTop);
    var g = b,
        k = as(f, a, g, c, e, 10, d);
    if (0 != (k & 496)) {
        if (k & 16 || k & 32) g ^= 4;
        if (k & 64 || k & 128) g ^= 1;
        k = as(f, a, g, c, e, 10, d);
        0 != (k & 496) && as(f, a, b, c, e, this.g, d)
    }
};
var pE = function(a, b) {
    wx.call(this, a, b);
    this.oe = !0;
    hx(this, !0);
    this.setVisible(!1, !0);
    this.b = new tj
};
t(pE, wx);
h = pE.prototype;
h.vj = !1;
h.Pi = 0;
h.Bb = null;
h.Da = function(a) {
    pE.D.Da.call(this, a);
    (a = a.getAttribute("for") || a.htmlFor) && qE(this, this.a.j(a), 1)
};
h.aa = function() {
    pE.D.aa.call(this);
    this.b.forEach(this.$e, this);
    var a = Y(this);
    a.listen(this, "action", this.lh);
    a.listen(this.a.a, "mousedown", this.Ca, !0)
};
var qE = function(a, b, c, d, e, f) {
    b && wj(a.b, Pa(b)) || (c = a.vg(b, c, d, e, f), a.ya && a.$e(c), b = Sa(a.Ym, b), a.j() && Y(a).listen(a.j(), "keydown", b))
};
h = pE.prototype;
h.Ym = function(a, b) {
    if (27 == b.keyCode) a.focus();
    else if (a = br(this, this.Ka)) {
        a = a.j();
        var c = new Tg(b.b, a);
        c.target = a;
        if (32 == b.keyCode || 13 == b.keyCode) Yg(a) ? Rh(a, "keydown", !1, c) : sh(a, "keydown", !1, c);
        32 == b.keyCode && this.Ic()
    }
};
h.vg = function(a, b, c, d, e) {
    if (!a) return null;
    b = {
        v: a,
        pj: b,
        Dm: c,
        ud: d ? "contextmenu" : "mousedown",
        Ti: e
    };
    this.b.set(Pa(a), b);
    return b
};
h.$e = function(a) {
    Y(this).listen(a.v, a.ud, this.Xf);
    "contextmenu" != a.ud && Y(this).listen(a.v, "keydown", this.an)
};
h.hf = function() {
    if (this.ya)
        for (var a = this.b.Cb(), b = 0; b < a.length; b++) this.xg(this.b.get(a[b]));
    this.b.Wc()
};
h.xg = function(a) {
    Y(this).Ga(a.v, a.ud, this.Xf)
};
h.Jf = function(a, b, c) {
    b = void 0 !== a.pj ? new zx(a.v, a.pj, !0) : new oE(b, c);
    b.c && b.c(5);
    var d = a.Dm;
    c = a.Ti;
    var e = a.v;
    a = this.isVisible();
    var f;
    (f = this.isVisible()) || (f = 150 > Ta() - this.Pi);
    f && this.vj ? this.Ic() : (this.Bb = e || null, this.dispatchEvent("beforeshow") && (d = "undefined" != typeof d ? d : 8, a || (this.j().style.visibility = "hidden"), W(this.j(), !0), b.b(this.j(), d, c), a || (this.j().style.visibility = "visible"), this.Qb(-1), this.setVisible(!0)))
};
h.Ic = function() {
    this.isVisible() && (this.setVisible(!1), this.isVisible() || (this.Pi = Ta(), this.Bb = null))
};
h.lh = function() {
    this.Ic()
};
h.Xf = function(a) {
    rE(this, a)
};
h.an = function(a) {
    32 != a.keyCode && 13 != a.keyCode && 40 != a.keyCode || rE(this, a);
    40 == a.keyCode && dx(this)
};
var rE = function(a, b) {
    for (var c = a.b.Cb(), d = 0; d < c.length; d++) {
        var e = a.b.get(c[d]);
        if (e.v == b.a) {
            a.Jf(e, b.clientX, b.clientY);
            b.preventDefault();
            b.stopPropagation();
            break
        }
    }
};
pE.prototype.Ca = function(a) {
    this.isVisible() && !this.oc(a.target) && this.Ic()
};
pE.prototype.Af = function(a) {
    pE.D.Af.call(this, a);
    this.Ic()
};
pE.prototype.T = function() {
    pE.D.T.call(this);
    this.b && (this.b.Wc(), delete this.b)
};
var sE = function(a, b, c, d) {
    return new bE(a, .218, {
        opacity: c
    }, {
        opacity: d
    }, {
        aj: "opacity",
        duration: .218,
        timing: b,
        delay: 0
    })
};
var tE = function(a) {
    J.call(this);
    this.v = a;
    a = y ? "focusout" : "blur";
    this.a = G(this.v, y ? "focusin" : "focus", this, !y);
    this.b = G(this.v, a, this, !y)
};
t(tE, J);
tE.prototype.handleEvent = function(a) {
    var b = new Tg(a.b);
    b.type = "focusin" == a.type || "focus" == a.type ? "focusin" : "focusout";
    this.dispatchEvent(b)
};
tE.prototype.T = function() {
    tE.D.T.call(this);
    ph(this.a);
    ph(this.b);
    delete this.v
};
var uE = function(a, b, c) {
    pE.call(this, b, c);
    this.w = new tj;
    this.g = a || 5;
    this.C = null;
    this.K = !1;
    this.h = Array(this.g);
    this.V = Array(this.g);
    this.R = Gm.M();
    this.F = K.M();
    this.W = this.m = this.zc = null;
    this.vj = !0
};
t(uE, pE);
var vE = "";
uE.prototype.Ja = function() {
    uE.D.Ja.call(this);
    for (var a = 0; a < this.g; ++a) this.jb(new qx(""), !0);
    "" != vE && (this.m = new qx(vE), Gr(this.m, "gt-edit-menuitem"), this.jb(this.m, !0))
};
uE.prototype.render = function(a) {
    uE.D.render.call(this, a);
    T(this.j(), "alt-menu")
};
uE.prototype.rh = function(a) {
    a = this.w.get(Pa(a));
    for (var b = 0; b < H(a, 2) && b < this.g; ++b) {
        var c = br(this, b);
        c.g(I(Fo(a, b), 0));
        c.na = b;
        c.setVisible(!0, !0)
    }
    for (; b < this.g; ++b) br(this, b).setVisible(!1);
    this.m && this.m.setVisible(!0, !0)
};
var wE = function(a, b, c) {
    a.w.set(Pa(b), c);
    qE(a, b, 9, 8, !1, new Zp(-2, 1, -2, 1))
};
h = uE.prototype;
h.hf = function() {
    uE.D.hf.call(this);
    null != this.zc && this.zc.b();
    this.w.Wc()
};
h.setVisible = function(a, b) {
    var c = this.Bb;
    this.W = c;
    if (a && null != c) {
        xE(this, c);
        Om(this.R, "altshow");
        var d = this.F;
        M(d, N(d, 207))
    } else null != this.C && lE(this.C, 0, 0);
    null != c && (a ? this.wg(c) : this.rg(c));
    b = uE.D.setVisible.call(this, a, b);
    a && null != this.j() && Dq(this.j(), !1);
    return b
};
h.sb = function() {
    if (null != this.W) {
        var a = Cg(this.W);
        if (null != a) return a
    }
    return ""
};
h.Ic = function() {
    uE.D.Ic.call(this);
    if (this.K)
        for (var a = 0; a < this.h.length; a++) {
            var b = this.h[a];
            Di(b.w);
            b.G();
            b.C(-1);
            b.G();
            b.setVisible(!1)
        }
};
h.wg = function(a) {
    T(a, "trans-target");
    null !== this.zc ? this.zc.b(a) : a.title = ""
};
h.rg = function(a) {
    U(a, "trans-target");
    null !== this.zc ? this.zc.a(a) : a.title = ""
};
h.Ya = function(a) {
    if (a.shiftKey || a.ctrlKey || a.altKey || 36 == a.keyCode || 35 == a.keyCode) return !1;
    var b = uE.D.Ya.call(this, a);
    if (!b && (37 == a.keyCode || 39 == a.keyCode)) {
        var c = Bq(this.Bb.parentNode.parentNode),
            d = null;
        if (!c && 37 == a.keyCode || c && 39 == a.keyCode) d = !1;
        if (!c && 39 == a.keyCode || c && 37 == a.keyCode) d = !0;
        if (this.lg(d) && (c = this.Bb, (c = d ? void 0 !== c.nextElementSibling ? c.nextElementSibling : lg(c.nextSibling, !0) : void 0 !== c.previousElementSibling ? c.previousElementSibling : lg(c.previousSibling, !1)) && c != this.Bb)) return this.Ic(),
            this.gj(d), this.Jf(c ? this.b.get(Pa(c)) : null, 0, 0), yE(this), a.preventDefault(), a.stopPropagation(), !0
    }
    return b
};
h.Jf = function(a, b, c) {
    Bq((a.v || this.Bb).parentNode.parentNode) ? cq(this.j(), "direction", "rtl") : cq(this.j(), "direction", "");
    if (this.K)
        for (var d = 0; d < this.h.length; d++) zE(this, d), E(this.h[d].g, "...");
    this.rh(a.v);
    uE.D.Jf.call(this, a, b, c)
};
var AE = function(a, b, c) {
        !a.K || b >= a.g || "" == c || (E(a.h[b].g, c), zE(a, b))
    },
    zE = function(a, b) {
        bs(br(a, b).j(), 12, a.h[b].j(), 8, new Ef(1, 0))
    };
h = uE.prototype;
h.Fe = function(a) {
    uE.D.Fe.call(this, a);
    var b = this.Bb;
    if (null != b) {
        Om(this.R, "altmenuhl");
        var c = this.F;
        M(c, N(c, 209));
        xE(this, b);
        a = this.qf(a.target); - 1 != a && a != this.g && (Di(this.V[a]), this.V[a] = Ci(this.ym, 300, this), this.K && (b = this.h[a], Bq(this.Bb.parentNode.parentNode) ? (T(b.j(), "rtl"), cq(b.j(), "direction", "rtl")) : (U(b.j(), "rtl"), cq(b.j(), "direction", "")), zE(this, a), b.show()))
    }
};
h.ym = function() {
    Om(this.R, "altmenuhold");
    var a = this.F;
    M(a, N(a, 208))
};
h.Og = function(a) {
    uE.D.Og.call(this, a);
    a = this.qf(a.target); - 1 != a && a != this.g && (Di(this.V[a]), this.K && this.h[a].K())
};
h.qf = function(a) {
    return dr(this, a)
};
h.lg = function() {
    return !0
};
h.gj = function() {};
h.vg = function(a, b, c, d, e) {
    (a = uE.D.vg.call(this, a, b, c, d, e)) && "mousedown" == a.ud && (a.ud = "click");
    return a
};
h.$e = function(a) {
    uE.D.$e.call(this, a);
    Y(this).listen(a.v, "mouseover", this.xa);
    Y(this).listen(a.v, "mouseout", this.N);
    Y(this).listen(a.v, "contextmenu", this.ia);
    Y(this).listen(a.v, "mousemove", this.ra)
};
h.xg = function(a) {
    uE.D.xg.call(this, a);
    Y(this).Ga(a.v, "mouseover", this.xa);
    Y(this).Ga(a.v, "mouseout", this.N);
    Y(this).Ga(a.v, "contextmenu", this.ia);
    Y(this).Ga(a.v, "mousemove", this.ra)
};
var xE = function(a, b) {
        if (null != a.C && (b = a.w.get(Pa(b))) && (a = a.C, a.b))
            for (var c = a.v && (a.v.value || Cg(a.v)), d = -1, e = -1, f = !1, g = 0; g < H(a.b, 5); g++) {
                var k = pp(a.b, g);
                if (0 != H(k, 2) && (0 == Ih(k, 5) && (f = c.indexOf(I(k, 4), e + 1), 0 <= f ? (d = f, e = d + I(k, 4).length, f = !0) : f = !1), pp(a.b, g).zb() == b.zb())) {
                    if (f) {
                        c = [];
                        for (e = 0; e < H(b, 3); ++e) c.push({
                            xe: d + Ih(Go(b, e), 0),
                            yh: d + Ih(Go(b, e), 1)
                        });
                        lE(a, 0, 0, void 0, c)
                    } else d = c.indexOf(I(b, 0)), 0 <= d && lE(a, d, d + I(b, 0).length);
                    break
                }
            }
    },
    BE = function(a, b) {
        b ? sj(a.b.mc(!1), function(c) {
            "" == this.a.pi(c.v) && (T(c.v,
                "trans-target-empty"), this.a.wf(c.v, "_"));
            return !0
        }, a) : sj(a.b.mc(!1), function(c) {
            Qp(c.v, "trans-target-empty") && (U(c.v, "trans-target-empty"), this.a.wf(c.v, ""));
            return !0
        }, a)
    };
uE.prototype.xa = function(a) {
    !iA() && this.isEnabled() && (T(a.target, "trans-target-highlight"), xE(this, a.target), BE(this, !0), Om(this.R, "althighlight"), a = this.F, M(a, N(a, 206)))
};
uE.prototype.N = function(a) {
    U(a.target, "trans-target-highlight");
    null == this.C || this.isVisible() || lE(this.C, 0, 0);
    BE(this, !1)
};
uE.prototype.ra = function(a) {
    iA() && this.N(a)
};
uE.prototype.ia = function(a) {
    iA() || (this.N(a), Wz(a.target, void 0).select())
};
var yE = function(a) {
    sj(a.b.mc(!1), function(b) {
        U(b.v, "trans-target-highlight");
        return !0
    }, a)
};
uE.prototype.lh = function(a) {
    a && a.a && a.a.Bb && (a.h = a.a.Bb);
    uE.D.lh.call(this, a)
};
uE.prototype.Xf = function(a) {
    iA() ? yE(this) : this.Yc && uE.D.Xf.call(this, a)
};
var CE = function(a, b, c) {
    this.Z = this.c = null;
    uE.call(this, a, b, c)
};
t(CE, uE);
h = CE.prototype;
h.gj = function(a) {
    this.c = a
};
h.setVisible = function(a, b) {
    b = CE.D.setVisible.call(this, a, b);
    this.c = null;
    a ? this.Z = this.sb() : null != this.Z && this.Z != this.sb() && this.dispatchEvent(new F("action", this));
    return b
};
h.wg = function(a) {
    CE.D.wg.call(this, a);
    T(a, "trans-edit");
    a.contentEditable = !0;
    ax(this, a);
    Yw(this).focus();
    xg(Yw(this), !0);
    Y(this).listen(a, "keydown", this.Ci);
    Y(this).listen(a, "mouseout", this.Lf);
    Y(this).listen(a, "mouseover", this.Lf);
    if (null != this.c) {
        a = Wz(a, void 0);
        var b = this.c ? a.Yb() : a.uc(),
            c = zz(a);
        a = c;
        var d = b,
            e = new Uz;
        e.g = dA(a, d, c, b);
        if (ng(a) && !cg(a)) {
            var f = a.parentNode;
            d = ib(f.childNodes, a);
            a = f
        }
        ng(c) && !cg(c) && (f = c.parentNode, b = ib(f.childNodes, c), c = f);
        e.g ? (e.a = c, e.h = b, e.b = a, e.c = d) : (e.a = a, e.h = d, e.b =
            c, e.c = b);
        e.select()
    }
};
h.rg = function(a) {
    CE.D.rg.call(this, a);
    U(a, "trans-edit");
    a.contentEditable = !1;
    Yw(this) && xg(Yw(this), !1);
    Y(this).Ga(a, "keydown", this.Ci);
    Y(this).Ga(a, "mouseout", this.Lf);
    Y(this).Ga(a, "mouseover", this.Lf)
};
h.Lf = function() {
    var a = hA();
    null == a || a.Xb() == a.tc() && a.Yb() == a.uc() || this.setVisible(a.Xb() == a.tc())
};
h.Ci = function(a) {
    for (var b = 0; b < this.g; ++b) br(this, b).setVisible(!1);
    this.m && this.m.setVisible(!1);
    if (13 == a.keyCode || 3 == a.keyCode) return null === cx(this) ? (this.Ic(), a.stopPropagation(), a.preventDefault(), !0) : !1;
    null === cx(this) || !wh(a) && 37 != a.keyCode && 39 != a.keyCode || (this.Bb.focus(), this.Qb(dr(this, null)));
    return !1
};
h.lg = function(a) {
    var b = hA();
    if (b.Xb() == b.tc() && b.Yb() == b.uc()) {
        var c = b.$g() ? b.Yb() : b.uc();
        b = Wz(zz(b), void 0);
        if (!a && c == b.Yb() || a && c == b.uc()) return !0
    }
    return !1
};
var DE = function(a, b, c) {
    uE.call(this, a, b, c);
    this.c = null
};
t(DE, uE);
h = DE.prototype;
h.render = function(a) {
    DE.D.render.call(this, a);
    this.c = new EE("");
    this.jb(this.c, !0)
};
h.rh = function(a) {
    DE.D.rh.call(this, a);
    this.c.j().firstChild.value = this.a.pi(a)
};
h.setVisible = function(a, b) {
    b = DE.D.setVisible.call(this, a, b);
    a && null != this.j() && (Yw(this) == this.c.j().firstChild || Yw(this) == this.c.j().firstChild.nextSibling) && this.c.Mb(!0);
    return b
};
h.Fe = function(a) {
    DE.D.Fe.call(this, a);
    a.target == this.c ? ax(this, this.c.j().firstChild) : ax(this, this.j());
    Yw(this).focus();
    Yw(this).tabIndex = 0
};
h.qf = function(a) {
    return a == this.c ? -1 : DE.D.qf.call(this, a)
};
h.Ya = function(a) {
    return 9 == a.keyCode ? (this.c.Ea(2) ? (Yw(this) == this.c.j().firstChild ? ax(this, this.c.j().firstChild.nextSibling) : ax(this, this.c.j().firstChild), Yw(this).focus(), Yw(this).tabIndex = 0) : this.c.Mb(!0), a.preventDefault(), a.stopPropagation(), !0) : DE.D.Ya.call(this, a)
};
h.lg = function() {
    return null === cx(this) || !(cx(this) instanceof EE)
};
var EE = function(a, b, c) {
    Z.call(this, a, c || FE.M(), b);
    this.Oa(4, !1)
};
t(EE, Z);
EE.prototype.vb = function(a) {
    a.target == this.j().firstChild.nextSibling && this.dispatchEvent("action")
};
EE.prototype.aa = function() {
    EE.D.aa.call(this);
    Y(this).listen(this.j().firstChild, "keydown", function(a) {
        32 == a.keyCode && a.stopPropagation()
    })
};
EE.prototype.sb = function() {
    return this.j().firstChild.value
};
var FE = function() {};
t(FE, mr);
Fa(FE);
FE.prototype.mb = function(a) {
    var b = a.a.b("INPUT", {
            value: a.Sa(),
            id: "alt-input-text",
            type: "text"
        }),
        c = a.a.b("INPUT", {
            value: "",
            id: "alt-input-submit",
            "class": "",
            type: "button"
        });
    return a.a.b("DIV", {
        id: "alt-input"
    }, b, c)
};
var GE = function(a, b, c, d, e, f) {
    this.a = a;
    this.w = b;
    this.C = c;
    this.G = d;
    G(this.a.j(), "focus", function() {
        T(d, "focus")
    });
    G(this.a.j(), "blur", function() {
        U(d, "focus")
    });
    this.c = f;
    null != this.c && G(this.c, "action", this.K, !1, this);
    this.h = !1;
    this.g = null;
    this.b = !1;
    this.m = null;
    this.o = e;
    this.L = !1;
    this.F = K.M()
};
GE.prototype.K = function() {
    this.b = !1;
    this.a.b("");
    this.a.j().focus();
    var a = this.F;
    M(a, N(a, 27));
    this.c.setVisible(!1)
};
var HE = function(a) {
    a.h = !1;
    U(a.G, "full-edit");
    W(a.C, !0);
    W(a.w, !1);
    W(a.o, a.L);
    a.a.setVisible(!1);
    a.a.ce(!1)
};
GE.prototype.O = function(a) {
    this.b = !1;
    "" != this.a.Y() && (this.c.setVisible(!0), this.a.Y() != this.m && (this.b = !0));
    a()
};
var IE = function(a, b, c, d, e) {
    X.call(this);
    this.b = d;
    Gm.M();
    this.c = new As(a);
    Cs(this.c, 2);
    this.m = null;
    this.w = new As(b);
    this.h = null;
    this.N = c;
    this.K = e || !1;
    this.C = this.g = null
};
t(IE, X);
h = IE.prototype;
h.oa = function(a) {
    this.c.oa(a)
};
h.Ja = function() {
    IE.D.Ja.call(this);
    this.Da($f("DIV"))
};
h.Da = function(a) {
    IE.D.Da.call(this, a);
    null == this.b || this.b.wb || this.b.ba(a);
    T(a, "st-wrap");
    a.appendChild(Wp(eo, {
        Pm: this.K,
        Qm: this.N
    }));
    this.g = B("st-stp1", a);
    a = Kf("st-buttons");
    this.c.render(a);
    this.c.Fd(this);
    Y(this).listen(this.c, "action", this.vl);
    this.w.render(a);
    this.w.Fd(this);
    Y(this).listen(this.w, "action", this.mo)
};
h.vl = function(a) {
    W(this.g, !1);
    null != this.b && this.b.setVisible(!0);
    null != this.m && this.m(a)
};
h.mo = function(a) {
    W(this.g, !1);
    null != this.h && this.h(a)
};
h.reset = function() {
    this.C && Di(this.C);
    this.C = null;
    Cs(this.c, 2);
    xq(this.j(), 1);
    W(this.j(), !0);
    W(this.g, !0);
    null != this.b && this.b.setVisible(!1)
};
var JE = y || ze || ve || we || !1;
Ye && Ck("4") || Ze && Qe("533") || ye && Qe("2.0") || y && Qe("10") || ve && xd();
var KE = function(a, b, c, d, e, f, g, k, l) {
    X.call(this, a);
    this.c = g || null;
    if (null != this.c) {
        a = this.c;
        g = p(this.zl, this);
        a.g = p(a.O, a, g);
        g = a.a.j();
        var m = new fr(g);
        G(m, "key", a.g, !1, a);
        m = new Qv(g);
        G(m, "paste", a.g, !1, a);
        G(g, "keyup", a.g, !1, a)
    }
    this.h = null;
    this.C = "auto";
    this.X = this.m = "";
    this.Ca = new qp("mt");
    this.gb = !!b && JE && !y;
    this.R = null != e ? e : 0;
    this.b = null;
    this.gb ? this.b = new CE : this.b = new DE;
    l && this.b.oa(!1);
    if (0 < this.R)
        for (b = this.b, b.K = !0, e = 0; e < b.g; e++) a = D("DIV", "goog-menu", ""), l = D("DIV", null, a), a = new hE(l, a), b.h[e] =
            a, document.body.appendChild(l);
    this.b.render(c);
    this.g = k || null;
    this.ra = null != d ? d : -1;
    this.N = Gm.M();
    this.K = new tj;
    this.xa = "t";
    this.V = this.W = null;
    this.w = f || null;
    this.Z = !1;
    null != this.w && (c = p(this.ab, this), this.w.m = c, c = p(this.ul, this), this.w.h = c);
    this.ia = null;
    this.F = K.M()
};
t(KE, X);
var TE = function(a, b, c, d, e) {
        if (null != a.w) {
            var f = a.w;
            W(f.j(), !1);
            W(f.g, !1);
            null != f.b && f.b.setVisible(!1)
        }
        b && (a.h = new lp(b), a.V = null);
        c && (a.C = c);
        d && (a.m = d);
        e && (a.X = e);
        LE(a) && (HE(a.c), null != a.g && a.g.a(!1));
        if (a.h) {
            b = 0 != Nf("alt-edited").length;
            a.a.vf(a.j());
            a.b.hf();
            a.ia && (a.ia.b = a.h);
            d = "";
            for (c = e = 0; c < H(a.h, 5); c++) ME(a.h, c) && (d += " "), d += NE(a.h, c), e += H(pp(a.h, c), 2);
            if (0 == e) return !1;
            d = [];
            e = !1;
            cv(a.h);
            for (c = 0; c < H(a.h, 5); c++) {
                f = pp(a.h, c);
                var g = Fo(f, 0);
                ME(a.h, c) ? a.a.appendChild(a.j(), a.a.a.createTextNode(" ")) :
                    ("km" == a.m || "lo" == a.m) && a.a.appendChild(a.j(), ze ? bg(document, Id("WBR")) : ve ? ag("&shy;") : y ? ag("&#8203;") : bg(document, Id("WBR")));
                Eh(f, 4) && 0 < I(f, 4).length && 0 == Ih(f, 5) && d.push(I(f, 4));
                var k, l = NE(a.h, c);
                xc(l) ? 0 == l.length || (k = OE(l)) : (k = a.a.b("SPAN", null, l), g = Ih(g, 1), v(0 <= g, "Invalid confidence value: " + g), v(1E3 >= g, "Invalid confidence value: " + g), 0 <= a.ra && g < a.ra && T(k, "alt-low-conf"), wj(a.K, a.C + "." + a.m + "." + I(f, 0)) && (g = a.K.get(a.C + "." + a.m + "." + I(f, 0)), g != PE(f, 0) && (a.a.wf(k, g), T(k, "alt-edited"), e = !0, QE(a, !0))),
                    null != a.b.zc ? a.b.zc.a(k) : k.title = "", wE(a.b, k, f));
                k && a.a.appendChild(a.j(), k)
            }
            if (null != a.c) {
                k = a.C + "." + a.m;
                for (c = 0; c < d.length; ++c) k += "." + d[c];
                wj(a.K, k) && (RE(a, !1), e = !0, SE(a, a.K.get(k)), null != a.g && a.g.a(!1), QE(a, !0))
            }
            e || (QE(a, !1), RE(a, !1));
            (e || b) && a.dispatchEvent("action");
            return 0 < H(a.h, 5)
        }
        QE(a, !1);
        RE(a, !1);
        return !1
    },
    OE = function(a) {
        a = Ac(de(a)).split("<br>");
        var b = document.createDocumentFragment(),
            c = 0;
        w(a, function(d) {
            0 != c && b.appendChild(D("BR"));
            c++;
            "" != d && b.appendChild(ag(ge(d)))
        });
        return b
    },
    UE = function(a,
        b) {
        if (LE(a)) return a.c.a.Y();
        var c = [];
        if (a.j() && a.j().childNodes)
            for (var d = 0; d < a.j().childNodes.length; ++d) {
                var e = a.j().childNodes[d];
                c[d] = b && "BR" == e.tagName ? "\n" : Cg(e)
            }
        return c.join("")
    },
    WE = function(a, b, c, d) {
        for (a = 0; a < H(b, 5); a++) {
            var e = pp(b, a),
                f = c;
            if ((e = e && gb(e, Cl)) && Bl(f.Wa, e.Wa)) {
                c = b;
                b = a;
                f = -1;
                a = H(c, 5);
                for (e = b; 0 <= e; e--)
                    if (0 == Ih(pp(c, e), 5)) {
                        f = e;
                        break
                    } for (e = b + 1; e <= H(c, 5); e++)
                    if (0 == Ih(pp(c, e), 5)) {
                        a = e;
                        break
                    } if (null != d && d) b = VE(c, f, a);
                else if (d = c, c = f, d) {
                    f = b + 1;
                    e = b;
                    for (b = NE(d, b).length; 64 > b && (f != a || e !=
                            c);) f < a && (b += NE(d, f++).length + 1), 64 > b && e > c && (b += NE(d, --e).length + 1);
                    b = VE(d, e, f)
                } else b = "";
                return b
            }
        }
        return ""
    },
    VE = function(a, b, c) {
        var d = [];
        d.push(NE(a, b));
        for (b += 1; b < c; b++) ME(a, b) && d.push(" "), d.push(NE(a, b));
        return d.join("")
    },
    ME = function(a, b) {
        if (0 == b) return !1;
        var c = pp(a, b),
            d = pp(a, b - 1);
        return Fl(Fo(c, 0), 2) && !Fl(Fo(d, 0), 3) && !wc(NE(a, b - 1), "\n")
    };
h = KE.prototype;
h.Ce = function() {
    return this.m
};
h.Ja = function() {
    this.Da(Hg(this.a, "span"))
};
h.Da = function(a) {
    KE.D.Da.call(this, a);
    TE(this)
};
h.aa = function() {
    KE.D.aa.call(this);
    Y(this).listen(this.b, "action", this.Ta);
    null != this.g && null != this.g.b && (Y(this).listen(this.g.b, "click", this.Xl), Oq(Y(this), this.g.b, this.F.g, this.F));
    Y(this).listen(this.b, "show", this.Il);
    this.j() && Y(this).listen(this.j(), "keydown", function(a) {
        32 == a.keyCode && a.stopPropagation()
    }, !0)
};
h.T = function() {
    KE.D.T.call(this);
    this.b.Ia()
};
h.zl = function() {
    this.w.oa(this.c.b);
    QE(this, this.c.b)
};
var XE = function(a) {
    null != a.g && a.g.a(!0);
    var b = a.c,
        c = UE(a);
    T(b.G, "full-edit");
    b.c.setVisible(!0);
    b.m = c;
    b.a.g(c);
    b.a.setVisible(!0);
    b.a.ce(!0);
    W(b.w, !0);
    W(b.C, !1);
    b.L = yq(b.o);
    W(b.o, !1);
    c = b.a.j();
    c.focus();
    c.setSelectionRange(c.value.length, c.value.length);
    b.h = !0;
    a.Z = yq(a.w.j());
    a.w.reset();
    null != a.g ? a.w.oa(yq(a.g.b)) : a.w.oa(!1);
    QE(a, !1)
};
KE.prototype.Ta = function(a) {
    if ("hide" != a.type || a.target == this.b)
        if (a.target == this.b.m && null != this.c) {
            this.N.log("editpopupclk");
            var b = this.F;
            M(b, N(b, 233));
            XE(this)
        } else {
            var c = a.h;
            null == c && null != a.a && (c = a.a.Bb);
            b = a.target.sb();
            if (null != c && null != a.target) {
                var d = c,
                    e = v(this.b.w.get(Pa(d)));
                this.a.wf(d, b);
                b == PE(e, 0) ? (U(d, "alt-edited"), 0 == Nf("alt-edited").length && (QE(this, !1), RE(this, !1))) : (T(d, "alt-edited"), QE(this, !0), RE(this, !0));
                null != this.K && this.K.set(this.C + "." + this.m + "." + I(e, 0), b);
                e = v(this.b.w.get(Pa(c)));
                null != this.K && this.K.set(this.C + "." + this.m + "." + I(e, 0), b);
                d = PE(e, 0);
                c = dr(this.b, a.target);
                d = {
                    sl: this.C,
                    tl: this.m,
                    utrans: b,
                    gtrans: d,
                    index: c,
                    ophrase: I(e, 0),
                    osentence: I(e, 4),
                    tsentence: WE(this, this.h, e)
                };
                0 < H(e, 2) && (d.confidence = Ih(Fo(e, 0), 1));
                if (a.target instanceof EE || -1 == c) d.manual = 1, c = this.F, M(c, N(c, 240));
                else {
                    a = this.F;
                    e = N(a, 239);
                    var f = new ql,
                        g = nf(nf(f, 2, ol), 3, ml);
                    A(g, 1, c);
                    lf(e, 27, f);
                    M(a, e)
                }
                for (var k in d) "string" === typeof d[k] && 64 < d[k].length && (d.tr = 1, d[k] = d[k].substr(0, 64));
                this.N.log("usealt", d,
                    null);
                k = new F("usealt");
                k.text = b;
                this.dispatchEvent(k);
                this.dispatchEvent("action")
            }
        }
};
var SE = function(a, b) {
    if (a.j()) {
        null == a.W && (a.V = xb(a.a.oi(a.j())));
        a.W = b;
        var c;
        if (c = a.j().childNodes && 0 < a.j().childNodes.length) c = (c = a.j().childNodes[0]) ? wj(a.b.b, Pa(c)) : !1;
        c ? (a.a.vf(a.j()), a.b.hf(), b = a.a.b("SPAN", "alt-edited", a.W), a.a.appendChild(a.j(), b), wE(a.b, b, new Do)) : a.j().innerHTML = Ac(de(b))
    }
};
h = KE.prototype;
h.Xl = function() {
    if (null != this.c && LE(this)) {
        var a = this.c;
        a.c.setVisible(!0);
        a.a.g(a.m);
        a.a.j().focus();
        a.g(null)
    } else LE(this) && (null != this.g && this.g.a(!1), HE(this.c)), this.K.Wc(), this.W = null, TE(this), this.dispatchEvent("action");
    this.N.log("clkundo", void 0, null)
};
h.ul = function() {
    LE(this) && (this.c.b && (SE(this, this.c.a.Y()), this.Z = !0), HE(this.c), null != this.g && this.g.a(!1), this.c.b && QE(this, !0), this.w.oa(!0), W(this.w.j(), this.Z), this.dispatchEvent("action"));
    var a = this.F;
    M(a, N(a, 215));
    this.N.log("clkcancel", void 0, null)
};
h.Il = function() {
    var a = this.b.w.get(Pa(this.b.Bb));
    if (a) {
        if (0 < this.R) {
            var b = new Zm("source=baf");
            if (1 == this.R) {
                for (var c = [], d = 0, e = H(a, 2); d < e; d++) c.push(PE(a, d));
                tp(this.Ca, this.m, this.C, YE(this), c, p(this.En, this), void 0, b, void 0)
            } else
                for (d = 0, e = H(a, 2); d < e; d++) c = PE(a, d), vp(this.Ca, this.m, this.C, YE(this), c, ["at", "t"], p(this.Fn, this, d), void 0, b)
        }
        b = new F("click");
        b.text = this.b.sb();
        b.m = H(this.h, 5);
        this.dispatchEvent(b);
        b = {};
        b.confidence = Ih(Fo(a, 0), 1);
        this.C && this.m && this.X && (b.segments = H(this.h, 5), b.sl =
            this.C, b.tl = this.m, b.hl = this.X);
        a = this.F;
        M(a, N(a, 238));
        this.N.log("phrsclk", b, null)
    }
};
h.Fn = function(a, b) {
    if (1 == this.R || 1 < H(b, 5)) {
        var c = b.cb(0).Tc();
        var d = 1;
        for (var e = b.jc(); d < e; d++) c += " " + b.cb(d).Tc();
        d = c
    } else if (1 == H(b, 5)) {
        c = [];
        b = pp(b, 0);
        d = 0;
        for (e = Math.min(this.R, H(b, 2)); d < e; d++) c.push(PE(b, d));
        d = c.join(", ")
    } else d = "...";
    AE(this.b, a, d)
};
h.En = function(a) {
    for (var b = 0; b < a.length; b++) AE(this.b, b, a[b])
};
var QE = function(a, b) {
        null != a.g && null != a.g.b && W(a.g.b, b)
    },
    RE = function(a, b) {
        null != a.w && (b && a.w.reset(), W(a.w.j(), b))
    };
KE.prototype.ab = function() {
    var a = [],
        b;
    null != this.V ? b = this.V : b = kg(this.j());
    for (var c = {
            segment: []
        }, d = null, e = 0, f = 0; f < b.length; f++) {
        var g = pp(this.h, f);
        if (null != g) {
            var k = Cg(b[f]);
            a: {
                var l = k;
                var m = g;
                if (0 == H(m, 2)) l = 0;
                else {
                    for (var q = 0; q < H(m, 2); ++q)
                        if (l == PE(m, q)) {
                            l = q;
                            break a
                        } l = -1
                }
            }
            m = yc(I(g, 4));
            q = WE(this, this.h, g, !0);
            if (0 != m.length) {
                if (0 == a.length || m != a[a.length - 1]) a.push(m), d = ZE(this, a.length - 1), e = 0, d = {
                    source: m,
                    original_target: q,
                    segment_source: d,
                    phrase_correction: []
                }, c.segment.push(d);
                if (0 != l)
                    for (m = PE(g,
                            0).length, l = {
                            alternative_index: l,
                            edited_phrase: k,
                            source_span: [],
                            target_span: [{
                                start: e,
                                end: e + m
                            }]
                        }, d.phrase_correction.push(l), m = 0; m < H(g, 3); ++m) q = Go(g, m), l.source_span.push({
                        start: Ih(q, 0),
                        end: Ih(q, 1)
                    });
                e += k.length;
                Fl(Fo(g, 0), 2) && e++
            }
        }
    }
    if (LE(this)) {
        this.dispatchEvent("action");
        HE(this.c);
        null != this.g && this.g.a(!1);
        QE(this, !0);
        this.c.a.Y() != UE(this) && SE(this, this.c.a.Y());
        b = this.C + "." + this.m;
        for (f = 0; f < a.length; ++f) b += "." + a[f];
        a = this.c.a.Y();
        this.K.set(b, a);
        c.contains_full_edit = !0
    }
    c.edited_target = UE(this,
        !0);
    a = new Zm;
    a.set("ue", JSON.stringify(c));
    a.set("sl", this.C);
    a.set("tl", this.m);
    Qj("/translate_suggestion?client=" + this.xa, void 0, "POST", a.toString(), void 0, 1E4)
};
var ZE = function(a, b) {
        if (b < a.h.jc()) switch (a.h.cb(b).mf()) {
            case 0:
                return 1;
            case 1:
                return 2;
            case 2:
                return 3;
            case 10:
                return 4;
            case 3:
                return 5
        }
        return 0
    },
    LE = function(a) {
        return null != a.c && a.c.h
    },
    NE = function(a, b) {
        a = pp(a, b);
        return 0 == H(a, 2) ? I(a, 0) : PE(a, 0)
    },
    PE = function(a, b) {
        return I(Fo(a, b), 0)
    },
    YE = function(a) {
        a = a.X;
        0 === a.length && null != Kf("hl") && (a = Kf("hl").value);
        return a
    };
var $E = function(a) {
    Dl(this, a, 7)
};
t($E, Cl);
var aF = {
    translation_id: {
        H: 0,
        J: !1
    },
    sl: {
        H: 1,
        J: !1
    },
    tl: {
        H: 2,
        J: !1
    },
    source: {
        H: 3,
        J: !1
    },
    trans: {
        H: 4,
        J: !1
    },
    write_timestamp: {
        H: 5,
        J: !1
    },
    label: {
        H: 6,
        J: !0
    }
};
$E.prototype.za = function() {
    return aF
};
$E.prototype.Be = function() {
    return I(this, 3)
};
$E.prototype.Tc = function() {
    return I(this, 4)
};
var bF = function(a) {
    Dl(this, a, 7)
};
t(bF, Cl);
var cF = {
    total: {
        H: 0,
        J: !1
    },
    token: {
        H: 1,
        J: !1
    },
    translations: {
        H: 2,
        va: function(a) {
            return Kl($E, a)
        },
        sa: function(a) {
            return Jl(new $E(a))
        },
        J: !0
    },
    error: {
        H: 3,
        J: !1
    },
    timestamp: {
        H: 4,
        J: !1
    },
    id: {
        H: 5,
        J: !1
    },
    max_translations: {
        H: 6,
        J: !1
    }
};
bF.prototype.za = function() {
    return cF
};
bF.prototype.getToken = function() {
    return I(this, 1)
};
var dF = function() {
    var a = DATA.Usage;
    this.g = DATA.DisplayLanguage;
    this.a = "";
    this.b = a;
    this.h = ""
};
dF.prototype.c = function(a, b) {
    b = b.target;
    if (ak(b) && "" != bk(b) && null != ck(b)) {
        b = ck(b);
        b = new bF(b);
        var c = b.getToken();
        null != c && "" != c && (this.a = c)
    } else b = new bF, b.Wa[3] = this.h;
    a(b)
};
var eF = function(a, b, c, d, e, f) {
    var g = window.location.href;
    b = new Rm(b);
    (g = (new Rm(g, !0)).a.get("authuser")) && b.a.set("authuser", g);
    b = b.toString();
    b += "&hl=" + a.g;
    a.b && (b += "&xt=" + a.b);
    Qj(b, p(a.c, a, c), d, e, f)
};
dF.prototype.tb = function(a, b, c, d, e, f) {
    var g = {
        cm: "g"
    };
    null != b && "all" != b && (g.sl = b);
    null != c && "all" != c && (g.tl = c);
    null != d && "" != d && (g.q = d);
    null != e && "" != e && (g.utrans = e);
    null != f && "0" != f && (g.od = f);
    "" != this.a && (g.tk = this.a, this.a = "");
    eF(this, "/translate_a/sg?client=webapp&" + Ej(g), a, "GET", void 0, {
        "cache-control": "no-cache"
    })
};
var fF = function(a, b, c, d, e, f, g) {
        var k = {
            cm: "a"
        };
        k.sl = c;
        k.tl = d;
        k.ql = e.length + "";
        g && (k.edit = "1");
        c = {};
        c.q = e;
        c.utrans = f;
        eF(a, "/translate_a/sg?client=webapp&" + Ej(k), b, "POST", Ej(c))
    },
    gF = function(a, b, c) {
        var d = {
            cm: "d"
        };
        d.count = c.length + "";
        var e = {};
        e.id = c;
        eF(a, "/translate_a/sg?client=webapp&" + Ej(d), b, "POST", Ej(e))
    };
var Rb = {},
    hF = null,
    iF = function(a) {
        a = Pa(a);
        delete Rb[a];
        Sb() && hF && hF.stop()
    },
    kF = function() {
        hF || (hF = new Ur(function() {
            jF()
        }, 20));
        var a = hF;
        a.nb() || a.start()
    },
    jF = function() {
        var a = Ta();
        Jb(Rb, function(b) {
            lF(b, a)
        });
        Sb() || kF()
    };
var mF = function(a, b, c, d) {
    ZD.call(this);
    if (!Ia(a) || !Ia(b)) throw Error("Start and end parameters must be arrays");
    if (a.length != b.length) throw Error("Start and end points must be the same length");
    this.o = a;
    this.K = b;
    this.duration = c;
    this.L = d;
    this.coords = [];
    this.progress = 0;
    this.G = null
};
t(mF, ZD);
mF.prototype.play = function(a) {
    if (a || 0 == this.a) this.progress = 0, this.coords = this.o;
    else if (1 == this.a) return !1;
    iF(this);
    this.startTime = a = Ta(); - 1 == this.a && (this.startTime -= this.duration * this.progress);
    this.endTime = this.startTime + this.duration;
    this.G = this.startTime;
    this.progress || this.c();
    this.b("play"); - 1 == this.a && this.b("resume");
    this.a = 1;
    var b = Pa(this);
    b in Rb || (Rb[b] = this);
    kF();
    lF(this, a);
    return !0
};
mF.prototype.stop = function(a) {
    iF(this);
    this.a = 0;
    a && (this.progress = 1);
    nF(this, this.progress);
    this.b("stop");
    this.g()
};
mF.prototype.T = function() {
    0 == this.a || this.stop(!1);
    this.b("destroy");
    mF.D.T.call(this)
};
var lF = function(a, b) {
        Za(a.startTime);
        Za(a.endTime);
        Za(a.G);
        b < a.startTime && (a.endTime = b + a.endTime - a.startTime, a.startTime = b);
        a.progress = (b - a.startTime) / (a.endTime - a.startTime);
        1 < a.progress && (a.progress = 1);
        a.G = b;
        nF(a, a.progress);
        1 == a.progress ? (a.a = 0, iF(a), a.b("finish"), a.g()) : 1 == a.a && a.C()
    },
    nF = function(a, b) {
        Ka(a.L) && (b = a.L(b));
        a.coords = Array(a.o.length);
        for (var c = 0; c < a.o.length; c++) a.coords[c] = (a.K[c] - a.o[c]) * b + a.o[c]
    };
mF.prototype.C = function() {
    this.b("animate")
};
mF.prototype.b = function(a) {
    this.dispatchEvent(new oF(a, this))
};
var oF = function(a, b) {
    F.call(this, a);
    this.coords = b.coords;
    this.x = b.coords[0];
    this.duration = b.duration;
    this.progress = b.progress;
    this.state = b.a
};
t(oF, F);
var pF = function(a, b, c, d, e) {
    mF.call(this, b, c, d, e);
    this.h = a
};
t(pF, mF);
pF.prototype.m = Ea;
pF.prototype.C = function() {
    this.m();
    pF.D.C.call(this)
};
pF.prototype.g = function() {
    this.m();
    pF.D.g.call(this)
};
pF.prototype.c = function() {
    this.m();
    pF.D.c.call(this)
};
var qF = function(a, b, c, d, e) {
    "number" === typeof b && (b = [b]);
    "number" === typeof c && (c = [c]);
    pF.call(this, a, b, c, d, e);
    if (1 != b.length || 1 != c.length) throw Error("Start and end points must be 1D");
    this.w = -1
};
t(qF, pF);
var rF = 1 / 1024;
qF.prototype.m = function() {
    var a = this.coords[0];
    Math.abs(a - this.w) >= rF && (xq(this.h, a), this.w = a)
};
qF.prototype.c = function() {
    this.w = -1;
    qF.D.c.call(this)
};
qF.prototype.g = function() {
    this.w = -1;
    qF.D.g.call(this)
};
qF.prototype.show = function() {
    this.h.style.display = ""
};
var sF = function(a, b, c) {
    qF.call(this, a, 0, 1, b, c)
};
t(sF, qF);
var tF = function(a, b, c) {
    qF.call(this, a, 1, 0, b, c)
};
t(tF, qF);
tF.prototype.c = function() {
    this.show();
    tF.D.c.call(this)
};
tF.prototype.g = function() {
    this.h.style.display = "none";
    tF.D.g.call(this)
};
var uF = function(a, b, c) {
    qF.call(this, a, 0, 1, b, c)
};
t(uF, qF);
uF.prototype.c = function() {
    this.show();
    uF.D.c.call(this)
};
var vF = function(a, b, c) {
    var d = "rw";
    null != c && c && (d = "m" + d);
    this.g = b;
    Gs.call(this, a, d, MSG_SEE_ALSO, MSG_SEE_ALSO, 10);
    this.Uh = !0
};
t(vF, Gs);
vF.prototype.update = function(a, b, c, d) {
    vF.D.update.call(this, a, b, c, d);
    if (!d || 0 == H(op(d), 0)) return !1;
    (a = this.j()) && Mp(a, Cg(this.Oc));
    fg(this.b);
    this.Ed();
    c = a = D("DIV", {
        "class": "gt-rw-div"
    });
    b = 15 < H(op(d), 0);
    for (var e = 0; e < H(op(d), 0); ++e) {
        var f = op(d);
        var g = Gh(f, 0, e);
        f = D("SPAN", {
            "class": "gt-cd-cl"
        });
        E(f, g);
        Gp(f, "option");
        f.tabIndex = -1;
        this.c.push(f);
        if (10 == e && b) {
            var k = D("DIV", {
                "class": "gt-rw-div"
            });
            c = k;
            k = b ? D("SPAN", {
                "class": "gt-card-fadein-wrapper"
            }, k) : k;
            cq(k, {
                display: "none"
            })
        }
        this.g || 0 != e && e != H(op(d), 0) &&
            c.appendChild(ag(", "));
        c.appendChild(f)
    }
    c = jc(this.Ba) ? "rtl" : "ltr";
    cq(this.b, {
        direction: c
    });
    this.b.appendChild(a);
    k && this.b.appendChild(k);
    b && (d = MSG_N_MORE_RELATED_LABEL.replace("%1$s", (H(op(d), 0) - 7).toLocaleString(this.Ra)), Is(this, d, MSG_FEWER_RELATED_LABEL));
    wF(this, xb(kg(a)));
    this.setVisible(!0);
    return !0
};
vF.prototype.aa = function() {
    vF.D.aa.call(this);
    var a = this.j();
    a && (Gp(a, "listbox"), Bh(a, this.w.bind(this)))
};
var wF = function(a, b) {
    a.g && (qh(a.j(), "keydown"), G(a.j(), "keydown", function(c) {
        Ah(c, b)
    }, !1))
};
vF.prototype.w = function(a) {
    Qp(a.target, "gt-cd-cl") && this.dispatchEvent(new F("a", a.target))
};
vF.prototype.fe = function(a) {
    var b = [],
        c = Nf("gt-card-fadein-wrapper", this.j());
    if (this.g) {
        if (a) var d = xb(Nf("gt-cd-cl", this.j()));
        else d = B("gt-rw-div", this.j()), d = xb(kg(d));
        wF(this, d)
    }
    for (var e = 0; e < c.length; e++) d = c[e], a ? b.push(new uF(d, 218)) : b.push(new tF(d, 218));
    for (e = 0; e < b.length; e++) b[e].play()
};
var xF = function() {},
    yF = function(a) {
        var b = D("SPAN");
        b.style.color = "transparent";
        b.style.background = "transparent";
        b.style.top = "-1000px";
        b.style.left = "-1000px";
        b.style.position = "absolute";
        dg(document.body, b);
        E(b, a);
        a = b.offsetWidth;
        jg(b);
        return a
    };
Fa(xF);
var zF = function() {
    xF.M()
};
Fa(zF);
var AF = function(a) {
    var b = yF(a);
    a = yF(a.substr(0, 1));
    return b != a
};
var BF = function() {
    HB.apply(this, arguments)
};
ka(BF, HB);
BF.prototype.K = function(a) {
    HB.prototype.K.call(this, a);
    CF(this.Z);
    CF(this.b);
    this.j().addEventListener("keydown", p(this.Ta, this), !1)
};
var CF = function(a) {
        V(a, "tw-ll-top", !0);
        a.addEventListener("scroll", function() {
            V(a, "tw-ll-top", 0 >= a.scrollTop)
        })
    },
    DF = function(a) {
        return Gg(document) === PB(a)
    };
BF.prototype.na = function(a) {
    return Gg(document) === a.j()
};
var EF = function(a) {
    a = eq(a.m, "columnCount");
    return parseInt(a, 10) || 1
};
BF.prototype.Ta = function(a) {
    if (this.isVisible()) switch (a.keyCode) {
        case 27:
            this.close();
            break;
        case 13:
            if (DF(this)) {
                var b = FF(this);
                yq(this.b) && null != b && (b.ue(AB(b.j())), a.preventDefault())
            } else b = (yq(this.b) ? this.g : this.a).find(this.na) || null, null != b && (b.ue(AB(b.j())), a.preventDefault());
            break;
        case 40:
            DF(this) ? (b = FF(this), null != b && (PB(this).blur(), b.j().focus(), a.preventDefault())) : GF(this, a);
            break;
        case 38:
            DF(this) || HF(this, a);
            break;
        case 39:
            if (!DF(this) && (b = EF(this), 1 < b)) {
                var c = Math.ceil(this.a.length /
                        b),
                    d = (yq(this.b) ? this.g : this.a).findIndex(this.na) + c;
                d >= this.a.length && (d -= b * c);
                0 > d && (d += c);
                this.a[d].j().focus();
                a.preventDefault()
            }
            break;
        case 37:
            DF(this) || (b = EF(this), 1 < b && (c = Math.ceil(this.a.length / b), d = (yq(this.b) ? this.g : this.a).findIndex(this.na) - c, 0 > d && (d += b * c), d >= this.a.length && (d -= c), this.a[d].j().focus(), a.preventDefault()));
            break;
        default:
            this.X(a)
    }
};
var GF = function(a, b) {
        var c = Gg(document);
        if (c)
            for (var d = a.a.find(function(g) {
                    return "auto" === g.code
                }), e = a.a.find(function(g) {
                    return "auto" !== g.code
                }), f = c;;) {
                (f = d && f === d.j() ? e.j() : f.nextElementSibling) || (f = !yq(a.b) && d ? d.j() : c.parentElement.children[0]);
                if (f === c) break;
                if (0 <= f.tabIndex && yq(f)) {
                    f.focus();
                    b.preventDefault();
                    break
                }
            }
    },
    HF = function(a, b) {
        var c = Gg(document);
        if (c)
            for (var d = a.a.find(function(g) {
                    return "auto" === g.code
                }), e = qb(a.a, function(g) {
                    return "auto" !== g.code
                }), f = c;;) {
                (f = d && f === d.j() ? e.j() : f.previousElementSibling) ||
                (f = !yq(a.b) && d ? d.j() : hb(c.parentElement.children));
                if (f === c) break;
                if (0 <= f.tabIndex && yq(f)) {
                    f.focus();
                    b.preventDefault();
                    break
                }
            }
    },
    FF = function(a) {
        if (yq(a.b)) return a = a.g.find(function(c) {
            return yq(c.j())
        }), null != a ? a : null;
        var b = hb(a.a);
        return "auto" === b.code ? b : a.a[0]
    };
BF.prototype.X = function(a) {
    DF(this) || !vh(a.keyCode) || a.altKey || a.ctrlKey || a.metaKey || (RB(this), PB(this).focus())
};
var IF = function(a, b, c, d) {
    this.Ba = a;
    this.Ma = b;
    this.Zf = c;
    this.c = d;
    this.b = this.a = null
};
var JF = function(a) {
        this.a = a;
        Gm.M()
    },
    KF = function(a) {
        Ey("TranslationStarred", function(b, c) {
            c = b ? new JF(c) : null;
            a && a(b, c)
        })
    },
    LF = function(a, b, c, d, e) {
        Jy(a.a, b, c, d, 0, e)
    };
var MF = function(a, b, c, d) {
    this.a = a;
    this.w = b;
    this.o = c;
    this.h = "AUTO" === this.o.toUpperCase() && b.src ? b.src : null;
    this.m = d;
    this.b = this.Za();
    this.g = this.c = null
};
MF.prototype.Za = function() {
    return lv(this.w)
};
MF.prototype.Pa = function() {
    return this.o
};
var NF = function(a) {
    return "AUTO" === a.o.toUpperCase() && null != a.h ? a.h : a.o
};
MF.prototype.ma = function() {
    return this.m
};
var OF = function(a, b) {
        a.w = b;
        a.b = a.Za()
    },
    PF = function(a, b) {
        xc(a.b) || (a.b = b)
    },
    QF = function(a, b) {
        return a.a === b.a && a.b === b.b && NF(a) === NF(b) && a.ma() === b.ma()
    },
    RF = function(a, b) {
        var c = a.a.toLowerCase();
        a = a.Za().toLowerCase();
        b = b.toLowerCase();
        return c.includes(b) || a.includes(b)
    },
    SF = function(a) {
        return a.Za() !== a.b
    },
    TF = function(a) {
        var b = JSON.parse(JSON.stringify(a.w));
        v(b instanceof Object, "Translation result isn't JSON");
        b = new MF(a.a, b, a.o, a.m);
        null != a.c && (b.c = a.c);
        null != a.g && (b.g = a.g);
        null != a.h && (b.h = a.h);
        PF(b, a.b);
        return b
    };
var UF = function(a) {
        return 1 == a % 10 && 11 != a % 100 ? "one" : 2 == a % 10 && 12 != a % 100 ? "two" : 3 == a % 10 && 13 != a % 100 ? "few" : "other"
    },
    VF = UF;
VF = UF;
var WF = function(a, b) {
        if (void 0 === b) {
            b = a + "";
            var c = b.indexOf(".");
            b = Math.min(-1 == c ? 0 : b.length - c - 1, 3)
        }
        return 1 == (a | 0) && 0 == b ? "one" : "other"
    },
    XF = WF;
XF = WF;
var aG = function(a) {
        this.g = a;
        this.b = this.a = this.h = null;
        a = vv;
        var b = sv;
        if (YF !== a || ZF !== b) YF = a, ZF = b, $F = new yv(1);
        this.o = $F
    },
    YF = null,
    ZF = null,
    $F = null,
    bG = /'([{}#].*?)'/g,
    cG = /''/g,
    dG = function(a, b) {
        return Aw(a, b)
    },
    Aw = function(a, b) {
        if (a.g) {
            a.h = [];
            var c = eG(a, a.g);
            a.b = fG(a, c);
            a.g = null
        }
        if (!a.b || 0 == a.b.length) return "";
        a.a = xb(a.h);
        c = [];
        gG(a, a.b, b, !1, c);
        b = c.join("");
        for (v(-1 == b.search("#"), "Not all # were replaced."); 0 < a.a.length;) b = b.replace(a.c(a.a), a.a.pop());
        return b
    },
    gG = function(a, b, c, d, e) {
        for (var f = 0; f < b.length; f++) switch (b[f].type) {
            case 4:
                e.push(b[f].value);
                break;
            case 3:
                var g = b[f].value,
                    k = a,
                    l = e,
                    m = c[g];
                void 0 === m ? l.push("Undefined parameter - " + g) : (k.a.push(m), l.push(k.c(k.a)));
                break;
            case 2:
                g = b[f].value;
                k = a;
                l = c;
                m = d;
                var q = e,
                    r = g.Ze;
                void 0 === l[r] ? q.push("Undefined parameter - " + r) : (r = g[l[r]], void 0 === r && (r = g.other, cb(r, "Invalid option or missing other option for select block.")), gG(k, r, l, m, q));
                break;
            case 0:
                g = b[f].value;
                hG(a, g, c, XF, d, e);
                break;
            case 1:
                g = b[f].value;
                hG(a, g, c, VF, d, e);
                break;
            default:
                Ya("Unrecognized block type: " + b[f].type)
        }
    },
    hG = function(a, b, c,
        d, e, f) {
        var g = b.Ze,
            k = b.Vh,
            l = +c[g];
        isNaN(l) ? f.push("Undefined or invalid parameter - " + g) : (k = l - k, g = b[c[g]], void 0 === g && (d = d(Math.abs(k)), $a(d, "Invalid plural key."), g = b[d], void 0 === g && (g = b.other), cb(g, "Invalid option or missing other option for plural block.")), b = [], gG(a, g, c, e, b), c = b.join(""), $a(c, "Empty block in plural."), e ? f.push(c) : (a = Iv(a.o, k), f.push(c.replace(/#/g, a))))
    },
    eG = function(a, b) {
        var c = a.h,
            d = p(a.c, a);
        b = b.replace(cG, function() {
            c.push("'");
            return d(c)
        });
        return b = b.replace(bG, function(e, f) {
            c.push(f);
            return d(c)
        })
    },
    iG = function(a) {
        var b = 0,
            c = [],
            d = [],
            e = /[{}]/g;
        e.lastIndex = 0;
        for (var f; f = e.exec(a);) {
            var g = f.index;
            "}" == f[0] ? (f = c.pop(), v(void 0 !== f && "{" == f, "No matching { for }."), 0 == c.length && (f = {
                type: 1
            }, f.value = a.substring(b, g), d.push(f), b = g + 1)) : (0 == c.length && (b = a.substring(b, g), "" != b && d.push({
                type: 0,
                value: b
            }), b = g + 1), c.push("{"))
        }
        v(0 == c.length, "There are mismatched { or } in the pattern.");
        b = a.substring(b);
        "" != b && d.push({
            type: 0,
            value: b
        });
        return d
    },
    jG = /^\s*(\w+)\s*,\s*plural\s*,(?:\s*offset:(\d+))?/,
    kG = /^\s*(\w+)\s*,\s*selectordinal\s*,/,
    lG = /^\s*(\w+)\s*,\s*select\s*,/,
    fG = function(a, b) {
        var c = [];
        b = iG(b);
        for (var d = 0; d < b.length; d++) {
            var e = {};
            if (0 == b[d].type) e.type = 4, e.value = b[d].value;
            else if (1 == b[d].type) {
                var f = b[d].value;
                switch (jG.test(f) ? 0 : kG.test(f) ? 1 : lG.test(f) ? 2 : /^\s*\w+\s*/.test(f) ? 3 : 5) {
                    case 2:
                        e.type = 2;
                        e.value = mG(a, b[d].value);
                        break;
                    case 0:
                        e.type = 0;
                        e.value = nG(a, b[d].value);
                        break;
                    case 1:
                        e.type = 1;
                        e.value = oG(a, b[d].value);
                        break;
                    case 3:
                        e.type = 3;
                        e.value = b[d].value;
                        break;
                    default:
                        Ya("Unknown block type for pattern: " +
                            b[d].value)
                }
            } else Ya("Unknown part of the pattern.");
            c.push(e)
        }
        return c
    },
    mG = function(a, b) {
        var c = "";
        b = b.replace(lG, function(k, l) {
            c = l;
            return ""
        });
        var d = {};
        d.Ze = c;
        b = iG(b);
        for (var e = 0; e < b.length;) {
            var f = b[e].value;
            $a(f, "Missing select key element.");
            e++;
            v(e < b.length, "Missing or invalid select value element.");
            var g;
            1 == b[e].type ? g = fG(a, b[e].value) : Ya("Expected block type.");
            d[f.replace(/\s/g, "")] = g;
            e++
        }
        cb(d.other, "Missing other key in select statement.");
        return d
    },
    nG = function(a, b) {
        var c = "",
            d = 0;
        b = b.replace(jG,
            function(l, m, q) {
                c = m;
                q && (d = parseInt(q, 10));
                return ""
            });
        var e = {};
        e.Ze = c;
        e.Vh = d;
        b = iG(b);
        for (var f = 0; f < b.length;) {
            var g = b[f].value;
            $a(g, "Missing plural key element.");
            f++;
            v(f < b.length, "Missing or invalid plural value element.");
            var k;
            1 == b[f].type ? k = fG(a, b[f].value) : Ya("Expected block type.");
            e[g.replace(/\s*(?:=)?(\w+)\s*/, "$1")] = k;
            f++
        }
        cb(e.other, "Missing other key in plural statement.");
        return e
    },
    oG = function(a, b) {
        var c = "";
        b = b.replace(kG, function(k, l) {
            c = l;
            return ""
        });
        var d = {};
        d.Ze = c;
        d.Vh = 0;
        b = iG(b);
        for (var e =
                0; e < b.length;) {
            var f = b[e].value;
            $a(f, "Missing ordinal key element.");
            e++;
            v(e < b.length, "Missing or invalid ordinal value element.");
            if (1 == b[e].type) var g = fG(a, b[e].value);
            else Ya("Expected block type.");
            d[f.replace(/\s*(?:=)?(\w+)\s*/, "$1")] = g;
            e++
        }
        cb(d.other, "Missing other key in selectordinal statement.");
        return d
    };
aG.prototype.c = function(a) {
    v(0 < a.length, "Literal array is empty.");
    return "\ufddf_" + (a.length - 1).toString(10) + "_"
};
var rG = function(a, b, c, d) {
        this.N = a;
        this.R = b;
        this.L = c;
        this.b = d;
        this.F = K.M();
        this.G = 1E4;
        this.h = 0;
        this.Fa = new yv("######");
        this.O = new aG(DATA.TooManyPhrases);
        this.o = null;
        this.g = [];
        if ("openDatabase" in window) {
            a = !0;
            try {
                window.openDatabase("", "", "", 0)
            } catch (e) {
                a = !1
            }
        } else a = !1;
        this.c = a;
        this.C = !1;
        this.c && pG(this);
        this.w = new dF;
        this.a = [];
        this.m = !1;
        qG(this)
    },
    pG = function(a) {
        KF(function(b, c) {
            b && c && (a.o = c, LF(a.o, null, null, null, function(d, e) {
                d && (a.g = kb(e, function(f) {
                    return new IF(f.sl, f.tl, f.src, f.trg)
                }), a.g.reverse());
                a.C = !0;
                sG(a)
            }))
        })
    },
    tG = function(a, b) {
        Eh(b, 6) && (b = Number(I(b, 6, ""))) && (a.G = b)
    },
    qG = function(a) {
        DATA.SignedIn && a.w.tb(function(b) {
            return uG(a, b)
        }, "", "", "", "", "1")
    },
    sG = function(a) {
        if ((!a.c || a.C) && a.m) {
            var b = a.F;
            M(b, vm(b, 241, a.g.length));
            b = a.F;
            M(b, vm(b, 242, a.a.length));
            b = {};
            O(a.b, "webapp", "stld", "b", (b.wc = a.g.length, b.gc = a.a.length, b));
            b = a.g.concat(a.a);
            a.h = b.length;
            a.N(b)
        }
    },
    vG = function(a, b, c) {
        if (a.c && !a.o) return !1;
        var d = NF(b),
            e = b.ma(),
            f = b.a,
            g = function() {
                var k = 0 === c;
                a.h += k ? 1 : -1;
                a.R(b, k)
            };
        if (0 === c) {
            if (300 <
                f.length) return a.L(DATA.PhraseTooLong), d = {}, O(a.b, "webapp", "stlm", "l", (d.sz = f.length, d)), um(a.F, f.length), !1;
            if (a.h >= a.G) return f = {}, O(a.b, "webapp", "stlm", "n", (f.sz = a.h + 1, f)), wm(a.F, a.h + 1), a.L(dG(a.O, {
                saved_phrase_limit: Iv(a.Fa, a.G)
            })), !1;
            fF(a.w, p(a.La, a, b, g), d, e, f, b.b, SF(b))
        } else if (1 == c) null != b.c ? gF(a.w, p(a.K, a, b, g), [b.c]) : a.c && Gy(a.o.a, d, e, f, g);
        else throw "Unexpected operation";
        return !0
    };
rG.prototype.La = function(a, b, c) {
    tG(this, c);
    if (c && !I(c, 3) && I(c, 5)) {
        a.c = I(c, 5);
        a.g = Number(I(c, 4, ""));
        var d = {};
        d.trans = a.b;
        d = {
            sentences: [d]
        };
        a = new IF(NF(a), a.ma(), a.a, d);
        a.a = I(c, 5);
        a.b = me(I(c, 4, ""));
        this.a.push(a);
        b(!0)
    } else O(this.b, "webapp", "stfl", "a"), mm(this.F, 151)
};
rG.prototype.K = function(a, b, c) {
    tG(this, c);
    c && !I(c, 3) ? (O(this.b, "webapp", "stsu", "d"), c = this.F, M(c, N(c, 234)), a = wG(this, a), -1 === a ? (O(this.b, "webapp", "stfl", "u"), mm(this.F, 154)) : (O(this.b, "webapp", "stsu", "u"), c = this.F, M(c, N(c, 235)), Ab(this.a, a, 1)), b(!0)) : (O(this.b, "webapp", "stfl", "d"), mm(this.F, 152))
};
var uG = function(a, b) {
        tG(a, b);
        a.a = Array.from(Il(b, 2, $E)).map(function(c) {
            var d = {};
            d.trans = c.Tc();
            d = {
                sentences: [d]
            };
            d = new IF(I(c, 1), I(c, 2), c.Be(), d);
            d.a = I(c, 0);
            d.b = Number(I(c, 5, ""));
            return d
        });
        a.m = !0;
        sG(a)
    },
    xG = function(a, b, c, d, e) {
        LF(a.o, b, c, d, function(f, g) {
            e(f && 0 < g.length)
        })
    },
    wG = function(a, b) {
        var c = NF(b),
            d = b.ma(),
            e = b.a,
            f = b.b,
            g = -1;
        a.a.forEach(function(k, l) {
            c === k.Ba && d === k.Ma && e === k.Zf && f === lv(k.c) && (k.a && (b.c = k.a), k.b && (b.g = k.b), g = l)
        });
        return g
    },
    yG = function(a, b, c) {
        if (!a.c || a.o) {
            var d = NF(b),
                e = b.ma(),
                f = b.a; - 1 !== wG(a, b) ? c(!0) : a.c ? xG(a, d, e, f, c) : c(!1)
        }
    };
var AG = function(a, b) {
    J.call(this);
    var c = ba(a);
    for (a = c.next(); !a.done; a = c.next()) zG(a.value, this.a.bind(this));
    b = ba(b);
    for (a = b.next(); !a.done; a = b.next()) zG(a.value, this.b.bind(this))
};
ka(AG, J);
AG.prototype.a = function(a) {
    a = BG(a.target);
    if ("" != a) {
        var b = new F("select");
        b.text = a;
        this.dispatchEvent(b)
    }
};
AG.prototype.b = function(a) {
    a = BG(a.target);
    if ("" != a) {
        var b = new F("select");
        b.text = a;
        b.o = !0;
        this.dispatchEvent(b)
    }
};
var BG = function(a) {
    var b = "";
    try {
        if (uw(a)) var c = a.value.substring(a.selectionStart, a.selectionEnd);
        else if (vw()) {
            var d = ww(a),
                e = d[1];
            if (d[0].inRange(e)) {
                if ("textarea" == a.type) {
                    var f = e.duplicate(),
                        g = f.text;
                    a = g;
                    for (d = !1; !d;) 0 == f.compareEndPoints("StartToEnd", f) ? d = !0 : (f.moveEnd("character", -1), f.text == g ? a += "\r\n" : d = !0);
                    var k = a
                } else k = e.text;
                var l = k
            } else l = "";
            c = l
        } else throw Error("Cannot get the selection text");
        b = c.trim();
        if ("" != b) return b
    } catch (m) {}
    b = xz(window);
    return b.toString ? b.toString().trim() : ""
};

function zG(a, b) {
    G(a, "mouseup", b);
    G(a, "keyup", function(c) {
        16 == c.keyCode && b(c)
    })
};
var CG = function() {},
    DG = new CG,
    EG = ["click", "keydown", "keyup"];
CG.prototype.listen = function(a, b, c, d, e) {
    var f = function(g) {
        var k = ih(b),
            l = ng(g.target) ? g.target.getAttribute("role") || null : null;
        "click" == g.type && Wg(g) ? k.call(d, g) : 13 != g.keyCode && 3 != g.keyCode || "keyup" == g.type ? 32 != g.keyCode || "keyup" != g.type || "button" != l && "tab" != l || (k.call(d, g), g.preventDefault()) : (g.type = "keypress", k.call(d, g))
    };
    f.$b = b;
    f.Bn = d;
    e ? e.listen(a, EG, f, c) : G(a, EG, f, c)
};
CG.prototype.Ga = function(a, b, c, d, e) {
    for (var f, g = 0; f = EG[g]; g++) {
        var k = a;
        var l = f;
        var m = !!c;
        l = Yg(k) ? k.pf(l, m) : k ? (k = kh(k)) ? k.pf(l, m) : [] : [];
        for (k = 0; m = l[k]; k++) {
            var q = m.listener;
            if (q.$b == b && q.Bn == d) {
                e ? e.Ga(a, f, m.listener, c, d) : oh(a, f, m.listener, c, d);
                break
            }
        }
    }
};
var FG = function(a) {
    var b = a.Hn;
    a = a.uid;
    a = '<div class="' + S("jfk-bubble") + '" role="alertdialog"' + (a ? ' aria-describedby="' + S(a) + '"' : "") + '><div class="' + S("jfk-bubble-content-id") + '"' + (a ? ' id="' + S(a) + '"' : "") + "></div>";
    b && (b = a += '<div class="' + S("jfk-bubble-closebtn-id") + " " + S("jfk-bubble-closebtn") + '" aria-label="', a = "Close".replace(In, Jn), a = b + a + '" role="button" tabindex=0></div>');
    a += '<div class="' + S("jfk-bubble-arrow-id") + " " + S("jfk-bubble-arrow") + '"><div class="' + S("jfk-bubble-arrowimplbefore") + '"></div><div class="' +
        S("jfk-bubble-arrowimplafter") + '"></div></div></div>';
    return Q(a)
};
FG.a = "jfk.templates.bubble.main";
var GG = function(a) {
    X.call(this, a);
    this.c = new ds("jfk-bubble", !0);
    this.b = new gE;
    this.K = []
};
t(GG, X);
GG.prototype.g = !0;
GG.prototype.h = !1;
var HG = function(a, b, c, d) {
        v(!a.ya, "Must call setPosition() before rendering");
        a.c.Xe = !1;
        es(a.c, 1, b, c, d)
    },
    IG = function(a, b) {
        v(!a.ya, "Must call showCloseButton() before rendering");
        a.g = b
    },
    KG = function(a, b) {
        v("string" === typeof b || b.nodeType || b instanceof wn || b instanceof zd, "Content must be a string or HTML.");
        a.V = b;
        JG(a, b)
    },
    JG = function(a, b) {
        a = a.Zb();
        b && a && ("string" === typeof b ? E(a, b) : b instanceof wn ? Td(a, vn(b)) : b instanceof zd ? Td(a, b) : (Td(a, Jd), dg(a, b)))
    };
h = GG.prototype;
h.setAutoHide = function(a) {
    this.b.setAutoHide(a)
};
h.Zb = function() {
    return this.wd("jfk-bubble-content-id")
};
h.Ja = function() {
    this.v = Xp(FG, {
        Hn: this.g,
        uid: "bubble-" + Pa(this)
    }, void 0, this.a);
    JG(this, this.V);
    W(this.j(), !1);
    var a = this.b,
        b = this.j();
    cE(a);
    a.v = b;
    if (!Ae) {
        a = this.b;
        b = sE(this.j(), "ease-out", 0, 1);
        var c = sE(this.j(), "ease-in", 1, 0);
        a.o = b;
        a.h = c
    }
    Rp(this.j(), this.K)
};
h.aa = function() {
    GG.D.aa.call(this);
    Y(this).listen(this.b, ["beforeshow", "show", "beforehide", "hide"], this.R);
    if (this.g) {
        var a = Y(this),
            b = this.wd("jfk-bubble-closebtn-id");
        DG.listen(b, Sa(this.setVisible, !1), void 0, a.m || a, a)
    }
    a = this.j();
    v(a, "getElement() returns null.");
    b = this.wd("jfk-bubble-arrow-id");
    v(b, "No arrow element is found!");
    var c = this.c;
    c.a = a;
    c.h = b;
    a = this.b;
    a.L = this.c || void 0;
    a.isVisible() && a.m()
};
h.setVisible = function(a) {
    this.b.setVisible(a)
};
h.isVisible = function() {
    return this.b.isVisible()
};
var LG = function(a) {
    a.isVisible() && a.b.m()
};
GG.prototype.T = function() {
    this.b.Ia();
    delete this.b;
    GG.D.T.call(this)
};
GG.prototype.m = function() {
    rq(this.j());
    return !1
};
GG.prototype.R = function(a) {
    if ("show" == a.type || "hide" == a.type) {
        var b = Y(this),
            c = this.a;
        c = y ? Ig(c) : c.a;
        "show" == a.type ? b.listen(c, "scroll", this.m) : b.Ga(c, "scroll", this.m)
    }
    b = this.dispatchEvent(a.type);
    this.h && "hide" == a.type && this.Ia();
    return b
};
var MG = function(a, b) {
        this.a = a;
        this.b = b
    },
    NG = {
        af: "af-ZA",
        am: "am-ET",
        az: "az-AZ",
        bg: "bg-BG",
        ca: "ca-ES",
        cs: "cs-CZ",
        da: "da-DK",
        de: "de-DE",
        el: "el-GR",
        eu: "eu-ES",
        fa: "fa-IR",
        fi: "fi-FI",
        tl: "fil-PH",
        gl: "gl-ES",
        gu: "gu-IN",
        hi: "hi-IN",
        hr: "hr-HR",
        hu: "hu-HU",
        hy: "hy-AM",
        iw: "he-IL",
        id: "id-ID",
        is: "is-IS",
        it: "it-IT",
        ja: "ja-JP",
        jw: "jv-ID",
        ka: "ka-GE",
        km: "km-KH",
        kn: "kn-IN",
        ko: "ko-KR",
        lo: "lo-LA",
        lt: "lt-LT",
        lv: "lv-LV",
        ml: "ml-IN",
        mr: "mr-IN",
        ms: "ms-MY",
        ne: "ne-NP",
        no: "nb-NO",
        nl: "nl-NL",
        pl: "pl-PL",
        ro: "ro-RO",
        ru: "ru-RU",
        si: "si-LK",
        sk: "sk-SK",
        sl: "sl-SI",
        sr: "sr-RS",
        su: "su-ID",
        sv: "sv-SE",
        te: "te-IN",
        th: "th-TH",
        tr: "tr-TR",
        uk: "uk-UA",
        vi: "vi-VN",
        zu: "zu-ZA",
        "ar::ae": "ar-AE",
        "ar::bh": "ar-BH",
        "ar::dz": "ar-DZ",
        "ar::eg": "ar-EG",
        "ar::il": "ar-IL",
        "ar::jo": "ar-JO",
        "ar::kw": "ar-KW",
        "ar::lb": "ar-LB",
        "ar::ma": "ar-MA",
        "ar::om": "ar-OM",
        "ar::ps": "ar-PS",
        "ar::qa": "ar-QA",
        "ar::sa": "ar-SA",
        "ar::tn": "ar-TN",
        ar: "ar-EG",
        "bn::bd": "bn-BD",
        "bn::in": "bn-IN",
        bn: "bn-BD",
        "en::au": "en-AU",
        "en::ca": "en-CA",
        "en::com": "en-US",
        "en::gh": "en-GH",
        "en::ie": "en-IE",
        "en::in": "en-IN",
        "en::ke": "en-KE",
        "en::ng": "en-NG",
        "en::nz": "en-NZ",
        "en::ph": "en-PH",
        "en::tz": "en-TZ",
        "en::uk": "en-GB",
        "en::za": "en-ZA",
        en: "en-001",
        "es::ar": "es-AR",
        "es::bo": "es-BO",
        "es::cl": "es-CL",
        "es::co": "es-CO",
        "es::cr": "es-CR",
        "es::do": "es-DO",
        "es::ec": "es-EC",
        "es::es": "es-ES",
        "es::gt": "es-GT",
        "es::hn": "es-HN",
        "es::mx": "es-MX",
        "es::ni": "es-NI",
        "es::pa": "es-PA",
        "es::pe": "es-PE",
        "es::pr": "es-PR",
        "es::py": "es-PY",
        "es::sv": "es-SV",
        "es::com": "es-US",
        "es::uy": "es-UY",
        "es::ve": "es-VE",
        es: "es-ES",
        "fr::ca": "fr-CA",
        "fr::fr": "fr-FR",
        fr: "fr-FR",
        "pt::pt": "pt-PT",
        pt: "pt-BR",
        "ta::in": "ta-IN",
        "ta::lk": "ta-LK",
        "ta::sg": "ta-SG",
        "ta::my": "ta-MY",
        ta: "ta-IN",
        "sw::ke": "sw",
        "sw::tz": "sw-TZ",
        sw: "sw",
        "ur::pk": "ur-PK",
        "ur::in": "ur-IN",
        ur: "ur-PK",
        "zh-CN:zh-TW:hk": "yue-Hant-HK",
        "zh-CN:zh-CN:hk": "cmn-Hans-HK",
        "zh-CN:zh-TW": "cmn-Hant-TW",
        "zh-CN": "cmn-Hans-CN"
    };
MG.prototype.get = function(a) {
    return NG[a + ":" + this.b + ":" + this.a] || NG[a + "::" + this.a] || NG[a + ":" + this.b] || NG[a] || null
};
var OG = function(a, b) {
    GG.call(this, b);
    this.C = 0;
    this.c.Qf = !0;
    this.setAutoHide(!1);
    this.c.c = a;
    LG(this);
    HG(this, 2);
    IG(this, !1);
    KG(this, Xp(bo, {
        label: MSG_SPEAK_NOW
    }))
};
t(OG, GG);
OG.prototype.aa = function() {
    OG.D.aa.call(this);
    this.w = B("gt-speech-l3", this.j())
};
var PG = function(a) {
    0 == a.C++ && T(a.w, "trigger");
    Ci(a.N, 600, a)
};
OG.prototype.N = function() {
    0 == --this.C && U(this.w, "trigger")
};
var QG = function(a, b, c, d, e, f, g, k, l) {
    J.call(this);
    this.X = a;
    this.K = b;
    this.a = null;
    po && "webkitSpeechRecognition" in window && (a = new webkitSpeechRecognition, a.continuous = kt(), a.interimResults = !0, this.a = a);
    this.V = new MG(c, d);
    this.R = !e;
    this.c = "";
    this.Ib = !1;
    this.b = null;
    this.w = "init";
    this.m = f || null;
    this.C = l || null;
    this.L = g || null;
    this.na = !!k;
    this.Z = new Xu;
    this.o = Gm.M();
    this.W = tl.M();
    this.F = K.M();
    this.h = null;
    this.G = ""
};
t(QG, J);
QG.prototype.init = function(a) {
    if (null != this.a) {
        var b = Kf("gt-src-tools-l");
        a = this.h = a || eb(b);
        this.b = new Ht(MSG_SPEECH_INPUT_TURN_ON, MSG_SPEECH_INPUT_TURN_OFF, new Nt("speech-button", !1));
        this.b.ba(D("DIV", {
            id: "gt-speech",
            tabindex: "0"
        }));
        ig(a, this.b.j(), 1);
        this.g = new OG(this.b.j());
        this.g.render(this.b.j());
        this.a.onresult = p(this.N, this);
        this.a.onstart = p(this.Sl, this);
        this.a.onspeechstart = p(this.jo, this);
        this.a.onend = p(this.Al, this);
        this.a.onspeechend = p(this.Ql, this);
        this.a.onerror = p(this.ia, this);
        this.a.onnomatch =
            p(this.O, this);
        G(this.b, "action", this.ho, !1, this);
        G(this.h, "click", this.io, !1, this)
    }
};
var RG = function(a, b) {
        var c = a.W;
        b ? (c.m = c.b, c.b = 3) : c.b = c.m;
        a.g.setVisible(b && a.R)
    },
    SG = "init:buttonOn end:buttonOn buttonOn:start start:speechStart speechStart:result result:result result:buttonOff buttonOff:speechEnd speechEnd:end".split(" "),
    TG = function(a, b) {
        if (!(0 <= SG.indexOf(a.w + ":" + b))) {
            var c = {};
            c.from = a.w;
            c.to = b;
            a.o.log("speech", c)
        }
        a.w = b
    };
h = QG.prototype;
h.ho = function() {
    if (this.b.Ea(16)) {
        var a = this.F;
        M(a, N(a, 149));
        O(this.o, "webapp", "si", "start", {
            sl: this.G
        });
        RA(this.K, !0);
        this.c = "";
        this.a.start();
        TG(this, "buttonOn")
    } else this.a.stop(), RG(this, !1), TG(this, "buttonOff"), RA(this.K, !1)
};
h.io = function() {
    if (!this.b.isEnabled()) {
        this.dispatchEvent("userInteractionWhileDisabled");
        var a = this.F;
        M(a, N(a, 305));
        O(this.o, "webapp", "dia", "click", {
            dias: "vi"
        })
    }
};
h.Sl = function() {
    this.Ib = !0;
    RG(this, !0);
    TG(this, "start");
    this.dispatchEvent("start")
};
h.jo = function() {
    PG(this.g);
    TG(this, "speechStart");
    this.dispatchEvent("speechStart")
};
h.Al = function() {
    UG(this);
    TG(this, "end");
    this.dispatchEvent("end")
};
h.Ql = function() {
    PG(this.g);
    TG(this, "speechEnd")
};
var UG = function(a) {
    a.Ib = !1;
    RG(a, !1);
    a.b.cd(!1)
};
QG.prototype.N = function(a) {
    PG(this.g);
    for (var b = "", c = a.resultIndex; c < a.results.length; ++c) this.a.continuous && (this.c || b) && 0 < a.results[c].length && a.results[c][0].transcript && a.results[c][0].transcript.length && " " != a.results[c][0].transcript[0] || (a.results[c].isFinal ? this.c += a.results[c][0].transcript : b += a.results[c][0].transcript);
    a = this.c + b;
    Nm(this.o, "inputm", 3);
    this.X.b(a);
    TG(this, "result")
};
QG.prototype.ia = function() {
    UG(this);
    TG(this, "error")
};
QG.prototype.O = function() {
    UG(this);
    TG(this, "noMatch")
};
QG.prototype.nb = function() {
    return this.Ib
};
var VG = function(a, b, c, d, e, f) {
    X.call(this);
    this.R = a;
    this.X = b;
    this.ia = c;
    this.Z = d || "";
    this.ra = e || "";
    this.Ca = f || function() {};
    this.c = this.N = this.g = "";
    this.b = !1;
    this.C = !0;
    this.w = [];
    this.m = "";
    this.V = !1;
    this.K = new Ur(this.zm, 1E3, this);
    this.h = Gm.M();
    this.F = K.M()
};
t(VG, X);
h = VG.prototype;
h.setVisible = function(a) {
    a || (this.V = this.b = !1, this.K.stop());
    W(this.j(), a)
};
h.isVisible = function() {
    return yq(this.j())
};
h.show = function(a) {
    if ("" == a.ve) this.setVisible(!1);
    else {
        if (a.vh) {
            if (this.V) return
        } else this.V = !0;
        this.m = a.vh || "";
        this.g = a.$i;
        this.N = a.kj;
        this.c = this.m ? this.c : a.ve;
        this.W = a.rk || de(a.ve);
        this.b = a.ci && this.C;
        var b = a.vh ? this.X : a.ci && this.C ? this.Z : this.ia;
        if (this.b && rb(a.sg, 6)) {
            this.setVisible(!1);
            var c = Kf("src-translit");
            c && E(c, this.c);
            if (a.result)
                for (c = 0; c < a.result.jc(); c++) a.result.cb(c).Wa[3] = 0 == c ? this.c : ""
        } else this.b ? (c = this.j(), U(c, "gt-spell-correct-message"), T(c, "gt-related-suggest-message")) :
            (c = this.j(), U(c, "gt-related-suggest-message"), T(c, "gt-spell-correct-message")), this.setVisible(!0);
        E(this.j(), b + " ");
        this.w = a.sg;
        b = D("a", {
            tabindex: 0,
            href: "javascript:void(0)"
        });
        cq(b, {
            direction: jc(this.N) ? "rtl" : "ltr"
        });
        cq(b, {
            "text-decoration": "none"
        });
        b.innerHTML = this.W;
        G(b, "click", this.Um, !1, this);
        this.j().appendChild(b);
        b = D("DIV", "gt-spell-icon");
        this.j().appendChild(b);
        this.b && !rb(a.sg, 6) && (a = D("div"), E(a, this.ra + " "), b = D("a", {
                tabindex: 1,
                href: "javascript:void(0)"
            }), G(b, "click", this.xa, !1, this),
            E(b, this.g), a.appendChild(b), this.j().appendChild(a), T(a, "gt-revert-correct-message"));
        this.K.start()
    }
};
h.zm = function() {
    var a = {};
    a.orig = this.g;
    a.sl = this.N;
    this.b && (a.autocorrect = this.b);
    this.m ? (a.corrlang = this.m, this.h.log("langidshow", a), im(this.F, 5, 1, !1)) : (a.corr = this.c, a.corrtype = this.w, this.h.log("spell", a), im(this.F, 4, 1, !1))
};
h.Um = function() {
    if (this.m) {
        var a = this.g;
        64 < a.length && (a = a.substr(0, 64));
        Nm(this.h, "orig", a);
        Nm(this.h, "psl", this.N);
        this.Ca(this.W, this.m);
        yt(this.R, this.m, "", this.g, "tws_lsugg");
        a = this.F;
        M(a, em(a, 79, 5, 1, !1, 1))
    } else a = this.g, 64 < a.length && (a = a.substr(0, 64)), Nm(this.h, "orig", a), Nm(this.h, "corrtype", this.w), this.b ? yt(this.R, "", "", this.c, "tws_confirm") : yt(this.R, "", "", this.c, "tws_spell"), a = this.F, M(a, em(a, 79, 4, 1, !1, 1));
    a = this.K;
    a.nb() && (a.stop(), a.Jg());
    this.setVisible(!1)
};
var WG = {},
    XG = (WG[1] = 1, WG[2] = 2, WG[3] = 3, WG[4] = 4, WG[5] = 5, WG[6] = 6, WG[7] = 7, WG[8] = 8, WG[9] = 9, WG[10] = 10, WG);
VG.prototype.xa = function() {
    var a = this.c;
    64 < a.length && (a = a.substr(0, 64));
    Nm(this.h, "corr", a);
    Nm(this.h, "corrtype", this.w);
    this.C = !1;
    yt(this.R, "", "", this.g, "tws_revert");
    a = this.K;
    a.nb() && (a.stop(), a.Jg());
    this.setVisible(!1);
    a = this.F;
    for (var b = this.g, c = [], d = 0; d < this.w.length; d++) {
        var e = XG[this.w[d]];
        c.push(e ? e : 0)
    }
    d = new fl;
    b = A(d, 1, b);
    c = A(b, 2, c || []);
    b = N(a, 139);
    c = lf(b, 55, c);
    M(a, c)
};
var YG = function() {
        this.a = Kw(INPUT_SUGGESTION_SERVER_URL);
        this.ed = 5E3
    },
    ZG = 0;
YG.prototype.send = function(a, b, c, d) {
    a = a ? Ub(a) : {};
    d = d || "_" + (ZG++).toString(36) + Ta().toString(36);
    var e = "_callbacks___" + d;
    b && (n[e] = $G(d, b), a.callback = e);
    b = {
        timeout: this.ed,
        jk: !0
    };
    e = rc(this.a);
    e = sc.exec(e);
    var f = e[3] || "";
    e = tc(e[1] + uc("?", e[2] || "", a) + uc("#", f, void 0));
    b = dz(e, b);
    Xy(b, null, aH(d, a, c), void 0);
    return {
        qa: d,
        ei: b
    }
};
YG.prototype.cancel = function(a) {
    a && (a.ei && a.ei.cancel(), a.qa && bH(a.qa, !1))
};
var aH = function(a, b, c) {
        return function() {
            bH(a, !1);
            c && c(b)
        }
    },
    $G = function(a, b) {
        return function(c) {
            bH(a, !0);
            b.apply(void 0, arguments)
        }
    },
    bH = function(a, b) {
        a = "_callbacks___" + a;
        if (n[a])
            if (b) try {
                delete n[a]
            } catch (c) {
                n[a] = void 0
            } else n[a] = Ea
    };
var cH = function() {
        var a = INPUT_SUGGESTION_CLIENT_NAME,
            b = INPUT_SUGGESTION_DATASET;
        this.g = new YG;
        this.g.ed = 500;
        this.a = null;
        this.h = 0;
        this.c = !1;
        this.C = Gm.M();
        this.F = K.M();
        this.m = b || "translate";
        this.G = a || "translate_separate_corpus"
    },
    zD = function(a, b, c, d, e) {
        OD(a);
        if (0 == b.length || 64 < b.length || "auto" == c) e([]);
        else {
            c = "zh-CN" == c || "zh-TW" == c ? "zh" : c;
            var f = 167 - (Ta() - a.h);
            0 > f && (f = 0);
            a.b = Ci(function() {
                if (this.b) {
                    this.b = void 0;
                    var g = c;
                    this.h = Ta();
                    var k = {};
                    k.q = b;
                    k.client = this.G;
                    k.ds = this.m;
                    k.hl = g;
                    k.requiredfields = "tl:" +
                        d;
                    this.a = this.g.send(k, p(this.w, this, b, g, d, e), p(this.o, this, "4", b, g, d, 144))
                }
            }, f, a)
        }
    },
    OD = function(a) {
        a.a && (a.c = !0, a.g.cancel(a.a), a.a = null);
        a.b && (Di(a.b), a.b = void 0)
    };
cH.prototype.o = function(a, b, c, d, e, f, g, k) {
    if (!this.c) {
        b = {
            q: b,
            sl: c,
            tl: d
        };
        if (null != g) try {
            b.se = g.substring(0, 64)
        } catch (l) {
            throw Error(l + " opt_context is " + g);
        }
        k && (b.msg = k.substring(0, 64));
        mm(this.F, e);
        O(this.C, "webapp", "is", a, b)
    }
    this.c = !1
};
cH.prototype.w = function(a, b, c, d, e) {
    try {
        var f = kb(e[1], function(g) {
            return ge(g[0])
        }, this);
        d(f)
    } catch (g) {
        this.o("5", a, b, c, 53, null, ej(e), g.message)
    }
    this.a = null
};
var dH = function() {
        this.a = [];
        this.c = this.b = null
    },
    TD = function(a) {
        var b = a.a.length;
        b += a.b ? 1 : 0;
        b += a.c ? 1 : 0;
        return a = b + (a.c ? 1 : 0)
    };
var eH = function(a) {
    this.a = a || "menu"
};
t(eH, Qw);
Fa(eH);
eH.prototype.Ee = function() {
    return "gt-is"
};
eH.prototype.b = function(a) {
    return mg(a)
};
eH.prototype.zf = function(a) {
    return "DIV" == a.tagName && a.firstChild && "DIV" == a.firstChild.tagName ? !0 : !1
};
eH.prototype.c = function() {
    var a = D("DIV", "gt-is"),
        b = D("DIV", "gt-is-ctr");
    dg(a, b);
    return a
};
var fH = function(a, b, c) {
    Xw.call(this, a || Ww(eH.M()), b || eH.M(), c);
    this.b = [];
    this.h = this.g = this.c = null;
    hx(this, !1)
};
t(fH, Xw);
var ND = function(a, b) {
        w(a.b, function(c) {
            this.removeChild(c, !0)
        }, a);
        w(b, function(c, d) {
            this.c ? this.qd(c, dr(this, this.c), !0) : this.jb(c, !0);
            d = "gt-is-si-" + d;
            c.wd("gt-is-sg").id = d
        }, a);
        a.b = b
    },
    RD = function(a, b) {
        a.g && a.removeChild(a.g, !0);
        if (b) {
            var c = dr(a, a.h) + 1;
            a.qd(b, c, !0)
        }
        a.g = b
    },
    SD = function(a, b) {
        (a = a.b[0]) && (a = a.wd(a.ii ? "gt-is-ld-top" : "gt-is-ld")) && W(a, b)
    };
fH.prototype.Ya = function(a) {
    return 27 == a.keyCode ? (this.setVisible(!1), a.stopPropagation(), a.preventDefault(), !0) : fH.D.Ya.call(this, a)
};
var gH = function(a, b, c) {
    var d = "ss";
    null != c && c && (d = "m" + d);
    this.w = b;
    Gs.call(this, a, d, MSG_SYNONYMS_OF, MSG_SYNONYMS, 8);
    this.g = []
};
t(gH, Gs);
h = gH.prototype;
h.update = function(a, b, c, d) {
    gH.D.update.call(this, a, b, c, d);
    if (!d || 0 == H(d, 11)) return !1;
    fg(this.b);
    this.Ed();
    var e = c = 0;
    for (a = 0; a < H(d, 11); ++a) {
        var f = new fp(Hl(d, 11, a)),
            g = I(f, 2);
        c += f.a();
        for (b = 0; b < f.a(); ++b) e += H(f.b(b), 0)
    }
    if (b = 2 < c / H(d, 11) && 1 < e - c) a = MSG_N_MORE_SYNONYMS_LABEL.replace("%1$s", (e - c).toLocaleString(this.Ra)), Is(this, a, MSG_FEWER_SYNONYMS_LABEL);
    c = 1 == c / H(d, 11);
    g && (this.cf = g, Hs(this, g));
    for (a = 0; a < H(d, 11); ++a) {
        f = new fp(Hl(d, 11, a));
        g = D("DIV", {
            "class": "gt-cd-pos"
        });
        this.b.appendChild(g);
        E(g, I(f, 0));
        g = f;
        f = c;
        e = b;
        var k = D("UL", {
            "class": "gt-syn-list"
        });
        var l = jc(this.Ba) ? "rtl" : "ltr";
        cq(k, {
            direction: l
        });
        if (e) {
            l = D("SPAN", {
                "class": "gt-syn-span"
            });
            for (var m = D("DIV", {
                    "class": "gt-syn-row"
                }, l), q = [], r = 0; r < g.a(); ++r) {
                var u = g.b(r);
                u = Gh(u, 0, 0);
                if (!rb(q, u)) {
                    q.push(u);
                    this.w || 0 < r && l.appendChild(ag(", "));
                    var z = D("SPAN", {
                        "class": "gt-cd-cl"
                    });
                    l.appendChild(z);
                    this.w ? E(z, " " + u + " ") : E(z, u);
                    this.g.push(z)
                }
            }
            l = D("DIV", {
                "class": "gt-syn-summary-row"
            }, m);
            k.appendChild(l)
        }
        for (l = 0; l < g.a(); ++l) {
            m = g.b(l);
            r = e;
            u = f ? "DIV" : "LI";
            q = D("SPAN", {
                "class": "gt-syn-span"
            });
            u = D(u, {
                "class": "gt-syn-row"
            }, q);
            r = Js(u, !r);
            for (u = 0; u < H(m, 0); ++u) z = D("SPAN", {
                "class": "gt-cd-cl"
            }), q.appendChild(z), this.w ? E(z, " " + Gh(m, 0, u) + " ") : E(z, Gh(m, 0, u)), this.c.push(z), this.w || u < H(m, 0) - 1 && q.appendChild(ag(", "));
            k.appendChild(r)
        }
        this.b.appendChild(k)
    }
    this.setVisible(!0);
    return !0
};
h.aa = function() {
    gH.D.aa.call(this);
    Y(this).listen(this.j(), "click", this.oo)
};
h.oo = function(a) {
    Qp(a.target, "gt-cd-cl") && this.dispatchEvent(new F("a", a.target))
};
h.fe = function(a) {
    gH.D.fe.call(this, a);
    for (var b = Nf("gt-syn-summary-row", this.j()), c = 0; c < b.length; c++) {
        var d = b[c],
            e = B("gt-syn-row", d),
            f = Hq(e, "margin");
        e = vq(e).height + f.top + f.bottom;
        cq(d, "max-height", a ? 0 : e + "px")
    }
};
h.ze = function() {
    return this.m ? gH.D.ze.call(this) : this.g.length
};
h.Gg = function(a) {
    return this.m ? gH.D.Gg.call(this, a) : this.g.indexOf(a)
};
h.Ed = function() {
    gH.D.Ed.call(this);
    this.g = []
};
var hH = function(a, b) {
    this.C = Gm.M();
    this.F = K.M();
    this.g = a;
    y || we || ye || G(a, "copy", this.m, !1, this);
    this.a = b;
    for (a = 0; a < b.length; a++) G(b[a], "mousedown", this.w, !1, this);
    this.c = this.b = null;
    this.o = this.h = !1
};
t(hH, Jg);
hH.prototype.T = function() {
    hH.D.T.call(this);
    oh(this.g, "copy", this.m, !1, this);
    this.g = null;
    for (var a = 0; a < this.a.length; a++) oh(this.a[a], "mousedown", this.w, !1, this);
    this.a = null
};
hH.prototype.m = function() {
    var a = hA();
    a && this.g && (this.c = a, Ci(this.G, 0, this), Kf("gt-res-edit") && (this.h = yq(Kf("gt-res-edit")), this.o = yq(Kf("gt-res-undo")), W(Kf("gt-res-edit"), !1), W(Kf("gt-res-undo"), !1)), a = xz(window).toString(), this.b = kA(a))
};
hH.prototype.w = function(a) {
    var b = a.b.detail;
    1 < b && Wg(a) && rb(this.a, a.target) && (a.preventDefault(), jA(this.g), a = {}, a.clickCount = b, this.C.log("dblClickSelectall", a), b = this.F, M(b, N(b, 236)))
};
hH.prototype.G = function() {
    this.c && (this.c.select(), this.c = null);
    this.b && (jg(this.b), this.b = null);
    this.h && W(Kf("gt-res-edit"), !0);
    this.o && W(Kf("gt-res-undo"), !0)
};
var iH = function(a) {
    this.a = Aq(Jw(""));
    this.b = (Ia(a) ? a.join(",") : a) + "{font-family:%FONT%arial,sans-serif!important}"
};
iH.prototype.set = function(a) {
    zq(this.a, Jw("" == a ? "" : this.b.replace("%FONT%", '"' + a + '",')))
};
var jH = function() {
    zF.M();
    var a = yF("\u1288") == yF("\u1290"),
        b = AF("\u09a5\u09cd"),
        c = AF("\u1780\u17d1"),
        d = AF("\u0e81\u0ec8"),
        e = AF("\u0d15\u0d4d"),
        f = AF("\u1001\u1039\u1010"),
        g = AF("\u0da5\u0dca");
    var k = AF("\u0ba4\u0bcd") || yF("\u0bb1\u0bc6\u0bbe") + yF("\u0bb1") != yF("\u0bb1\u0bc6") + yF("\u0bb1\u0bbe");
    this.a = {
        am: a,
        bn: b,
        km: c,
        lo: d,
        ml: e,
        my: f,
        ps: !0,
        sd: !0,
        si: g,
        ta: k
    }
};
Fa(jH);
var kH = {
        "Noto Sans Ethiopic": "notosansethiopic",
        "Noto Naskh Arabic": "notonaskharabic",
        "Noto Sans Malayalam": "notosansmalayalam",
        "Noto Sans Myanmar": "notosansmyanmar",
        "Noto Sans Sinhala": "notosanssinhala"
    },
    lH = {
        Dhyana: Ze || ve || Xe || We || Ve
    },
    mH = {
        lo: De && 0 <= Lc(Yr, "6.0")
    },
    nH = {
        am: "Noto Sans Ethiopic",
        bn: "Lohit Bengali",
        lo: "Dhyana",
        km: "Nokora",
        ml: "Noto Sans Malayalam",
        my: "Noto Sans Myanmar",
        ps: "Noto Naskh Arabic",
        sd: "Noto Naskh Arabic",
        si: "Noto Sans Sinhala",
        ta: "Lohit Tamil"
    },
    oH = function() {
        this.a = {};
        jH.M()
    };
Fa(oH);
var sH = function() {
        this.h = jH.M();
        this.g = oH.M();
        this.c = new iH(pH);
        this.a = new iH(qH);
        this.b = new iH(rH)
    },
    pH = ["body", "#gb"],
    qH = "#source .gt-hl-layer .gt-baf-translations .round-trip-content .vk-cap .vk-t .orig".split(" "),
    rH = "#result_box .gt-baf-word .gt-baf-word-clickable .alt-menu .gt-ex-translate #alt-input-text .text-wrap".split(" "),
    tH = function(a, b, c) {
        a: {
            var d = mH[c],
                e = a.h.a[c];
            if ((null == d || !d) && null != e && e && (c = nH[c], null != c && (d = lH[c], null == d || !d))) break a;c = ""
        }
        a = a.g;
        "" != c && null == a.a[c] && (a = a.a, d = c,
            e = new Rm, null != kH[d] ? Vm(e, "/earlyaccess/" + kH[d] + ".css") : (Vm(e, "/css"), e.a.set("family", d)), a[c] = Aq(Jw("@import url(//fonts.googleapis.com" + e.toString() + ");")));b.set(c)
    };
var uH = function(a) {
    J.call(this);
    this.v = a;
    this.b = C("tlid-app-download-button", this.v);
    this.F = K.M();
    this.a = Gm.M();
    Bh(this.b, this.c.bind(this))
};
ka(uH, J);
uH.prototype.c = function() {
    if (Qp(this.v, "popup-open")) vH(this, !1);
    else {
        if (Qp(this.v, "tlid-android-download")) {
            var a = this.F;
            M(a, N(a, 333));
            this.a.log("cad=and", {})
        } else Qp(this.v, "tlid-ios-download") && (a = this.F, M(a, N(a, 334)), this.a.log("cad=ios", {}));
        vH(this, !0)
    }
};
var vH = function(a, b) {
    V(a.v, "popup-open", b);
    b && a.dispatchEvent("popup_opened")
};
var xH = function(a) {
        this.v = a;
        a = Nf("tlid-app-download-button-container", this.v);
        for (var b = [], c = 0; c < a.length; c++) b.push(new uH(a[c]));
        this.a = b;
        wH(this)
    },
    wH = function(a) {
        a.a.forEach(function(b) {
            G(b, "popup_opened", p(a.b, a, b), !1, a)
        });
        G(a.v, "keydown", function(b) {
            Ah(b, Nf("tlid-app-download-button", a.v))
        }, !1)
    };
xH.prototype.b = function(a) {
    this.a.forEach(function(b) {
        b != a && vH(b, !1)
    })
};
var yH = function(a) {
        this.a = a;
        this.b = C("tlid-brain-logo", this.a);
        this.c = C("tlid-no-brain-logo", this.a)
    },
    BH = function(a, b, c) {
        b = zH(b, c) && !AH(b, c) ? !0 : "en" !== b && "en" !== c ? zH(b, "en") && zH("en", c) && !AH(b, c) : !1;
        V(a.b, "hidden", !b);
        V(a.c, "hidden", b)
    },
    zH = function(a, b) {
        var c = !1;
        w(DATA.NeuralEnabledPairs, function(d) {
            d.Source === a && d.Target === b && (c = !0)
        });
        return c
    },
    AH = function(a, b) {
        var c = !1;
        w(DATA.ExcludedPairs, function(d) {
            d.Source === a && d.Target === b && (c = !0)
        });
        return c
    };
var DH = function(a, b, c) {
    J.call(this);
    this.target = a;
    this.m = b || a;
    this.g = c || new $p(NaN, NaN, NaN, NaN);
    this.c = If(a);
    this.a = new Lq(this);
    Lg(this, this.a);
    this.deltaY = this.deltaX = this.C = this.G = this.screenY = this.screenX = this.clientY = this.clientX = 0;
    this.o = !0;
    this.b = !1;
    G(this.m, ["touchstart", "mousedown"], this.mj, !1, this);
    this.h = CH
};
t(DH, J);
var CH = n.document && n.document.documentElement && !!n.document.documentElement.setCapture && !!n.document.releaseCapture;
h = DH.prototype;
h.oa = function(a) {
    this.o = a
};
h.T = function() {
    DH.D.T.call(this);
    oh(this.m, ["touchstart", "mousedown"], this.mj, !1, this);
    Qq(this.a);
    this.h && this.c.releaseCapture();
    this.m = this.target = null
};
h.mj = function(a) {
    var b = "mousedown" == a.type;
    if (!this.o || this.b || b && !Wg(a)) this.dispatchEvent("earlycancel");
    else if (this.dispatchEvent(new EH("start", this, a.clientX, a.clientY, a))) {
        this.b = !0;
        b && a.preventDefault();
        b = this.c;
        var c = b.documentElement,
            d = !this.h;
        this.a.listen(b, ["touchmove", "mousemove"], this.Gl, {
            capture: d,
            passive: !1
        });
        this.a.listen(b, ["touchend", "mouseup"], this.jf, d);
        this.h ? (c.setCapture(!1), this.a.listen(c, "losecapture", this.jf)) : this.a.listen(Vf(b), "blur", this.jf);
        this.K && this.a.listen(this.K,
            "scroll", this.L, d);
        this.clientX = this.G = a.clientX;
        this.clientY = this.C = a.clientY;
        this.screenX = a.screenX;
        this.screenY = a.screenY;
        this.deltaX = this.target.offsetLeft;
        this.deltaY = this.target.offsetTop;
        this.w = Uf(Jf(this.c).a)
    }
};
h.jf = function(a, b) {
    Qq(this.a);
    this.h && this.c.releaseCapture();
    this.b ? (this.b = !1, this.dispatchEvent(new EH("end", this, a.clientX, a.clientY, a, FH(this, this.deltaX), GH(this, this.deltaY), b || "touchcancel" == a.type))) : this.dispatchEvent("earlycancel")
};
h.Gl = function(a) {
    if (this.o) {
        var b = a.clientX - this.clientX,
            c = a.clientY - this.clientY;
        this.clientX = a.clientX;
        this.clientY = a.clientY;
        this.screenX = a.screenX;
        this.screenY = a.screenY;
        if (!this.b) {
            var d = this.G - this.clientX,
                e = this.C - this.clientY;
            if (0 < d * d + e * e)
                if (this.dispatchEvent(new EH("start", this, a.clientX, a.clientY, a))) this.b = !0;
                else {
                    this.isDisposed() || this.jf(a);
                    return
                }
        }
        c = HH(this, b, c);
        b = c.x;
        c = c.a;
        this.b && this.dispatchEvent(new EH("beforedrag", this, a.clientX, a.clientY, a, b, c)) && (IH(this, a, b, c), a.preventDefault())
    }
};
var HH = function(a, b, c) {
    var d = Uf(Jf(a.c).a);
    b += d.x - a.w.x;
    c += d.a - a.w.a;
    a.w = d;
    a.deltaX += b;
    a.deltaY += c;
    return new Ef(FH(a, a.deltaX), GH(a, a.deltaY))
};
DH.prototype.L = function(a) {
    var b = HH(this, 0, 0);
    a.clientX = this.clientX;
    a.clientY = this.clientY;
    IH(this, a, b.x, b.a)
};
var IH = function(a, b, c, d) {
        a.target.style.left = c + "px";
        a.target.style.top = d + "px";
        a.dispatchEvent(new EH("drag", a, b.clientX, b.clientY, b, c, d))
    },
    FH = function(a, b) {
        var c = a.g;
        a = isNaN(c.left) ? null : c.left;
        c = isNaN(c.width) ? 0 : c.width;
        return Math.min(null != a ? a + c : Infinity, Math.max(null != a ? a : -Infinity, b))
    },
    GH = function(a, b) {
        var c = a.g;
        a = isNaN(c.top) ? null : c.top;
        c = isNaN(c.height) ? 0 : c.height;
        return Math.min(null != a ? a + c : Infinity, Math.max(null != a ? a : -Infinity, b))
    },
    EH = function(a, b, c, d, e, f, g) {
        F.call(this, a);
        this.clientX = c;
        this.clientY = d;
        this.left = void 0 !== f ? f : b.deltaX;
        this.top = void 0 !== g ? g : b.deltaY
    };
t(EH, F);
(function() {
    for (var a = ["ms", "moz", "webkit", "o"], b, c = 0; b = a[c] && !n.requestAnimationFrame; ++c) n.requestAnimationFrame = n[b + "RequestAnimationFrame"], n.cancelAnimationFrame = n[b + "CancelAnimationFrame"] || n[b + "CancelRequestAnimationFrame"];
    if (!n.requestAnimationFrame) {
        var d = 0;
        n.requestAnimationFrame = function(e) {
            var f = (new Date).getTime(),
                g = Math.max(0, 16 - (f - d));
            d = f + g;
            return n.setTimeout(function() {
                e(f + g)
            }, g)
        };
        n.cancelAnimationFrame || (n.cancelAnimationFrame = function(e) {
            clearTimeout(e)
        })
    }
})();
var JH = [
        [],
        []
    ],
    KH = 0,
    LH = !1,
    MH = 0,
    OH = function(a, b) {
        var c = MH++,
            d = {
                Cm: {
                    id: c,
                    Dc: a.measure,
                    context: b
                },
                Mm: {
                    id: c,
                    Dc: a.Lm,
                    context: b
                },
                state: {},
                Jb: void 0,
                Sf: !1
            };
        return function() {
            0 < arguments.length ? (d.Jb || (d.Jb = []), d.Jb.length = 0, d.Jb.push.apply(d.Jb, arguments), d.Jb.push(d.state)) : d.Jb && 0 != d.Jb.length ? (d.Jb[0] = d.state, d.Jb.length = 1) : d.Jb = [d.state];
            d.Sf || (d.Sf = !0, JH[KH].push(d));
            LH || (LH = !0, window.requestAnimationFrame(NH))
        }
    },
    NH = function() {
        LH = !1;
        var a = JH[KH],
            b = a.length;
        KH = (KH + 1) % 2;
        for (var c, d = 0; d < b; ++d) {
            c = a[d];
            var e = c.Cm;
            c.Sf = !1;
            e.Dc && e.Dc.apply(e.context, c.Jb)
        }
        for (d = 0; d < b; ++d) c = a[d], e = c.Mm, c.Sf = !1, e.Dc && e.Dc.apply(e.context, c.Jb), c.state = {};
        a.length = 0
    };
var PH = y ? tc(cc(dc('javascript:""'))) : tc(cc(dc("about:blank")));
rc(PH);
var QH = y ? tc(cc(dc('javascript:""'))) : tc(cc(dc("javascript:undefined")));
rc(QH);
var RH = function(a, b) {
    this.v = a;
    this.b = b
};
var SH = function(a, b) {
    X.call(this, b);
    this.W = !!a;
    this.g = null;
    this.R = OH({
        Lm: this.Yf
    }, this)
};
t(SH, X);
h = SH.prototype;
h.Eg = null;
h.If = !1;
h.Ab = null;
h.qb = null;
h.kc = null;
h.og = !1;
h.Le = function() {
    return "goog-modalpopup"
};
h.nf = function() {
    return this.Ab
};
h.Ja = function() {
    SH.D.Ja.call(this);
    var a = this.j();
    v(a);
    Rp(a, yc(this.Le()).split(" "));
    xg(a, !0);
    W(a, !1);
    TH(this);
    UH(this)
};
var TH = function(a) {
        if (a.W && !a.qb) {
            var b = a.a.b("IFRAME", {
                frameborder: 0,
                style: "border:0;vertical-align:bottom;"
            });
            Vd(b, PH);
            a.qb = b;
            a.qb.className = a.Le() + "-bg";
            W(a.qb, !1);
            xq(a.qb, 0)
        }
        a.Ab || (a.Ab = a.a.b("DIV", a.Le() + "-bg"), W(a.Ab, !1))
    },
    UH = function(a) {
        a.kc || (a.kc = Hg(a.a, "SPAN"), W(a.kc, !1), xg(a.kc, !0), a.kc.style.position = "absolute")
    };
h = SH.prototype;
h.bj = function() {
    this.og = !1
};
h.Xc = function(a) {
    return !!a && "DIV" == a.tagName
};
h.Da = function(a) {
    SH.D.Da.call(this, a);
    a = yc(this.Le()).split(" ");
    Rp(v(this.j()), a);
    TH(this);
    UH(this);
    xg(this.j(), !0);
    W(this.j(), !1)
};
h.aa = function() {
    v(!!this.Ab, "Background element must not be null.");
    this.qb && gg(this.qb, this.j());
    gg(this.Ab, this.j());
    SH.D.aa.call(this);
    hg(this.kc, this.j());
    this.Eg = new tE(this.a.a);
    Y(this).listen(this.Eg, "focusin", this.Wm);
    VH(this, !1)
};
h.bb = function() {
    this.isVisible() && this.setVisible(!1);
    Kg(this.Eg);
    SH.D.bb.call(this);
    jg(this.qb);
    jg(this.Ab);
    jg(this.kc)
};
h.setVisible = function(a) {
    v(this.ya, "ModalPopup must be rendered first.");
    if (a != this.If)
        if (this.m && this.m.stop(), this.C && this.C.stop(), this.h && this.h.stop(), this.w && this.w.stop(), this.ya && VH(this, a), a) {
            if (this.dispatchEvent("beforeshow")) {
                try {
                    this.g = this.a.a.activeElement
                } catch (e) {}
                this.Yf();
                var b = Vf(this.a.a) || window;
                if ("fixed" == fq(this.j(), "position")) var c = a = 0;
                else c = Uf(this.a.a), a = c.x, c = c.a;
                var d = vq(this.j());
                b = Sf(b || window);
                a = Math.max(a + b.width / 2 - d.width / 2, 0);
                c = Math.max(c + b.height / 2 - d.height /
                    2, 0);
                hq(this.j(), a, c);
                hq(this.kc, a, c);
                Y(this).listen(Ig(this.a), "resize", this.Yf).listen(Ig(this.a), "orientationchange", this.R);
                WH(this, !0);
                this.ji();
                this.If = !0;
                this.m && this.C ? (hh(this.m, "end", this.Hf, !1, this), this.C.play(), this.m.play()) : this.Hf()
            }
        } else if (this.dispatchEvent("beforehide")) {
        Y(this).Ga(Ig(this.a), "resize", this.Yf).Ga(Ig(this.a), "orientationchange", this.R);
        this.If = !1;
        this.h && this.w ? (hh(this.h, "end", this.Gf, !1, this), this.w.play(), this.h.play()) : this.Gf();
        a: {
            try {
                c = this.a;
                d = c.a.body;
                b =
                    c.a.activeElement || d;
                if (!this.g || this.g == d) {
                    this.g = null;
                    break a
                }(b == d || c.contains(this.j(), b)) && this.g.focus()
            } catch (e) {}
            this.g = null
        }
    }
};
var VH = function(a, b) {
        a.K || (a.K = new RH(Wq(a), a.a));
        a = a.K;
        if (b) {
            a.a || (a.a = []);
            b = a.b.oi(a.b.a.body);
            for (var c = 0; c < b.length; c++) {
                var d = b[c];
                d == a.v || Jp(d, "hidden") || (Ip(d, "hidden", !0), a.a.push(d))
            }
        } else if (a.a) {
            for (c = 0; c < a.a.length; c++) a.a[c].removeAttribute(Hp("hidden"));
            a.a = null
        }
    },
    WH = function(a, b) {
        a.qb && W(a.qb, b);
        a.Ab && W(a.Ab, b);
        W(a.j(), b);
        W(a.kc, b)
    };
h = SH.prototype;
h.Hf = function() {
    this.dispatchEvent("show")
};
h.Gf = function() {
    WH(this, !1);
    this.dispatchEvent("hide")
};
h.isVisible = function() {
    return this.If
};
h.Yf = function() {
    this.qb && W(this.qb, !1);
    this.Ab && W(this.Ab, !1);
    var a = this.a.a,
        b = Sf(Vf(a) || window || window),
        c = Math.max(b.width, Math.max(a.body.scrollWidth, a.documentElement.scrollWidth));
    a = Math.max(b.height, Math.max(a.body.scrollHeight, a.documentElement.scrollHeight));
    this.qb && (W(this.qb, !0), uq(this.qb, c, a));
    this.Ab && (W(this.Ab, !0), uq(this.Ab, c, a))
};
h.Wm = function(a) {
    this.og ? this.bj() : a.target == this.kc && Ci(this.ji, 0, this)
};
h.ji = function() {
    try {
        y && this.a.a.body.focus(), this.j().focus()
    } catch (a) {}
};
h.T = function() {
    Kg(this.m);
    this.m = null;
    Kg(this.h);
    this.h = null;
    Kg(this.C);
    this.C = null;
    Kg(this.w);
    this.w = null;
    SH.D.T.call(this)
};
var aI = function(a, b, c) {
    SH.call(this, b, c);
    this.c = a || "modal-dialog";
    this.b = XH(XH(new YH, ZH, !0), $H, !1, !0)
};
t(aI, SH);
h = aI.prototype;
h.gi = !0;
h.Ui = !0;
h.zg = !0;
h.bf = .5;
h.wh = "";
h.zd = null;
h.Qc = null;
h.Hb = null;
h.yb = null;
h.ag = null;
h.Gb = null;
h.ic = null;
h.kb = null;
h.Le = function() {
    return this.c
};
var bI = function(a, b) {
        a.wh = b;
        a.yb && E(a.yb, b)
    },
    cI = function(a, b) {
        a.zd = b;
        a.ic && Td(a.ic, b)
    };
aI.prototype.Sa = function() {
    return null != this.zd ? Ad(this.zd).toString() : ""
};
aI.prototype.Zb = function() {
    this.j() || this.render();
    return this.ic
};
aI.prototype.nf = function() {
    this.j() || this.render();
    return aI.D.nf.call(this)
};
var dI = function(a, b) {
        a.bf = b;
        a.j() && (b = a.nf()) && xq(b, a.bf)
    },
    eI = function(a, b) {
        var c = yc(a.c + "-title-draggable").split(" ");
        a.j() && (b ? Rp(v(a.Hb), c) : Sp(v(a.Hb), c));
        b && !a.Qc ? (a.Qc = new DH(a.j(), a.Hb), Rp(v(a.Hb), c), G(a.Qc, "start", a.Dn, !1, a)) : !b && a.Qc && (a.Qc.Ia(), a.Qc = null)
    };
h = aI.prototype;
h.Ja = function() {
    aI.D.Ja.call(this);
    var a = this.j();
    v(a, "getElement() returns null");
    var b = this.a;
    this.Hb = b.b("DIV", this.c + "-title", this.yb = b.b("SPAN", {
        className: this.c + "-title-text",
        id: Uq(this)
    }, this.wh), this.Gb = b.b("SPAN", this.c + "-title-close"));
    eg(a, this.Hb, this.ic = b.b("DIV", this.c + "-content"), this.kb = b.b("DIV", this.c + "-buttons"));
    Gp(this.yb, "heading");
    Gp(this.Gb, "button");
    xg(this.Gb, !0);
    Mp(this.Gb, "Close");
    this.ag = this.yb.id;
    Gp(a, "dialog");
    Ip(a, "labelledby", this.ag || "");
    this.zd && Td(this.ic, this.zd);
    W(this.Gb, !0);
    this.b && (a = this.b, a.v = this.kb, a.render());
    W(this.kb, !!this.b);
    dI(this, this.bf)
};
h.Da = function(a) {
    aI.D.Da.call(this, a);
    a = this.j();
    v(a, "The DOM element for dialog cannot be null.");
    var b = this.c + "-content";
    this.ic = Mf(document, null, b, a)[0];
    this.ic || (this.ic = this.a.b("DIV", b), this.zd && Td(this.ic, this.zd), a.appendChild(this.ic));
    b = this.c + "-title";
    var c = this.c + "-title-text",
        d = this.c + "-title-close";
    (this.Hb = Mf(document, null, b, a)[0]) ? (this.yb = Mf(document, null, c, this.Hb)[0], this.Gb = Mf(document, null, d, this.Hb)[0]) : (this.Hb = this.a.b("DIV", b), a.insertBefore(this.Hb, this.ic));
    this.yb ? (this.wh =
        Cg(this.yb), this.yb.id || (this.yb.id = Uq(this))) : (this.yb = D("SPAN", {
        className: c,
        id: Uq(this)
    }), this.Hb.appendChild(this.yb));
    this.ag = this.yb.id;
    Ip(a, "labelledby", this.ag || "");
    this.Gb || (this.Gb = this.a.b("SPAN", d), this.Hb.appendChild(this.Gb));
    W(this.Gb, !0);
    b = this.c + "-buttons";
    if (this.kb = Mf(document, null, b, a)[0]) {
        if (a = this.b = new YH(this.a), (b = this.kb) && 1 == b.nodeType) {
            a.v = b;
            b = Lf("BUTTON", a.v);
            c = 0;
            for (var e, f; d = b[c]; c++)
                if (e = d.name || d.id, f = Cg(d) || d.value, e) {
                    var g = 0 == c;
                    a.set(e, f, g, "cancel" == d.name);
                    g && T(d,
                        "goog-buttonset-default")
                }
        }
    } else this.kb = this.a.b("DIV", b), a.appendChild(this.kb), this.b && (a = this.b, a.v = this.kb, a.render()), W(this.kb, !!this.b);
    dI(this, this.bf)
};
h.aa = function() {
    aI.D.aa.call(this);
    Y(this).listen(this.j(), "keydown", this.N).listen(this.j(), "keypress", this.N);
    Y(this).listen(this.kb, "click", this.V);
    eI(this, this.zg);
    Y(this).listen(this.Gb, "click", this.cn);
    var a = this.j();
    v(a, "The DOM element for dialog cannot be null");
    Gp(a, "dialog");
    "" !== this.yb.id && Ip(a, "labelledby", this.yb.id);
    if (!this.Ui) {
        this.Ui = !1;
        if (this.ya) {
            a = this.a;
            var b = this.nf();
            a.ri(this.qb);
            a.ri(b)
        }
        this.isVisible() && VH(this, !1)
    }
};
h.bb = function() {
    this.isVisible() && this.setVisible(!1);
    eI(this, !1);
    aI.D.bb.call(this)
};
h.setVisible = function(a) {
    a != this.isVisible() && (this.ya || this.render(), aI.D.setVisible.call(this, a))
};
h.Hf = function() {
    aI.D.Hf.call(this);
    this.dispatchEvent("aftershow")
};
h.Gf = function() {
    aI.D.Gf.call(this);
    this.dispatchEvent("afterhide")
};
h.Dn = function() {
    var a = this.a.a,
        b = Sf(Vf(a) || window || window),
        c = Math.max(a.body.scrollWidth, b.width);
    a = Math.max(a.body.scrollHeight, b.height);
    var d = vq(this.j());
    "fixed" == fq(this.j(), "position") ? this.Qc.g = new $p(0, 0, Math.max(0, b.width - d.width), Math.max(0, b.height - d.height)) : this.Qc.g = new $p(0, 0, c - d.width, a - d.height)
};
h.cn = function() {
    fI(this)
};
var fI = function(a) {
    var b = a.b,
        c = b && b.Ff;
    c ? (b = b.get(c), a.dispatchEvent(new gI(c, b)) && a.setVisible(!1)) : a.setVisible(!1)
};
aI.prototype.T = function() {
    this.kb = this.Gb = null;
    aI.D.T.call(this)
};
var hI = function(a, b) {
    a.b = b;
    a.kb && (a.b ? (b = a.b, b.v = a.kb, b.render()) : Td(a.kb, Jd), W(a.kb, !!a.b))
};
aI.prototype.V = function(a) {
    a: {
        for (a = a.target; null != a && a != this.kb;) {
            if ("BUTTON" == a.tagName) break a;
            a = a.parentNode
        }
        a = null
    }
    if (a && !a.disabled) {
        a = a.name;
        var b = this.b.get(a);
        this.dispatchEvent(new gI(a, b)) && this.setVisible(!1)
    }
};
aI.prototype.N = function(a) {
    var b = !1,
        c = !1,
        d = this.b,
        e = a.target;
    if ("keydown" == a.type)
        if (this.gi && 27 == a.keyCode) {
            var f = d && d.Ff;
            e = "SELECT" == e.tagName && !e.disabled;
            f && !e ? (c = !0, b = d.get(f), b = this.dispatchEvent(new gI(f, b))) : e || (b = !0)
        } else {
            if (9 == a.keyCode && a.shiftKey && e == this.j()) {
                this.og = !0;
                try {
                    this.kc.focus()
                } catch (q) {}
                Ci(this.bj, 0, this)
            }
        }
    else if (13 == a.keyCode) {
        if ("BUTTON" == e.tagName && !e.disabled) f = e.name;
        else if (e == this.Gb) fI(this);
        else if (d) {
            var g = d.gf,
                k;
            if (k = g) a: {
                k = Lf("BUTTON", v(d.v));
                for (var l = 0, m; m =
                    k[l]; l++)
                    if (m.name == g || m.id == g) {
                        k = m;
                        break a
                    } k = null
            }
            e = ("TEXTAREA" == e.tagName || "SELECT" == e.tagName || "A" == e.tagName) && !e.disabled;
            !k || k.disabled || e || (f = g)
        }
        f && d && (c = !0, b = this.dispatchEvent(new gI(f, String(d.get(f)))))
    } else e != this.Gb || 32 != a.keyCode && " " != a.key || fI(this);
    if (b || c) a.stopPropagation(), a.preventDefault();
    b && this.setVisible(!1)
};
var gI = function(a, b) {
    this.type = "dialogselect";
    this.key = a;
    this.caption = b
};
t(gI, F);
var YH = function(a) {
    a || Jf();
    tj.call(this)
};
t(YH, tj);
h = YH.prototype;
h.gf = null;
h.v = null;
h.Ff = null;
h.Wc = function() {
    tj.prototype.Wc.call(this);
    this.gf = this.Ff = null
};
h.set = function(a, b, c, d) {
    tj.prototype.set.call(this, a, b);
    c && (this.gf = a);
    d && (this.Ff = a);
    return this
};
var XH = function(a, b, c, d) {
    return a.set(b.key, b.caption, c, d)
};
YH.prototype.render = function() {
    if (this.v) {
        Td(this.v, Jd);
        var a = Jf(this.v);
        this.forEach(function(b, c) {
            b = a.b("BUTTON", {
                name: c
            }, b);
            c == this.gf && (b.className = "goog-buttonset-default");
            this.v.appendChild(b)
        }, this)
    }
};
YH.prototype.j = function() {
    return this.v
};
var ZH = {
        key: "ok",
        caption: "OK"
    },
    $H = {
        key: "cancel",
        caption: "Cancel"
    },
    iI = {
        key: "yes",
        caption: "Yes"
    },
    jI = {
        key: "no",
        caption: "No"
    },
    kI = {
        key: "save",
        caption: "Save"
    },
    lI = {
        key: "continue",
        caption: "Continue"
    };
"undefined" != typeof document && (XH(new YH, ZH, !0, !0), XH(XH(new YH, ZH, !0), $H, !1, !0), XH(XH(new YH, iI, !0), jI, !1, !0), XH(XH(XH(new YH, iI), jI, !0), $H, !1, !0), XH(XH(XH(new YH, lI), kI), $H, !0, !0));
var mI = Gm.M(),
    nI = null,
    oI = function(a, b, c, d, e) {
        var f = {};
        f.id = b;
        f.sl = c;
        f.tl = d;
        f.query = e.substring(0, 64);
        f.len = e.length;
        f.client = "webapp";
        mI.log(a, f)
    },
    pI = function(a, b) {
        var c = "";
        switch (DATA.CampaignTrackerId) {
            case "0":
                c = "https://goo.gl/ELUFVd";
                break;
            case "1a":
                c = "https://goo.gl/cHnrfS";
                break;
            case "1b":
                c = "https://goo.gl/7apRL6";
                break;
            case "1c":
                c = "https://goo.gl/ozXBPg";
                break;
            case "1f":
                c = "https://goo.gl/R0JqsC";
                break;
            case "1g":
                switch (b) {
                    case 0:
                        c = "http://goo.gl/iosgoogleapp/translate2a";
                        break;
                    case 1:
                        c = "http://goo.gl/iosgoogleapp/translate2b";
                        break;
                    case 2:
                        c = "http://goo.gl/iosgoogleapp/translate2c"
                }
                break;
            case "1h":
                switch (b) {
                    case 0:
                        c = "http://goo.gl/iosgoogleapp/translate2d";
                        break;
                    case 1:
                        c = "http://goo.gl/iosgoogleapp/translate2e";
                        break;
                    case 2:
                        c = "http://goo.gl/iosgoogleapp/translate2f";
                        break;
                    case 3:
                        c = "http://goo.gl/iosgoogleapp/translate2g"
                }
                break;
            default:
                c = "https://goo.gl/F17Wul"
        }
        a ? Xd(window.location, c + "?url=google-deeplink://search%3Fq%3D" + be(be(a)) + "&waypoint_id=gt-" + DATA.CampaignTrackerId) : Xd(window.location, c + "?url=google-deeplink://open-url?url=http://www.google.com&waypoint_id=gt-" +
            DATA.CampaignTrackerId);
        O(mI, "webapp", "gsa", "open", {
            id: DATA.CampaignTrackerId
        });
        Ch("gsa", "gsa:open", "", 1)
    },
    qI = function(a) {
        a = "https://www.google.com/search?q=" + be(a) + "&source=gt-" + DATA.CampaignTrackerId;
        Xd(Vf().location, a)
    },
    sI = function(a) {
        var b = $f("DIV");
        b.id = "bg-msk";
        document.body.appendChild(b);
        Ci(function() {
            b.style.opacity = 1
        }, 0);
        nI = G(document.body, "touchmove", function(c) {
            c.preventDefault()
        });
        G(b, "click", function() {
            rI();
            a()
        })
    },
    rI = function() {
        var a = Kf("bg-msk");
        a && (jg(a), null != nI && (ph(nI), nI = null))
    },
    uI = function(a, b, c, d, e) {
        if (DATA.SignedIn) c();
        else {
            c = new aI("gt-md", !0);
            bI(c, DATA.Messages.SAVED_INTERSTITIAL_TITLE);
            cI(c, Dd(DATA.Messages.SAVED_INTERSTITIAL_CONTENT));
            c.zg = !1;
            eI(c, !1);
            var f = new YH;
            f.set("not_now", DATA.Messages.NOT_NOW);
            f.set("sign_in", DATA.Messages.SIGN_IN);
            hI(c, f);
            dI(c, .7);
            c.setVisible(!0);
            c.listen("dialogselect", p(tI, null, a, b, d, e));
            T(Lf("BODY")[0], "gt-md-on")
        }
    },
    tI = function(a, b, c, d, e) {
        "sign_in" == e.key ? dv(d) : (b.log("nosi", a), b = K.M(), M(b, N(b, lm[a])), c(), U(Lf("BODY")[0], "gt-md-on"))
    },
    wI = function(a) {
        return vI(a, DATA.SourceLanguageCodeNameList)
    },
    xI = function(a) {
        return vI(a, DATA.TargetLanguageCodeNameList)
    },
    vI = function(a, b) {
        return (b = Object.values(b).find(function(c) {
            return c.Code === a
        })) ? b.Name : ""
    },
    yI = function(a) {
        return !!a && Eh(a, 18) && 1 === (new cm(a.Wa[18])).Sc() && 0 < H(new cm(a.Wa[18]), 0)
    },
    AI = function(a) {
        if (!yI(a)) return [];
        a = Array.from(Il(new cm(a.Wa[18]), 0, am));
        a.sort(function(b, c) {
            b = zI(b.Rc());
            c = zI(c.Rc());
            return b.localeCompare(c, DATA.DisplayLanguage)
        });
        return a
    },
    zI = function(a) {
        switch (a) {
            case 2:
                return DATA.Messages.GRAMMATICAL_GENDER_FEMININE_WITH_PARENTHESES;
            case 1:
                return DATA.Messages.GRAMMATICAL_GENDER_MASCULINE_WITH_PARENTHESES;
            default:
                throw Error("Unsupported gender " + a);
        }
    };
var BI = function(a) {
    var b = Tn("string" === typeof a.qe, "buttonText", a.qe, "string"),
        c = Tn("string" === typeof a.qg, "classname", a.qg, "string");
    a = Tn("string" === typeof a.identifier, "identifier", a.identifier, "string");
    return Q("<div class='tlid-app-download-button-container " + S(a) + " app-download-button-container " + S(c) + "'><div class='tlid-app-download-button app-download-button header-button' role='button' tabindex='-1'><div class='text'>" + R(b) + "</div></div><div class='app-download-popup'><div class='popup-triangle'></div><div class='popup-container'><div class='text'>\u626b\u63cf\u4e8c\u7ef4\u7801\u4e0b\u8f7d</div><div class='download-image'></div></div></div></div>")
};
var DI = function(a) {
    var b = Tn("string" === typeof a.Ba, "sourceLanguage", a.Ba, "string"),
        c = Tn("string" === typeof a.Rb, "sourcePhrase", a.Rb, "string"),
        d = Tn("string" === typeof a.Ma, "targetLanguage", a.Ma, "string"),
        e = Tn("string" === typeof a.Sb, "targetPhrase", a.Sb, "string"),
        f = Tn("boolean" === typeof a.Mc || 1 === a.Mc || 0 === a.Mc, "showStar", a.Mc, "boolean");
    a = Tn("string" === typeof a.lj, "starLabel", a.lj, "string");
    return Q("<div class='tlid-history-entry history-entry' role=\"option\"><div class='language-pair' role=\"button\" tabindex=\"0\"><div class='language-pair-languages'>" +
        R(b) + " <span class='language-pair-arrow'></span> " + R(d) + "</div></div>" + (f ? "<button class='tlid-star-history-entry star-button button-icon' aria-label='" + S(a) + "' data-tooltip='" + S(a) + "'></button>" : "") + "<div class='tlid-browse-entry browse-entry' role=\"button\" tabindex=\"0\"><div class='starbutton-placeholder'></div>" + CI({
            Rb: c,
            Sb: e
        }) + "</div><div class='tlid-select-entry select-entry' role=\"button\" tabindex=\"0\"><div class='star-placeholder'></div>" + CI({
            Rb: c,
            Sb: e
        }) + "</div></div>")
};
DI.a = "trans.mobile.components.history.entry.template.main";
var CI = function(a) {
    var b = Tn("string" === typeof a.Rb, "sourcePhrase", a.Rb, "string");
    a = Tn("string" === typeof a.Sb, "targetPhrase", a.Sb, "string");
    return Q("<div class='phrase'><div class='tl-input'><bdi>" + R(b) + "</bdi></div><div class='tl-output'><bdi>" + R(a) + "</bdi></div></div>")
};
var EI = function(a, b, c) {
    Jg.call(this);
    this.$b = null != c ? p(a, c) : a;
    this.c = b;
    this.b = p(this.$k, this);
    this.a = []
};
t(EI, Jg);
h = EI.prototype;
h.rf = !1;
h.Qd = null;
h.li = function(a) {
    this.a = arguments;
    this.Qd ? this.rf = !0 : FI(this)
};
h.stop = function() {
    this.Qd && (Di(this.Qd), this.Qd = null, this.rf = !1, this.a = [])
};
h.T = function() {
    EI.D.T.call(this);
    this.stop()
};
h.$k = function() {
    this.Qd = null;
    this.rf && (this.rf = !1, FI(this))
};
var FI = function(a) {
    a.Qd = Ci(a.b, a.c);
    a.$b.apply(null, a.a)
};
var HI = function(a, b) {
    J.call(this);
    this.a = a;
    this.v = b;
    this.b = B("tlid-star-history-entry", this.v);
    this.c = C("tlid-browse-entry", this.v);
    this.g = C("tlid-select-entry", this.v);
    this.h = new EI(this.Rl, 500, this);
    GI(this)
};
ka(HI, J);
var GI = function(a) {
    a.b && G(a.b, "click", function() {
        a.h.li()
    }, !1, a);
    Bh(a.c, a.Jm.bind(a));
    Bh(a.g, a.Km.bind(a))
};
h = HI.prototype;
h.Rl = function() {
    this.dispatchEvent("f")
};
h.Jm = function() {
    this.dispatchEvent("d")
};
h.Km = function() {
    this.dispatchEvent("e")
};
h.j = function() {
    return this.v
};
h.jh = function(a) {
    V(this.v, "starred", a)
};
var JI = function(a, b) {
    J.call(this);
    this.F = K.M();
    this.g = Gm.M();
    this.v = a;
    this.a = [];
    this.o = b;
    this.c = null;
    this.C = II(this, C("tlid-history-delete-all-button", this.v), this.L, !1);
    this.C.g("Clear history");
    II(this, C("tlid-history-close-button", this.v), this.G);
    this.m = C("tlid-history-entry-list", this.v);
    this.w = !1;
    this.h = [];
    this.b = null;
    this.O = new aG(DATA.Messages.NUM_TRANSLATIONS);
    this.K = C("tlid-history-num-entries", this.v)
};
ka(JI, J);
var II = function(a, b, c, d) {
        d = void 0 === d ? !0 : d;
        var e = new Sr(null, new Mt);
        e.ba(b);
        d && (ps(b), ss(b, 2));
        c && G(e, "action", c, !1, a);
        return e
    },
    MI = function(a, b) {
        for (var c = 0; c < b.length; c++) KI(a, b[c]);
        0 < b.length && V(a.v, "empty", !1);
        U(a.v, "loading");
        LI(a, a.a.length)
    },
    KI = function(a, b) {
        b = TF(b);
        for (var c = a.a.length - 1; 0 <= c; c--) {
            var d = a.a[c];
            QF(d.a, b) && (a.a.splice(c, 1), jg(d.j()), qh(d))
        }
        c = Xp(DI, {
            Ba: wI(NF(b)),
            Rb: b.a,
            Ma: xI(b.ma()),
            Sb: b.Za(),
            Mc: !DATA.InChina,
            lj: "Star translation"
        });
        ig(a.m, c, 0);
        b = new HI(b, c);
        a.a.unshift(b);
        NI(a, b);
        a.w ? OI(a, b) : a.h.push(b)
    },
    NI = function(a, b) {
        G(b, "d", function() {
            var c = b.a;
            a.dispatchEvent({
                type: "history_entry_selected",
                text: c.a,
                hb: c.Pa(),
                ib: c.ma()
            });
            a.c && V(a.c.v, "browsed", !1);
            V(b.v, "browsed", !0);
            a.c = b;
            PI(a, b)
        }, !1);
        G(b, "e", function() {
            var c = b.a;
            a.dispatchEvent({
                type: "history_entry_selected",
                text: c.a,
                hb: c.Pa(),
                ib: c.ma()
            });
            a.G();
            PI(a, b)
        }, !1);
        G(b, "f", function() {
            var c = b.a;
            if (DATA.SignedIn) {
                var d = !Qp(b.v, "starred");
                vG(a.o, c, d ? 0 : 1) && (b.jh(d), c = a.F, M(c, Dm(c, 64, a.a.indexOf(b), d)), a.g.log("th=sc", {}))
            } else {
                d =
                    Qp(b.v, "starred") ? "unst" : "st";
                var e = new at;
                bt(e, "history");
                et(e, NF(c), c.ma(), c.a);
                uI(d, a.g, Ea, Ea, e.toString())
            }
        }, !1)
    },
    QI = function(a) {
        a.c && (V(a.c.v, "browsed", !1), a.c = null)
    };
JI.prototype.G = function() {
    this.dispatchEvent("close_requested");
    QI(this)
};
JI.prototype.L = function() {
    if (0 !== this.a.length) {
        fg(this.m);
        for (var a = 0; a < this.a.length; a++) qh(this.a[a]);
        this.a = [];
        this.dispatchEvent("clear_history_clicked");
        V(this.v, "empty", !0);
        LI(this, this.a.length);
        a = this.F;
        M(a, N(a, 63));
        this.g.log("th=ch", {})
    }
};
var RI = function(a, b, c, d) {
        a.b = new MF(d, {}, b, c)
    },
    SI = function(a) {
        a.w = !0;
        for (var b = 0; b < a.h.length; b++) OI(a, a.h[b])
    },
    OI = function(a, b) {
        a.b && NF(a.b) === NF(b.a) && a.b.ma() === b.a.ma() && a.b.a === b.a.a ? (a.b = null, vG(a.o, b.a, 0)) : yG(a.o, b.a, b.jh.bind(b))
    },
    LI = function(a, b) {
        b = dG(a.O, {
            NUM_TRANSLATIONS: b
        });
        E(a.K, b)
    },
    PI = function(a, b) {
        var c = a.F,
            d = Qp(b.v, "starred");
        M(c, Dm(c, 61, a.a.indexOf(b), d));
        a.g.log("th=es", {})
    };
var TI = function(a) {
    a = a.Qa;
    return Q("<div class='tlid-history-container history-container loading empty'><div class='history-top-header'><div class='history-top-bar'><div class='tlid-history-close-button close-button button-icon' aria-label=\"" + (a.CLOSE_HISTORY ? S(a.CLOSE_HISTORY) : S(a.CLOSE)) + "\"></div><div class='title'>" + R(a.HISTORY_SECTION_TITLE) + "</div><div class='history-features'><div class='tlid-history-delete-all-button delete-all-button'></div></div></div><div class='tlid-history-info-bar info-bar'><div class='tlid-history-num-entries num-entries'></div></div></div><div class='history-body'><div class='tlid-history-entry-list entry-list' role=\"listbox\" tabindex=\"0\"></div></div><div class='empty-placeholder'><div class='placeholder-image'></div><div class='placeholder-text-holder'><div class='placeholder-title'>" +
        R(a.HISTORY_INFO_HEADER) + "</div><div class='placeholder-body'>" + R(a.HISTORY_INFO_TEXT) + "</div></div></div><div class='history-loader'><div class='mspin-googblue-medium'><div><div></div></div></div></div></div>")
};
TI.a = "trans.mobile.components.history.template.main";
var UI = function(a) {
    var b = Tn("string" === typeof a.Ba, "sourceLanguage", a.Ba, "string");
    a = Tn("string" === typeof a.Ma, "targetLanguage", a.Ma, "string");
    return Q("<div class='tlid-phrasebook-language-chip language-chip' role=\"button\" tabindex=\"0\"><div class='language-chip-languages'>" + R(b) + " <span class='language-chip-arrow'></span> " + R(a) + "</div><button class='tlid-phrasebook-language-chip-clear-button clear-button button-icon'></button></div>")
};
UI.a = "trans.mobile.components.phrasebook.languagechip.template.main";
var WI = function(a, b, c) {
    b = c || b;
    c = Tn("string" === typeof a.Ba, "sourceLanguage", a.Ba, "string");
    var d = Tn("string" === typeof a.Rb, "sourcePhrase", a.Rb, "string"),
        e = Tn("string" === typeof a.Ma, "targetLanguage", a.Ma, "string"),
        f = Tn("string" === typeof a.Sb, "targetPhrase", a.Sb, "string");
    a = a.Qa;
    return Q("<div class='tlid-phrasebook-entry phrasebook-entry' role=\"option\">" + R(UI({
            Ba: c,
            Ma: e
        }, b)) + "<button class='tlid-delete-phrasebook-entry trashcan-button button-icon' aria-label='" + S(a.DELETE_THIS_PHRASE) + "'></button><div class='tlid-browse-entry browse-entry' role=\"button\" tabindex=\"0\"><div class='trashcan-placeholder'></div><div class='phrase'>" +
        VI({
            Rb: d,
            Sb: f,
            Oe: !0,
            Qa: a
        }) + "</div></div><div class='tlid-select-entry select-entry' role=\"button\" tabindex=\"0\"><div class='trashcan-placeholder'></div>" + VI({
            Rb: d,
            Sb: f
        }) + "</div></div>")
};
WI.a = "trans.mobile.components.phrasebook.entry.template.main";
var VI = function(a) {
    var b = Tn("string" === typeof a.Rb, "sourcePhrase", a.Rb, "string"),
        c = Tn("string" === typeof a.Sb, "targetPhrase", a.Sb, "string"),
        d = Tn(null == a.Oe || "boolean" === typeof a.Oe || 1 === a.Oe || 0 === a.Oe, "includeTts", a.Oe, "boolean|null|undefined");
    a = a.Qa;
    return Q("<div class='phrase'><div class='tl-input'><bdi>" + R(b) + "</bdi>" + (d && En(a) ? "<button class='tlid-phrasebook-entry-source-tts tts-button button-icon' aria-label='" + S(a.LISTEN) + "' data-tooltip='" + S(a.LISTEN) + "'></button>" : "") + "</div><div class='tl-output'><bdi>" +
        R(c) + "</bdi>" + (d && En(a) ? "<button class='tlid-phrasebook-entry-target-tts tts-button button-icon' aria-label='" + S(a.LISTEN) + "' data-tooltip='" + S(a.LISTEN) + "'></button>" : "") + "</div></div>")
};
var YI = function(a, b, c) {
    J.call(this);
    var d = this;
    this.v = a;
    jc(DATA.DisplayLanguage) && T(this.v, "rtl-display-language");
    this.a = b;
    this.b = c;
    this.c = C("tlid-phrasebook-language-chip-clear-button", this.v);
    G(this.c, "click", this.kl, !1, this);
    G(this.v, "click", function() {
        return XI(d)
    }, !1);
    G(this.v, "keypress", this.g, !1, this)
};
ka(YI, J);
h = YI.prototype;
h.j = function() {
    return this.v
};
h.Pa = function() {
    return this.a
};
h.ma = function() {
    return this.b
};
h.dd = function(a) {
    V(this.v, "selected", a)
};
h.kl = function(a) {
    a.stopPropagation();
    this.dispatchEvent("language_pair_deselected")
};
var XI = function(a) {
    a.dispatchEvent("language_pair_selected")
};
YI.prototype.g = function(a) {
    switch (a.keyCode) {
        case 13:
        case 32:
            XI(this)
    }
};
var aJ = function(a, b) {
    J.call(this);
    this.F = K.M();
    this.c = Gm.M();
    this.a = a;
    this.v = b;
    this.g = C("tlid-delete-phrasebook-entry", this.v);
    this.O = new YI(C("tlid-phrasebook-language-chip", this.v), NF(this.a), this.a.ma());
    this.b = C("tlid-browse-entry", this.v);
    this.o = C("tlid-select-entry", this.v);
    this.G = C("tlid-phrasebook-entry-source-tts", this.v);
    this.L = C("tlid-phrasebook-entry-target-tts", this.v);
    this.C = ZI(this, this.G, "&client=webapp&prev=pbsrc", 5);
    this.C.update(this.a.a, NF(this.a), void 0, wI(NF(this.a)));
    this.K =
        ZI(this, this.L, "&client=webapp&prev=pbtgt", 6);
    this.K.update(this.a.b, this.a.ma(), void 0, xI(this.a.ma()));
    $I(this)
};
ka(aJ, J);
var $I = function(a) {
        G(a.v, "focusin", function() {
            T(a.v, "focus-within")
        }, !1);
        G(a.v, "focusout", function(b) {
            pg(a.v, b.relatedTarget) || U(a.v, "focus-within")
        }, !1);
        G(a.g, "click", a.h, !1, a);
        G(a.O, "language_pair_selected", function() {
            a.dispatchEvent("language_pair_selected")
        }, !1);
        G(a.b, "click", a.m, !1, a);
        G(a.b, "keypress", function(b) {
            13 != b.keyCode && 32 != b.keyCode || a.m.bind(a)(b)
        }, !1);
        G(a.o, "click", a.w, !1, a);
        G(a.o, "keypress", function(b) {
            13 != b.keyCode && 32 != b.keyCode || a.w.bind(a)(b)
        }, !1);
        G(a.C, "userInteractionWhileDisabled",
            function() {
                a.dispatchEvent({
                    type: "interaction_with_disabled_voice_output",
                    Nb: wI(NF(a.a))
                })
            }, !1);
        G(a.K, "userInteractionWhileDisabled", function() {
            a.dispatchEvent({
                type: "interaction_with_disabled_voice_output",
                Nb: xI(a.a.ma())
            })
        }, !1)
    },
    ZI = function(a, b, c, d) {
        var e = new Ht(DATA.Messages.LISTEN);
        e.ba(b);
        c = new fv(e, c, d, !1, !0, DATA.Messages.LISTEN, DATA.Messages.VOICE_OUTPUT_UNAVAILABLE);
        ss(b, 2);
        Lg(a, c);
        return c
    };
aJ.prototype.h = function() {
    var a = this.F;
    M(a, N(a, 316));
    this.c.log("api=ed", {});
    this.dispatchEvent("delete_button_clicked");
    oh(this.g, "click", this.h, !1, this)
};
aJ.prototype.m = function(a) {
    a.target != this.G && a.target != this.L && (this.c.log("api=es", {}), a = this.F, M(a, N(a, 315)), this.dispatchEvent("entry_browsed"))
};
aJ.prototype.w = function() {
    this.c.log("api=es", {});
    var a = this.F;
    M(a, N(a, 315));
    this.dispatchEvent("entry_selected")
};
aJ.prototype.j = function() {
    return this.v
};
var bJ = function(a, b) {
    J.call(this);
    this.v = a;
    this.na = b;
    this.a = [];
    this.h = [];
    this.O = {};
    this.N = "0";
    this.m = new Map;
    this.b = null;
    this.w = this.G = this.L = this.X = !1;
    this.C = "";
    this.g = this.c = null;
    this.V = this.R = this.W = this.o = -1;
    this.K = null
};
ka(bJ, J);
var fJ = function(a, b) {
        w(b, function(c) {
            var d = new MF(c.Zf, c.c, c.Ba, c.Ma);
            null != c.a && (d.c = c.a);
            null != c.b && (d.g = c.b);
            a.a.unshift(d);
            cJ(a, NF(d), d.ma())
        }, a);
        dJ(a, 0);
        0 === a.a.length ? a.dispatchEvent("list_empty") : a.dispatchEvent("list_no_longer_empty");
        a.X = !0;
        null != a.K && (eJ(a, a.K), a.K = null)
    },
    gJ = function(a, b) {
        switch (b) {
            case "0":
                a.a.sort(function(c, d) {
                    return d.g - c.g
                });
                a.h.sort(function(c, d) {
                    return d.g - c.g
                });
                break;
            case "2":
                a.a.sort(function(c, d) {
                    return c.a.localeCompare(d.a)
                });
                a.h.sort(function(c, d) {
                    return c.a.localeCompare(d.a)
                });
                break;
            default:
                return
        }
        a.N = b;
        dJ(a, 0)
    },
    hJ = function(a, b) {
        a.G = !0;
        a.C = b;
        a.h = [];
        for (var c = ba(a.a), d = c.next(); !d.done; d = c.next()) d = d.value, RF(d, b) && a.h.push(d);
        dJ(a, 0)
    },
    iJ = function(a, b, c) {
        a.w = !0;
        a.c = b;
        a.g = c;
        a.h = [];
        for (var d = ba(a.a), e = d.next(); !e.done; e = d.next()) e = e.value, b === NF(e) && c === e.m && a.h.push(e);
        dJ(a, 0)
    },
    jJ = function(a) {
        a.G = !1;
        a.C = "";
        dJ(a, 0)
    },
    kJ = function(a) {
        return a.w || a.G ? a.h : a.a
    },
    dJ = function(a, b) {
        if (!(0 > b || b > lJ(a))) {
            var c = 0 === kJ(a).length ? 0 : 10 * b,
                d = mJ(a, b),
                e = kJ(a).length;
            var f = kJ(a),
                g = 0 === kJ(a).length ?
                0 : 10 * b,
                k = mJ(a, b);
            if (0 !== f.length && g > f.length - 1) b = !1;
            else {
                for (fg(a.v); g < k; g++) {
                    var l = nJ(a, f[g]);
                    a.v.appendChild(l.j())
                }
                a.o = b;
                b = !0
            }
            b && (a.W === c && a.R === d && a.V === e || 0 !== e && c > e - 1 || (a.W = c, a.R = d, a.V = e, a.dispatchEvent({
                type: "num_entries_and_indices_updated",
                On: c + 1,
                Ok: d,
                Rm: e
            })), b = d = !1, 0 !== c && (d = !0), e > c + 10 && (b = !0), a.dispatchEvent({
                type: "page_update",
                $l: b,
                bm: d
            }))
        }
    },
    lJ = function(a) {
        var b = 0;
        for (a = kJ(a).length; 0 < a;) b++, a -= 10;
        return b
    },
    mJ = function(a, b) {
        a = kJ(a).length;
        if (0 === a) return 0;
        b = 10 * (b + 1);
        b > a && (b = a);
        return b
    },
    nJ = function(a, b) {
        var c = oJ(b),
            d = a.O[c];
        if (null != d) return d;
        d = Xp(WI, {
            Ba: wI(NF(b)),
            Rb: b.a,
            Ma: xI(b.ma()),
            Sb: b.b,
            Qa: DATA.Messages
        });
        b = new aJ(b, d);
        pJ(a, b);
        d = b;
        return a.O[c] = d
    },
    qJ = function(a, b) {
        var c = !0;
        a.G && !RF(b, a.C) && (c = !1);
        a.w && a.c && a.g && (a.c !== NF(b) || a.g !== b.m) && (c = !1);
        return c
    },
    pJ = function(a, b) {
        G(b, "entry_browsed", function() {
            if (a.b !== b) {
                var c = b.a;
                a.dispatchEvent({
                    type: "entry_browsed",
                    text: c.a,
                    hb: c.Pa(),
                    ib: c.ma()
                });
                rJ(a);
                V(b.v, "browsed", !0);
                a.b = b
            }
        }, !1);
        G(b, "delete_button_clicked", function() {
            vG(a.na,
                b.a, 1);
            a.dispatchEvent("delete_entry_requested")
        }, !1);
        G(b, "entry_selected", function() {
            var c = b.a;
            a.dispatchEvent({
                type: "entry_selected",
                text: c.a,
                hb: c.Pa(),
                ib: c.ma()
            })
        }, !1);
        G(b, "language_pair_selected", function() {
            a.dispatchEvent({
                type: "language_pair_selected",
                hb: NF(b.a),
                ib: b.a.ma()
            })
        }, !1);
        G(b, "interaction_with_disabled_voice_output", function(c) {
            a.dispatchEvent({
                type: "interaction_with_disabled_voice_output",
                Nb: c.Nb
            })
        }, !1)
    },
    rJ = function(a) {
        a.b && (V(a.b.v, "browsed", !1), a.b = null)
    },
    eJ = function(a, b) {
        if (!a.X) a.K =
            b;
        else if (null == a.b || !QF(a.b.a, b))
            for (var c = a.b, d = a.a, e = 0; e < d.length; e++) {
                var f = d[e];
                if (QF(f, b)) {
                    b = nJ(a, f);
                    rJ(a);
                    V(b.v, "browsed", !0);
                    a.b = b;
                    null != c && Gg(document) === c.b && b.b.focus();
                    break
                }
            }
    },
    sJ = function(a) {
        a.match(/[",\t\n]/) && (a = '"' + a.replace(/"/g, '""') + '"');
        return a
    },
    cJ = function(a, b, c) {
        var d = b + "|" + c;
        a.m.has(d) ? (b = a.m.get(d), a.m.set(d, b + 1)) : (a.m.set(d, 1), a.dispatchEvent({
            type: "language_pair_added",
            hb: b,
            ib: c
        }))
    };

function oJ(a) {
    return NF(a) + "|" + a.ma() + "|" + a.a + "|" + a.b
};
var tJ = function(a) {
    X.call(this, a)
};
t(tJ, X);
tJ.prototype.Ja = function() {
    this.v = this.a.b("FORM", {
        method: "POST",
        style: "display:none"
    })
};
var uJ = function(a, b, c) {
    var d, e = [];
    for (d in c) {
        var f = c[d];
        Ja(f) ? w(f, p(function(g) {
            e.push(Id("input", {
                type: "hidden",
                name: d,
                value: String(g)
            }))
        }, a)) : e.push(Id("input", {
            type: "hidden",
            name: d,
            value: String(f)
        }))
    }
    Td(b, Ld(e))
};
var vJ = function(a, b, c) {
    Jg.call(this);
    this.$b = null != c ? p(a, c) : a;
    this.h = b;
    this.g = p(this.m, this);
    this.b = this.a = null;
    this.c = []
};
t(vJ, Jg);
vJ.prototype.o = function(a) {
    this.c = arguments;
    this.a ? this.b = Ta() + this.h : this.a = Ci(this.g, this.h)
};
vJ.prototype.stop = function() {
    this.a && (Di(this.a), this.a = null);
    this.b = null;
    this.c = []
};
vJ.prototype.T = function() {
    this.stop();
    vJ.D.T.call(this)
};
vJ.prototype.m = function() {
    this.b ? (this.a = Ci(this.g, this.b - Ta()), this.b = null) : (this.a = null, this.$b.apply(null, this.c))
};
var wJ = function(a, b) {
        X.call(this, b);
        this.b = a || ""
    },
    xJ;
t(wJ, X);
wJ.prototype.g = null;
var yJ = function() {
    null == xJ && (xJ = "placeholder" in $f("INPUT"));
    return xJ
};
h = wJ.prototype;
h.Ne = !1;
h.Ja = function() {
    this.v = this.a.b("INPUT", {
        type: "text"
    })
};
h.Da = function(a) {
    wJ.D.Da.call(this, a);
    this.b || (this.b = a.getAttribute("label") || "");
    Gg(If(a)) == a && (this.Ne = !0, a = this.j(), v(a), U(a, "label-input-label"));
    yJ() && (this.j().placeholder = this.b);
    a = this.j();
    v(a, "The label input element cannot be null.");
    Ip(a, "label", this.b)
};
h.aa = function() {
    wJ.D.aa.call(this);
    var a = new Lq(this);
    a.listen(this.j(), "focus", this.Di);
    a.listen(this.j(), "blur", this.il);
    if (yJ()) this.c = a;
    else {
        ye && a.listen(this.j(), ["keypress", "keydown", "keyup"], this.Bl);
        var b = If(this.j());
        a.listen(Vf(b), "load", this.Zl);
        this.c = a;
        zJ(this)
    }
    AJ(this);
    this.j().b = this
};
h.bb = function() {
    wJ.D.bb.call(this);
    this.c && (this.c.Ia(), this.c = null);
    this.j().b = null
};
var zJ = function(a) {
    !a.m && a.c && a.j().form && (a.c.listen(a.j().form, "submit", a.El), a.m = !0)
};
h = wJ.prototype;
h.T = function() {
    wJ.D.T.call(this);
    this.c && (this.c.Ia(), this.c = null)
};
h.Di = function() {
    this.Ne = !0;
    var a = this.j();
    v(a);
    U(a, "label-input-label");
    if (!yJ() && !BJ(this) && !this.w) {
        var b = this;
        a = function() {
            b.j() && (b.j().value = "")
        };
        y ? Ci(a, 10) : a()
    }
};
h.il = function() {
    yJ() || (this.c.Ga(this.j(), "click", this.Di), this.g = null);
    this.Ne = !1;
    AJ(this)
};
h.Bl = function(a) {
    27 == a.keyCode && ("keydown" == a.type ? this.g = this.j().value : "keypress" == a.type ? this.j().value = this.g : "keyup" == a.type && (this.g = null), a.preventDefault())
};
h.El = function() {
    BJ(this) || (this.j().value = "", Ci(this.cl, 10, this))
};
h.cl = function() {
    BJ(this) || (this.j().value = this.b)
};
h.Zl = function() {
    AJ(this)
};
var BJ = function(a) {
        return !!a.j() && "" != a.j().value && a.j().value != a.b
    },
    CJ = function(a) {
        a.j().value = "";
        null != a.g && (a.g = "")
    };
wJ.prototype.reset = function() {
    BJ(this) && (CJ(this), AJ(this))
};
wJ.prototype.Y = function() {
    return null != this.g ? this.g : BJ(this) ? this.j().value : ""
};
var AJ = function(a) {
    var b = a.j();
    v(b, "The label input element cannot be null.");
    yJ() ? a.j().placeholder != a.b && (a.j().placeholder = a.b) : zJ(a);
    Ip(b, "label", a.b);
    BJ(a) ? (b = a.j(), v(b), U(b, "label-input-label")) : (a.w || a.Ne || (b = a.j(), v(b), T(b, "label-input-label")), yJ() || Ci(a.h, 10, a))
};
wJ.prototype.oa = function(a) {
    this.j().disabled = !a;
    var b = this.j();
    v(b);
    V(b, "label-input-label-disabled", !a)
};
wJ.prototype.isEnabled = function() {
    return !this.j().disabled
};
wJ.prototype.h = function() {
    !this.j() || BJ(this) || this.Ne || (this.j().value = this.b)
};
var DJ = function() {};
t(DJ, Cx);
Fa(DJ);
DJ.prototype.wa = function() {
    return "goog-toolbar-menu-button"
};
var NJ = function(a, b) {
    J.call(this);
    var c = this;
    this.F = K.M();
    this.h = Gm.M();
    this.v = a;
    V(this.v, "mobile", jt());
    this.a = new bJ(C("tlid-phrasebook-entry-list", this.v), b);
    EJ(this);
    this.xa = C("tlid-phrasebook-header-num-phrases", this.v);
    this.ra = C("tlid-phrasebook-body-num-phrases", this.v);
    this.Ca = new aG(DATA.Messages.NUM_PHRASES_PAGINATED);
    this.L = FJ(this);
    G(this.L, "change", this.N, !1, this);
    GJ(this, C("tlid-phrasebook-export-to-sheets", this.v), this.o);
    this.ia = HJ(this);
    this.R = IJ(this);
    this.K = GJ(this, C("tlid-phrasebook-search-button",
        this.v), this.na);
    JJ(this, !1);
    this.C = new vJ(this.X, 500, this);
    this.b = new wJ(DATA.Messages.SEARCH_PHRASES);
    this.b.ba(C("tlid-phrasebook-search-box", this.v));
    G(this.b.j(), "keydown", function(d) {
        switch (d.keyCode) {
            case 27:
                c.C.stop();
                CJ(c.b);
                KJ(c);
                jJ(c.a);
                break;
            case 9:
                break;
            default:
                c.C.o()
        }
    }, !1, this);
    GJ(this, C("tlid-phrasebook-search-clear-button", this.v), this.V);
    GJ(this, C("tlid-phrasebook-close-button", this.v), this.Na);
    this.w = B("tlid-phrasebook-header-next-page", this.v) || null;
    null != this.w && G(this.w, "click",
        function() {
            var d = c.F;
            M(d, N(d, 336));
            LJ(c, "np");
            d = c.a;
            var e = d.o + 1;
            e > lJ(d) || dJ(d, e)
        }, !1);
    this.G = B("tlid-phrasebook-header-prev-page", this.v) || null;
    null != this.G && G(this.G, "click", function() {
        var d = c.F;
        M(d, N(d, 337));
        LJ(c, "pp");
        d = c.a;
        var e = d.o - 1;
        0 > e || dJ(d, e)
    }, !1);
    this.Z = C("tlid-phrasebook-header-language-pair-container", this.v);
    this.g = [];
    this.O = C("tlid-phrasebook-body-language-pair-container", this.v);
    this.c = [];
    this.m = !1;
    a = b.c && !b.C || !b.m ? null : b.g.concat(b.a);
    null !== a && MJ(this, a)
};
ka(NJ, J);
var FJ = function(a) {
        var b = C("tlid-phrasebook-sort", a.v),
            c = [DATA.Messages.SORT_BY_DATE, DATA.Messages.SORT_ALPHABETICALLY];
        ps(b);
        ss(b, 2);
        xc(ke("sort-button-tooltip")) || b.setAttribute("data-tooltip-class", "sort-button-tooltip");
        b = new my(b, c, 10, ["0", "2"], void 0, DATA.Messages.SORT, DJ.M(), void 0, !0);
        Rx(b, new yx(b.Zb(), 13));
        Sx(b, new Zp(-16, -24, 0, 0));
        c = Qx(b);
        c.render(C("tlid-phrasebook-sort-menu", a.v));
        G(c, "show", function() {
            var d = a.F;
            M(d, N(d, 319));
            LJ(a, "so")
        }, !1);
        return b
    },
    GJ = function(a, b, c) {
        var d = void 0 ===
            d ? !0 : d;
        var e = new Sr(null, new Mt);
        e.ba(b);
        d && (ps(b), ss(b, 2));
        c && G(e, "action", c, !1, a);
        return e
    },
    HJ = function(a) {
        var b = C("tlid-phrasebook-more-button", a.v),
            c = new Nx;
        c.ba(b);
        ps(b);
        ss(b, 2);
        c.Je(OJ(a, DATA.Messages.DELETE_ALL, a.W, "delete-all-menuitem"));
        c.Je(OJ(a, DATA.Messages.EXPORT_TO_SHEETS, a.o, "export-menuitem"));
        Rx(c, new yx(b, 13));
        c.ra = new Zp(-20, 0, 0, 0);
        Qx(c).render(C("tlid-phrasebook-more-menu", a.v));
        return c
    },
    OJ = function(a, b, c, d) {
        b = new qx(b);
        Gr(b, d);
        G(b, "action", c, !1, a);
        return b
    },
    IJ = function(a) {
        var b =
            new aI("phrasebook-delete-all-dialog", !0);
        bI(b, DATA.Messages.DELETE_ALL_DIALOG_TITLE);
        cI(b, Dd(DATA.Messages.DELETE_ALL_DIALOG_CONTENT));
        b.zg = !1;
        eI(b, !1);
        b.gi = !0;
        var c = new YH;
        c.set("cancel", DATA.Messages.CANCEL, !1, !0);
        c.set("delete", DATA.Messages.DELETE);
        hI(b, c);
        G(b, "dialogselect", function(d) {
            if ("delete" !== d.key) d = a.F, M(d, N(d, 326)), LJ(a, "dn");
            else {
                d = a.a;
                if (0 === d.a.length) d = !1;
                else {
                    d.L = !0;
                    for (var e = 0; e < d.a.length; e++) vG(d.na, d.a[e], 1);
                    d = !0
                }
                d && T(a.v, "loading");
                d = a.F;
                M(d, N(d, 325));
                LJ(a, "dy")
            }
        }, !1);
        return b
    },
    EJ = function(a) {
        G(a.a, "delete_all_complete", function() {
            U(a.v, "loading")
        }, !1);
        G(a.a, "entry_browsed", function(b) {
            a.dispatchEvent({
                type: "phrasebook_entry_selected",
                text: b.text,
                hb: b.hb,
                ib: b.ib
            })
        }, !1);
        G(a.a, "delete_entry_requested", function() {
            a.dispatchEvent("delete_entry_requested")
        }, !1);
        G(a.a, "entry_selected", function(b) {
            a.dispatchEvent({
                type: "phrasebook_entry_selected",
                text: b.text,
                hb: b.hb,
                ib: b.ib
            });
            a.dispatchEvent("close_requested")
        }, !1);
        G(a.a, "page_update", function(b) {
            var c = b.bm;
            V(a.v, "has-next-page",
                b.$l);
            V(a.v, "has-prev-page", c)
        }, !1);
        G(a.a, "language_pair_added", function(b) {
            if (null == b) a.h.log("jse=lpa", {});
            else {
                var c = b.hb;
                b = b.ib;
                PJ(a, c, b, a.Z, a.g);
                PJ(a, c, b, a.O, a.c)
            }
        }, !1);
        G(a.a, "language_pair_removed", function(b) {
            if (null == b) a.h.log("jse=lpr", {});
            else {
                var c = b.hb;
                b = b.ib;
                QJ(c, b, a.g);
                QJ(c, b, a.c)
            }
        }, !1);
        G(a.a, "language_pair_selected", function(b) {
            null == b ? a.h.log("jse=lps", {}) : (RJ(a, b.hb, b.ib), b = a.F, M(b, N(b, 322)), LJ(a, "fs"))
        }, !1);
        G(a.a, "list_empty", function() {
            V(a.v, "empty", !0)
        }, !1);
        G(a.a, "list_no_longer_empty",
            function() {
                V(a.v, "empty", !1)
            }, !1);
        G(a.a, "num_entries_and_indices_updated", function(b) {
            var c = DATA.DisplayLanguage;
            b = dG(a.Ca, {
                NUM_PHRASES: b.Rm,
                START_NUM: b.On.toLocaleString(c),
                END_NUM: b.Ok.toLocaleString(c)
            });
            E(a.xa, b);
            E(a.ra, b)
        }, !1);
        G(a.a, "last_displayed_entry_deleted", function() {
            SJ(a)
        }, !1);
        G(a.a, "interaction_with_disabled_voice_output", function(b) {
            a.dispatchEvent({
                type: "interaction_with_disabled_voice_output",
                Nb: b.Nb
            })
        }, !1)
    },
    MJ = function(a, b) {
        a.m || (fJ(a.a, b), a.m = !0, U(a.v, "loading"))
    },
    SJ = function(a) {
        TJ(a);
        CJ(a.b);
        KJ(a);
        jJ(a.a)
    };
NJ.prototype.N = function() {
    var a = this.L.Y();
    switch (a) {
        case "0":
            var b = this.F;
            M(b, N(b, 320));
            LJ(this, "s1");
            break;
        case "2":
            b = this.F;
            M(b, N(b, 321));
            LJ(this, "s2");
            break;
        default:
            return
    }
    gJ(this.a, a)
};
var JJ = function(a, b) {
    V(a.v, "search-open", b)
};
NJ.prototype.na = function() {
    var a = this.F;
    M(a, N(a, 318));
    LJ(this, "os");
    UJ(this)
};
var UJ = function(a) {
        JJ(a, !0);
        CJ(a.b);
        a.b.j().focus();
        TJ(a);
        jJ(a.a);
        T(a.v, "empty-search-query")
    },
    KJ = function(a) {
        JJ(a, !1);
        U(a.v, "empty-search-query")
    };
NJ.prototype.X = function() {
    this.b.Y() ? (U(this.v, "empty-search-query"), hJ(this.a, this.b.Y())) : UJ(this)
};
NJ.prototype.V = function() {
    this.b.Y() ? UJ(this) : (KJ(this), jJ(this.a))
};
NJ.prototype.Na = function() {
    var a = this.F;
    M(a, N(a, 317));
    LJ(this, "cb");
    this.dispatchEvent("close_requested");
    SJ(this)
};
NJ.prototype.o = function() {
    var a = {
            authuser: Jj() || "0",
            target: "_blank"
        },
        b = this.a;
    var c = [];
    for (var d = b.a, e = d.length - 1; 0 <= e; --e) {
        var f = [],
            g = d[e];
        qJ(b, g) && (f.push(wI(NF(g))), f.push(xI(g.ma())), f.push(sJ(g.a)), f.push(sJ(g.b)), c.push(f.join(",")))
    }
    c = c.join("\n");
    b = this.a;
    d = DATA.Messages.SAVED_TRANSLATIONS_SPREADSHEET_TITLE;
    b.w && null != b.c && null != b.g && (d = d + " - " + wI(b.c) + " - " + xI(b.g));
    a = a || {};
    b = a.target;
    e = a.trixPath || (a.useCorp ? "https://docs.google.com/a/google.com/spreadsheets/" : void 0);
    delete a.target;
    delete a.useCorp;
    delete a.trixPath;
    Wb(a, {
        content: c,
        title: d
    });
    c = a.authuser;
    d = Lj(void 0 === e ? "https://docs.google.com/spreadsheets/" : e, "import");
    d = Lj(d, "inline");
    c && (d = Gj(d, "authuser", c));
    c = d;
    d = new tJ;
    e = d.j();
    e || (d.render(), e = d.j());
    e.action = c || "";
    e.target = b || "";
    uJ(d, e, a);
    e.submit()
};
var PJ = function(a, b, c, d, e) {
        var f = VJ(b, c);
        b = new YI(f, b, c);
        dg(d, f);
        e.push(b);
        G(b, "language_pair_selected", function(g) {
            g = g.target;
            RJ(a, g.Pa(), g.ma());
            g = a.F;
            M(g, N(g, 322));
            LJ(a, "fs")
        }, !1);
        G(b, "language_pair_deselected", function() {
            TJ(a);
            var g = a.F;
            M(g, N(g, 323));
            LJ(a, "fr")
        }, !1)
    },
    QJ = function(a, b, c) {
        for (var d = c.length - 1; 0 <= d; d--) {
            var e = c[d];
            a === e.a && b === e.b && (jg(e.j()), c.splice(d, 1), qh(e))
        }
    },
    RJ = function(a, b, c) {
        T(a.v, "language-pair-selected");
        for (var d = 0; d < a.g.length; d++) {
            var e = a.g[d];
            e.dd(b === e.a && c === e.b)
        }
        for (d =
            0; d < a.c.length; d++) e = a.c[d], e.dd(b === e.a && c === e.b);
        iJ(a.a, b, c);
        KJ(a)
    },
    TJ = function(a) {
        U(a.v, "language-pair-selected");
        for (var b = 0; b < a.g.length; b++) a.g[b].dd(!1);
        for (b = 0; b < a.c.length; b++) a.c[b].dd(!1);
        a = a.a;
        a.w = !1;
        a.c = null;
        a.g = null;
        dJ(a, 0)
    };
NJ.prototype.W = function() {
    this.R.setVisible(!0);
    this.ia.Xa(!1);
    var a = this.F;
    M(a, N(a, 324));
    LJ(this, "da")
};
var LJ = function(a, b) {
    a.h.log("api=" + b, {})
};

function VJ(a, b) {
    return Xp(UI, {
        Ba: wI(a),
        Ma: xI(b)
    })
};
var WJ = function(a) {
    var b = Tn("string" === typeof a.Ra, "displayLanguage", a.Ra, "string");
    a = a.Qa;
    var c = Q,
        d = "<div class='tlid-phrasebook-container phrasebook-container loading'><div class='phrasebook-top-header'><div class='phrasebook-top-bar'><div class='tlid-phrasebook-close-button close-button button-icon' aria-label=\"" + S(a.CLOSE_SAVED_TRANSLATIONS) + "\"></div><div class='title'>" + R(a.SAVED_SECTION_TITLE) + "</div><div class='tlid-phrasebook-search-button search-button search-image-black button-icon' title=\"" +
        S(a.SEARCH_PHRASES) + "\"></div><div class='tlid-phrasebook-search-bar search-bar'><div class='search-image-black button-icon'></div><input class='tlid-phrasebook-search-box search-box'><div class='tlid-phrasebook-search-clear-button clear-button clear-image-black button-icon' title=\"" + S(a.CLEAR_TEXT) + "\"></div></div><div class='phrasebook-features'><div class='tlid-phrasebook-sort-menu sort-menu'></div><div class='tlid-phrasebook-more-menu more-menu'></div><div class='tlid-phrasebook-sort sort-button button-icon' aria-label='" +
        S(a.SORT) + "' title='" + S(a.SORT) + "'></div><div class='export-button-container'><div class='tlid-phrasebook-export-to-sheets export-button button-icon' title='" + S(a.EXPORT_TO_SHEETS) + "'></div></div><div class='tlid-phrasebook-more-button more-button button-icon' aria-label='" + S(a.MORE) + "' title='" + S(a.MORE) + "'></div></div></div><div class='nav-bar'><div class='tlid-phrasebook-header-num-phrases num-phrases'></div><div class='nav-button-container'><button class='tlid-phrasebook-header-prev-page prev-button page-nav-button'></button><button class='tlid-phrasebook-header-next-page next-button page-nav-button'></button></div></div><div class='selected-chip-bar'><div class='tlid-phrasebook-header-language-pair-container language-pair-container'></div></div></div><div class='phrasebook-body'><div class='tlid-phrasebook-body-language-pair-container language-pair-container'><div class='title'>" +
        R(a.LANGUAGE_PAIRS) + "</div></div><div class='tlid-phrasebook-body-num-phrases num-phrases'></div>";
    var e = Q('<div class=\'tlid-phrasebook-entry-list entry-list\' role="listbox" tabindex="0"></div>');
    return c(d + R(e) + "</div><div class='empty-placeholder'><div class='placeholder-image'></div><div class='placeholder-text-holder'><div class='placeholder-title'>" + R(a.PHRASEBOOK_INFO_HEADER) + "</div><div class='placeholder-body'>" + R(a.PHRASEBOOK_INFO_TEXT) + "</div></div><div class='placeholder-link'><a target='_blank' href='https://support.google.com/translate?p=phrasebook_web_help&hl=" +
        Mn(b) + "'>" + R(a.LEARN_MORE) + "</a></div></div><div class='phrasebook-loader'><div class='mspin-googblue-medium'><div><div></div></div></div></div></div>")
};
WJ.a = "trans.mobile.components.phrasebook.template.main";
var XJ = function() {
        var a = Kf("backend-stats-decoder");
        this.b = null != a ? a : null;
        a = Kf("backend-stats-decoder1");
        this.o = null != a ? a : null;
        a = Kf("backend-stats-decoder2");
        this.g = null != a ? a : null;
        a = Kf("backend-stats-rapid-response");
        this.m = null != a ? a : null;
        a = Kf("backend-stats-stt-total");
        this.w = null != a ? a : null;
        a = Kf("backend-stats-community");
        this.a = null != a ? a : null;
        a = Kf("backend-stats-dictionary");
        this.c = null != a ? a : null;
        a = Kf("backend-stats-other");
        this.h = null != a ? a : null;
        a = Kf("backend-models-used");
        this.L = null != a ? a : null;
        a = Kf("backend-models-checksum");
        this.G = null != a ? a : null;
        a = Kf("backend-models-launch-doc");
        this.C = null != a ? a : null
    },
    YJ = function(a) {
        a.w && a.a && a.c && a.b && a.o && a.g && a.m && a.h && a.L && a.G && a.C && (E(a.b, "0"), E(a.o, "0"), E(a.g, "0"), E(a.m, "0"), E(a.w, "0"), E(a.a, "0"), E(a.c, "0"), E(a.h, "0"), E(a.L, ""), E(a.G, ""), E(a.C, ""))
    },
    ZJ = function(a, b, c) {
        var d = $f("A"),
            e = ag(" ");
        d.appendChild(ag(c));
        Ud(d, b);
        a.appendChild(d);
        a.appendChild(e)
    };
var $J = function(a, b) {
    J.call(this);
    this.F = K.M();
    this.a = a;
    this.g = b;
    this.b = C("tlid-file-input", this.a);
    this.o = C("tlid-select-file-button", this.a);
    this.R = C("tlid-sl-input", this.a);
    this.V = C("tlid-tl-input", this.a);
    this.m = C("tlid-selected-file-label", this.a);
    this.w = C("tlid-selected-file-size", this.a);
    this.L = C("tlid-cancel-selected-file-button", this.a);
    this.h = C("tlid-translate-doc-button", this.a);
    this.c = this.h.form;
    this.K = new Xu;
    G(this.o, "click", this.G, !1, this);
    G(this.h, "click", this.N, !1, this);
    G(this.b,
        "change", this.C, !1, this);
    G(this.L, "click", this.O, !1, this);
    U(this.a, "loading")
};
ka($J, J);
$J.prototype.N = function() {
    U(this.a, "has-file");
    T(this.a, "translating-file");
    var a = aK(this),
        b = bK(this.b.value),
        c = this.F,
        d = cK(b),
        e = N(c, 301),
        f = new Kk;
    d = A(f, 1, d);
    d = A(d, 2, a);
    lf(e, 76, d);
    M(c, e);
    dK("success", a, b);
    this.c.enctype = this.c.encoding = "multipart/form-data";
    this.R.value = this.g.a;
    this.V.value = this.g.b;
    this.c.submit()
};
$J.prototype.G = function() {
    var a = this.F;
    M(a, N(a, 297));
    eK("bc")
};
$J.prototype.C = function() {
    var a = this.b.value;
    if ("" !== a) {
        var b = a.replace("C:\\fakepath\\", "");
        a = bK(b);
        if (0 === a.length) var c = !1;
        else switch (a.toLowerCase()) {
            case "doc":
            case "docx":
            case "odf":
            case "pdf":
            case "ppt":
            case "pptx":
            case "ps":
            case "rtf":
            case "txt":
            case "xls":
            case "xlsx":
                c = !0;
                break;
            default:
                c = !1
        }
        if (c) {
            if (void 0 !== window.FileReader) {
                c = aK(this);
                if (c > DATA.FileSizeLimit) {
                    this.dispatchEvent({
                        type: "file_too_big",
                        Rk: DATA.FileSizeLimit
                    });
                    this.b.value = "";
                    b = this.F;
                    var d = cK(a),
                        e = N(b, 148);
                    var f = new Mk;
                    f =
                        A(f, 1, 161);
                    lf(e, 63, f);
                    f = new Kk;
                    d = A(f, 1, d);
                    d = A(d, 2, c);
                    lf(e, 76, d);
                    M(b, e);
                    dK("ftbe", c, a);
                    return
                }
                a = this.w;
                c = aK(this);
                e = DATA.Messages.FILE_SIZE_BYTES;
                1 <= c / 1024 && (c /= 1024, e = DATA.Messages.FILE_SIZE_KILOBYTES);
                1 <= c / 1024 && (c /= 1024, e = DATA.Messages.FILE_SIZE_MEGABYTES);
                c = this.K.a(e, c.toFixed(0));
                E(a, c)
            }
            E(this.m, b);
            T(this.a, "has-file");
            U(this.a, "translating-file");
            a = this.F;
            M(a, N(a, 308));
            eK("fs")
        } else this.dispatchEvent("unsupported_filetype"), this.b.value = "", mm(this.F, 160), dK("ufte", 0, a)
    }
};
$J.prototype.O = function() {
    var a = this.F;
    M(a, N(a, 298));
    eK("c");
    this.b.value = "";
    U(this.a, "has-file");
    U(this.a, "translating-file")
};
var bK = function(a) {
        a = a.split(".");
        return 1 === a.length ? "" : a[a.length - 1].toLowerCase()
    },
    cK = function(a) {
        switch (a.toLowerCase()) {
            case "doc":
                return 1;
            case "docx":
                return 2;
            case "odf":
                return 3;
            case "pdf":
                return 4;
            case "ppt":
                return 5;
            case "pptx":
                return 6;
            case "ps":
                return 7;
            case "rtf":
                return 8;
            case "txt":
                return 9;
            case "xls":
                return 10;
            case "xlsx":
                return 11;
            default:
                return 0
        }
    },
    aK = function(a) {
        return 0 === a.b.files.length ? 0 : a.b.files[0].size
    },
    dK = function(a, b, c) {
        O(mI, "webapp", "dt", a, {
            dtfs: b,
            dtft: c
        })
    },
    eK = function(a) {
        O(mI,
            "webapp", "dti", a, {})
    };
var fK = function(a, b) {
    J.call(this);
    this.F = K.M();
    this.v = a;
    this.o = b;
    this.a = null;
    this.g = !1;
    this.b = null;
    this.c = []
};
ka(fK, J);
var gK = function(a, b, c, d) {
    a.a ? RI(a.a, b, c, d) : a.b = new MF(d, {}, b, c)
};
fK.prototype.m = function() {
    this.dispatchEvent("close_requested")
};
fK.prototype.h = function() {
    this.dispatchEvent("history_cleared")
};
var hK = function(a) {
    if (null == a.a) {
        var b = Xp(TI, {
            Qa: DATA.Messages
        });
        C("tlid-translation-history-container", a.v).appendChild(b);
        a.a = new JI(b, a.o);
        G(a.a, "close_requested", a.m, !1, a);
        G(a.a, "clear_history_clicked", a.h, !1, a);
        G(a.a, "history_entry_selected", function(c) {
            a.dispatchEvent({
                type: "history_entry_selected",
                hb: c.hb,
                ib: c.ib,
                text: c.text
            })
        }, !1);
        MI(a.a, a.c);
        a.c = [];
        null != a.b && RI(a.a, a.b.Pa(), a.b.ma(), a.b.a);
        a.g && SI(a.a)
    }
};
var jK = function(a, b) {
        this.F = K.M();
        this.c = a;
        this.a = C("tlid-transliteration-content", this.c);
        this.h = C("tlid-show-more-link", this.c);
        this.g = C("tlid-show-less-link", this.c);
        this.b = b;
        this.o = !1;
        iK(this)
    },
    lK = function(a, b) {
        if (void 0 === b) b = "";
        else {
            var c = [];
            if (b.sentences)
                for (var d = 0, e; e = b.sentences[d]; d++) 1 === a.b ? e["src-translit"] && c.push(e["src-translit"]) : 2 === a.b && e.translit && c.push(e.translit);
            b = c.join("")
        }
        kK(a, b)
    },
    kK = function(a, b) {
        mK(a);
        E(a.a, b);
        V(a.c, "rtl", mc(b));
        Ci(function() {
            return nK(a)
        }, 0)
    },
    nK = function(a) {
        mK(a);
        var b = a.a.offsetHeight,
            c = parseInt(eq(a.a, "lineHeight"), 10);
        3 < Math.ceil(b / c) ? a.o ? oK(a) : pK(a) : (V(a.a, "full", !0), V(a.a, "truncated", !1), W(a.h, !1), W(a.g, !1));
        V(a.a, "intermediate", !1)
    },
    oK = function(a) {
        V(a.a, "full", !0);
        V(a.a, "truncated", !1);
        W(a.h, !1);
        W(a.g, !0)
    },
    pK = function(a) {
        V(a.a, "full", !1);
        V(a.a, "truncated", !0);
        W(a.h, !0);
        W(a.g, !1)
    },
    mK = function(a) {
        Sp(a.a, ["truncated", "full"]);
        T(a.a, "intermediate")
    };
jK.prototype.m = function() {
    var a = this;
    Ci(function() {
        return nK(a)
    }, 0)
};
var iK = function(a) {
    var b = 0,
        c = "";
    1 === a.b ? (b = 1, c = "src") : 2 === a.b && (b = 2, c = "tgt");
    G(a.h, "click", function() {
        this.o = !0;
        oK(this);
        Bm(this.F, 290, b, this.a.textContent.length);
        O(mI, "webapp", "showmore", "click", {
            l: c
        })
    }, !1, a);
    G(a.g, "click", function() {
        this.o = !1;
        pK(this);
        Bm(this.F, 291, b, this.a.textContent.length);
        O(mI, "webapp", "showless", "click", {
            l: c
        })
    }, !1, a);
    G(window, "resize", a.m, !1, a)
};
var qK = function(a) {
    X.call(this);
    this.m = a;
    this.b = new wJ;
    this.g = new As("");
    this.c = new As("");
    this.h = null
};
t(qK, X);
qK.prototype.init = function() {
    this.c.ba(B("clear", this.j()));
    this.c.xd(DATA.Messages.CLEAR_TEXT);
    this.c.setVisible(!1);
    this.g.ba(B("url-go-button", this.j()));
    this.g.xd(DATA.Messages.TRANSLATE);
    this.g.oa(!1);
    this.b.ba(B("url-orig", this.j()));
    var a = this.b,
        b = DATA.Messages.URL_INPUT_PLACEHOLDER,
        c = a.j();
    yJ() ? (c && (c.placeholder = b), a.b = b) : BJ(a) || (c && (c.value = ""), a.b = b, a.h());
    c && Ip(c, "label", a.b);
    this.h = B("url-err-msg", this.j());
    E(this.h, DATA.Messages.ENTER_VALID_URL);
    W(this.h, !1);
    G(this.b.j(), "input", this.w,
        !1, this);
    G(this.c, "action", this.C, !1, this);
    G(this.g, "action", this.K, !1, this)
};
qK.prototype.C = function() {
    CJ(this.b);
    this.b.j().focus();
    this.g.oa(!1);
    this.c.setVisible(!1);
    W(this.h, !1)
};
qK.prototype.w = function() {
    var a = yc(this.b.Y());
    this.g.oa(!!a);
    this.c.setVisible(!!this.b.Y());
    a = a && !av(a);
    W(this.h, a)
};
qK.prototype.K = function() {
    var a = yc(this.b.Y());
    if (av(a)) {
        var b = this.m.a,
            c = this.m.b;
        var d = n.location.href;
        var e = d.indexOf("#");
        d = 0 > e ? d : d.substr(0, e);
        d = d.replace("/m/translate", "/translate");
        d = Fj(d, "sl", b ? b : "auto", "tl", c, "u", escape(a));
        Zd(d, n, dc("webtrans"))
    }
};
var wK = function(a) {
    var b = a.fk,
        c = a.pk,
        d = a.wk,
        e = a.xk,
        f = a.Bk,
        g = a.Ck,
        k = a.Fk,
        l = a.Ra,
        m = a.Gk,
        q = a.Ik,
        r = a.Jk,
        u = a.Lk,
        z = a.Mk,
        P = a.fm,
        L = a.Qa,
        Ma = a.Fm,
        Kb = a.Hm,
        Ha = a.on,
        Lb = a.pn,
        yg = a.qn,
        Be = a.rn,
        Um = a.zn,
        Uj = a.Ln,
        lM = a.Zn,
        mM = a.Go,
        nM = Q,
        Lk;
    a.Ek ? Lk = Q("<div class='tlid-survey survey-container hidden'><div class='tlid-before-survey'><div class='tlid-dismiss-survey dismiss-button'></div><div class='title'>" + R(L.HAPPINESS_SURVEY_TITLE) + "</div><div class='tlid-survey-contents survey-contents'></div><div class='goog-logo-container'><div class='goog-logo'></div></div></div><div class='tlid-after-survey' style='display: none'><div class='title'>" +
        R(L.HAPPINESS_SURVEY_THANKS) + "</div><div class='after-message'><div>" + R(L.HAPPINESS_SURVEY_AFTER) + "</div><div class='more-feedback-link'><a href='javascript:void(0);' class='tlid-more-feedback'>" + R(L.HAPPINESS_SURVEY_MORE_FEEDBACK) + "</a></div></div></div></div>") : Lk = "";
    a = Lk + "<div class='frame'>";
    Lk = Q;
    var oM = "<div class='page tlid-homepage homepage translate-text'>" + Q("<div class='input-button-container'><div class='tlid-input-button-container focus-wrapper' role='tablist' tabindex='0'>" + rK({
            identifier: "tlid-input-button-text",
            Mi: "text-icon",
            label: L.INPUT_METHOD_TEXT
        }) + rK({
            identifier: "tlid-input-button-docs",
            Mi: "documents-icon",
            label: L.INPUT_METHOD_DOCUMENTS
        }) + "</div></div>") + (r ? Q("<span class='tlid-brain-logos-container'><span class='tlid-no-brain-logo no-brain-logo brain-container'></span><span class='tlid-brain-logo brain-logo brain-container'></span></span>") : ""),
        Rs;
    k ? Rs = Q('<div class="promo-notification-wrapper"><div class=\'' + S("tlid-magnet-promo") + " promo-notification'>" + R("Google Translate is hiring!") + " <span class='tlid-promo-notification-link'><a href='" +
        S(Qn("http://go/joinTranslate")) + "' target='_blank'>" + R("go/joinTranslate") + "</a></span></div></div>") : Rs = "";
    f = oM + Rs + (f ? Q("<div class='app-download-bar'><div class='tlid-app-download-bar focus-wrapper' tabindex=\"0\"><div class=\"prompt-text\">\u70b9\u51fb\u56fe\u6807\u4e0b\u8f7d App</div>" + R(BI({
        qe: "Android",
        qg: "android",
        identifier: "tlid-android-download"
    })) + R(BI({
        qe: "iOS",
        qg: "ios",
        identifier: "tlid-ios-download"
    })) + "</div></div>") : "") + "<div class='homepage-content-wrap'><div class='tlid-source-target main-header'><div class='source-target-row'>";
    k = Q;
    d = '<div class="tlid-input input"><div class="tlid-language-bar ls-wrap"><div class="sl-wrap"><div class="sl-sugg"></div><div class="sugg-fade"></div><div class="sl-more tlid-open-source-language-list" aria-label="' + S(L.MORE) + '" role="button" tabindex="0"></div></div>' + sK({
            className: "sl",
            identifier: "source",
            Oi: Uj,
            selected: d
        }) + '<div class="swap-wrap"><div class="swap jfk-button-narrow jfk-button-standard" aria-label="' + S(L.TOOLTIP_SWAP_LANGUAGES) + '" data-tooltip="' + S(L.TOOLTIP_SWAP_LANGUAGES) + '"><div class="jfk-button-img"></div></div></div><div class="tl-wrap"><div class="tl-sugg"></div><div class="sugg-fade"></div><div class="tl-more tlid-open-target-language-list" aria-label="' +
        S(L.MORE) + '" role="button" tabindex="0"></div></div>' + sK({
            className: "tl",
            identifier: "target",
            Oi: lM,
            selected: e
        }) + '</div><div class="source-wrap">';
    Lb = Q('<div class="input-full-height-wrapper tlid-input-full-height-wrapper"><div class="source-input"><div id="input-wrap" class="tlid-input-area input-area' + (Lb ? "" : " less-padding") + '"><textarea id="source" class="orig tlid-source-text-input" rows="1" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off"></textarea><div class="text-dummy"></div><div id=gt-src-is style="display:none" class="gt-is-mobile gt-is"><div id=gt-src-is-list class=gt-is-ctr></div></div></div><div class="source-header"><div class="clear-wrap"><div class="clear jfk-button-flat tlid-clear-source-text" aria-label="' +
        S(L.CLEAR_TEXT) + '" data-tooltip="' + S(L.CLEAR_TEXT) + '"><div class="jfk-button-img"></div></div></div>' + (Lb ? '<div class="go-wrap"><div class="go-button" aria-label="' + S(L.TRANSLATE) + '" data-tooltip="' + S(L.TRANSLATE) + '"><div class="go jfk-button-action"><div class="jfk-button-img"></div></div></div></div>' : "") + "</div>" + tK({
            containerId: "tlid-source-transliteration-container",
            Qa: L,
            nj: "source-transliteration-container"
        }) + '<div id="spelling-correction" class="tlid-spelling-correction spelling-correction"></div><div class="source-footer-wrap source-or-target-footer"><div class="source-input-tools" id="gt-input-tool"></div><div class="character-count tlid-character-count"><div class="cc-ctr"></div><div class="cc-msg"></div></div><div class="source-footer"><div class="speech-wrap source-or-target-footer-button left-positioned"><span class="speech-border"></span></div>' +
        uK({
            ef: ["src-tts", "left-positioned"],
            Qa: L
        }) + "</div></div></div></div>");
    Lb = k(d + Lb + "</div>" + (z ? Q('<div class="url-input-wrap" style="display:none"><input id="url-input" class="url-orig" rows="1" spellcheck="false" autocapitalize="off" autocomplete="off" autocorrect="off"><div class="url-clear-wrap"><div class="clear jfk-button-flat"><div class="jfk-button-img"></div></div></div><div class="url-go-wrap"><div class="url-go-button"><div class="go jfk-button-action"><div class="jfk-button-img"></div></div></div></div><div class="url-err-msg"></div></div>') :
            "") + Q('<div id="gt-ovfl" style="display: none;" class="snck ovfl"><div id="gt-ovfl-ctr" class="ovfl-ctr"><span id="gt-ovfl-msg" class="snck-msg" role="alert" aria-live="alert"></span><span id="gt-ovfl-xlt" class="ovfl-xlt" role="button">' + R(L.TRANSLATE_MORE) + "</span></div></div>") + Q('<div id="gt-ntfcn" style="display: none;" class="snck ntfcn"><div id="gt-ntfcn-ctr" class="ntfcn-ctr"><span id="gt-ntfcn-msg" class="snck-msg" role="alert" aria-live="alert"></span></div></div>') + Q('<div id="gt-cmty" style="display: none;" class="snck cmty"><div id="gt-cmty-ctr" class="cmty-ctr"><span id="gt-cmty-msg" class="snck-msg" role="alert" aria-live="alert"></span><span id="gt-cmty-btn" class="cmty-btn" role="button"></span></div></div>') +
        "</div>");
    Lb = f + Lb;
    l = Q('<div class="tlid-results-container results-container">' + (r ? '<div class="tlid-prod-translation prod-translation translation"></div>' : "") + (u ? '<div class="error-placeholder placeholder"><span class="tlid-result-error"></span><span class="tlid-result-container-error-button translation-error-button">' + R(L.TRY_AGAIN) + "</span></div>" : '<span class="tlid-result-error error-placeholder placeholder"></span>') + '<span class="empty-placeholder placeholder">' + R(L.TRANSLATION) + '</span><span class="translating-placeholder placeholder">' +
        R(L.TRANS_IN_PROGRESS) + '</span><div class="gendered-translations-header">' + R(L.GENDER_SPECIFIC_TRANSLATIONS_LABEL) + ' <a class="gendered-translations-learn-more" href="https://support.google.com/translate?p=gendered_translations&hl=' + Mn(l) + '" target="_blank">' + R(L.LEARN_MORE) + "</a></div></div>");
    l = Lb + l + "</div><div class='tlid-select-file-page-container'></div></div>";
    u = Q("<div class='tlid-result-view cllist'>" + (u ? "<div class='tlid-translation-error translation-error-box' style='display: none'><span class=\"tlid-translation-error-message translation-error\"></span><span class=\"tlid-result-view-error-button translation-error-button\">" +
        R(L.TRY_AGAIN) + "</span></div>" : "<div class='tlid-translation-error tlid-translation-error-message translation-error' style='display: none'></div>") + "<div class='cp-promo-wrapper'></div><div class='gt-lc gt-lc-mobile' style='display: none'></div></div>");
    u = l + u + "<div class='feedback-link'><a href='javascript:void(0);' class='tlid-send-feedback-link'>" + R(L.SEND_FEEDBACK) + "</a></div></div>";
    l = Q;
    c = '<div class="gp-footer">' + Q('<div class="ft-icon-row"><div class="ft-icon-ctr"><a class="ft-link" href="javascript:void(0);" onclick="_e(event, \'' +
        S($n(P)) + "')\">" + vK({
            Of: "ft-icon-img-hst",
            caption: L.HISTORY_SECTION_TITLE
        }) + "</a></div>" + (m ? '<div class="ft-icon-ctr"><a class="ft-link" href="javascript:void(0);" onclick="_e(event, \'' + S($n(Um)) + "')\">" + vK({
            Of: "ft-icon-img-svd",
            caption: L.SAVED_SECTION_TITLE
        }) + "</a></div>" : "") + (g ? '<div class="ft-icon-ctr tlid-community-button">' + (q ? '<a class="ft-link" href="javascript:void(0);" onclick="_e(event, \'' + S($n(c)) + "')\">" : '<a class="ft-link" href="/community?source=mfooter">') + vK({
            Of: "ft-icon-img-cmn",
            caption: L.FOOTER_COMMUNITY
        }) + "</a></div>" : "") + (z ? '<div class="ft-icon-ctr"><a class="ft-link" href="javascript:void(0);" onclick="_e(event, \'' + S($n(mM)) + "')\">" + vK({
            Of: "ft-icon-img-web",
            caption: L.FOOTER_WEBSITES
        }) + "</a></div>" : "") + "</div>");
    var Ss;
    yg ? Ss = Q('<div class="ad-panel gsa-promo"><div><span class="gsa-icon-animated"></span></div><div class="ad-panel-title">' + R(L.SEARCH_HANDS_FREE) + '</div><div class="ad-panel-subtitle">' + R(L.GSA_PURE_AD_TEXT) + '</div><div class="ad-panel-buttons"><span class="tlid-dismiss-promo dismiss-promo">' +
        R(Ma) + '</span><span class="tlid-accept-promo accept-promo">' + R(Kb) + "</span></div></div>") : Ss = "";
    yg = c + Ss;
    var Ts;
    Ha ? Ts = Q('<div class="ad-panel at-promo"><div><span class="translate-icon"></span></div><div class="ad-panel-title">' + R(b) + '</div><div class="ad-panel-buttons"><span class="tlid-dismiss-promo dismiss-promo">' + R(Ma) + '</span><span class="tlid-accept-promo accept-promo">' + R(Kb) + "</span></div></div>") : Ts = "";
    b = l(yg + Ts + "</div>");
    b = Lk(u + b + "</div>");
    b = a + b + Q("<div class='page tlid-history-page history-page' tabindex='0' aria-label='" +
        S(L.HISTORY_SECTION_TITLE) + "'><div class='outer-wrap'><div class=\"tlid-translation-history-container\"></div></div></div>");
    q = Q(q ? "<div class='page tlid-instant-page instant-page' tabindex='0' aria-label='" + S(L.COMMUNITY_INSTANT_TITLE) + "'><div class='outer-wrap'><div class=\"tlid-community-instant-container\"></div></div></div>" : "");
    Be = b + q + (Be ? "<div class='page tlid-phrasebook-page phrasebook-page' tabindex='0' aria-label='" + S(L.SAVED_SECTION_TITLE) + "'><div class='tlid-phrasebook-outer-wrap outer-wrap'></div></div>" :
        "");
    L = Q("<div class='page tlid-language-picker-page language-picker-page'><div class='language-picker-wrapper'>" + Q('<div class="tlid-language-list-toolbar language-list-toolbar"><div class="tlid-language-list-back-button language-list-back-button" aria-label="' + S(L.CLOSE) + '"><div class="backbutton-image language-picker-toolbar-image"></div><div class="clear-image-black language-picker-toolbar-image"></div></div><div class="tlid-language-list-search-button language-list-search-button"><div class="tlid-language-list-label language-list-label"></div><div class="searchbutton-image language-picker-toolbar-image"></div></div></div>') +
        "<div class='outer-wrap'></div></div></div>");
    L = Be + L;
    Be = Q("<div class='toast-container'><div class='toast " + S({
        identifier: "tlid-toast"
    }.identifier) + "' style='display: none'><div class='tlid-toast-message message'></div><div class='tlid-toast-action toast-action'><a target='_blank' class='tlid-toast-action-link action-link'><span class='tlid-toast-action-text'></span></a></div></div></div>");
    return nM(L + Be + "</div>")
};
wK.a = "trans.mobile.widget.main";
var rK = function(a) {
        var b = a.Mi,
            c = a.label;
        return Q("<div class='tlid-input-button input-button header-button " + S(a.identifier) + " " + S(b) + "' role='tab' tabindex=\"-1\"><div class='text'>" + R(c) + "</div></div>")
    },
    xK = function(a) {
        var b = a.Ra,
            c = a.Qa;
        return Q("<div class='select-file-page tlid-file-selector loading'><form method='post' action='" + S(Qn(a.Sk)) + "'><input type='hidden' name='hl' value='" + S(b) + "' class='tlid-hl-input'><input type='hidden' name='ie' value='UTF-8' class='tlid-ie-input'><input type='hidden' name='js' value='y' class='tlid-js-input'><input type='hidden' name='prev' value='_t' class='tlid-prev-input'><input type='hidden' name='sl' class='tlid-sl-input'><input type='hidden' name='tl' class='tlid-tl-input'><div class='tlid-select-file-section select-file-section'><div class='choose-document-prompt'>" +
            R(c.CHOOSE_A_DOCUMENT) + "</div><div class='upload-filetypes-prompt'>" + R(c.UPLOAD_FILETYPES) + "</div><input type='file' name='file' id='tlid-file-input' class='file-input tlid-file-input'><label for='tlid-file-input' class='tlid-select-file-button button'>" + R(c.BROWSE_YOUR_COMPUTER) + "</label></div><div class='tlid-file-selected-section file-selected-section'><div class='file-holder'><div class='file-holder-icon'></div><div class='file-info'><div class='tlid-selected-file-label file-label'></div><div class='tlid-selected-file-size file-size'>&nbsp;</div></div><div class='selected-and-cancel'><div class='tlid-cancel-selected-file-button cancel-file'></div></div></div><div class='button-container'><input type='submit' class='tlid-translate-doc-button button' value='" +
            S(c.TRANSLATE) + "'></div></div><div class='loading-or-translating-file-section'><div class='mspin-googblue-medium'><div><div></div></div></div><div class='translating-file-caption'>" + R(c.TRANS_IN_PROGRESS) + "</div></div></form></div>")
    };
xK.a = "trans.mobile.widget.selectFilePage";
var vK = function(a) {
        var b = a.Of;
        a = a.caption;
        return Q('<div class="footer-icon-container ' + S(b) + '"><div class="ft-icon-img-ctr"><div class="ft-icon-oval" id="' + S(b) + '"></div><div class="ft-icon-notification"></div></div><div class="ft-icon-txt">' + R(a) + "</div></div>")
    },
    tK = function(a) {
        var b = a.Qa,
            c = a.nj;
        return Q("<div class='" + S(a.containerId) + " " + S(c) + " transliteration-container'><div class='tlid-transliteration-content transliteration-content'></div><div class='tlid-show-more-link truncate-link' style='display:none'>" +
            R(b.SHOW_MORE) + "</div><div class='tlid-show-less-link truncate-link' style='display:none'>" + R(b.SHOW_LESS) + "</div></div>")
    },
    uK = function(a) {
        var b = a.Qa,
            c = "<div class='";
        a = a.ef;
        for (var d = a.length, e = 0; e < d; e++) c += S(a[e]) + " ";
        c += "ttsbutton jfk-button-flat source-or-target-footer-button' aria-label='" + S(b.LISTEN) + "' data-tooltip='" + S(b.LISTEN) + "'><div class='jfk-button-img'></div></div>";
        return Q(c)
    },
    sK = function(a) {
        var b = a.className,
            c = a.identifier,
            d = a.Oi;
        a = a.selected;
        b = '<div class="' + S(b) + '-selector lang_list"><div class="lang-btn"><a class="ls-select new-ls-select ' +
            S(b) + "-button tlid-open-small-" + S(c) + '-language-list"';
        c = "";
        for (var e = d.length, f = 0; f < e; f++) {
            var g = d[f];
            c += Dn(g.Code, a) ? "" + g.Name : ""
        }
        b += ' aria-label="' + S(c) + '" tabindex="0">' + R(c) + "</a></div></div>";
        return Q(b)
    },
    yK = function(a) {
        var b = a.Qa;
        a = a.In;
        return Q('<div class="tlid-gender-promo gender-promo"><div class="gender-promo-graphic"></div><div class="gender-promo-content"><div class="gender-promo-pre-title">' + R(b.NEW_FEATURE) + '</div><div class="gender-promo-title">' + R(b.GENDER_SPECIFIC_TRANSLATIONS_PROMO_TITLE) +
            '</div><span class="gender-promo-message gender-promo-message-short-phrase">' + R(b.GENDER_SPECIFIC_TRANSLATIONS_PROMO_TEXT) + '</span><span class="gender-promo-message gender-promo-message-single-word">' + R(b.GENDER_SPECIFIC_TRANSLATIONS_PROMO_TEXT_SINGLE_WORD) + "</span>" + (a ? '<a class="gender-promo-learn-more" target="_blank" href="https://www.blog.google/products/translate/reducing-gender-bias-google-translate/">' + R(b.LEARN_MORE) + "</a>" : "") + "</div><div class='tlid-gender-promo-dismiss-button gender-promo-dismiss-button'></div></div>")
    };
yK.a = "trans.mobile.widget.genderPromo";
var zK = function(a) {
    var b = a.Bg,
        c = a.Ag,
        d = a.Em,
        e = a.Gm,
        f = a.Qa,
        g = Q,
        k;
    a.Mc ? k = Q('<div class="starbutton jfk-button-flat" aria-label="' + S(e) + '" data-tooltip="' + S(e) + '"><div class="jfk-button-img"></div></div>') : k = "";
    return g('<div class=\'tlid-result result-dict-wrapper\'><div class="result tlid-copy-target"><div class="result-header">' + k + '</div><div class="text-wrap tlid-copy-target"><div class="result-shield-container tlid-copy-target" tabindex="0"><span class="tlid-translation translation"></span><span class="tlid-translation-gender-indicator translation-gender-indicator"></span><span class="tlid-trans-verified-button trans-verified-button" style="display:none" role="button"></span></div></div>' + tK({
            containerId: "tlid-result-transliteration-container",
            Qa: f,
            nj: "result-transliteration-container"
        }) + '<div class="result-footer source-or-target-footer tlid-copy-target"><div class="tlid-share-translation-button share-translation-button jfk-button-flat source-or-target-footer-button right-positioned" aria-label=\'' + S(f.SHARE_TRANSLATION) + "' data-tooltip=\"" + S(f.SHARE_TRANSLATION) + '"><div class="jfk-button-img"></div></div><div class="tlid-suggest-edit-button suggest-edit-button jfk-button-flat source-or-target-footer-button right-positioned" aria-label=\'' +
        S(f.SUGGEST_AN_EDIT) + "' data-tooltip=\"" + S(f.SUGGEST_AN_EDIT) + '"><div class="jfk-button-img"></div></div><div class="more-wrapper"><div class="morebutton jfk-button-flat source-or-target-footer-button tlid-result-footer-more-button right-positioned" data-tooltip="' + S(f.MORE) + '"><div class="jfk-button-img"></div></div><div class="moremenu"></div></div>' + (c ? '<div class="tlid-copy-translation-button copybutton jfk-button-flat source-or-target-footer-button right-positioned" aria-label=\'' + S(d) + "' data-tooltip=\"" +
            S(d) + '"><div class="jfk-button-img"></div></div>' : "") + uK({
            ef: ["res-tts", "ttsbutton-res", "left-positioned"],
            Qa: f
        }) + (b ? '<div class="result-search"><div class="result-search-icon"></div></div>' : "") + '</div></div><div class="gt-edit" style="display:none"><div class="gt-clear" tabindex="0"><div class="jfk-button-img"></div></div><textarea class="contribute-target"></textarea></div></div>')
};
zK.a = "trans.mobile.widget.result";
var AK = function(a) {
    var b = a.yn;
    return Q("<span class='tlid-translation-page-link translation-page-link'><a href='" + S(Qn(a.xn)) + "' target='_blank'>" + R(b) + "<span class='open-translated-page-icon'></span></a></span>")
};
AK.a = "trans.mobile.widget.resultHyperlink";
var EB = function(a) {
    var b = a.re,
        c = a.wm;
    a = a.xm;
    return Q('<div class="language-list-search-box"><div class="back-image-black language-picker-toolbar-image"></div><div class="clear-image-black language-picker-toolbar-image"></div><div class="language_list_search_box_container"><input id="' + S(c) + '-search-box" type="text" oninput="_e(event, \'' + S($n(b)) + "', '" + S($n(c)) + '\')" placeholder="' + S(a) + '"></div></div>')
};
EB.a = "trans.mobile.widget.languageListSearchBox";
var vB = function(a) {
    var b = a.id,
        c = a.re,
        d = a.name;
    a = a.code;
    b = '<div class="language_list_item_wrapper language_list_item_wrapper-' + S(a) + " " + (Dn(a, "auto") ? " detect_language " : "") + '" onclick="_e(event, \'' + S($n(c)) + "', '" + S($n(b)) + '\')" role="button" tabindex="0"><div class="language_list_item_icon ' + S(b) + '_checkmark"></div>';
    c = Dn(a, "auto") ? "language_list_item" : "language_list_item language_list_item_language_name";
    b += "<div class='" + S(c) + "'>" + R(d) + "</div>" + (Dn(a, "auto") ? '<div class="detect_language_row_icon"></div>' :
        "") + "</div>";
    return Q(b)
};
vB.a = "trans.mobile.widget.languageListItem";
var SB = function(a) {
    return Q('<div class="language_list_section"><div class="language_list_section_header">' + R(a.text) + "</div></div>")
};
SB.a = "trans.mobile.widget.languageListSection";
var BK = function(a) {
    var b = a.xo,
        c = a.Qa,
        d = a.Kk,
        e = a.Nk,
        f = a.Eo;
    a = a.gm;
    return Q('<div class="share-module"><div class="tlid-share-panel share-panel" aria-hidden="true" tabindex="0"><div class="share-panel-wrap"><h3>' + R(c.SHARE_MODULE_TITLE) + "</h3>" + (En(e) && En(f) ? '<div id="not_installed"><span class="warning-icon"></span><span class="warning-msg">' + R(f) + "</span></div>" : "") + "<ul>" + (d ? '<li><a href="sms:' + (a ? "&body=" + S(b) : "?body=" + Mn(b)) + '" class="sms"><span class="share-link-icon"></span><span> ' + R(c.SHARE_MODULE_SMS) +
        " </span></a></li>" : "") + '<li><a href="mailto:?body=' + Mn(b) + '" target="_top" class="email"><span class="share-link-icon"></span><span> ' + R(c.SHARE_MODULE_EMAIL) + " </span></a></li>" + (En(e) && En(f) ? '<li><a href="whatsapp://send?text=' + Mn(b) + '" class="whatsapp"><span class="share-link-icon"></span><span> WhatsApp </span></a></li>' : "") + '<li><a href="https://twitter.com/intent/tweet?text=' + Mn(b) + '" target="_blank" class="twitter"><span class="share-link-icon"></span><span> Twitter </span></a></li></ul></div></div></div>')
};
BK.a = "trans.mobile.widget.shareModule";
var CK = function(a) {
    var b = a.Vn,
        c = a.ao,
        d = a.Wn,
        e = a.qe,
        f = a.Cn;
    return Q('<div class="gsa-interstitial"><div class="clear-wrap"><div class="clear jfk-button-flat" aria-label="' + S(a.Qa.CLEAR_TEXT) + '"><div class="jfk-button-img"></div></div></div><div><span class="gsa-icon"></span></div><div class="gsa-int-text">' + R(b) + (c ? "<b>" + R(c) + "</b>" : "") + R(d) + '</div><div class="gsa-int-button">' + R(e) + '</div><div class="gsa-int-second-choice">' + R(f) + "</div></div>")
};
CK.a = "trans.mobile.widget.iGSAInterstitial";
var DK = function(a) {
    var b = a.message;
    return Q("<span class='survey-option survey-option-" + S(a.dn) + "'><span class='survey-option-text'>" + R(b) + "</span></span>")
};
DK.a = "trans.mobile.widget.surveyOption";
var EK = function(a) {
    return Q("<span class='ink-container " + S(a.nk) + "'></span>")
};
EK.a = "trans.mobile.widget.inkContainer";
var FK = function() {
    var a = DATA.Messages.CLOSE_SEARCH,
        b = DATA.Messages.CLEAR_TEXT,
        c = DATA.Messages.RECENT_LANGUAGES,
        d = DATA.Messages.ALL_LANGUAGES,
        e = DATA.Messages.CHECKED_LANGUAGE;
    this.o = DATA.Messages.SEARCH_LANGUAGES;
    this.b = a;
    this.a = b;
    this.h = c;
    this.c = d;
    this.g = e
};
var MK = function(a, b, c, d, e, f) {
    var g = this;
    J.call(this);
    this.c = e;
    this.V = f;
    this.v = a;
    this.gb = b;
    this.R = C("tlid-open-small-source-language-list", this.v);
    this.wb = C("tlid-open-small-target-language-list", this.v);
    a = new FK;
    this.b = new BF("sl_list", a);
    this.g = new BF("tl_list", a);
    this.b.C = this.R;
    this.b.K(Nb(DATA.SourceLanguageCodeNameList));
    this.g.C = this.wb;
    this.g.K(Nb(DATA.TargetLanguageCodeNameList));
    this.a = new bw("", !0);
    this.a.ba(B("orig", this.v));
    zr(this.a, "orig-ios", Ie);
    kt() || (this.a.j().placeholder = DATA.Messages.ENTER_TEXT);
    this.Nc = new As("");
    a = C("swap", this.v);
    this.Nc.ba(a);
    kt() && this.Nc.xd(Ce ? DATA.Messages.TOOLTIP_SWAP_LANGUAGES_SHORTCUT_MAC : DATA.Messages.TOOLTIP_SWAP_LANGUAGES_SHORTCUT_NOTMAC);
    PA(this.V, {
        Nc: this.Nc
    });
    ss(a, 1);
    GK(this);
    this.Ca = eb(B("source-header", this.v));
    HK(this, c);
    this.C = null;
    c = B("go-button", this.v);
    null != c && (this.C = new As(""), this.C.ba(c), ss(c, 2), G(this.C.j(), "mousedown", function() {
        g.dispatchEvent("translateButtonClicked")
    }, !1));
    this.K = new As("");
    c = C("clear", this.v);
    this.K.ba(c);
    this.K.setVisible(!1);
    ss(c, 2);
    this.L = new As("", void 0, 4);
    this.L.Oa(16, !0);
    this.L.Oa(1, !0);
    c = C("src-tts", this.v);
    this.L.ba(c);
    ss(c, 2);
    this.o = new fv(this.L, "&client=webapp&prev=input", 1, !0, !0, DATA.Messages.LISTEN, DATA.Messages.VOICE_OUTPUT_UNAVAILABLE);
    this.F = K.M();
    this.xb = new dH;
    this.W = new fH;
    this.W.ba(B("gt-is-mobile", this.v));
    this.W.setVisible(!1);
    this.G = null;
    kt() && (this.G = new pz(B("source-input-tools", this.v), B("orig", this.v), B("source-input-tools", this.v), DATA.DisplayLanguage, DATA.InChina), G(this.G, "change", function() {
            IK(g)
        },
        !1));
    this.O = new wD(this.xb, this.W, {
        im: this.a,
        Gn: null,
        jm: this.G,
        ea: this.c,
        Qn: new cH,
        zo: new qp("webapp"),
        client: "webapp",
        Ra: DATA.DisplayLanguage,
        Kn: !DATA.DisableOtf,
        Am: 4,
        vo: !0,
        hk: !1,
        Tk: "",
        nm: !1,
        lm: !1,
        gr: DATA.Messages.QUICK_TRANSLATION,
        Nn: DATA.Messages.DID_YOU_MEAN,
        Uq: DATA.Messages.LANGUAGE_CORRECTION,
        qk: new Ew
    });
    this.na = new jK(eb(B("tlid-source-transliteration-container", this.v)), 1);
    this.ob = Gm.M();
    this.w = !1;
    this.Z = "";
    this.h = new QG(this.a, this.V, DATA.TopLevelDomain.substr(DATA.TopLevelDomain.lastIndexOf(".") +
        1), DATA.DisplayLanguage, !0, DATA.Messages.VOICE_INPUT_UNAVAILABLE, DATA.Messages.VOICE_INPUT_UNAVAILABLE_GENERIC, !0, DATA.Messages.CHOOSE_LANGUAGE_TO_ENABLE_VOICE_INPUT);
    this.m = eb(B("speech-wrap", this.v));
    JK(this);
    DATA.UrlTranslation && (this.X = new qK(this.c), c = B("url-input-wrap", this.v), this.X.ba(c), this.X.init());
    KK(this);
    LK(this)
};
t(MK, J);
var GK = function(a) {
        var b = new KA(eb(B("sl-sugg", a.v)), p(wI, a), 3, !0, !0, !0),
            c = new KA(eb(B("tl-sugg", a.v)), p(xI, a), 3, !1, !1, !0);
        PA(a.V, {
            jj: b,
            sj: c
        });
        rw(a.c);
        void 0 !== DATA.RecentLanguages && void 0 !== DATA.RecentLanguages.recent_sl && pw(a.c);
        void 0 !== DATA.RecentLanguages && void 0 !== DATA.RecentLanguages.recent_tl && qw(a.c);
        jw(a.c);
        kw(a.c);
        a = b.a;
        c = c.a;
        for (b = 0; b < a.length; b++) G(a[b].j(), "click", function(d) {
            NK(d)
        }, !1);
        for (a = 0; a < c.length; a++) G(c[a].j(), "click", function(d) {
            NK(d)
        }, !1)
    },
    NK = function(a) {
        var b = a.target;
        b.blur();
        var c = B("ink-container", b);
        c || (c = Xp(EK, {
            nk: "language-selector-ripple"
        }), b.insertBefore(c, b.firstChild));
        U(c, "ink-ripple-animation");
        if (!c.offsetHeight && !c.offsetWidth) {
            var d = Math.max(b.offsetHeight, b.offsetWidth);
            c.style.height = d + "px";
            c.style.width = d + "px"
        }
        b = b.getBoundingClientRect();
        d = a.clientX - (b.left + document.body.scrollLeft) - c.offsetWidth / 2;
        c.style.top = a.clientY - (b.top + document.body.scrollTop) - c.offsetHeight / 2 + "px";
        c.style.left = d + "px";
        T(c, "ink-ripple-animation")
    },
    JK = function(a) {
        if (po && "webkitSpeechRecognition" in
            window) {
            a.h.init(a.m);
            var b = D("span", ["speech-border", "speech-background"]);
            ig(a.m, b, 1);
            OK(a)
        } else W(a.m, !1)
    },
    KK = function(a) {
        G(a.a, "change", function(b) {
            LK(a, b.changeType)
        }, !1, a);
        G(a.a.j(), "focus", a.N, !1, a);
        G(a.a.j(), "blur", a.N, !1, a);
        G(a.a.j(), "focus", p(a.Na, a, !1), !1, a);
        G(a.a.j(), "blur", p(a.Na, a, !0), !1, a);
        G(a.a.j(), "focus", a.F.c, !1, a.F);
        G(window, "resize", a.ia, !1, a);
        G(a.c, "srcEmphasizeUpdated", a.xa, !1, a);
        G(a.c, "tgtEmphasizeUpdated", a.ab, !1, a);
        G(a.c, "srcLanguageUpdated", a.Ta, !1, a);
        G(a.c, "detectSrcUpdated",
            a.ra, !1, a);
        G(a.K, "action", a.Ob, !1, a);
        a.h && (G(a.h, "start", a.Pl, !1, a), G(a.h, "speechStart", a.qo, !1, a), G(a.h, "end", a.Ol, !1, a), G(a.h, "userInteractionWhileDisabled", a.Yl, !1, a), G(a.o, "userInteractionWhileDisabled", a.uo, !1, a));
        G(C("tlid-input-full-height-wrapper", a.v), "click", function(b) {
            var c = a.na;
            [c.c, c.a, c.h, c.g].includes(b.target) || Gg(document) === a.a.j() || IK(a)
        }, !1)
    },
    PK = {
        "small-font": 2
    };
MK.prototype.j = function() {
    return this.v
};
var QK = function(a) {
    var b = a.c.a;
    a.o.update(a.a.Y(), b, void 0, wI(b))
};
MK.prototype.N = function(a) {
    a = a ? "focus" == a.type : Gg(document) === this.a.j();
    var b = !!this.a.Y();
    this.K.setVisible(a || b);
    null != this.C && this.C.setVisible(a)
};
var IK = function(a) {
        a.a.j().focus()
    },
    RK = function(a) {
        var b = mq(a.Ca).a,
            c = aq(wq(a.a.j())).bottom,
            d = jq(document).a;
        d > b - 10 && c > d || Ci(p(window.scrollTo, window, 0, b - 8), 100, a)
    },
    OK = function(a) {
        if (a.h) {
            var b = a.c.a;
            a = a.h;
            var c = wI(b);
            if (null != a.a) {
                a.Ib && a.a.stop();
                var d = a.V.get(b);
                a.a.lang = null != d ? d : "";
                null != d ? (a.G = d, a.b.oa(!0), W(a.h, !0)) : (v(null != a.m || null != a.L, "Cannot disable button without providing a tooltip explanation"), "auto" === b && null != a.C ? (b = a.b, b.b = a.C, b.oa(!1)) : null != a.m ? (b = a.b, c = a.Z.a(a.m, c), b.b = c, b.oa(!1)) :
                    (b = a.b, b.b = a.L, b.oa(!1)), a.na || W(a.h, !1))
            }
        }
    };
h = MK.prototype;
h.Pl = function() {
    this.w = !0;
    SK(this)
};
h.qo = function() {
    T(this.m, "speech-data")
};
h.Ol = function() {
    this.w = !1;
    U(this.m, "speech-data");
    SK(this);
    LK(this)
};
h.Yl = function() {
    this.dispatchEvent("userInteractionWithDisabledVoiceInput")
};
h.uo = function() {
    this.dispatchEvent("userInteractionWithDisabledVoiceOutput")
};
var SK = function(a) {
    var b = "";
    a.w ? a.Z = dw(a.a) : b = dw(a.a) || a.Z;
    a.a.b(b);
    a.a.j().disabled = a.w;
    b = a.a;
    b.Dd = a.w ? MSG_SPEAK_NOW : DATA.Messages.ENTER_TEXT;
    b.j() && Yv(b);
    a.a.j().blur()
};
MK.prototype.Na = function(a) {
    for (var b = Nf("show-panel"), c = 0; c < b.length; c++) Ci(Sa(W, b[c], a), 100, this)
};
MK.prototype.Ob = function() {
    var a = this.F;
    M(a, N(a, 23));
    "" === this.a.Y() ? this.a.j().blur() : (this.a.b(""), IK(this));
    this.h && (this.h.c = "");
    this.o && this.o.stop();
    Nm(this.ob, "clearbtn", 1, "accumulate");
    this.dispatchEvent("inputCleared")
};
var LK = function(a, b) {
        a.ia();
        a.N();
        QK(a);
        "paste" === b && a.dispatchEvent("inputPasted")
    },
    TK = function(a) {
        var b = a.c.a;
        "auto" == b && (b = a.c.c);
        b && (b = jc(b) ? "rtl" : "ltr", cq(a.a.j(), "direction", b), a = B("gt-hl-layer", a.v), null != a && cq(a, "direction", b))
    };
MK.prototype.Ta = function() {
    var a = this.c.a;
    "auto" != a && HK(this, a);
    TK(this);
    OK(this);
    this.o.update(this.a.Y(), a, void 0, wI(a));
    null != this.G && sz(this.G, a)
};
MK.prototype.xa = function(a) {
    this.b.L = a.data
};
MK.prototype.ab = function(a) {
    this.g.L = a.data
};
MK.prototype.ra = function() {
    TK(this)
};
var HK = function(a, b) {
    var c = wI(b);
    a.b.V(c, b)
};
MK.prototype.update = function(a, b, c) {
    var d = this.na;
    if (void 0 === b) var e = "";
    else {
        e = [];
        if (b.cb(0))
            for (var f = 0; f < b.jc(); f++) {
                var g = b.cb(f);
                1 === d.b ? I(g, 3) && e.push(I(g, 3)) : 2 === d.b && I(g, 2) && e.push(I(g, 2))
            }
        e = e.join("")
    }
    kK(d, e);
    V(this.v, "has-transliteration", 0 !== this.na.a.textContent.length);
    d = I(np(b), 1);
    e = I(b, 2);
    this.o.update(c ? d : a, e, void 0, wI(e));
    "auto" == this.c.a && ((a = I(b, 2)) && "auto" != a ? (a = wI(a), a = source_language_detected.replace(/%\d\$s/g, a), E(this.R, a)) : E(this.R, wI("auto")))
};
MK.prototype.ia = function() {
    var a = this.a;
    a.hh = 0;
    Xv(a);
    a = B("text-dummy", this.v);
    var b = B("text-dummy", this.v);
    this.a.Y().endsWith("\n") ? E(b, this.a.Y() + "\n") : E(b, this.a.Y());
    Dg(a) ? (b = Iq(a), a = (a.scrollHeight - b.top - b.bottom) / 32) : a = 1;
    V(this.gb, "small-font", a > PK["small-font"]);
    Xv(this.a)
};
var UK = function(a) {
    J.call(this);
    this.v = a;
    this.a = null;
    this.o = this.h = "";
    this.g = this.c = !1
};
ka(UK, J);
UK.prototype.w = function(a) {
    null != a && null != a.reset && (this.c = a.reset, this.h = a.sourceLanguageCode || "", this.o = a.targetLanguageCode || "");
    this.dispatchEvent("close_requested")
};
UK.prototype.m = function(a) {
    null != a && a.available && !this.g && (this.dispatchEvent("tasks_available"), this.g = !0)
};
UK.prototype.b = function() {
    return !0
};
var VK = function(a, b, c, d, e, f) {
    var g = mv();
    pF.call(this, a, c, d, e, g);
    this.O = f;
    this.w = b
};
ka(VK, pF);
VK.prototype.m = function() {
    this.h.style.left = Math.round(this.coords[0]) + "px";
    this.h.style.bottom = Math.round(this.coords[1]) + "px"
};
VK.prototype.g = function() {
    (new sF(this.w, this.O)).play()
};
var WK = function() {
    X.call(this);
    this.h = null
};
ka(WK, X);
WK.prototype.b = function() {
    return ""
};
WK.prototype.setVisible = function(a, b) {
    var c = this,
        d = this.j();
    if (yq(d) != a) {
        var e = B(this.b(), this.j());
        a ? (cq(d, {
            opacity: 1
        }), cq(e, {
            opacity: 0
        }), W(d, !0), (new VK(d, e, XK, YK, 225, 100)).play(), b && (this.h = window.setTimeout(function() {
            return c.setVisible(!1)
        }, b))) : ((new tF(d, 195)).play(), this.h && (window.clearTimeout(this.h), this.h = null))
    }
};
var XK = [0, -48],
    YK = [0, 0];
var ZK = function() {
    WK.call(this)
};
ka(ZK, WK);
ZK.prototype.b = function() {
    return "ntfcn-ctr"
};
ZK.prototype.Xc = function(a) {
    if (!a || "DIV" != a.tagName) return !1;
    a = B("ntfcn-ctr", a);
    return a && "DIV" == a.tagName ? (a = B("snck-msg", a)) && "SPAN" == a.tagName ? !0 : !1 : !1
};
ZK.prototype.aa = function() {};
var $K = function() {};
ka($K, xr);
$K.prototype.Zc = function(a) {
    return a && "SPAN" == a.tagName ? !0 : !1
};
var aL = function(a, b, c, d) {
    WK.call(this);
    this.m = a;
    this.c = b;
    this.R = c;
    this.N = d;
    this.W = new yv("######");
    this.V = new aG(DATA.Messages.CHARACTER_LIMIT);
    this.X = new aG(DATA.Messages.TRANSLATE_NEXT);
    this.g = "";
    this.w = null;
    this.C = new Gm;
    this.C.c = "webapp";
    this.F = K.M()
};
ka(aL, WK);
aL.prototype.b = function() {
    return "ovfl-ctr"
};
aL.prototype.Xc = function(a) {
    return a && "DIV" == a.tagName ? (a = B(this.b(), a)) && B("snck-msg", a) && B("ovfl-xlt", a) ? !0 : !1 : !1
};
aL.prototype.aa = function() {
    var a = B("ovfl-xlt", this.j());
    this.w = new Sr(null, new $K);
    this.w.ba(a);
    G(this.w, "action", this.K, !1, this)
};
aL.prototype.K = function() {
    var a = this.c.c;
    "" == a && (a = this.c.a);
    var b = this.g.length,
        c = Math.max(b - this.N, 0);
    qm(this.F, b, c);
    O(this.C, "webapp", "xm", "1", {
        sl: this.c.a,
        tl: this.c.b,
        dl: a,
        hl: this.R,
        ql: b,
        ol: c
    });
    this.m.a.b(this.g);
    RK(this.m);
    var d = this.m.a,
        e = d.j();
    Ci(function() {
        e.focus();
        var f = d.Y().length;
        if (uw(e)) e.selectionStart = f, e.selectionEnd = f;
        else if (vw()) {
            f = yw(e, f);
            var g = e.createTextRange();
            g.collapse(!0);
            g.move("character", f);
            g.select()
        }
    }, 0)
};
var eL = function(a) {
        var b = DATA.DisplayLanguage;
        this.g = Gm.M();
        this.F = K.M();
        this.b = a;
        this.h = bL[1];
        this.a = cL[1];
        this.o = C("tlid-promo-notification-link", this.b);
        this.c = b;
        dL(this)
    },
    fL = function(a, b) {
        b ? (sm(a.F, a.a), a.g.log("bbarshow", {
            hl: a.c,
            type: a.h
        })) : V(a.b, "hidden", !0)
    },
    dL = function(a) {
        G(a.o, "click", function() {
            fL(this, !1);
            tm(this.F, this.a);
            this.g.log("bbarlm", {
                hl: this.c,
                type: this.h
            })
        }, !1, a)
    },
    cL = {
        1: 20
    },
    bL = {
        1: "hiring"
    };
var gL = function(a, b) {
    this.a = a;
    this.F = b;
    a: {
        b = DATA.Messages.LEARN_MORE_ABOUT_THIS;
        var c = "",
            d = "";28 > a.length && (c = DATA.Messages.LEARN_MORE_ABOUT.indexOf("%1$s"), -1 != c && (b = DATA.Messages.LEARN_MORE_ABOUT.slice(0, c), d = DATA.Messages.LEARN_MORE_ABOUT.slice(c + 4, DATA.Messages.LEARN_MORE_ABOUT.length)), c = a);a = Xp(CK, {
            Vn: b,
            ao: c,
            Wn: d,
            qe: DATA.Messages.TRY_IT.toUpperCase(),
            Cn: DATA.Messages.SEARCH_IN_BROWSER,
            Qa: DATA.Messages
        });
        break a;
        throw Error("Missing render function for GSA interstitial type gsaIntGsaWeb");
    }
    this.v =
        a;
    a: {
        break a;
        throw Error("Missing Promotion for GSA interstitial type gsaIntGsaWeb");
    }
};
gL.prototype.show = function() {
    document.body.appendChild(this.v);
    hL("show");
    sm(this.F, 21);
    sI(p(this.h, this));
    var a = this.g;
    var b = this.c;
    G(B("gsa-int-button", this.v), "click", a, !1, this);
    G(B("gsa-int-second-choice", this.v), "click", b, !1, this);
    G(B("clear", this.v), "click", this.b, !1, this)
};
var iL = function(a, b) {
    jg(a.v);
    a.v = null;
    hL(b)
};
gL.prototype.h = function() {
    iL(this, "dismissbg")
};
gL.prototype.g = function() {
    tm(this.F, 21);
    rI();
    iL(this, "accept");
    Km(mI, "/translate/uc?ua=dismiss&uav=searchgsa");
    pI(this.a, 2)
};
gL.prototype.c = function() {
    tm(this.F, 22);
    rI();
    iL(this, "webapp");
    Km(mI, "/translate/uc?ua=dismiss&uav=gsaint");
    qI(this.a)
};
gL.prototype.b = function() {
    var a = this.F;
    M(a, rm(a, 74, 21));
    rI();
    iL(this, "dismiss")
};
var hL = function(a) {
    O(mI, "webapp", "gsaIntGsaWeb", a, void 0);
    Ch("gsa", "gsaIntGsaWeb:" + a, "", 1)
};
var kL = function(a) {
        this.a = a;
        this.b = (new Date).getTime();
        jL(this, 1)
    },
    jL = function(a, b) {
        Ci(function() {
            (new Date).getTime() - this.b > 500 * b + 200 ? this.a(!0) : 8 > b ? jL(this, b + 1) : this.a(!1)
        }, 500, a)
    };
var lL = function(a, b, c, d, e, f, g, k, l) {
    J.call(this);
    var m = this;
    this.qa = a;
    this.v = b;
    this.o = c;
    this.a = new MF(d, e, f, g);
    this.ab = k;
    this.b = null;
    this.wb = new EI(this.ia, 500, this);
    a = B("starbutton", this.j());
    null != a && (this.b = new Kt, this.b.ba(a), ss(a, 2), G(this.b, "action", function() {
        m.wb.li()
    }, !1, this), Lt(this.b, l || !1));
    this.c = K.M()
};
ka(lL, J);
lL.prototype.j = function() {
    return this.v
};
lL.prototype.Ce = function() {
    return this.a.ma()
};
var mL = function(a) {
    if (a.v.parentElement && a.v.parentElement.childNodes)
        for (var b = a.v.parentElement.childNodes, c = 0; c < b.length; c++)
            if (b[c] == a.v) return c;
    return -1
};
lL.prototype.Za = function() {
    return this.a.Za()
};
lL.prototype.ia = function() {
    if (!DATA.InChina) {
        var a = null != this.b && this.b.b ? "unst" : "st",
            b = new Zm,
            c = {};
        b.g((c.op = "star", c.sl = this.a.Pa(), c.tl = this.Ce(), c.text = this.a.a, c.page = this.o, c));
        uI(a, mI, this.gb.bind(this), Ea, b.toString())
    }
};
lL.prototype.gb = function() {
    if (null != this.b) {
        var a = !(null != this.b && this.b.b);
        if (vG(this.ab, this.a, a ? 0 : 1))
            if (Lt(this.b, a), oI(a ? "star" : "unstar", this.qa, NF(this.a), this.a.ma(), this.a.a), "home" == this.o) {
                var b = this.c;
                a = N(b, a ? 67 : 180);
                var c = b.a.a;
                if (null != c) {
                    var d = new Pk;
                    c = A(d, 1, c || []);
                    lf(a, 83, c)
                }
                M(b, a)
            } else "history" == this.o ? (b = this.c, M(b, Dm(b, 64, mL(this), a))) : "saved" == this.o && (mI.log("sli=us", {}), b = this.c, M(b, Fm(b, 46)))
    }
};
var rL = function(a, b, c, d, e, f) {
    lL.call(this, "main", nL(f), "home", "", {}, "", "", b);
    var g = this;
    a.appendChild(this.j());
    this.V = oL();
    this.L = new As("", void 0, 4);
    this.L.Oa(16, !0);
    a = C("res-tts", this.j());
    this.L.ba(a);
    ss(a, 2);
    this.K = new fv(this.L, "&client=webapp", 2, !0, !0, DATA.Messages.LISTEN, DATA.Messages.VOICE_OUTPUT_UNAVAILABLE);
    G(this.K, "userInteractionWhileDisabled", this.Ta, !1, this);
    this.na = c;
    this.ra = d;
    this.O = null;
    DATA.InChina || (this.O = C("tlid-trans-verified-button", this.j()), Bh(this.O, function() {
        g.dispatchEvent("verifiedTranslationButtonClicked")
    }));
    this.G = this.w = null;
    pL(this);
    this.xa = e;
    this.N = new jK(eb(B("tlid-result-transliteration-container", this.j())), 2);
    this.C = new Sv("");
    this.C.ba(B("contribute-target", this.j()));
    this.h = null;
    this.Na = new qp("webapp");
    this.g = this.m = null;
    this.R = this.X = !1;
    this.ob = C("tlid-translation-gender-indicator", this.j());
    this.Z = new lA(qL(this), "trans", 14, "webapp", void 0, void 0, this.W.bind(this));
    new hH(qL(this), Array.from(Nf("tlid-copy-target", this.j())))
};
ka(rL, lL);
rL.prototype.T = function() {
    this.Z.Ia();
    jg(this.j());
    lL.prototype.T.call(this)
};
rL.prototype.Ca = function() {
    var a = this.a.Pa(),
        b = this.a.ma(),
        c = this.a.a.length,
        d = DATA.DisplayLanguage,
        e = qL(this);
    jA(e);
    e = xz(window).toString();
    e = kA(e);
    var f = "";
    try {
        document.execCommand("copy") ? (f = "success", qo && this.g ? jm(K.M(), this.g.Rc()) : jm(K.M()), this.dispatchEvent("translationCopied")) : (f = "failure", mm(K.M(), 157))
    } catch (g) {
        f = "error", mm(K.M(), 158)
    } finally {
        jg(e), O(mI, "webapp", "copy", f, {
            sl: a,
            tl: b,
            hl: d,
            ql: c
        })
    }
};
rL.prototype.Ta = function() {
    this.dispatchEvent("userInteractionWithDisabledVoiceOutput")
};
var sL = function(a, b, c) {
        O(mI, "webapp", a, b, c);
        Ch("gsa", a + ":" + b, "", 1)
    },
    pL = function(a) {
        tL(a);
        uL(a, "copybutton", a.Ca);
        uL(a, "tlid-share-translation-button", a.Ei);
        uL(a, "tlid-suggest-edit-button", a.Gi);
        if (a.V) {
            var b = B("result-search", a.j());
            G(b, "click", function() {
                var c = a.c;
                var d = N(c, 224);
                d = A(d, 52, "");
                M(c, d);
                sL("search" + DATA.CampaignTrackerId, "click", {
                    sl: a.a.Pa(),
                    tl: a.a.ma(),
                    hl: DATA.DisplayLanguage,
                    ql: a.a.a.length
                });
                c = a.Za();
                switch (DATA.ActionAfterSearch) {
                    case 0:
                        (new gL(c, a.c)).show();
                        break;
                    case 2:
                        qI(c);
                        break;
                    case 3:
                        pI(c, 3);
                        break;
                    default:
                        throw Error("Invalid value for DATA.ActionAfterSearch");
                }
            }, !1, a)
        }
    },
    tL = function(a) {
        var b = C("moremenu", a.j());
        a.G = new wx;
        a.G.ba(b);
        b = C("morebutton", a.j());
        a.w = new Nx(null, a.G);
        a.w.ba(b);
        Ir(a.w, DATA.Messages.MORE);
        Sx(a.w, new Zp(-8, 8, 0, 8));
        G(b, "click", function() {
            var c = this.c;
            M(c, N(c, 265));
            sL("more", "click");
            this.w.Xa(!0)
        }, !1, a);
        ss(b, 2);
        b = new qx(DATA.Messages.SUGGEST_AN_EDIT);
        b.Ja();
        G(b, "action", a.Gi, !1, a);
        T(b.j(), "tlid-suggest-edit-menu-item");
        a.G.jb(b, !0);
        b = new qx(DATA.Messages.SHARE_TRANSLATION);
        b.Ja();
        G(b, "action", a.Ei, !1, a);
        T(b.j(), "tlid-share-translation-menu-item");
        a.G.jb(b, !0)
    },
    uL = function(a, b, c) {
        b = B(b, a.j());
        if (b) {
            var d = new As("");
            d.ba(b);
            G(d, "action", c, !1, a);
            ss(b, 2)
        }
    },
    vL = function(a) {
        var b = new Sr("Clear text", new Nt("clear-button"));
        b.ba(B("gt-clear", a.j()));
        b.setVisible(!1);
        var c = $f("DIV");
        W(c, !1);
        hg(c, a.C.j());
        var d = new IE(DATA.Messages.SUBMIT_TRANSLATION_SUGGESTION, DATA.Messages.CANCEL_EDITS, DATA.Messages.EDIT_TRANSLATION_DISCLAIMER, a.ra, !0);
        d.ba(c);
        c = qL(a);
        b = new GE(a.C, B("gt-edit",
            a.j()), B("result", a.j()), a.j(), a.N.a, b);
        var e = void 0,
            f = void 0,
            g = !1,
            k = !0;
        kt() && (e = DATA.LowConfidenceThreshold, f = DATA.MaxRoundTripResults, g = !0, k = !1, vE = DATA.Messages.IMPROVE_TRANSLATION);
        a.h = new KE(void 0, g, void 0, e, f, d, b, void 0, k);
        a.h.ba(c);
        d = a.h;
        d.N.c = "webapp";
        d.xa = "webapp";
        DATA.EnablePhraseHighlighting && (d = a.h, c = a.xa, d.ia = c, d.b.C = c);
        G(a.h, "action", a.fl, !1, a)
    },
    wL = function(a) {
        var b = a.m ? a.m.zb() : void 0;
        TE(a.h, b, a.a.Pa(), a.a.ma(), DATA.DisplayLanguage) || (b = Dd(a.Za()), Td(qL(a), b))
    };
rL.prototype.update = function(a, b, c, d, e, f) {
    var g = this;
    this.a.a = a;
    OF(this.a, b);
    this.a.o = c;
    "auto" === c.toLowerCase() && (this.a.h = b.src);
    this.a.m = d;
    this.m = e || null;
    this.g = qo && f ? f : null;
    xL(this, d, this.m);
    f = B("result-shield-container", this.j());
    var k = jc(d);
    V(f, "result-rtl", k);
    qL(this).lang = d;
    this.C && cq(this.C.j(), "direction", k ? "rtl" : "ltr");
    this.h || vL(this);
    av(a) ? (f = new Rm(n.location.href.split("#")[0]), Vm(f, "translate"), hn(f, "sl", [c ? c : "auto"]), hn(f, "tl", [d]), hn(f, "u", [a]), qL(this).appendChild(Wp(AK, {
            xn: f,
            yn: a
        }))) :
        qo && this.g ? (yL(this, zI(this.g.Rc())), E(qL(this), this.Za())) : (E(qL(this), this.Za()), this.m && this.h && wL(this));
    lK(this.N, b);
    (a = B("copybutton", this.j())) && W(a, !0);
    (a = B("starbutton", this.j())) && W(a, !0);
    (a = B("result-search", this.j())) && W(a, !0);
    this.V && (xm(this.c), sL("search" + DATA.CampaignTrackerId, "show"), this.X && !this.R && Ci(function() {
        return zL(g)
    }, 0));
    this.O && null != e && (W(this.O, ev(e)), ev(e) && mI.log("community-promo", "show-webapp-served-community"))
};
var zL = function(a) {
    a.R = !0;
    Km(Gm.M(), "/translate/uc?ua=dismiss&uav=stooltip");
    var b = D("DIV");
    E(b, DATA.Messages.SEARCH_THIS_TRANSLATION);
    cq(b, "white-space", "nowrap");
    var c = B("result-search-icon", a.j()),
        d = new GG;
    d.c.c = c;
    LG(d);
    KG(d, b);
    HG(d, 0, 0, -20);
    d.c.Qf = !0;
    IG(d, !0);
    d.h = !0;
    d.render();
    T(d.j(), "trans-bubble");
    d.setVisible(!0);
    O(mI, "webapp", "searchtooltip", "show");
    Ch("gsa", "searchtooltip:show", "", 1);
    G(B("jfk-bubble-closebtn", d.j()), "click", function() {
        O(mI, "webapp", "searchtooltip", "dismiss");
        Ch("gsa", "searchtooltip:dismiss",
            "", 1)
    }, !1, a);
    window.onresize = function() {
        d.isDisposed() || LG(d)
    }
};
rL.prototype.Za = function() {
    return qo && this.g ? this.g.tb() : lL.prototype.Za.call(this)
};
var qL = function(a) {
    return C("tlid-translation", a.j())
};
rL.prototype.W = function() {
    return this.g ? this.g.Rc() : void 0
};
var yL = function(a, b) {
        E(a.ob, b)
    },
    AL = function(a, b, c) {
        if (!(wd() && qe() && re(9))) var d = setTimeout(function() {
                c(!0);
                new kL(function(f) {
                    f && c(!1)
                })
            }, 200),
            e = G(document, b, function() {
                clearTimeout(d);
                ph(e)
            }, !1, a)
    };
h = rL.prototype;
h.Ei = function() {
    var a = this;
    B("share-module", this.j()) && jg(B("share-module", this.j()));
    var b = Ae && (!Fe || Fe && 0 <= Lc(Yr, 8)),
        c = BL(),
        d;
    DATA.Messages.SHARE_MODULE_TITLE && c && (d = DATA.Messages.SHARE_APP_NOT_INSTALLED.replace("%1$s", "WhatsApp"));
    b = Xp(BK, {
        xo: this.Za(),
        Qa: DATA.Messages,
        Eo: d,
        Kk: b,
        Nk: Ae,
        gm: Fe || Ge
    });
    ig(B("result-footer", this.j()), b, 0);
    Dt(this.na, this.a.Pa(), this.a.ma(), this.a.a, !1, "share");
    b = B("tlid-share-panel", this.j());
    T(b, "show-share-panel");
    sI(p(this.Ji, this));
    Qf(b, {
        "aria-hidden": !1
    });
    b.focus();
    G(b, "keydown", function(e) {
        27 === e.keyCode && (rI(), a.Ji())
    }, !1);
    O(mI, "webapp", "share", "share", {
        sl: this.a.Pa(),
        tl: this.a.ma(),
        hl: DATA.DisplayLanguage,
        ql: this.a.a.length
    });
    ym("share");
    b = B("share-panel-wrap", this.j());
    b = Mf(document, "a", "", b);
    w(b, function(e) {
        G(e, "click", p(this.ll, this, e), !1, this)
    }, this)
};
h.Ji = function() {
    var a = B("tlid-share-panel", this.j());
    U(a, "show-share-panel");
    Qf(a, {
        "aria-hidden": !0
    });
    BL() && (a = Kf("not_installed")) && yq(a) && W(a, !1);
    Dt(this.na, this.a.Pa(), this.a.ma(), this.a.a, !1)
};
h.ll = function(a) {
    a = a.className.split(" ")[0];
    O(mI, "webapp", "share", a, {
        sl: this.a.Pa(),
        tl: this.a.ma(),
        hl: DATA.DisplayLanguage,
        ql: this.a.a.length
    });
    ym(a);
    var b = BL();
    if (b) {
        var c = Kf("not_installed");
        c && yq(c) && "whatsapp" !== a ? W(c, !1) : "whatsapp" === a && AL(this, b, function(d) {
            d ? (d = c.style, d.position = "relative", y && !Qe("8") ? (d.zoom = "1", d.display = "inline") : d.display = "inline-block") : W(c, !1)
        })
    }
};
h.Gi = function() {
    O(mI, "webapp", "editclk", "1", {
        sl: this.a.Pa(),
        tl: this.a.ma()
    });
    var a = this.c;
    M(a, N(a, 26));
    XE(this.h)
};
h.fl = function(a) {
    var b = UE(a.target);
    a = a.target.Ce();
    b != this.Za() && W(B("trans-verified-button", this.j()), !1);
    PF(this.a, b);
    up(this.Na, b, a, function(c) {
        kK(this.N, c)
    }.bind(this));
    this.K.update(b, a);
    this.dispatchEvent("resultTextEdited")
};
var BL = function() {
        var a = {
                hidden: "visibilitychange",
                webkitHidden: "webkitvisibilitychange",
                mozHidden: "mozvisibilitychange",
                msHidden: "msvisibilitychange"
            },
            b;
        for (b in a)
            if (b in document) {
                var c = a[b];
                break
            } return c
    },
    xL = function(a, b, c) {
        a.K.update(a.Za(), b, c, CL(b), a.W())
    },
    CL = function(a) {
        for (var b = "", c = Nb(DATA.TargetLanguageCodeNameList), d = 0; d < c.length; d++) c[d].Code === a && (b = c[d].Name);
        return b
    };

function oL() {
    var a = qe() && re(9);
    return DATA.EnableSearchIcon && a
}

function nL(a) {
    a = void 0 === a ? {} : a;
    var b = void 0 === a.Ag ? kt() || Ye && Ck(43) || qe() && re(10) : a.Ag,
        c = void 0 === a.Bg ? oL() : a.Bg;
    return Xp(zK, {
        Qa: DATA.Messages,
        Em: "Copy translation",
        Gm: "Star translation",
        Ag: b,
        Bg: c,
        Mc: void 0 === a.Mc ? !DATA.InChina : a.Mc
    })
};
var DL = function(a) {
    var b = this;
    this.v = a;
    this.a = !1;
    this.b = C("tlid-gender-promo-dismiss-button", this.v);
    G(this.b, "click", function() {
        b.a = !0;
        b.setVisible(!1);
        Km(Gm.M(), "/translate/uc?ua=dismiss&uav=genderpromo");
        var c = K.M(),
            d = N(c, 341);
        M(c, d)
    })
};
DL.prototype.setVisible = function(a, b) {
    b = void 0 === b ? !1 : b;
    a && !this.a ? (V(this.v, "gender-promo-is-single-word", b), V(this.v, "gender-promo-visible", !0), a = K.M(), b = N(a, 340), M(a, b)) : V(this.v, "gender-promo-visible", !1)
};
var FL = function(a, b, c, d, e, f) {
    J.call(this);
    this.w = 0;
    this.v = a;
    this.b = b;
    this.N = c;
    this.O = d;
    this.R = e;
    this.K = C("tlid-result-error", this.b);
    this.h = C("tlid-translation-error", this.v);
    this.L = C("tlid-translation-error-message", this.v);
    this.C = B("tlid-result-view-error-button", this.v) || null;
    this.G = B("tlid-result-container-error-button", this.b) || null;
    this.g = C("gt-lc", this.v);
    this.m = new Cw(DATA.Messages.COMMUNITY_CARD_LEARN_MORE, "", DATA.Messages.THANKS_FOR_CONTRIBUTING, DATA.Messages.CONTRIBUTION_BENEFIT, DATA.InChina ?
        "" : "/community?source=webapp-user-edit", "webapp-user-edit", 15);
    this.m.ba(C("cp-promo-wrapper", this.v));
    this.o = f ? new DL(f) : null;
    this.c = null;
    this.a = [];
    this.F = K.M();
    EL(this)
};
ka(FL, J);
FL.prototype.T = function() {
    GL(this);
    this.v = null;
    J.prototype.T.call(this)
};
var EL = function(a) {
        null != a.G && Bh(eb(a.G), function() {
            a.dispatchEvent("g")
        });
        null != a.C && Bh(eb(a.C), function() {
            a.dispatchEvent("g")
        })
    },
    HL = function(a) {
        if (!a.a[0]) throw Error("getTranslationData called without calling hasTranslationData first");
        return a.a[0].a
    };
FL.prototype.j = function() {
    return this.v
};
var IL = function(a) {
    return qo && yI(a.c) ? AI(a.c).map(function(b) {
        return b.tb()
    }).join("\n") : a.a[0] ? HL(a).Za() : ""
};
FL.prototype.update = function(a, b, c, d, e) {
    var f = this;
    GL(this);
    this.c = e || null;
    rI();
    W(this.h, !1);
    JL(this, 2);
    U(this.b, "result-error");
    qo && yI(this.c) && to(I(this.c, 2), d) ? (KL(this, !0, !("tr" === I(this.c, 2) && "en" === d)), e = AI(this.c), Cm(this.F, e), this.a = e.map(function(g, k) {
        k = LL(f, {
            Mc: 0 === k
        });
        k.update(a, b, c, d, f.c, g);
        return k
    })) : (KL(this, !1), e = LL(this), e.update(a, b, c, d, this.c), this.a = [e]);
    ML(this, !1);
    W(this.g, !0)
};
var LL = function(a, b) {
        b = new rL(a.b, a.N, a.O, a.m, a.R, b);
        b.Fd(a);
        return b
    },
    JL = function(a, b) {
        a.w = b;
        switch (b) {
            case 1:
                U(a.b, "result-error");
                T(a.b, "translating");
                a = ba(a.a);
                for (b = a.next(); !b.done; b = a.next()) {
                    b = b.value;
                    b.L.oa(!1);
                    var c = Dg(qL(b));
                    0 != c.length && E(qL(b), c + "...")
                }
                break;
            case 2:
                U(a.b, "translating")
        }
    };
FL.prototype.getState = function() {
    return this.w
};
var GL = function(a) {
        for (var b = ba(a.a), c = b.next(); !c.done; c = b.next()) c = c.value, c.K.stop(), c.Ia();
        a.a = [];
        a.c = null
    },
    NL = function(a, b, c) {
        if (a.a[0] && QF(HL(a), b)) {
            for (var d = ba(a.a), e = d.next(); !e.done; e = d.next()) e = e.value, null != e.b && Lt(e.b, c);
            b = b.c;
            null != b && (HL(a).c = b)
        }
    },
    OL = function(a) {
        a = ba(a.a);
        for (var b = a.next(); !b.done; b = a.next()) b.value.X = !0
    },
    ML = function(a, b) {
        V(a.b, "empty", b);
        V(a.v, "empty", b)
    },
    KL = function(a, b, c) {
        V(a.b, "gendered-translations", b);
        a.o && a.o.setVisible(b, c)
    };
var QL = function(a, b, c) {
        var d = DATA.DisplayLanguage,
            e = DATA.Messages,
            f = this;
        this.a = a;
        this.C = C("tlid-survey-contents", this.a);
        this.L = C("tlid-dismiss-survey", this.a);
        this.o = C("tlid-before-survey", this.a);
        this.h = C("tlid-after-survey", this.a);
        this.m = C("tlid-more-feedback", this.a);
        this.O = PL(this, e);
        w(this.O, function(g) {
            return f.C.appendChild(g)
        });
        this.K = d;
        this.c = c;
        this.Fa = b;
        this.F = K.M();
        this.g = Gm.M();
        G(this.L, "click", p(this.b, this, 0), !1, this);
        G(this.m, "click", this.w, !1, this)
    },
    PL = function(a, b) {
        b = [
            [b.HAPPINESS_SURVEY_OPTION1,
                0
            ],
            [b.HAPPINESS_SURVEY_OPTION2, 1],
            [b.HAPPINESS_SURVEY_OPTION3, 2],
            [b.HAPPINESS_SURVEY_OPTION4, 3],
            [b.HAPPINESS_SURVEY_OPTION5, 4]
        ];
        for (var c = [], d = 0; d < b.length; d++) {
            var e = b[d],
                f = e[1];
            e = Xp(DK, {
                message: e[0],
                dn: f
            });
            c.push(e);
            G(e, "click", p(a.G, a, f), !1, a)
        }
        return c
    };
QL.prototype.G = function(a) {
    var b = this.F,
        c = N(b, 262);
    var d = new il;
    d = A(d, 1, a + 1);
    lf(c, 72, d);
    M(b, c);
    RL(this, "select" + a);
    W(this.o, !1);
    W(this.h, !0);
    this.b(1E4)
};
QL.prototype.w = function() {
    this.b(0);
    this.Fa.call()
};
var RL = function(a, b) {
    var c = {},
        d = a.c.a,
        e = a.c.c;
    "auto" === d && "" !== e && (d = e);
    c.sl = d;
    c.tl = a.c.b;
    c.hl = a.K;
    c.e = b;
    a.g.log("survey", c)
};
QL.prototype.show = function() {
    U(this.a, "hidden");
    var a = this.F;
    M(a, N(a, 261));
    RL(this, "show")
};
QL.prototype.b = function(a) {
    var b = this;
    Km(this.g, "/translate/uc?ua=dismiss&uav=survey");
    Ci(function() {
        (new tF(b.a, 300)).play()
    }, null != a ? a : 0, this)
};
var TL = function(a) {
    J.call(this);
    this.F = K.M();
    this.v = a;
    this.h = C("tlid-toast-message", this.v);
    this.c = C("tlid-toast-action", this.v);
    a = Of("A", "tlid-toast-action-link", this.c);
    this.b = eb(a);
    this.o = C("tlid-toast-action-text", this.c);
    this.g = new Ur(this.m, 5E3, this);
    this.a = null;
    SL(this)
};
ka(TL, J);
var VL = function(a, b) {
        T(a.v, "with-message");
        U(a.v, "with-action");
        E(a.h, b);
        UL(a)
    },
    UL = function(a) {
        a.g.nb() || ((new uF(a.v, 218)).play(), a = a.g, a.nb() || a.start(void 0))
    };
TL.prototype.m = function() {
    (new tF(this.v, 218)).play()
};
var SL = function(a) {
    G(a.b, "click", p(function() {
        null != a.a && a.dispatchEvent(a.a)
    }, a), !1, a)
};
var WL = function() {};
ka(WL, xr);
WL.prototype.Zc = function(a) {
    return a && "SPAN" == a.tagName ? !0 : !1
};
var XL = function(a) {
    WK.call(this);
    this.g = a;
    this.m = new Gm;
    this.m.c = "webapp";
    this.c = null
};
ka(XL, WK);
XL.prototype.b = function() {
    return "cmty-ctr"
};
XL.prototype.Xc = function(a) {
    if (!a || "DIV" != a.tagName) return !1;
    a = B("cmty-ctr", a);
    if (!a || "DIV" != a.tagName) return !1;
    var b = B("snck-msg", a);
    return b && "SPAN" == b.tagName ? (a = B("cmty-btn", a)) && "SPAN" == a.tagName ? !0 : !1 : !1
};
XL.prototype.aa = function() {
    B("snck-msg", this.j()).textContent = MSG_VERIFIED_BY_COMMUNITY;
    var a = B("cmty-btn", this.j());
    a.textContent = MSG_JOIN;
    this.c = new Sr(null, new WL);
    this.c.ba(a);
    G(this.c, "action", this.w, !1, this)
};
XL.prototype.w = function() {
    this.m.log("community-promo", "click-" + this.g);
    this.setVisible(!1);
    Zd("/community?source=" + this.g)
};
Wi("wireless.events.ListenerCoalescer");
var YL = function(a) {
    Dl(this, a, 2)
};
t(YL, Cl);
var ZL = {
    language: {
        H: 0,
        J: !1
    },
    state: {
        H: 1,
        J: !1
    }
};
YL.prototype.za = function() {
    return ZL
};
YL.prototype.Ea = function() {
    return Eh(this, 1)
};
YL.prototype.getState = function() {
    return Fl(this, 1)
};
var $L = function(a) {
    Dl(this, a, 4)
};
t($L, Cl);
var aM = {
    language: {
        H: 0,
        J: !1
    },
    state: {
        H: 1,
        J: !1
    },
    tool_id: {
        H: 2,
        J: !1
    },
    element_id: {
        H: 3,
        J: !1
    }
};
$L.prototype.za = function() {
    return aM
};
$L.prototype.Ea = function() {
    return Eh(this, 1)
};
$L.prototype.getState = function() {
    return Fl(this, 1)
};
var bM = function(a) {
    Dl(this, a, 19)
};
t(bM, Cl);
var cM = {
    vkeyboard: {
        H: 0,
        va: function(a) {
            return Kl(YL, a)
        },
        sa: function(a) {
            return Jl(new YL(a))
        },
        J: !0
    },
    source_romanization: {
        H: 1,
        va: function(a) {
            return Kl(YL, a)
        },
        sa: function(a) {
            return Jl(new YL(a))
        },
        J: !0
    },
    result_romanization: {
        H: 2,
        va: function(a) {
            return Kl(YL, a)
        },
        sa: function(a) {
            return Jl(new YL(a))
        },
        J: !0
    },
    input_t13n: {
        H: 3,
        va: function(a) {
            return Kl(YL, a)
        },
        sa: function(a) {
            return Jl(new YL(a))
        },
        J: !0
    },
    default_source_romanization: {
        H: 4,
        J: !1
    },
    default_result_romanization: {
        H: 5,
        J: !1
    },
    dismiss_chrome_promotion: {
        H: 6,
        J: !1
    },
    source_example: {
        H: 7,
        J: !1
    },
    result_example: {
        H: 8,
        J: !1
    },
    input_tool: {
        H: 9,
        va: function(a) {
            return Kl($L, a)
        },
        sa: function(a) {
            return Jl(new $L(a))
        },
        J: !0
    },
    dismiss_phrasebook_promo: {
        H: 10,
        J: !1
    },
    dismiss_survey: {
        H: 11,
        J: !1
    },
    dismiss_gsa_pure_ad: {
        H: 12,
        J: !1
    },
    dismiss_search_tooltip: {
        H: 13,
        J: !1
    },
    dismiss_gsa_interstitial: {
        H: 14,
        J: !1
    },
    dismiss_gsa_prompt: {
        H: 15,
        J: !1
    },
    search_direct_gsa: {
        H: 16,
        J: !1
    },
    dismiss_android_translate: {
        H: 17,
        J: !1
    },
    dismiss_android_translate5: {
        H: 18,
        J: !1
    }
};
bM.prototype.za = function() {
    return cM
};
var dM = function(a) {
    Dl(this, a, 2)
};
t(dM, Cl);
var eM = {
    source_language: {
        H: 0,
        J: !1
    },
    target_language: {
        H: 1,
        J: !1
    }
};
dM.prototype.za = function() {
    return eM
};
dM.prototype.Ce = function() {
    return I(this, 1)
};
var fM = function(a) {
    Dl(this, a, 6)
};
t(fM, Cl);
var gM = {
    recent_sl: {
        H: 0,
        J: !0
    },
    recent_tl: {
        H: 1,
        J: !0
    },
    recent_lp: {
        H: 2,
        va: function(a) {
            return Kl(dM, a)
        },
        sa: function(a) {
            return Jl(new dM(a))
        },
        J: !0
    },
    sel_auto: {
        H: 3,
        J: !1
    },
    default_sl: {
        H: 4,
        J: !1
    },
    default_tl: {
        H: 5,
        J: !1
    }
};
fM.prototype.za = function() {
    return gM
};
var hM = function(a) {
    Dl(this, a, 3)
};
t(hM, Cl);
var iM = {
    recent_lang: {
        H: 0,
        va: function(a) {
            return Kl(fM, a)
        },
        sa: function(a) {
            return Jl(new fM(a))
        },
        J: !1
    },
    eotf: {
        H: 1,
        J: !1
    },
    stickiness_data: {
        H: 2,
        va: function(a) {
            return Kl(bM, a)
        },
        sa: function(a) {
            return Jl(new bM(a))
        },
        J: !1
    }
};
hM.prototype.za = function() {
    return iM
};
var jM = function(a, b, c) {
    a.timeOfStartCall = (new Date).getTime();
    var d = c || n,
        e = d.document,
        f = Ba(d);
    f && (a.nonce = f);
    if ("help" == a.flow) {
        var g = Da("document.location.href", d);
        !a.helpCenterContext && g && (a.helpCenterContext = g.substring(0, 1200));
        g = !0;
        if (b && JSON && JSON.stringify) {
            var k = JSON.stringify(b);
            (g = 1200 >= k.length) && (a.psdJson = k)
        }
        g || (b = {
            invalidPsd: !0
        })
    }
    b = [a, b, c];
    d.GOOGLE_FEEDBACK_START_ARGUMENTS = b;
    c = a.serverUri || "//www.google.com/tools/feedback";
    if (g = d.GOOGLE_FEEDBACK_START) g.apply(d, b);
    else {
        d = c + "/load.js?";
        for (var l in a) b = a[l], null == b || La(b) || (d += encodeURIComponent(l) + "=" + encodeURIComponent(b) + "&");
        a = Hg(Jf(e), "SCRIPT");
        f && a.setAttribute("nonce", f);
        Wd(a, Kw(d));
        e.body.appendChild(a)
    }
};
ya("userfeedback.api.startFeedback", jM);
var kM = aB("showhistory"),
    pM = aB("showinstant"),
    qM = aB("showsaved"),
    rM = aB("showfeedback"),
    sM = aB("showlanguagepicker"),
    tM = aB("urltranslation"),
    HM = function(a, b) {
        var c = uM,
            d = vM,
            e = wM,
            f = xM,
            g = this;
        this.K = vl();
        this.F = K.M();
        this.F.config(Jj() || "0", EXPERIMENT_IDS);
        this.K.c = c;
        this.K.g = d;
        this.xa = "closed";
        this.w = Gm.M();
        this.ab = new rG(this.gk.bind(this), this.Oj.bind(this), this.Jo.bind(this), this.w);
        this.gb = a;
        this.b = b;
        this.b.c = this;
        this.Wj = e;
        this.Yj = f;
        this.jd = new qp("webapp");
        this.wb = new Xu;
        this.ea = new gw(p(this.Gj,
            this), !0);
        so();
        this.L = new MA(this.ea);
        a = yM() ? "\u5373\u523b\u4e0b\u8f7dGoogle\u7ffb\u8bd1 app\uff01" : .5 > Math.random() ? DATA.Messages.TRANSLATE_PURE_AD_TEXT_SPEAK : DATA.Messages.TRANSLATE_PURE_AD_TEXT_READ;
        this.Hj = iz.M();
        zM(this);
        this.v = Xp(wK, {
            fk: a,
            pk: pM,
            wk: c,
            xk: d,
            Bk: DATA.InChina && "zh-CN" === DATA.DisplayLanguage,
            Ck: !DATA.InChina,
            Ek: DATA.DisplayHappinessSurvey,
            Fk: DATA.EnableHiringPromo,
            Ra: DATA.DisplayLanguage,
            Gk: !DATA.InChina,
            Ik: DATA.EnableCommunityInstant && DATA.SignedIn,
            Jk: DATA.CompareProdTrans,
            Lk: kt(),
            Mk: DATA.UrlTranslation,
            fm: kM,
            Tq: DATA.InChina,
            Qa: DATA.Messages,
            Fm: DATA.Messages.NO_THANKS.toUpperCase(),
            Hm: DATA.Messages.TRY_THE_APP.toUpperCase(),
            on: yM() || AM(),
            pn: !kt(),
            qn: BM(),
            rn: DATA.SignedIn,
            zn: qM,
            Ln: Nb(DATA.SourceLanguageCodeNameList),
            Zn: Nb(DATA.TargetLanguageCodeNameList),
            Go: tM
        });
        a = jc(DATA.DisplayLanguage);
        V(document.body, "rtl-display-lang", a);
        this.g = C("tlid-homepage", this.v);
        T(document.body, "displaying-homepage");
        this.O = new fK(C("tlid-history-page", this.v), this.ab);
        this.Fa = DATA.EnableCommunityInstant &&
            DATA.SignedIn ? new UK(C("tlid-instant-page", this.v)) : null;
        this.bc = this.c = null;
        this.he = C("tlid-language-picker-page", this.v);
        this.ke = C("tlid-source-target", this.v);
        this.a = new MK(C("tlid-input", this.g), this.ke, c, d, this.ea, this.L);
        this.Lj = new jE(this.a.a.j());
        this.Nh = new ZK;
        this.Nh.ba(B("ntfcn", this.a.j()));
        this.ld = new XL("webapp-served-community");
        this.ld.ba(B("cmty", this.a.j()));
        a = this.xb = null;
        DATA.EnableGenderedTranslationsPromo && (a = Xp(yK, {
            In: "en" === DATA.DisplayLanguage,
            Qa: DATA.Messages
        }));
        this.h =
            new FL(C("tlid-result-view", this.v), C("tlid-results-container", this.ke), this.ab, this.b, this.Lj, a);
        this.ob = this.hd = null;
        if (this.Na = B("tlid-input-button-container", this.g)) this.hd = C("tlid-input-button-text", this.Na), this.ob = C("tlid-input-button-docs", this.Na);
        (b = B("tlid-app-download-bar", this.g)) && new xH(b);
        this.ie = null;
        DATA.CompareProdTrans && (this.ie = C("tlid-prod-translation", this.g));
        this.X = null;
        DATA.CompareProdTrans && (this.X = new yH(C("tlid-brain-logos-container", this.g)));
        this.W = null;
        this.G = new ov(DATA.DisplayLanguage,
            this.jd, this, !0);
        this.md = new Ns(DATA.DisplayLanguage, [DATA.Messages.COMMON_TRANSLATION, DATA.Messages.UNCOMMON_TRANSLATION, DATA.Messages.RARE_TRANSLATION, MSG_N_MORE_TRANSLATIONS_LABEL], !0, !1, !0, DATA.Messages.TRANSLATION_FREQUENCY, DATA.Messages.TRANSLATION_FREQUENCY_HELP_TEXT);
        this.Id = new Gw(DATA.DisplayLanguage, !0, !0, !0);
        this.nd = new Lw(DATA.DisplayLanguage, !0, !0);
        this.Bo = new vF(DATA.DisplayLanguage, !0, !0);
        this.Kj = new gH(DATA.DisplayLanguage, !0, !0);
        this.Ob = [];
        b = {
            Nc: this.a.Nc,
            tj: this.a.a,
            Za: function() {
                return IL(g.h)
            }
        };
        e = B("outer-wrap", this.he);
        e.appendChild(this.a.b.j());
        e.appendChild(this.a.g.j());
        this.ac = B("tlid-language-list-toolbar", this.he);
        this.jn = B("tlid-language-list-back-button", this.ac);
        this.Lh = new As;
        this.Lh.ba(this.jn);
        this.Mh = B("tlid-language-list-label", this.ac);
        this.ra = new As;
        this.ra.ba(B("tlid-language-list-search-button", this.ac));
        this.ra.xd(DATA.Messages.SEARCH_LANGUAGES);
        NA(this.a.b, function() {
            g.R({})
        }, this);
        NA(this.a.g, function() {
            g.R({})
        }, this);
        e = this.a.b;
        f = this.a.g;
        Wb(b, {
            ij: e,
            rj: f,
            fj: this.ra,
            hj: e.G,
            qj: f.G
        });
        PA(this.L, b);
        this.ea.g(c);
        this.ea.h(d);
        c = B("ovfl", this.a.j());
        this.Th = new aL(this.a, this.ea, DATA.DisplayLanguage, DATA.MaxSingleQueryLength);
        this.Th.ba(c);
        this.Ta = null;
        if (c = B("tlid-character-count", this.g)) this.Ta = new Lv(DATA.MaxSingleQueryLength, "normal", "overflow"), this.Ta.ba(c), this.Ta.init();
        this.Xj = new zw(this.a.a, this.ea, this.Th, null != this.Ta ? this.Ta : void 0);
        this.Xj.init();
        c = B("tlid-spelling-correction", this.a.j());
        this.V = new VG(this, DATA.Messages.LANGUAGE_CORRECTION, DATA.Messages.DID_YOU_MEAN,
            DATA.Messages.SPELLING_AUTO_CORRECTION, DATA.Messages.SPELLING_REVERT_CORRECTION, p(this.a.b.V, this.a.b));
        this.V.ba(c);
        this.G.ba(B("gt-lc", this.h.j()));
        a && this.G.b.j().appendChild(a);
        this.G.b.jb(this.md, !0);
        this.G.c.jb(this.Id, !0);
        this.G.c.jb(this.nd, !0);
        this.G.c.jb(this.Kj, !0);
        this.G.c.jb(this.Bo, !0);
        this.Tn = new YD(this.a.a, !DATA.DisableOtf, p(this.na, this, !0), p(this.jd.m, this.jd));
        this.Do = new Lq(this);
        this.Do.listen(Jf().a, "scroll", this.Nj);
        this.Ve = Uf(document).a;
        this.je = {};
        this.C || (this.C = new pB(this,
            "Controller"), rB(this.C, kM, this.Qk), rB(this.C, qM, this.dm), rB(this.C, pM, this.Xk), rB(this.C, rM, this.Ca), rB(this.C, sM, this.R), rB(this.C, tM, this.Lo), qB.a.push(this.C));
        this.Sm = qe() && re(9);
        yM() ? CM(this, "http://www.gstatic.cn/translate/dl/android.html", 11) : DATA.InChina || (BM() ? DM(this, "gsa-promo", "gsaAd", "gsaad", 12, Sa(Ch, "gsa", "gsaAd:show", "", 1), Sa(Ch, "gsa", "gsaAd:dismiss", "", 1), p(this.bk, this)) : AM() ? CM(this, "https://play.google.com/store/apps/details?id=com.google.android.apps.translate&referrer=utm_source%3DMobileWebBanner%26utm_content%3DPureAd%26utm_campaign%3DTranslateAndroid&pcampaignid=Translate_022016",
            9) : DATA.EnableHiringPromo && fL(new eL(C("tlid-magnet-promo", this.v)), !0));
        c = B("tlid-survey", this.v);
        this.Sh = null;
        c && (this.Sh = new QL(c, p(this.Ca, this), this.ea), Ci(function() {
            this.Sh.show()
        }, 6E4, this));
        this.m = null;
        c = C("tlid-send-feedback-link", this.v);
        G(c, "click", this.Ca, !1, this);
        this.kd = this.le = 0;
        this.pd = this.We = this.o = "";
        void 0 !== DATA.RecentLanguages && void 0 !== DATA.RecentLanguages.recent_sl && (OB(this.a.b, DATA.RecentLanguages.recent_sl), OB(this.a.g, DATA.RecentLanguages.recent_tl));
        this.ia = "";
        this.N =
            new TL(C("tlid-toast", this.v));
        EM(this);
        FM(this);
        GM(this)
    },
    FM = function(a) {
        a.hd && Bh(a.hd, function() {
            var c = Bt(a.b);
            dt(c, a.ea.a, a.ea.b);
            a.b.a(c.toString(), !0);
            IM(a)
        });
        a.ob && Bh(a.ob, function() {
            var c = Bt(a.b),
                d = a.ea.a,
                e = a.ea.b;
            ct(c);
            c.a.set("op", "docs");
            null != d && c.a.set("sl", d);
            null != e && c.a.set("tl", e);
            a.b.a(c.toString(), !0);
            JM(a)
        });
        a.Na && G(a.Na, "keydown", function(c) {
            Ah(c, [a.hd, a.ob])
        }, !1);
        G(a.ac, "touchmove", KM);
        G(a.Lh, "action", function() {
            a.R({})
        }, !1, a);
        G(a.ra, "action", a.ln, !1, a);
        G(a.ra.j(), "keydown", a.Hk,
            !1, a);
        G(a.a, "translateButtonClicked", a.Qj, !1, a);
        G(a.O, "history_entry_selected", function(c) {
            yt(a, c.hb, c.ib, c.text)
        }, !1);
        G(a.O, "close_requested", a.La, !1, a);
        G(a.O, "history_cleared", a.Yj, !1, a);
        a.Fa && (G(a.Fa, "close_requested", a.Zj, !1, a), G(a.Fa, "tasks_available", a.Nm, !1, a), G(a.Fa, "sign_in_requested", a.Rj, !1, a));
        G(a.a.a, "clear", a.Qh, !1, a);
        G(document, "click", a.dk, !0, a);
        var b = Kf("trans-onebar-feedback");
        b && (G(b, "click", a.Ca, !1, a), G(b, "keypress", function(c) {
            13 == c.keyCode && this.Ca()
        }, !1, a));
        G(a.ea, "srcSuggestionUpdated",
            a.Fo, !1, a);
        G(a.ea, "languageSelected", a.Fj, !1, a);
        G(a.ea, "tgtLanguageUpdated", a.pm, !1, a);
        G(a.b, "c", function(c) {
            LM(a, c.Ah)
        }, !1);
        a.L.h && (G(a.L.h, "clickSelected", a.hm, !1, a), G(a.L.h, "click", a.Z, !1, a));
        a.L.m && (G(a.L.m, "clickSelected", a.qm, !1, a), G(a.L.m, "click", a.Z, !1, a), G(a.a.Nc, "action", a.Z, !1, a));
        Bh(C("tlid-open-source-language-list", a.g), a.Ih.bind(a));
        Bh(C("tlid-open-target-language-list", a.g), a.Jh.bind(a));
        Bh(C("tlid-open-small-source-language-list", a.g), a.Ih.bind(a));
        Bh(C("tlid-open-small-target-language-list",
            a.g), a.Jh.bind(a));
        DATA.CompareProdTrans && G(a.a, "inputCleared", function() {
            E(this.ie, "")
        }, !1, a);
        G(a.h, "verifiedTranslationButtonClicked", function() {
            a.ld.setVisible(!0, 8E3);
            a.w.log("community-promo", "open-webapp-served-community")
        });
        G(a.h, "g", function() {
            a.na(!1)
        }, !1);
        G(a.h, "resultTextEdited", function() {
            MM(a)
        }, !1);
        G(a.h, "translationCopied", function() {
            VL(this.N, "Translation copied")
        }, !1, a);
        G(a.a, "userInteractionWithDisabledVoiceInput", function() {
            if ("auto" === this.ea.a) VL(this.N, DATA.Messages.CHOOSE_LANGUAGE_TO_ENABLE_VOICE_INPUT);
            else {
                var c = wI(this.ea.a);
                VL(this.N, this.wb.a(DATA.Messages.VOICE_INPUT_UNAVAILABLE, c))
            }
        }, !1, a);
        G(a.a, "userInteractionWithDisabledVoiceOutput", function() {
            var c = wI(this.ea.a);
            VL(this.N, this.wb.a(DATA.Messages.VOICE_OUTPUT_UNAVAILABLE, c))
        }, !1, a);
        G(a.h, "userInteractionWithDisabledVoiceOutput", function() {
            var c = xI(this.ea.b);
            VL(this.N, this.wb.a(DATA.Messages.VOICE_OUTPUT_UNAVAILABLE, c))
        }, !1, a);
        G(a.N, "unsupported_filetype_learn_more_clicked", function() {
            var c = a.F,
                d = N(c, 309);
            var e = new $k;
            e = A(e, 1, 1);
            lf(d, 79,
                e);
            M(c, d);
            O(a.w, "webapp", "lm", "dtft", {});
            Zd("https://support.google.com/translate/answer/2534559?hl=" + DATA.DisplayLanguage)
        }, !1);
        b = new AG([a.a.a.j()], [C("tlid-results-container", a.ke)]);
        G(b, "select", a.G.Jl, !1, a.G);
        G(window, "beforeunload", function(c) {
            NM(a, c.type);
            a.m && OM(a, a.m.a, a.m.w, a.m.Pa(), a.m.ma())
        }, !1);
        G(a.a, "inputPasted", function() {
            PM(a, dw(a.a.a)) ? a.le++ : a.kd++
        }, !1);
        G(a.G, "translationRefreshed", function() {
            window.scrollTo(0, 0)
        }, !1, a);
        new IA(a.L)
    },
    IM = function(a) {
        var b = a.F;
        M(b, N(b, 295));
        O(a.w,
            "webapp", "ib", "t", {});
        T(a.g, "translate-text");
        U(a.g, "translate-docs")
    },
    JM = function(a) {
        var b = a.F;
        M(b, N(b, 296));
        O(a.w, "webapp", "ib", "d", {});
        null == a.xb && QM(a);
        U(a.g, "translate-text");
        T(a.g, "translate-docs")
    };
HM.prototype.Hk = function(a) {
    var b = this.a.b.isVisible() ? this.a.b : this.a.g.isVisible() ? this.a.g : void 0;
    if (b) switch (a.keyCode) {
        case 27:
            b.close();
            a.preventDefault();
            break;
        case 40:
            b.a[0].j().focus();
            a.preventDefault();
            break;
        default:
            b.X && b.X(a)
    }
};
HM.prototype.dk = function(a) {
    var b = eb(a.target);
    b.classList.contains("tlid-trans-verified-button") || pg(this.ld.j(), b) || this.ld.setVisible(!1);
    pg(this.he, b) || pg(C("tlid-language-bar"), b) || this.Z(a)
};
var LM = function(a, b) {
        var c = new at(b);
        "history" === c.b ? RM() || SM(a) : "instant" === c.b ? TM() || UM(a) : "saved" === c.b ? VM() || WM(a) : (v("home" === c.b, "Invalid view token in the URL fragment"), Qp(document.body, "displaying-homepage") || a.La());
        if (gt(c, "star")) "history" === c.b ? (a.ia = "", gK(a.O, c.Pa(), c.ma(), ft(c, "text"))) : (v("home" === c.b, "Invalid view token in the URL fragment for STAR operation"), a.ea.g(c.Pa()), a.ea.h(c.ma()), a.a.a.g(ft(c, "text")), a.na(!1), xD(a.a.O), a.Rh = !0);
        else if (gt(c, "docs")) {
            Qp(a.g, "translate-docs") ||
                JM(a);
            c = Nb(DATA.SourceLanguageCodeNameList).map(function(e) {
                return e.Code
            });
            var d = Nb(DATA.TargetLanguageCodeNameList).map(function(e) {
                return e.Code
            });
            At(a.b, b, c, d)
        } else gt(c, "translate") && (Qp(a.g, "translate-text") || IM(a), c = Nb(DATA.SourceLanguageCodeNameList).map(function(e) {
            return e.Code
        }), d = Nb(DATA.TargetLanguageCodeNameList).map(function(e) {
            return e.Code
        }), zt(a.b, b, c, d), dw(a.a.a) && QK(a.a))
    },
    yM = function() {
        return Ee && DATA.InChina && "zh-CN" === DATA.DisplayLanguage && DATA.EnableChinaAndroidPromo
    };
HM.prototype.Ih = function(a) {
    this.R(a, "sl")
};
HM.prototype.Jh = function(a) {
    this.R(a, "tl")
};
HM.prototype.hm = function(a) {
    this.R(a, "sl")
};
HM.prototype.qm = function(a) {
    this.R(a, "tl")
};
var BM = function() {
        return !DATA.InChina && DATA.EnableGSAPureAd && qe() && re(9) && wd()
    },
    AM = function() {
        return !DATA.InChina && Ee && "en" == DATA.DisplayLanguage && !!DATA.Messages.TRANSLATE_PURE_AD_TEXT_SPEAK && !!DATA.Messages.TRANSLATE_PURE_AD_TEXT_READ
    };
HM.prototype.Gj = function(a) {
    a: {
        var b = this.a.O.a;
        if ("ltr" == a) var c = "left";
        else if ("rtl" == a) c = "right";
        else break a;cq(b.j(), "direction", a);cq(b.j(), "text-align", c)
    }
};
var KM = function(a) {
    a.preventDefault()
};
HM.prototype.Fj = function() {
    var a = this.ea.a,
        b = this.ea.b;
    this.K.c = a;
    this.K.g = b;
    var c = this.gb;
    tH(c, c.a, a);
    c = this.gb;
    tH(c, c.b, b);
    this.na(!1, "ls");
    kt() && IK(this.a);
    this.X && BH(this.X, a, b)
};
HM.prototype.pm = function() {
    for (var a = this.ea.b, b = ba(this.h.a), c = b.next(); !c.done; c = b.next()) xL(c.value, a)
};
HM.prototype.j = function() {
    return this.v
};
var VM = function() {
        return Qp(document.body, "displaying-saved-page")
    },
    TM = function() {
        return Qp(document.body, "displaying-instant-page")
    },
    RM = function() {
        return Qp(document.body, "displaying-history-page")
    };
HM.prototype.La = function() {
    rI();
    var a = B("tlid-share-panel", this.v);
    a && U(a, "show-share-panel");
    U(document.body, "with-lang-list");
    U(document.body, "with-sl-list");
    U(document.body, "with-tl-list");
    if (!Qp(document.body, "displaying-homepage")) {
        a = VM();
        this.xa = "closed";
        T(document.body, "displaying-homepage");
        U(document.body, "displaying-history-page");
        U(document.body, "displaying-saved-page");
        U(document.body, "displaying-instant-page");
        var b = Bt(this.b);
        bt(b, "home");
        this.b.a(b.toString(), !0);
        b = this.F;
        M(b, N(b, 216));
        oI("show", "homepage", "", "", "");
        a && (a = this.F, M(a, N(a, 41)))
    }
};
HM.prototype.Qk = function() {
    if (RM()) {
        var a = this.O;
        a.a && QI(a.a);
        this.La()
    } else a = Bt(this.b), this.ia = a.toString(), bt(a, "history"), this.b.a(a.toString(), !0), SM(this)
};
var SM = function(a) {
    a.xa = "history";
    U(document.body, "displaying-homepage");
    T(document.body, "displaying-history-page");
    U(document.body, "displaying-saved-page");
    U(document.body, "displaying-instant-page");
    hK(a.O);
    oI("show", "history", "", "", "");
    a = a.F;
    M(a, N(a, 60))
};
HM.prototype.Xk = function() {
    if (this.Fa)
        if (TM()) {
            XM(this);
            this.La();
            var a = this.F;
            M(a, N(a, 371))
        } else a = Bt(this.b), this.ia = a.toString(), bt(a, "instant"), this.b.a(a.toString(), !0), UM(this)
};
HM.prototype.Nm = function() {
    if (DATA.EnableCommunityInstantNotifications) {
        var a = C("tlid-community-button", this.v);
        T(a, "available")
    }
};
var XM = function(a) {
    DATA.EnableCommunityInstantNotifications && (a = C("tlid-community-button", a.v), U(a, "available"))
};
HM.prototype.Zj = function() {
    var a = this.F;
    M(a, N(a, 370));
    XM(this);
    this.La()
};
var UM = function(a) {
    if (a.Fa && null != window.gapi && null != window.gapi.iframes) {
        a.xa = "instant";
        U(document.body, "displaying-homepage");
        U(document.body, "displaying-history-page");
        U(document.body, "displaying-saved-page");
        T(document.body, "displaying-instant-page");
        var b = a.Fa;
        null != b.a && b.c && (b.c = !1, b.a.send("restartInstant", {
            source: b.h,
            target: b.o
        }, void 0, b.b));
        oI("show", "instant", "", "", "");
        a = a.F;
        M(a, N(a, 361))
    }
};
HM.prototype.R = function(a, b) {
    var c = this;
    if (Qp(document.body, "with-lang-list")) this.Z(a);
    else {
        if (null == b) throw Error("No language picker class to show provided");
        VM() && this.c && (SJ(this.c), this.La());
        "sl" === b ? (E(this.Mh, DATA.Messages.TRANSLATE_FROM), this.a.b.setVisible(!0), this.a.g.setVisible(!1), MB(this.a.b), T(document.body, "with-sl-list")) : "tl" === b && (E(this.Mh, DATA.Messages.TRANSLATE_TO), this.a.b.setVisible(!1), this.a.g.setVisible(!0), MB(this.a.g), T(document.body, "with-tl-list"));
        T(document.body,
            "with-lang-list");
        Ci(function() {
            kt() && ("sl" === b ? RB(c.a.b) : "tl" === b && RB(c.a.g))
        }, 0);
        n.scrollTo(0, 0);
        a = B("language-list-unfiltered-langs-" + b + "_list");
        null != a && (a.scrollTop = 0)
    }
};
HM.prototype.Z = function(a) {
    "click" == a.type && a.defaultPrevented || !Qp(document.body, "with-lang-list") || (this.a.b.setVisible(!1), this.a.g.setVisible(!1), this.La(), kt() && IK(this.a))
};
HM.prototype.ln = function() {
    this.a.b.isVisible() && QB(this.a.b);
    this.a.g.isVisible() && QB(this.a.g)
};
HM.prototype.dm = function() {
    if (VM() && null != this.c) SJ(this.c), this.La();
    else {
        var a = Bt(this.b);
        this.ia = a.toString();
        bt(a, "saved");
        this.b.a(a.toString(), !0);
        WM(this)
    }
};
var WM = function(a) {
    DATA.InChina || uI("lnk", a.w, a.Ko.bind(a), a.b.a.bind(a.b, a.ia, !0), Bt(a.b).toString())
};
HM.prototype.Ko = function() {
    oI("show", "starred", "", "", "");
    var a = this.F;
    M(a, N(a, 40));
    this.xa = "saved";
    U(document.body, "displaying-homepage");
    U(document.body, "displaying-history-page");
    T(document.body, "displaying-saved-page");
    U(document.body, "displaying-instant-page");
    this.c || YM(this)
};
var YM = function(a) {
    var b = C("tlid-phrasebook-outer-wrap", a.v),
        c = Xp(WJ, {
            Ra: DATA.DisplayLanguage,
            Qa: DATA.Messages
        });
    b.appendChild(c);
    a.c = new NJ(c, a.ab);
    G(a.c, "close_requested", function() {
        SJ(a.c);
        a.La()
    }, !1);
    G(a.c, "phrasebook_entry_selected", function(d) {
        Qp(a.g, "translate-text") || IM(a);
        yt(a, d.hb, d.ib, d.text)
    }, !1);
    G(a.c, "interaction_with_disabled_voice_output", function(d) {
        VL(a.N, a.wb.a(DATA.Messages.VOICE_OUTPUT_UNAVAILABLE, d.Nb))
    }, !1, a);
    a.bc && eJ(a.c.a, a.bc)
};
HM.prototype.Ca = function() {
    var a = {
            productId: "101820",
            locale: DATA.DisplayLanguage,
            version: DATA.VersionLabel
        },
        b = {};
    0 < EXPERIMENT_IDS.length && (b.EXP = EXPERIMENT_IDS.join(","));
    b.SOURCE_LANGUAGE = this.ea.a;
    b.TARGET_LANGUAGE = this.ea.b;
    b.PANEL_STATE = this.xa;
    window.JS_ERR_COUNT && (b.JS_ERR_COUNT = window.JS_ERR_COUNT, b.JS_ERR_ARR = window.JS_ERR_ARR);
    this.g.scrollIntoView(!0);
    jM(a, b);
    oI("show", "feedback", "", "", "")
};
var QM = function(a) {
    var b = Xp(xK, {
        Ra: DATA.DisplayLanguage,
        Sk: DATA.FileTranslationPath,
        Qa: DATA.Messages
    });
    C("tlid-select-file-page-container", a.g).appendChild(b);
    a.xb = new $J(b, a.ea);
    G(a.xb, "file_too_big", function(c) {
        VL(a.N, a.wb.a(DATA.Messages.FILE_TOO_BIG_PARAMETERIZED, (c.Rk / 1024 / 1024).toFixed()))
    }, !1);
    G(a.xb, "unsupported_filetype", function() {
        var c = a.N,
            d = DATA.Messages.CANT_READ_FILE,
            e = DATA.Messages.LEARN_MORE;
        T(c.v, "with-action");
        U(c.v, "with-message");
        E(c.h, d);
        E(c.o, e);
        c.b.removeAttribute("href");
        c.a =
            "unsupported_filetype_learn_more_clicked";
        UL(c)
    }, !1)
};
HM.prototype.Lo = function() {
    var a = this.a;
    if (DATA.UrlTranslation) {
        var b = B("source-wrap", a.v);
        W(b, !1);
        W(a.X.j(), !0)
    }
};
var ZM = function(a) {
    var b = [];
    if (qo && yI(a)) b = [{
        trans: AI(a).map(function(g) {
            return g.tb()
        }).join("\n"),
        orig: I(a.cb(0), 1),
        translit: "",
        src_translit: I(a.cb(0), 3)
    }];
    else
        for (var c = 0; c < a.jc(); c++) {
            var d = {
                trans: a.cb(c).Tc(),
                orig: I(a.cb(c), 1),
                translit: I(a.cb(c), 2),
                src_translit: I(a.cb(c), 3)
            };
            b[c] = d
        }
    d = [];
    for (c = 0; c < H(a, 1); c++) {
        for (var e = [], f = 0; f < H(Dh(a, c), 1); f++) e[f] = Ro(Dh(a, c), f);
        e = {
            pos: I(Dh(a, c), 0),
            terms: e
        };
        d[c] = e
    }
    return {
        sentences: b,
        src: I(a, 2),
        dict: d
    }
};
HM.prototype.Pj = function(a, b, c, d, e) {
    this.V.setVisible(!1);
    this.je = {};
    var f = ZM(e);
    if (this.m) {
        var g = this.m.w,
            k = this.m.Pa(),
            l = this.m.ma(),
            m = this.m.a;
        k === b && l === c && vc(d, m) || OM(this, m, g, k, l);
        k === b && l === c && vc(m, d) || (this.m = new MF(d, f, b, c))
    } else this.m = new MF(d, f, b, c);
    a || (OM(this, d, f, b, c), this.m = new MF(d, f, b, c));
    Eh(e, 7) && (a = I(np(e), 1), g = Fl(np(e), 5), this.V.show({
        rk: I(np(e), 0),
        ve: a,
        ci: g,
        $i: dw(this.a.a),
        sg: Array.from(Gl(np(e), 2).slice().values()),
        kj: this.ea.a,
        result: e
    }), this.V.C = !0);
    "auto" == this.ea.a && lw(this.ea,
        I(e, 2));
    a = this.ea;
    nw(a.a, a.o);
    nw(a.b, a.m);
    new Yo(e.Wa[8]);
    a = [];
    for (g = 0; g < H(new Yo(e.Wa[8]), 0); ++g) k = new Yo(e.Wa[8]), k = Gh(k, 0, g), a.push(k);
    hw(this.ea, a);
    a = this.ea;
    g = "auto" == a.a ? "" : a.a;
    k = tw(a.o, g);
    k.push(a.a);
    a.W = xb(k);
    k = k.concat(tw(a.L.a, g));
    a.ia.update(k);
    a = this.ea;
    g = tw(a.m, a.b);
    g.push(a.b);
    a.X.update(g);
    T(document.body, "show-result");
    this.a.update(d, e, this.V.b);
    cv(e);
    this.h.update(d, f, b, c, e);
    y && IK(this.a);
    b = HL(this.h);
    this.Rh ? (this.Rh = !1, vG(this.ab, b, 0)) : MM(this);
    !this.W && B("tlid-debug-information",
        document.body) && (this.W = new XJ);
    if (this.W && (b = this.W, YJ(b), b.w && b.a && b.c && b.b && b.o && b.g && b.m && b.h && b.L && b.G && b.C)) {
        f = [];
        a = Kf("backend-models-used");
        g = Kf("backend-models-checksum");
        k = Kf("backend-models-launch-doc");
        if (e.cb(0))
            for (l = 0; l < e.jc(); l++) {
                m = e.cb(l);
                Eh(m, 0) && m.Tc() && f.push(m.mf());
                if (0 < H(m, 5)) {
                    for (var q = 0; q < H(m, 5); q++) ZJ(a, "https://cnsviewer.corp.google.com" + Gh(m, 5, q), Gh(m, 5, q));
                    a.appendChild($f("br"))
                }
                if (0 < H(m, 8)) {
                    for (q = 0; q < H(m, 8); q++) {
                        var r = new Vl((new Xl(Hl(m, 8, q))).Wa[0]);
                        ZJ(g, "http://go/bleu-eval-dashboard?fb=Checksum:in:" +
                            I(r, 0), I(r, 0));
                        "" != I(r, 1) && "TODO" != I(r, 1) ? ZJ(k, "https://g3doc.corp.google.com/nlp/nmt/models/g3doc/" + I(r, 1), I(r, 1)) : ZJ(k, "http://go/no-launch-doc-doc", "Temp_Doc")
                    }
                    g.appendChild($f("br"));
                    k.appendChild($f("br"))
                }
            }
        for (r = q = m = l = k = g = a = 0; r < f.length; r++) 0 === f[r] ? a++ : 3 === f[r] ? g++ : 4 === f[r] ? k++ : 1 === f[r] ? l++ : 2 === f[r] ? m++ : 10 === f[r] && q++;
        f = a + g;
        r = l + m;
        E(b.o, a.toString());
        E(b.g, g.toString());
        E(b.m, k.toString());
        E(b.b, f.toString());
        E(b.a, l.toString());
        E(b.c, m.toString());
        E(b.w, r.toString());
        E(b.h, q.toString())
    }
    b =
        this.G;
    f = I(e, 2);
    b.g.reset();
    b.g.push(d, f, c, e);
    this.Ve = Uf(document).a;
    d = ba(this.Ob);
    for (b = d.next(); !b.done; b = d.next()) b.value.Ia();
    this.Ob = [];
    this.Ob.push(new lA(this.a.a.j(), "orig", 13, "webapp"));
    $M(this, this.md);
    $M(this, this.Id);
    $M(this, this.nd);
    (d = B("show-panel", this.v)) && U(d, "show-panel");
    RA(this.L, !1);
    this.X && BH(this.X, I(e, 2), c)
};
var MM = function(a) {
        var b = HL(a.h);
        yG(a.ab, b, function(c) {
            NL(a.h, b, c);
            null != a.c ? c ? eJ(a.c.a, b) : rJ(a.c.a) : c && (a.bc = b)
        })
    },
    OM = function(a, b, c, d, e) {
        var f = a.O;
        if (null == f.a) {
            var g = new MF(b, c, d, e);
            f.c.push(g)
        } else f.a && (g = new MF(b, c, d, e), f = f.a, KI(f, g), V(f.v, "empty", !1), LI(f, f.a.length));
        a.Wj(b, c, d, e)
    };
HM.prototype.Bm = function(a) {
    var b = this.h;
    a = 413 == a ? MSG_REQUEST_TOO_BIG : MSG_TRANSLATION_ERROR;
    T(b.b, "empty");
    T(b.b, "result-error");
    U(b.b, "translating");
    E(b.K, a);
    E(b.L, a);
    W(b.h, !0);
    W(b.g, !1)
};
var yt = function(a, b, c, d, e) {
    null != e && wl(a.K, e);
    a.a.a.b(d);
    if (b) {
        var f = void 0;
        "tws_lsugg" == e && (f = 3);
        a.ea.g(b, f);
        a.K.c = b;
        f = a.gb;
        tH(f, f.a, b)
    }
    c && ("auto" !== c && a.ea.h(c), c = a.ea.b, a.K.g = c, b = a.gb, tH(b, b.b, c));
    c = a.a.O;
    b = a.ea.a;
    f = a.ea.b;
    c.h = GD(d);
    c.b = b;
    c.c = f;
    xD(c);
    e && Nm(a.w, "source", e);
    a.na(!1, e)
};
HM.prototype.gk = function(a) {
    null != this.c && MJ(this.c, a);
    a = this.O;
    null == a.a ? a.g = !0 : a.a && SI(a.a)
};
HM.prototype.Oj = function(a, b) {
    NL(this.h, a, b);
    var c = this.O;
    if (null != c.a && c.a) {
        c = c.a;
        for (var d = 0; d < c.a.length; d++) {
            var e = c.a[d];
            QF(e.a, a) && e.jh(b)
        }
    }
    if (null != this.c)
        if (b) b = this.c.a, c = TF(a), b.a.push(c), qJ(b, c) && b.h.push(c), gJ(b, b.N), cJ(b, NF(c), c.ma()), 1 === b.a.length && b.dispatchEvent("list_no_longer_empty"), this.h.a[0] && QF(HL(this.h), a) && eJ(this.c.a, a);
        else {
            b = this.c.a;
            d = !1;
            for (c = b.a.length - 1; 0 <= c; c--)
                if (e = b.a[c], QF(e, a)) {
                    d = oJ(e);
                    e = b.O[d];
                    b.b === e && (b.b = null);
                    qh(e);
                    delete b.O[d];
                    b.a.splice(c, 1);
                    d = !0;
                    e = b;
                    var f = NF(a),
                        g = a.ma(),
                        k = f + "|" + g,
                        l = e.m.get(k);
                    l && (1 === l ? (e.m.delete(k), e.dispatchEvent({
                        type: "language_pair_removed",
                        hb: f,
                        ib: g
                    })) : e.m.set(k, l - 1))
                } d && (b.L || (b.w && null != b.c && null != b.g ? iJ(b, b.c, b.g) : b.G ? hJ(b, b.C) : (a = b.o, 0 < b.o && b.o + 1 > lJ(b) && (a = b.o - 1), dJ(b, a))), 0 === kJ(b).length && b.dispatchEvent("last_displayed_entry_deleted"), 0 === b.a.length && (b.dispatchEvent("list_empty"), b.L && (b.b = null, dJ(b, 0), b.dispatchEvent("delete_all_complete"), b.L = !1)))
        }
    else b && (this.bc = a)
};
HM.prototype.Qj = function() {
    var a = this;
    Ci(function() {
        return aN(a)
    }, 0)
};
var aN = function(a) {
        var b = dw(a.a.a),
            c = a.ea.a,
            d = a.ea.b;
        if (av(b)) {
            var e = new Rm(n.location.href.split("#")[0]);
            Vm(e, "translate");
            hn(e, "sl", [c ? c : "auto"]);
            hn(e, "tl", [d]);
            hn(e, "u", [b]);
            Zd(e.toString())
        } else Nm(a.w, "source", "btn"), wl(a.K, "btn"), a.na(!1), Ci(function() {
            xD(a.a.O)
        }, 0), n.scrollTo(0, 0), DATA.EnableSearchTooltip && a.Sm && OL(a.h)
    },
    GM = function(a) {
        var b = a.ea.a,
            c = a.ea.b;
        U(document.body, "show-result");
        a.V.show({
            ve: ""
        });
        a.G.update("", b, c, new lp);
        hw(a.ea, null);
        a.a.update("", new lp, !1);
        b = a.h;
        KL(b, !1);
        ML(b,
            !0);
        GL(b);
        a.W && YJ(a.W)
    };
HM.prototype.Qh = function() {
    null != this.c && rJ(this.c.a);
    GM(this)
};
HM.prototype.na = function(a, b) {
    this.Tn.reset(a);
    var c = dw(this.a.a),
        d = xc(ke(c));
    this.K.G = c.substring(0, 64);
    this.K.a = null;
    var e = this.ea.a,
        f = this.ea.b;
    !kt() && a || "bh" === b || d && "ls" !== b || Dt(this.b, e, f, c, a);
    if (d) this.Qh();
    else if (YA(this.L), d = new Zm(Qm(this.w)), d.g(new Zm(bv())), d.add("kc", ew(this.a.a)), RA(this.L, !0), JL(this.h, 1), Am(this.F), b = "tws_revert" !== b, wp(this.jd, e, f, DATA.DisplayLanguage, c, p(this.Pj, this, a, e, f, c), b, void 0, d, p(this.Bm, this)), a = !1, PM(this, c) ? (NM(this), a = !0) : c.length >= this.o.length &&
        (a = !0), a && (this.o = c, this.We = e, this.pd = f), DATA.CompareProdTrans) {
        a = Xm(d);
        a.add("internal", 1);
        a.add("expflags", "NMT__enable_nmt_level:0");
        d = new qp("webapp", "https://translate.google.com");
        var g = this.ie;
        wp(d, e, f, DATA.DisplayLanguage, c, function(k) {
            fg(g);
            W(g, !!k);
            if (k) {
                for (var l = [], m = 0; m < k.jc(); m++) l.push(k.cb(m).Tc());
                E(g, l.join(""))
            }
        }, !0, void 0, a)
    }
};
HM.prototype.Fo = function(a) {
    if (a && a.data && 0 < a.data.length) {
        a = a.data[0];
        var b = wI(a);
        if (b) {
            this.K.o = a;
            var c = this.gb;
            tH(c, c.a, a);
            this.V.show({
                ve: b,
                vh: a,
                $i: dw(this.a.a),
                kj: this.ea.a
            })
        }
    }
};
var DM = function(a, b, c, d, e, f, g, k) {
    var l = C(b, a.v);
    b = C("tlid-dismiss-promo", l);
    var m = C("tlid-accept-promo", l);
    d = "/translate/uc?ua=dismiss&uav=" + d;
    n.setTimeout(function() {
        T(l, "show-panel")
    }, 400);
    O(mI, "webapp", c, "show");
    sm(a.F, e);
    f();
    G(b, "click", p(a.ak, a, l, d, c, e, g), !1, a);
    G(m, "click", p(a.$j, a, l, d, c, e, k), !1, a)
};
HM.prototype.$j = function(a, b, c, d, e) {
    tm(this.F, d);
    U(a, "show-panel");
    Km(this.w, b);
    O(mI, "webapp", c, "accept");
    e()
};
HM.prototype.ak = function(a, b, c, d, e) {
    var f = this.F;
    M(f, rm(f, 74, d));
    U(a, "show-panel");
    Km(this.w, b);
    O(mI, "webapp", c, "dismiss");
    e()
};
HM.prototype.An = function(a) {
    Xd(n.location, a)
};
var CM = function(a, b, c) {
    DM(a, "at-promo", "atPromo", "at", c, Ea, Ea, p(a.An, a, b))
};
HM.prototype.bk = function() {
    Ch("gsa", "gsaAd:accept", "", 1);
    pI(void 0, 0)
};
HM.prototype.Nj = function() {
    bN(this, this.md);
    bN(this, this.Id);
    bN(this, this.nd);
    return !1
};
var bN = function(a, b) {
        var c = b.j();
        if (null != c) {
            var d = mq(c).a;
            c = d + vq(c).height;
            c > n.innerHeight + a.Ve && (cN(a, d, !0, b), cN(a, c, !1, b))
        }
    },
    cN = function(a, b, c, d) {
        var e = c ? "top" : "bot",
            f = d.Kb(),
            g = f + "_" + e,
            k = Uf(document).a;
        b > k && b < k + n.innerHeight && !a.je[g] && (a.je[g] = !0, a.w.log("card_scroll", {
            card: f,
            position: e
        }), a = a.F, b = d.Nd(), e = d.fb(), M(a, em(a, c ? 213 : 214, b, e, d.sc, 0)))
    },
    $M = function(a, b) {
        var c = b.j();
        c && a.Ob.push(new lA(c, b.Kb(), b.Nd(), "webapp"))
    };
HM.prototype.Jo = function(a) {
    var b = Kf("gt-ntfcn-msg");
    b && (b.textContent = a, this.Nh.setVisible(!0, 2E3))
};
HM.prototype.Rj = function() {
    dv(Bt(this.b).toString())
};
var EM = function(a) {
        var b = window.gapi;
        b && (b.load("iframes", function() {
            if (this.Fa && null != window.gapi && null != window.gapi.iframes) {
                var c = this.Fa;
                if (null != window.gapi && null != window.gapi.iframes && null == c.a && null != c.v) {
                    var d = B("tlid-community-instant-container", c.v);
                    if (null != d) {
                        var e = window.gapi.iframes,
                            f = new Rm;
                        f.b = "" === DATA.CommunityInstantHostname ? window.location.hostname : DATA.CommunityInstantHostname;
                        var g = DATA.InstantPrefetchSourceLanguage || "",
                            k = DATA.InstantPrefetchTargetLanguage || "";
                        Vm(f, "/instant/select_pair");
                        f.a.set("source", g);
                        f.a.set("target", k);
                        f.a.set("hl", DATA.DisplayLanguage);
                        f.a.set("origin", window.location.protocol + "//" + window.location.hostname);
                        f.a.set("parent", window.location.protocol + "//" + window.location.hostname);
                        c.a = e.getContext().openChild({
                            url: f.toString(),
                            where: d,
                            messageHandlers: {
                                closeInstant: c.w.bind(c),
                                notifyTasksAvailable: c.m.bind(c)
                            },
                            messageHandlersFilter: c.b
                        });
                        "" != g && "" != k && c.a.send("restartInstant", {
                            source: g,
                            target: k
                        }, void 0, c.b)
                    }
                }
                c = this.F;
                M(c, N(c, 372))
            }
            "instant" === Bt(this.b).b &&
                !TM() && UM(this)
        }.bind(a)), b.load("client", function() {
            var c = b.client,
                d = b.config;
            d.update("googleapis.config/auth/useFirstPartyAuth", !0);
            d.update("googleapis.config/auth/useFirstPartyAuthV2", !0);
            d.update("client/xd4", !0);
            c.setApiKey("AIzaSyA8PX4bTrtr1-DtDsGJSbTXQkfWbWkCjTM")
        }))
    },
    NM = function(a, b) {
        if ("" !== a.o) {
            var c = a.F,
                d = a.o,
                e = a.pd,
                f = a.kd,
                g = N(c, 246);
            e = A(g, 1, e);
            e = A(e, 74, d.length);
            d = A(e, 52, d.substring(0, 64));
            e = new Nk;
            f = A(e, 1, f);
            lf(d, 70, f);
            M(c, d);
            64 < a.o.length && (a.o = a.o.substr(0, 64));
            c = {
                sl: a.We,
                tl: a.pd,
                ql: a.o.length,
                q: a.o,
                pc: a.kd
            };
            b && (c[b] = 1);
            a.kd = a.le;
            a.le = 0;
            a.w.log("fq", c);
            a.o = ""
        }
    },
    PM = function(a, b) {
        return "" !== a.o && b[0] !== a.o[0] && b[b.length - 1] !== a.o[a.o.length - 1]
    },
    zM = function(a) {
        if (DATA.FeatureStickiness) {
            var b = JSON.parse(DATA.FeatureStickiness);
            null == b && (b = []);
            b = new hM(b);
            if (Eh(b, 2)) {
                a = a.Hj;
                b = new bM(b.Wa[2]);
                a.a = {};
                a.a["gt-input-tool"] = new hz;
                for (var c, d = 0; d < H(b, 3); ++d)
                    if (c = new YL(Hl(b, 3, d)), 0 == !!c.getState())
                        for (var e in a.a) a.a[e].update(I(c, 0), !1, "");
                a.c = {};
                for (d = 0; d < H(b, 1); ++d) c = new YL(Hl(b,
                    1, d)), a.c[I(c, 0)] = !!c.getState();
                a.b = {};
                for (d = 0; d < H(b, 2); ++d) c = new YL(Hl(b, 2, d)), a.b[I(c, 0)] = !!c.getState();
                for (d = 0; d < H(b, 9); ++d) e = new $L(Hl(b, 9, d)), (Eh(e, 3) ? lz(a, I(e, 3), !0) : lz(a, "gt-input-tool", !0)).update(I(e, 0), e.getState(), I(e, 2))
            }
        }
    };
var dN = {},
    eN = null,
    fN = function(a, b, c) {
        if (a = dN[c]) "history" == a.o ? (b = a.c, M(b, Dm(b, 61, mL(a), null != a.b && a.b.b))) : "saved" == a.o && (mI.log("sli=sl", {}), b = a.c, M(b, Fm(b, 48))), a.dispatchEvent({
            type: "translate_requested",
            hb: a.a.Pa(),
            ib: a.a.ma(),
            text: a.a.a
        }), oI("populate", c, a.a.Pa(), a.a.ma(), a.a.a)
    },
    gN = aB("translate");
var Fy = null,
    hN = null,
    uM = DATA.MaybeDefaultSourceLanguageCode || "auto",
    vM = DATA.MaybeDefaultTargetLanguageCode,
    jN = function() {
        var a = new ji(function(c) {
                KF(function() {
                    c()
                })
            }),
            b = new ji(function(c) {
                Ly(function(d, e) {
                    d ? (Fy = e, iN(c)) : c()
                })
            });
        pi([b, a])
    },
    iN = function(a) {
        Jy(Fy.a, null, null, null, 100, function(b, c) {
            if (b) {
                b = [];
                for (var d = c.length - 1; 0 <= d; d--) {
                    var e = c[d],
                        f = e.sl,
                        g = e.tl,
                        k = e.src;
                    e = e.trg;
                    0 == d && (uM = f, vM = g);
                    b.push({
                        sl: f,
                        tl: g,
                        orig: k,
                        result: e
                    })
                }
                c = hN.O;
                d = [];
                for (f = 0; f < b.length; f++) g = b[f], d.push(new MF(g.orig, g.result,
                    g.sl, g.tl));
                c.a ? MI(c.a, d) : c.c = d
            }
            a()
        })
    },
    wM = function(a, b, c, d) {
        Fy && Hy(c, d, a, b)
    },
    xM = function() {
        Fy && Gy(Fy.a, void 0, void 0, void 0, void 0)
    };
ya("init", function() {
    var a = new sH;
    tH(a, a.c, DATA.DisplayLanguage);
    tH(a, a.a, uM);
    tH(a, a.b, vM);
    var b = $f("INPUT");
    b.id = "history-input";
    W(b, !1);
    var c = $f("IFRAME");
    c.id = "history-frame";
    c.src = "about:blank";
    W(c, !1);
    document.body.appendChild(b);
    document.body.appendChild(c);
    b = new xt(!0, b, c);
    hN = new HM(a, b);
    document.body.appendChild(hN.j());
    eN || (eN = new pB(null, "TranslationItem"), rB(eN, gN, fN), qB.a.push(eN));
    CB || (CB = new pB(null, "LanguageListItem"), rB(CB, wB, BB), rB(CB, DB, JB), qB.a.push(CB));
    window.location.hash.substr(1) &&
        LM(hN, window.location.hash.substr(1));
    b.b.oa(!0);
    jN();
    DATA.UserInputQuery && yt(hN, uM, vM, DATA.UserInputQuery)
});
if (window.jstiming) {
    window.jstiming.pe = {};
    window.jstiming.oh = 1;
    var kN = function(a, b, c) {
            var d = a.t[b],
                e = a.t.start;
            if (d && (e || c)) return d = a.t[b][0], void 0 != c ? e = c : e = e[0], Math.round(d - e)
        },
        lN = function(a, b, c) {
            var d = "";
            window.jstiming.srt && (d += "&srt=" + window.jstiming.srt, delete window.jstiming.srt);
            window.jstiming.pt && (d += "&tbsrt=" + window.jstiming.pt, delete window.jstiming.pt);
            try {
                window.external && window.external.tran ? d += "&tran=" + window.external.tran : window.gtbExternal && window.gtbExternal.tran ? d += "&tran=" +
                    window.gtbExternal.tran() : window.chrome && window.chrome.csi && (d += "&tran=" + window.chrome.csi().tran)
            } catch (r) {}
            var e = window.chrome;
            if (e && (e = e.loadTimes)) {
                e().wasFetchedViaSpdy && (d += "&p=s");
                if (e().wasNpnNegotiated) {
                    d += "&npn=1";
                    var f = e().npnNegotiatedProtocol;
                    f && (d += "&npnv=" + (encodeURIComponent || escape)(f))
                }
                e().wasAlternateProtocolAvailable && (d += "&apa=1")
            }
            var g = a.t,
                k = g.start;
            e = [];
            f = [];
            for (var l in g)
                if ("start" != l && 0 != l.indexOf("_")) {
                    var m = g[l][1];
                    m ? g[m] && f.push(l + "." + kN(a, l, g[m][0])) : k && e.push(l + "." +
                        kN(a, l))
                } delete g.start;
            if (b)
                for (var q in b) d += "&" + q + "=" + b[q];
            (b = c) || (b = "https:" == document.location.protocol ? "https://csi.gstatic.com/csi" : "http://csi.gstatic.com/csi");
            return [b, "?v=3", "&s=" + (window.jstiming.sn || "translate_mobileweb") + "&action=", a.name, f.length ? "&it=" + f.join(",") : "", d, "&rt=", e.join(",")].join("")
        },
        mN = function(a, b, c) {
            a = lN(a, b, c);
            if (!a) return "";
            b = new Image;
            var d = window.jstiming.oh++;
            window.jstiming.pe[d] = b;
            b.onload = b.onerror = function() {
                window.jstiming && delete window.jstiming.pe[d]
            };
            b.src = a;
            b = null;
            return a
        };
    window.jstiming.report = function(a, b, c) {
        var d = document.visibilityState,
            e = "visibilitychange";
        d || (d = document.webkitVisibilityState, e = "webkitvisibilitychange");
        if ("prerender" == d) {
            var f = !1,
                g = function() {
                    if (!f) {
                        b ? b.prerender = "1" : b = {
                            prerender: "1"
                        };
                        if ("prerender" == (document.visibilityState || document.webkitVisibilityState)) var k = !1;
                        else mN(a, b, c), k = !0;
                        k && (f = !0, document.removeEventListener(e, g, !1))
                    }
                };
            document.addEventListener(e, g, !1);
            return ""
        }
        return mN(a, b, c)
    }
};