browser.menus.create({ // 컨텍스트 메뉴 생성
	id: 'translate',
	title: 'translate',
	contexts: ['selection']
})
browser.menus.create({
	id: 'notification',
	title: 'notification',
	contexts: ['all']
})
browser.menus.create({
	id: 'test',
	title: 'test',
	contexts: ['all']
})
browser.menus.create({
	id: 'version',
	title: 'version',
	contexts: ['all']
})

browser.menus.onClicked.addListener((info, tab) => { // 컨텍스트 메뉴 동작
	// console.log(info)
	// console.log(tab)
	// console.log(info.selectionText)
	// console.log(tab.id)
	if (info.menuItemId === 'translate') {
		sendMessageTab('translate')
	} else if (info.menuItemId === 'notification') {
		let tmp1 = ''
		for (let i1 = 1; i1 <= 20; i1++) {
			let tmp2 = ''
			for (let i2 = 0; i2 < 10 - String(i1).length; i2++) {
				tmp2 += 'a'
			}
			tmp1 += tmp2 + i1
		}
		browser.notifications.create(
			'notification id1',
			{
				type: 'basic',
				title: tmp1,
				message: tmp1 // 최대 200char
			}
		)
	} else if (info.menuItemId === 'test') {
		if (!eu) {
			tkkRequest()
			let count = 20
			let interval = setInterval(() => {
				if (eu && count) {
					clearInterval(interval)
					transalteRequest(info.selectionText)
				}
				count--
			}, 200)
		} else {
			transalteRequest(info.selectionText)
		}
	} else if (info.menuItemId === 'version') {
		let version = 'v20200212'
		browser.tabs.executeScript({ code: `alert('${version}')` })
	}
})

async function sendMessageTab (string) { // 활성 탭으로 메시지
	let activeTabArray = await browser.tabs.query({
		active: true, currentWindow: true
	})
	let tabId = activeTabArray[0].id

	await browser.tabs.sendMessage(tabId, [string, 0])
}

function tkkRequest () {
	let xhr = new XMLHttpRequest()
	xhr.onreadystatechange = () => {
		if (xhr.readyState === 4 && xhr.status === 200) {
			// tkk:'439260.900540207'
			eu = /\d+\.\d+/.exec(/tkk:'\d+\.\d+'/.exec(xhr.responseText)[0])[0]
		}
	}
	xhr.open('GET', 'https://translate.google.com/', true)
	xhr.send()
	// xhr.onloadend = () => {
	// 	browser.notifications.create(
	// 		'notification id1',
	// 		{
	// 			type: 'basic',
	// 			title: 'tkk',
	// 			message: eu || 'wait'
	// 		}
	// 	)
	// }
}

function transalteRequest (request) {
	console.log(request)
	console.log(encodeURIComponent(request))
	let response = ''
	let message = ''
	let xhr = new XMLHttpRequest()
	xhr.onreadystatechange = () => {
		if (xhr.readyState === 4) {
			if (xhr.status === 200) {
				response = xhr.responseText
				message = response
				console.log(response)
				console.log(JSON.parse(response))
			} else {
				message = 'error'
			}
		}
	}
	xhr.open('POST', `https://translate.google.com/translate_a/single?client=webapp&sl=auto&tl=ko&hl=ko&dt=at&dt=bd&dt=ex&dt=ld&dt=md&dt=qca&dt=rw&dt=rm&dt=ss&dt=t&otf=1&ssel=0&tsel=0&kc=1&tk=${fu(request)}`, true)
	xhr.setRequestHeader(requestHeader[0], requestHeader[1])
	xhr.send(`q=${encodeURIComponent(request)}`)
	xhr.onloadend = () => {
		browser.notifications.create(
			'notification id1',
			{
				type: 'basic',
				title: 'translate',
				message: message
			}
		)
	}
}
